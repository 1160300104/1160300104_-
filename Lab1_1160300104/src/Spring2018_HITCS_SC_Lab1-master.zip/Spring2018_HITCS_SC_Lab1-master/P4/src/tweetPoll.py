[
    {
        "created_at": "Mon Feb 12 03:41:30 +0000 2018",
        "id": 962894403256901632,
        "text": "RT @JonAcuff: Dear Olympics commentators, at the beginning of each figure skating couple please let us know if the couple loves each other\u2026",
        "user.screen_name": "h0llaJess"
    },
    {
        "created_at": "Mon Feb 12 03:41:30 +0000 2018",
        "id": 962894403210809349,
        "text": "RT @charliekirk11: South Korea only exists thanks to US troops sacrifice in the 1950\u2019s \n\n36,000 Americans died so South Korea could be free\u2026",
        "user.screen_name": "DCiszczon"
    },
    {
        "created_at": "Mon Feb 12 03:41:30 +0000 2018",
        "id": 962894402849927168,
        "text": "RT @JordanSchachtel: When u watch N Korean \"cheerleaders\" doing Olympics routine\n\nWhat you see is slavery in action \n\nThey r forced to prac\u2026",
        "user.screen_name": "goldwaterkid65"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894402648670213,
        "text": "I used to wonder what being an Olympian would be like, but I just heard that Julia Marino's favorite snack is dried\u2026 https://t.co/xPfu8WvBdo",
        "user.screen_name": "KaraGiacobazzi"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894402606661632,
        "text": "RT @bobby: normally i don't care about the events that are included in the olympics, but now? when the olympics are happening? well let's j\u2026",
        "user.screen_name": "HarshilShah1910"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894402573209600,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "DesotellRacing"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894401205780480,
        "text": "RT @kalynkahler: \"That was shiny, sparkling redemption.\" - @JohnnyGWeir \nMirai was eating In and Out with @Adaripp and watching the last Ol\u2026",
        "user.screen_name": "JKBartleby"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894401105100800,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "dar_vidder"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894401079934976,
        "text": "RT @94_degrees: Russian Figure Skater, Evgeniia Medvedeva who\u2019s an EXO-L set a new world record in the Pyeongchang Olympics &amp; mentioned EXO\u2026",
        "user.screen_name": "kyungmallows"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894400547360768,
        "text": "RT @peachyblackgorl: as the winter Olympics begin....never forget about Surya Bonaly, a French figure skater who did a backflip and landed\u2026",
        "user.screen_name": "braggs02"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894400274780160,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "kyahas"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894400073359360,
        "text": "RT @Devin_Heroux: This was Mark McMorris 11 months ago. \n\nHe\u2019s a bronze medallist at the #Olympics today. \n\nRemarkable. https://t.co/UnhBs9\u2026",
        "user.screen_name": "ashleyhines_"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894399394013185,
        "text": "RT @maybealexislost: RT if adam rippon just made you cry FAV if you\u2019re buying a bedazzler on ebay rn #olympics https://t.co/LzRkQEmzLj",
        "user.screen_name": "Sethersk82"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894399322632193,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "parker_jody"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894399125491721,
        "text": "the winter olympics are ass in comparison to the summer olympics",
        "user.screen_name": "DaniMartorella"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894399100342272,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "taryngraceee"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894398877925376,
        "text": "RT @EWTimStack: ANDREA #Olympics https://t.co/xbqm8FDt7u",
        "user.screen_name": "jman151"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894398806781952,
        "text": "RT @markfollman: My god, how does @NBC's Olympics coverage manage to suck so badly. Nothing shown live or when you want to see it, the endl\u2026",
        "user.screen_name": "rimarthag"
    },
    {
        "created_at": "Mon Feb 12 03:41:29 +0000 2018",
        "id": 962894398773235712,
        "text": "RT @TheRickyDavila: It says something when our amazing athletes can so easily represent the United States with class, grace, honor, dignity\u2026",
        "user.screen_name": "Piatfernandez"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894398592815104,
        "text": "RT @LynnRutherford: Mixed zone: \"I landed triple axel at the Olympics. That's historical and no one can take it away from me.\" #Pyeongchang\u2026",
        "user.screen_name": "quadlutzes"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894398580195328,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "LanaDelRae__"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894398357950465,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "fvnnyboo"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894398093713408,
        "text": "RT @ThatBoysGood: The Winter Olympics are like hockey and soccer if hockey and soccer fans didn\u2019t try to convince you they\u2019re fun. Ok wait,\u2026",
        "user.screen_name": "CoachBourbonUSA"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894398055907328,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "erikarunning"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894397758234625,
        "text": "RT @billboard: Olympic figure skater Adam Rippon on how Martin Garrix, Coldplay &amp; Queen helped him go for the gold https://t.co/omcLm2iLlr\u2026",
        "user.screen_name": "LadyGagaKids"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894397468823552,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "wizardjada"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894397024059392,
        "text": "RT @hnltraveler: NBC's Olympics Asian Analyst Joshua Cooper Ramo says having the next three Olympics in Korea, Japan and China is an \"oppor\u2026",
        "user.screen_name": "shutale_3981"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894396999065601,
        "text": "Planet Earth needs Bob Costas' pink eye back to make these olympics even palatable.",
        "user.screen_name": "mentallyunsable"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894396608958465,
        "text": "RT @MMFlint: I just loved the whole F-Trump opening to the Olympics last night. From all Koreans coming in together under one blue flag of\u2026",
        "user.screen_name": "rhonutau3"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894395803611136,
        "text": "Burned my tongue sipping hot chocolate while doing my taxes and trying to keep my dog interested in a game of tug-o\u2026 https://t.co/Om8tXLJKFn",
        "user.screen_name": "carIisIe"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894395786846209,
        "text": "RT @dumbbeezie: I could do that. \n\n-Me watching people eating at the Olympics",
        "user.screen_name": "heyjude305"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894395765903365,
        "text": "RT @HRC: Anti-LGBTQ Mike Pence can't hide his hatred behind misleading tweets. As @HRC's @cmclymer said, \"He\u2019s a soft-spoken bigot. He does\u2026",
        "user.screen_name": "exoknowles"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894395396702208,
        "text": "RT @MichaelWosnick: Spirit of Canada.  Last year he almost died in a snowboarding accident. Now he's won bronze at the Olympics @cnnsport h\u2026",
        "user.screen_name": "DrPeterLang"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894394817789955,
        "text": "IOC President Bach should take responsibility for this political exploitation of the Olympics. https://t.co/HD9tIpjzcn",
        "user.screen_name": "cooler_cucumber"
    },
    {
        "created_at": "Mon Feb 12 03:41:28 +0000 2018",
        "id": 962894394511650816,
        "text": "RT @HarlanCoben: Me: I\u2019ve never watched luge. I know nothing about it. \n\nMe 20 minutes later: Turns 9 through 12 are really the key to vict\u2026",
        "user.screen_name": "lavishhog"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894392884449280,
        "text": "#Olympics #FigureSkating Cappellini was so excited with that beautiful performance she almost knocked Lanotte over\u2026 https://t.co/mONXRaMVZ7",
        "user.screen_name": "JKMemeQueen"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894392699772928,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "ashbetkouchar"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894392616013825,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Jesskreegs"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894392427134976,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "_A2GH_"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894392276107264,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "ElwerLauren"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894392007839744,
        "text": "RT @judah_robinson: Here's the story of the last time #SouthKorea hosted the #Olympics -- and more importantly the chaos that surrounded th\u2026",
        "user.screen_name": "umesh5152"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894391995256832,
        "text": "RT @501stLegion: Members of the @AlpineGarrison in the winter Olympics spirit! #501st https://t.co/HlgygwY6L6",
        "user.screen_name": "derekester"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894391928152064,
        "text": "RT @NBCOlympics: A performance for the record books by Mirai Nagasu, complete with a celebration we'll remember for a long time. #BestOfUS\u2026",
        "user.screen_name": "jessaloliveira"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894391701467138,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "alexiswins12"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894391529570304,
        "text": "Watching team free dance #winter Olympics This Italian Team skating to the theme from the movie Life is Beautiful.\u2026 https://t.co/RWoQOUPclt",
        "user.screen_name": "fawn_Graham"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894390921519104,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "SimmonsREteam"
    },
    {
        "created_at": "Mon Feb 12 03:41:27 +0000 2018",
        "id": 962894390523031552,
        "text": "For this #Luge demonstration, @NBCOlympics used their patented \nBall-Cam\u2122 technology. \ud83d\udd35\ud83d\udd35\n#Olympics #PyeongChang2018\u2026 https://t.co/yzSfF2b2FA",
        "user.screen_name": "NormanCharles88"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894389738586114,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "adamricardo14"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894389419954176,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "axshup"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894389340180480,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "Lb28627987"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894389285662721,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "ssedloffthomas"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894389004656640,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "psychopappy1961"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894388824330241,
        "text": "Gonna join the Olympics to contract aids",
        "user.screen_name": "bradberryzone"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894388769812481,
        "text": "RT @peachyblackgorl: as the winter Olympics begin....never forget about Surya Bonaly, a French figure skater who did a backflip and landed\u2026",
        "user.screen_name": "brucejones105"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894388723638273,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Bianca8282"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894388673372160,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "CoachWertz12"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894388274913282,
        "text": "RT @TwitterMoments: Team USA figure skater @mirai_nagasu is the first American woman to land a triple axel at the Winter Olympics. #PyeongC\u2026",
        "user.screen_name": "CubbyPau"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894387909988352,
        "text": "Can I just permanently join figure skating Stan twt this is so less stressful than kpop twt and it\u2019s during the Olympics",
        "user.screen_name": "HanyvYuzuru"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894387742113792,
        "text": "Winter Olympics 2018: Samsung giveaway phone snub sparks Iran fury",
        "user.screen_name": "Paul_Banal"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894387574394880,
        "text": "RT @Lesdoggg: Um did Adam need to fall to his routine wtf?! Very confused right now. @NBCOlympics @Olympics https://t.co/KGiGW4OUrs",
        "user.screen_name": "Cartoonfreak1"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894387519918080,
        "text": "@NoelleGodfather LOL, the machines are taking over the Olympics!",
        "user.screen_name": "francium11"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894387322802176,
        "text": "RT @rodger_sherman: The Olympics are a reminder that in spite of our differences, every country has super-hot people",
        "user.screen_name": "TristynTucker3"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894387138256899,
        "text": "I also got emotional for that performance. #Olympics",
        "user.screen_name": "AnnaRMercier"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894387071143941,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "1nomdeplume"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894386970284032,
        "text": "RT @oniontaker: SNSD Gee dance competition at the Olympics on the big screen! 9 years and still iconic.\n\nDo not ask how I got raw footage f\u2026",
        "user.screen_name": "chuti_petch"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894386962059264,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "LuchoLap"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894386639065088,
        "text": "RT @5RingsPodcast: 5 Rings Daily-PyeongChang 2018, Day 2 Curling Talk with Ben Massey and Our GSBWP Medals for Day 2\nhttps://t.co/4fykUsIEe\u2026",
        "user.screen_name": "KevLaramee"
    },
    {
        "created_at": "Mon Feb 12 03:41:26 +0000 2018",
        "id": 962894386202849281,
        "text": "RT @olympicchannel: That feeling when you land the first triple axel by a @TeamUSA woman at the #Olympics! \ud83e\udd29\ud83e\udd17 An incredible moment for @mir\u2026",
        "user.screen_name": "cargille5"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894385942880256,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "wolfsan11"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894385808470016,
        "text": "Since the winter Olympics are going on  just want to say my favorite figure skaters are Chazz Micheal Micheals and\u2026 https://t.co/NRFWlGEhgK",
        "user.screen_name": "Paaccoo24"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894385238237184,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Wanncook"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894385124859904,
        "text": "RT @u2gigs: The Mexican alpine skiers (yes you read that right) have amazing Dia de los Muertas themed outfits at these Olympics.",
        "user.screen_name": "juliomarmol"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894384822931457,
        "text": "\"I think this is irresponsible.\"\n\nThere are strong gusts of wind, but the #snowboard slopestyle continues. \n\nWatch\u2026 https://t.co/QbGz7WWdaL",
        "user.screen_name": "BBCSport"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894384768286721,
        "text": "RT @VP: What a special privilege &amp; honor for Karen and me to lead the U.S. delegation to the Olympics Opening Ceremony, to represent our GR\u2026",
        "user.screen_name": "morris0731"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894384030101506,
        "text": "RT @jdaniel4smom: Your children can create their own Olympic flame in a bottle! This is a fun STEM activity! https://t.co/DYyyRdomuX #STEM\u2026",
        "user.screen_name": "mishrendon"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894383984140288,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "AustinBurrowsX"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894383916908544,
        "text": "RT @peachyblackgorl: as the winter Olympics begin....never forget about Surya Bonaly, a French figure skater who did a backflip and landed\u2026",
        "user.screen_name": "whoelsebutrico"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894383640076289,
        "text": "They should stop referring to the previously banned athletes as #Russians. They are athletes of the Olympiad. Russi\u2026 https://t.co/pZLfqFLuPD",
        "user.screen_name": "mkwtsn"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894382792871937,
        "text": "RT @mishacollins: You have great taste in TV, @bradie_tennell! We're rooting for you to bring home the gold, of course... But if you bring\u2026",
        "user.screen_name": "AtomicNun"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894382100709377,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "TaePhoenix"
    },
    {
        "created_at": "Mon Feb 12 03:41:25 +0000 2018",
        "id": 962894382021017600,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "MaryGambetty"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894381098336256,
        "text": "Please tell me the guys have pads in their pants for when the girl stands on their leg, digging in their blade. Rig\u2026 https://t.co/ROPnRdncaW",
        "user.screen_name": "LisaJohnson"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894381056430081,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "3dancelover"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894381022724096,
        "text": "RT @JORDANBENNlNG: grown ass men be looking me dead in the eye and telling me that they couldve made it to the olympics when they were youn\u2026",
        "user.screen_name": "ninanovakk"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894381014573056,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "Gdf4r"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894380737671168,
        "text": "RT @NPRrussell: The first medals of the Pyeongchang Olympics are in the books. In the women\u2019s 7.5km + 7.5km skiathlon, Sweden's Charlotte K\u2026",
        "user.screen_name": "SPORTYNBICHT"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894380511170560,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "EEnebak"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894379542224897,
        "text": "RT @Swanny_06: I get too hype during the Olympics. I don\u2019t think you\u2019re supposed to be yelling during the figure skating",
        "user.screen_name": "OverRitz"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894379152232448,
        "text": "Day 284 of why I love Lego - the #biathlon is totally king and I've loved watching it this #olympics. Thanks, inter\u2026 https://t.co/Wv1CzGJJ1B",
        "user.screen_name": "FloorCharts"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894378879524865,
        "text": "RT @BTSFollowing: @Koreaboo Look at the kings getting all this media coverage and not even being at the olympics \n\n#BestFanArmy #BTSARMY #i\u2026",
        "user.screen_name": "Starberryvie"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894378632060928,
        "text": "NBC Olympics on Twitter https://t.co/YntqEDZRqa",
        "user.screen_name": "thewilliam"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894378590093312,
        "text": "My moms watching figure skating for the Winter Olympics and she said @EthanDolan and @GraysonDolan can do it better\ud83d\ude02",
        "user.screen_name": "AlexSandValero"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894378388852736,
        "text": "RT @TheRickyDavila: What can I say? Mirai Nagasu was effortlessly brilliant. So proud of her and proud that she\u2019s representing the USA. Go\u2026",
        "user.screen_name": "SharonGammell1"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894378372075520,
        "text": "RT @THV11: Mirai Nagasu is now the first American woman to land triple axel during Olympics figure skating! \n\nhttps://t.co/TrkyZy9stA\n\n#Oly\u2026",
        "user.screen_name": "MelindaKinnaird"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894378011373568,
        "text": "RT @adamconover: read this headline three times before i realized it\u2019s about the olympics and not a man who dates skeletons \ud83d\ude0d\u2620\ufe0f https://t.c\u2026",
        "user.screen_name": "meta_jeff"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894377914904576,
        "text": "3.40am and I\u2019m watching the Winter Olympics because as usual I can\u2019t sleep.",
        "user.screen_name": "archersfan2"
    },
    {
        "created_at": "Mon Feb 12 03:41:24 +0000 2018",
        "id": 962894377889693696,
        "text": "RT @MarkHarrisNYC: I finally feel represented at the Olympics. https://t.co/RUiylelbbD",
        "user.screen_name": "Linds_Zolna"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894377541660677,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Perspectvz"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894377465999361,
        "text": "RT @lolacoaster: olympics drinking game rules\nsomeone falls: do a shot\nsomeone cries when they get their score: do a shot\na koch industries\u2026",
        "user.screen_name": "cxmicsams"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894377248067585,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "butterfly4u4eva"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894377151426560,
        "text": "@Ray_Devlin @TIME The Olympics is during the summer break for soccer players, so they love the pre season competiti\u2026 https://t.co/hBI07eNXcz",
        "user.screen_name": "SeanTheLad20"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894376316866561,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Nova21471346"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894375851143168,
        "text": "The first Sunday without #NFL football has left a void in my life. Thank God for the #Olympics #PyeongChang2018",
        "user.screen_name": "sara_candice"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894375633195009,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "AnniDoub"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894375587078144,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "yeskisc"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894375528300544,
        "text": "RT @USATODAY: It doesn\u2019t get much more impressive than this. https://t.co/La2NeZLE9J #Olympics",
        "user.screen_name": "jsonlee71"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894375230607360,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "schmat22"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894375012438016,
        "text": "RT @LynnRutherford: Mixed zone: \"I landed triple axel at the Olympics. That's historical and no one can take it away from me.\" #Pyeongchang\u2026",
        "user.screen_name": "marcylauren"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894374786031618,
        "text": "Nice! Way to go @mirai_nagasu \ud83d\udc4f\ud83c\udffb #TeamUSA #Olympics \ud83c\uddfa\ud83c\uddf8 https://t.co/c5qRpHD1aD",
        "user.screen_name": "LinCrossland"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894374786031617,
        "text": "Hey @nbc. There's other sports besides figure skating. #Olympics",
        "user.screen_name": "shanejblair"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894374647599104,
        "text": "RT @KFCBarstool: The Olympics are tough to really get into because it\u2019s hard to relate to these weirdos who play weirdo sports.\n\nBut that\u2019s\u2026",
        "user.screen_name": "bircheezy"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894374181974016,
        "text": "RT @16WAPTNews: Everyone is buzzing about this figure skater who performed to Beyonc\u00e9 at the Olympics https://t.co/WKmUjmUCvl https://t.co/\u2026",
        "user.screen_name": "Stagger_Lee__"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894374022602752,
        "text": "RT @RepMarkMeadows: While some in the media look fondly upon North Korea during the Olympics, I can't help but recall this from 2 weeks ago\u2026",
        "user.screen_name": "Prof_Treylawney"
    },
    {
        "created_at": "Mon Feb 12 03:41:23 +0000 2018",
        "id": 962894373917724672,
        "text": "RT @Lesdoggg: Shiiiiit like to see you give her a bad score!!! @NBCOlympics @Olympics https://t.co/0krtijP4vb",
        "user.screen_name": "_bangbanguk"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894373414494213,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "bethsinniresist"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894373376659457,
        "text": "Beautiful free dance skating by the Italian team! \ud83d\udc4f\ud83d\udc4f\ud83d\udc4f#Olympics  #Olympics2018",
        "user.screen_name": "AnneDASHMarie"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894373087334400,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "kshyamasagar"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894372974022656,
        "text": "The Life is Beautiful program is gorgeous. #olympics",
        "user.screen_name": "ac_bitter"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894372957175809,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "DeepEndDining"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894372709785600,
        "text": "RT @NumbersMuncher: Me in 2017: I can't understand how people could be so stupid to fall for fake Facebook stories promoted by Russia.\n\nMe\u2026",
        "user.screen_name": "angelazinypsi"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894372638511104,
        "text": "RT @peachyblackgorl: as the winter Olympics begin....never forget about Surya Bonaly, a French figure skater who did a backflip and landed\u2026",
        "user.screen_name": "crumrineJenny"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894372567052288,
        "text": "RT @RepMarkMeadows: While some in the media look fondly upon North Korea during the Olympics, I can't help but recall this from 2 weeks ago\u2026",
        "user.screen_name": "Darkvader1776"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894372302761984,
        "text": "My brother tried holding me on his back and DROPPED MY ASS so I envy the pairs team with their level of trust cause\u2026 https://t.co/EXNE7SsSzA",
        "user.screen_name": "jbdd1293"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894372193882112,
        "text": "RT @BizNasty2point0: Good luck to all the @TeamCanada athletes in this years Olympics. Some very special stories going in. Especially the o\u2026",
        "user.screen_name": "drkeating"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894372139347968,
        "text": "RT @KAy_TIEmyshoes: I love the Olympics https://t.co/YarQnjbr9c",
        "user.screen_name": "GabrielaDayss"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894371669491712,
        "text": "I am missing @BobCostasEyes in this winter Olympics.",
        "user.screen_name": "fourcookies"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894371573116933,
        "text": "RT @Machaizelli: A figure skater just made American Olympic history and the NBC commentators still had to compare her to the men #Olympics\u2026",
        "user.screen_name": "watson_susy"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894371560525824,
        "text": "RT @mikalapaula: Patrick Chan and Olympic Athlete from Russia can fall over the damn ice repeatedly and score higher than Adam Rippon's per\u2026",
        "user.screen_name": "marley_lunsford"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894371489304578,
        "text": "RT @jpbrammer: my favorite part of the Olympics so far was when Aja jumped off that box",
        "user.screen_name": "MOONLlGHT_MP3"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894371061485571,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "AlyxODay"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894370570727425,
        "text": "I thought Nagasu should've gone to the last #Olympics and I guess she proved her right to be there tonight! #PyeongChang2018",
        "user.screen_name": "shortygotloh"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894370520420353,
        "text": "Caught the 10km Sprint at the Olympics which is the skiing then stopping to shoot at targets. Instead of giving the\u2026 https://t.co/uhXXPbmUvN",
        "user.screen_name": "Wheels865"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894370356781056,
        "text": "RT @JamesHasson20: Here are stories fawning over North Korea at the Olympics from:\n-Wapo\n-Wall Street Journal\n-NYT\n-CNN\n-ABC News\n-NBC News\u2026",
        "user.screen_name": "MaeAndTheDove"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894370201571329,
        "text": "RT @misslaneym: Italy ice dancing to Life is Beautiful is everything. #IceDancing #olympics2018 #olympics",
        "user.screen_name": "mich_eck"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894370000326656,
        "text": "We deserve so much better than NBC. #Olympics",
        "user.screen_name": "MurrayRen"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894369668943872,
        "text": "RT @RealAlexJones: Watch Live: As MSM Cheers North Korea Against America At The Winter Olympics https://t.co/QhyUB1ooLt",
        "user.screen_name": "Zacharyeldog245"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894369492742144,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "MariaaaT"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894369316421633,
        "text": "RT @MarkDice: @CNN You clowns just reported that Kim Jun Un's sister 'stole the show' at the Olympics.   Stop.",
        "user.screen_name": "TeenyLZP"
    },
    {
        "created_at": "Mon Feb 12 03:41:22 +0000 2018",
        "id": 962894369303887872,
        "text": "RT @PHShriver: Trying to convince my 12 year old son to watch @TeamUSA during team skating, I told him this is the same country I competed\u2026",
        "user.screen_name": "gabyserrar"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894369115144193,
        "text": "RT @thehill: Dutch fans troll Trump at the Olympics with flag: \"Sorry Mr. President. The Netherlands First... And 2nd... And 3rd\" https://t\u2026",
        "user.screen_name": "jrad1014hi"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894368947421184,
        "text": "But they put their legs up like that with a FLEXED foot! \ud83d\ude31 #Olympics",
        "user.screen_name": "TalkNerdyWithUs"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894368872034304,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "caroljdavy"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894368767066112,
        "text": "@amandacarpenter This game is about the athletes. Don\u2019t rain on the Olympics. Shelf your politics for 2 was.",
        "user.screen_name": "LaurieBouchar12"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894368414752769,
        "text": "RT @Spokesbird: Skraaarrk! Reactions to watching the Olympics, as told by ocean creatures: https://t.co/B4aXFCUkeH #EarnTheFern\ud83c\udf3f\u00a0#PyeongCha\u2026",
        "user.screen_name": "7_ohmiya"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894368167354368,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "drshnpatel"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894367408181248,
        "text": "RT @BreakingNNow: #BREAKING: Canada has won Gold in the Figure Skating Team event at the Winter Olympics.",
        "user.screen_name": "Audreypearlz23"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894366724456449,
        "text": "RT @SandraTXAS: CNN, NY Times, etc:\nUS mainstream media reckless in praise of Little Rocket Girl Kim Yo Jong. Undermining foreign affairs b\u2026",
        "user.screen_name": "BuhByeHillary"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894366581735424,
        "text": "Adam Rippon's skate today though. \ud83d\udc4f\ud83d\udc4f\ud83d\udc4f #TeamUSA #Olympics",
        "user.screen_name": "Jasey6"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894366296559617,
        "text": "So this guy was last and passed every. single. skier. To win. Only at the Olympics.... #respect https://t.co/nN8GI9Yrsh",
        "user.screen_name": "elexis_h"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894366128857088,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "OhhKimmiekoe"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894365851971584,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Emily_1797"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894365378015232,
        "text": "RT @greenikkie: \uff03WINNER on \"Sports Hochi\" and \"Nikkan Sports\" (News Paper with the focus of Sports and Entertainment) Interestingly, they b\u2026",
        "user.screen_name": "WayamaYukihiro"
    },
    {
        "created_at": "Mon Feb 12 03:41:21 +0000 2018",
        "id": 962894365118124033,
        "text": "@NBCOlympics Wait - so no woman has done a triple axel in olympics???",
        "user.screen_name": "dissentingj"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894364979748865,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "emilykchilton"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894364681916416,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "xtabaychaparro"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894364262457344,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "AlexaSa135"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894364262330368,
        "text": "RT @Clefairyhyun: Acc to this article, the artists in the opening and closing of the Olympics ceremony, Exo included, receive little to no\u2026",
        "user.screen_name": "kyngshoo"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894363872374784,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "_terralu"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894363226525696,
        "text": "RT @KristySwansonXO: I Am Beyond Excited! Tyler Is Gonna Hold On To His Gloves For Me \ud83d\ude03 He Was My Team Captain On The @HollywoodCurl Team C\u2026",
        "user.screen_name": "benvoncronos"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894362958073856,
        "text": "RT @peachyblackgorl: as the winter Olympics begin....never forget about Surya Bonaly, a French figure skater who did a backflip and landed\u2026",
        "user.screen_name": "NicaRozier"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894362307805184,
        "text": "RT @CBCOlympics: Medal Alert \ud83d\udea8\n\nCanada guaranteed to win first gold medal in figure skating team event \ud83c\udde8\ud83c\udde6 \ud83e\udd47 #PyeongChang2018 \n\nWatch Tessa\u2026",
        "user.screen_name": "The_Unicorn22"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894362207191040,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "Alexa_romo1"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894361737359361,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "HYPERSILVER777"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894361724968961,
        "text": "RT @TechnicallyRon: Your definitive guide to the sports of the 2018 Winter Olympics https://t.co/Oyon5qfHBc",
        "user.screen_name": "spacedaydreamer"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894361691172864,
        "text": "I like how some of these ice skaters dress up. It's like cosplay on ice. #Olympics",
        "user.screen_name": "TheDoIIars"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894361557176320,
        "text": "@Lesdoggg live tweeting the Olympics gives me life. \ud83d\ude02\ud83d\ude02\ud83d\ude02 she\u2019s sooooo funny and true. You go girl! #Olympics2018",
        "user.screen_name": "lizpro2401"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894361401835520,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "HeyGenevieve"
    },
    {
        "created_at": "Mon Feb 12 03:41:20 +0000 2018",
        "id": 962894361087430656,
        "text": "They should put diving competitions in the winter Olympics. And also hold them outside.",
        "user.screen_name": "johncheese"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894360793767936,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "toonys_tweets"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894360433053696,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "jdclements50"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894360034525184,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "bwv_816"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894359640260608,
        "text": "The Italian ice dancers are really lovely but I feel like either his shirt should be white or her costume yellow? M\u2026 https://t.co/4HMHTHDvU5",
        "user.screen_name": "WintersRegan"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894359371833345,
        "text": "RT @ReutersSports: North Korean cheerleaders sing 'We are one!' in Games culture clash https://t.co/SRwMycYLFR @pearswick #PyeongChang2018\u2026",
        "user.screen_name": "twinkleyapp"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894358864216064,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "BarbaritaRunner"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894357815812097,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "diablejambe"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894357669011456,
        "text": "RT @sohanjnu1: Winter Olympics 2018 opening ceremony: Korean athletes enter under unified flag \u2013 live! https://t.co/EhDOMK5MmA",
        "user.screen_name": "RealBobHoward"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894357534781441,
        "text": "RT @TrumpGirlStrong: No desire whatsoever to watch #Olympics with so many whiny bitches representing USA - or shall I say \"representing the\u2026",
        "user.screen_name": "KahlerSabrina"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894357371244544,
        "text": "RT @hotfunkytown: Race reared its ugly head at the Olympics.  Davis boycotted the opening ceremonies using #blackhistorymonth\n\nFor Shani Da\u2026",
        "user.screen_name": "JarredMattingl3"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894357161529344,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "spencebrandon3"
    },
    {
        "created_at": "Mon Feb 12 03:41:19 +0000 2018",
        "id": 962894356830093312,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "jessianna_r"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894356649861121,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "dbol1964"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894356595331072,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "CMontclaire45"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894356414894081,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "careuhhlynn"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894356385550339,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "dianen207"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894356326834177,
        "text": "RT @CarolineSiede: This on-ice interview he did with Tyler Oakley made me fall in love with Adam Rippon. #Olympics #Pyeonchang2018 https://\u2026",
        "user.screen_name": "ljessg"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894355739566080,
        "text": "Retweeted Sarah (@sarah_liza21):\n\nAgain... this Italian team is just so charming \ud83d\udc96\ud83d\udc96\ud83d\udc96 #PyeongChang2018 #Olympics #OlympicGames #FigureSkating",
        "user.screen_name": "SashaCAiresse"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894355626446849,
        "text": "RT @CBCOlympics: Medal Alert \ud83d\udea8\n\nCanada guaranteed to win first gold medal in figure skating team event \ud83c\udde8\ud83c\udde6 \ud83e\udd47 #PyeongChang2018 \n\nWatch Tessa\u2026",
        "user.screen_name": "_KMarcotte"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894355341238273,
        "text": "RT @CoxWebDev: Hey @NBCSports I know there are other sports going on besides figure skating. Can we see some of those? #Olympics",
        "user.screen_name": "ViralDonutz"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894355034984448,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "angxlitav"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894354846187521,
        "text": "RT @hotfunkytown: Race reared its ugly head at the Olympics.  Davis boycotted the opening ceremonies using #blackhistorymonth\n\nFor Shani Da\u2026",
        "user.screen_name": "jayMAGA45"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894354724671489,
        "text": "I'm a proud supporter of democracy and runaway spending so I only root for the European countries that nearly collapsed in 2008. #Olympics",
        "user.screen_name": "zacklemore92"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894354602962944,
        "text": "Still a fan of the snowboard slopestyle event, but it is kind of interesting to hear the announcers talk about how,\u2026 https://t.co/AjTvmrfZBl",
        "user.screen_name": "KBecks_ATC"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894354078621696,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "BIGSEXYYT"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894353927680000,
        "text": "RT @rockerskating: In case you need to know, the tiebreaker rules for the #Olympics #figureskating Team Event https://t.co/goLqHw85oA",
        "user.screen_name": "dukebaby401"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894353294245889,
        "text": "RT @linzsports: Four years ago, Adam Rippon and MIrai Nagasu were eating in-n-out burger in California, crying and watching the Sochi Olymp\u2026",
        "user.screen_name": "LeeCaraher"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894352983953408,
        "text": "RT @NBCOlympics: Italy's Carolina Kostner was magnificent in the ladies' short program. #WinterOlympics https://t.co/a8E2Sv9O2T https://t.c\u2026",
        "user.screen_name": "ChrisPe00000486"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894352933679104,
        "text": "RT @pronounced_ing: Also, I\u2019m having a lot of feelings at seeing so many Asian Americans in the spotlight the Olympics. I remember what see\u2026",
        "user.screen_name": "Anthropic"
    },
    {
        "created_at": "Mon Feb 12 03:41:18 +0000 2018",
        "id": 962894352593940485,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "gabi32luis"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894352245719042,
        "text": "This is amazing!!!  \ud83d\ude01\ud83d\ude01\ud83d\ude01#Olympics https://t.co/c88Z4o1UQM",
        "user.screen_name": "jesschnei"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894351637602305,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "_clayonce"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894351150989312,
        "text": "Holy damn! Italy\u2019s ice dance performance is mesmerising!! I mean, the lady is too graceful omg \ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\udc4f\ud83d\udc4f\ud83d\udc4f #figureskating #Olympics",
        "user.screen_name": "matelliii"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894350928642049,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "sunezzell"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894350345801733,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "AmericanBoxFan"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894350324727808,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "doggietreat"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894350236700672,
        "text": "RT @SohrabAhmari: Replace \"North Korea\" with \"Germany\" and add \"1936\" before \"Olympics,\" and it'll give you a good sense of what a disgrace\u2026",
        "user.screen_name": "pyarnes"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894350077386753,
        "text": "RT @Heritage: The perverse fawning over brutal Kim Jong-un\u2019s sister at the Olympics @bethanyshondark https://t.co/CTijmDXibJ https://t.co/O\u2026",
        "user.screen_name": "JPhlps"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894350047940608,
        "text": "RT @CBCOlympics: When the event is delayed, women's slopestyle will play! \n\n@spencerobrien @LaurieBlouin Brooke Voigt @aimee_fuller \n\nLive\u2026",
        "user.screen_name": "TitsDeep"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894349318189061,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "kristennic27"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894349087408129,
        "text": "RT @jpbrammer: my favorite part of the Olympics so far was when Aja jumped off that box",
        "user.screen_name": "thekaeleesi"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894348349329408,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "ShaunLKelly1955"
    },
    {
        "created_at": "Mon Feb 12 03:41:17 +0000 2018",
        "id": 962894348336721920,
        "text": "RT @RebeccaUgolini: Figure skating announcers: \"The... very soul of... skating... lies within... this woman... splendid.\"\nSnowboarding anno\u2026",
        "user.screen_name": "autumnbreezed"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894348047220736,
        "text": "RT @JHanuszczyk: Imagine what if everyone who sees this bought a pair of Johnscrazysocks. 5% of profits go to Special Olympics. https://t.c\u2026",
        "user.screen_name": "FubarFoot"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894347707600897,
        "text": "RT @guskenworthy: We're here. We're queer. Get used to it. @Adaripp #Olympics #OpeningCeremony https://t.co/OCeiqiY6BN",
        "user.screen_name": "herdesertplaces"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894347552215040,
        "text": "RT @NBCOlympics: COMING UP: @mirai_nagasu returns to the #WinterOlympics!\n\nSee it on @nbc or stream it here: https://t.co/NsNuy9F46h https:\u2026",
        "user.screen_name": "cristallum_arca"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894347250253825,
        "text": "Winter Olympics 2018: Windy conditions cause Aimee Fuller problems in first run   https://t.co/BKt08NEItu",
        "user.screen_name": "LIMITED_ZONE"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894347187490817,
        "text": "RT @CHENGANSITO: Since the Olympics just started I'm bringing back this iconic moment\n\n#EXOL #BestFanArmy #iHeartAwards @weareoneEXO PUPPY\u2026",
        "user.screen_name": "zhazhma"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894347019673600,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "brooke_dunn143"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894346478587904,
        "text": "RT @VP: Headed to the Olympics to cheer on #TeamUSA. One reporter trying to distort 18 yr old nonstory to sow seeds of division. We won\u2019t l\u2026",
        "user.screen_name": "BrandyRena_79"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894345933414400,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "browngirlvibes"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894345668997121,
        "text": "tbh i both can and cannot believe that the US does not let you stream the olympics for free, adding this to the man\u2026 https://t.co/o3zM2wWjcV",
        "user.screen_name": "karaastone"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894345497030656,
        "text": "RT @billboard: Korean singers and K-pop acts get drawn into Pyeongchang 2018 Winter Olympics! EXO and CL are set to perform at the closing\u2026",
        "user.screen_name": "salsabilafr_"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894345211863040,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "danasbrookes"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894345048240128,
        "text": "RT @jongninied: EXO CHOSE NOT TO RECEIVE ANYTHING AS IT IS SUCH AN HONOR FOR THEM TO PERFORM AT THE CLOSING CEREMONY PYEONCHANG WINTER OLYM\u2026",
        "user.screen_name": "PurpleNatelie"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894344901529601,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "RachaelHash98"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894344788365313,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "CarlyCausey"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894344456777728,
        "text": "RT @ABC: U.S. figure skater Mirai Nagasu makes history, becoming the first American woman - and third overall - to land a triple axel in th\u2026",
        "user.screen_name": "Earlgrey000052"
    },
    {
        "created_at": "Mon Feb 12 03:41:16 +0000 2018",
        "id": 962894344268238853,
        "text": "RT @ChelseaClinton: Catching up on the Olympics. @Adaripp, you were spectacular on the ice and completely charming afterwards. Very proud y\u2026",
        "user.screen_name": "JoshuaDeck2"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894343995625473,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "PennyEMN"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894343919976448,
        "text": "RT @TheAlexNevil: Nobody paid attention to Bob.\nHis ideas were dismissed.\nHis enthusiasm was laughed at.\n\nBut then he was hired by the Wint\u2026",
        "user.screen_name": "lmwortho"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894343693570048,
        "text": "RT @btschartdata: [!] Another BTS' song played at #Olympics , '21st Century Girl' was used as background music in Women Hockey Match, Canad\u2026",
        "user.screen_name": "AlejandraSiles3"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894343618011136,
        "text": "RT @CBCOlympics: #CAN's @tessavirtue &amp; @ScottMoir skate 5th in the last event of the #FigureSkating Team Event. Even if they finish last, C\u2026",
        "user.screen_name": "physedbum"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894343483920385,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "laurenss14"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894343257362433,
        "text": "RT @RachelRoseGold1: Adam Rippon and Mirai Nagasu are roomies at the Olympics. They ate In and Out Burger when they didn't make the 2014 Ol\u2026",
        "user.screen_name": "sharminated"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894342917472256,
        "text": "Omg the Italian team free dance fr made me cry #Olympics",
        "user.screen_name": "SlayBitch666"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894342674403333,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "alexpokerguy"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894342351474695,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "reddcurlz"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894341575512065,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "mabess96"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894341357297664,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "radicalanduhrew"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894341202219009,
        "text": "RT @USATODAY: It doesn\u2019t get much more impressive than this. https://t.co/La2NeZLE9J #Olympics",
        "user.screen_name": "kevinlockett"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894340635832320,
        "text": "RT @sarah_liza21: Again... this Italian team is just so charming \ud83d\udc96\ud83d\udc96\ud83d\udc96 #PyeongChang2018 #Olympics #OlympicGames #FigureSkating",
        "user.screen_name": "SashaCAiresse"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894340061323264,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "eDiscMatters"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894340044582913,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "sarumitrash"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894339973132288,
        "text": "RT @jpbrammer: my favorite part of the Olympics so far was when Aja jumped off that box",
        "user.screen_name": "joshdotgif"
    },
    {
        "created_at": "Mon Feb 12 03:41:15 +0000 2018",
        "id": 962894339943878656,
        "text": "RT @benshapiro: All you need to know about the media\u2019s not-so-secret love for Marxist dictatorships can be seen in their treatment of the c\u2026",
        "user.screen_name": "watin_dey"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894339725766656,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "Barbara80014143"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894339708928000,
        "text": "I\u2019m amazed at how people who have never played a particular sport suddenly become experts during the Olympics. It\u2019s\u2026 https://t.co/zIw1SqsNm7",
        "user.screen_name": "itsmikebivins"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894338748551173,
        "text": "RT @TheRickyDavila: It says something when our amazing athletes can so easily represent the United States with class, grace, honor, dignity\u2026",
        "user.screen_name": "bdworkin"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894338694008837,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "the_teezus"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894338635321344,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "BrynnLay"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894337955708928,
        "text": "RT @USATODAY: It doesn\u2019t get much more impressive than this. https://t.co/La2NeZLE9J #Olympics",
        "user.screen_name": "randyslovacek"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894337863401472,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "citlalli861"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894337758629888,
        "text": "team free skating is so cute! some of the couples are really amazing! #Winter #Olympics 2018\ud83e\udd29\u2728",
        "user.screen_name": "simoneaustina"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894337737744384,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "mattinwpg"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894337670557697,
        "text": "Damn Italy that was beautiful. #Olympics2018 #olympics",
        "user.screen_name": "ChristineInLou"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894337054068737,
        "text": "Wow...judges are especially shading the American figure skaters this year...they hate us. #Olympics",
        "user.screen_name": "MeLovesMLE"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894336982577152,
        "text": "RT @maddysnekutai: winter olympics 2018? you mean the return of yuzuru hanyu and his infamous winnie the pooh tissue box https://t.co/0xu0C\u2026",
        "user.screen_name": "mooglins"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894336869335040,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "Clogic3"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894336865153024,
        "text": "this Italian team's style is on point. #Olympics #figureskating",
        "user.screen_name": "irishbronco"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894336701665282,
        "text": "PSA: Do not twitter while watching the Olympics. #spoilers",
        "user.screen_name": "jen_hedberg"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894336601088002,
        "text": "The bravest team with the most at risk at the #Olympics is the #NorthKoreanCheerleaders. If they don't perform with\u2026 https://t.co/X5x0IFH6yZ",
        "user.screen_name": "Wombat32"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894336173121536,
        "text": "RT @joshrogin: Did I photobomb the North Korea cheer squad? Absolutely. #PyeongChang #Olympics H/T: @W7VOA https://t.co/q8WnOK7hhF",
        "user.screen_name": "Dan__i"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894336005476352,
        "text": "RT @LanceUlanoff: Boom! 3.25\u2013 a first at the Winter #Olympics #nagasu #tripleaxel https://t.co/f5sG2pJVb8",
        "user.screen_name": "RoadsideWonders"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894335925784576,
        "text": "@ljqzhang All of the sudden I care about the Olympics",
        "user.screen_name": "alindsaydiaz"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894335825113088,
        "text": "RT @morgan_murphy: I am having a separate Olympics at my house and it\u2019s completely thrilling. https://t.co/sonV0zWGCe",
        "user.screen_name": "chesspoof"
    },
    {
        "created_at": "Mon Feb 12 03:41:14 +0000 2018",
        "id": 962894335820861440,
        "text": "@KattyKayBBC US should be boycotting the Olympics as part of sanctions against the korean duopoluy",
        "user.screen_name": "ALLSOLUTIONS_"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894335627808769,
        "text": "RT @BleacherReport: Mirai Nagasu becomes the first U.S. woman to land a triple axel at the #WinterOlympics \n\n\ud83c\udfa5: https://t.co/sG1l47slJ4 htt\u2026",
        "user.screen_name": "u2bheavenbound"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894335397236736,
        "text": "@bec901 I was watching the Olympics in the room before we went to the track.  And Dan Hicks is a commentator for NB\u2026 https://t.co/a05EFmW1lu",
        "user.screen_name": "ldock93"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894335321677826,
        "text": "RT @chalanlexi: MIDORI-MAO-MIRAI --- Three women who landed the difficult triple axel in the Olympics #Midori, #MaoAsada and @mirai_nagasu.\u2026",
        "user.screen_name": "nica_idling"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894335279878144,
        "text": "RT @StandWithUs: Israel's \ud83c\uddee\ud83c\uddf1\ufe0f  Aimee Buchanan wows the crowd in the Olympics team competition today! \u26f8\ufe0f \u26f8\ufe0f \u26f8\ufe0f We are so proud!\n\n\ud83c\uddee\ud83c\uddf1\ufe0f  GO TEA\u2026",
        "user.screen_name": "indifrundig"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894335015612417,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "LaMonica"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894334952534016,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "pacortez16"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894334910545926,
        "text": "The only part of the olympics I care about is figure skating",
        "user.screen_name": "yokoneris"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894334789120001,
        "text": "These ice skating athletes are so amazing. Can we at least get them fabric that doesn\u2019t show sweat stains? #Olympics #IceDancing",
        "user.screen_name": "JillBidenVeep"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894334541606912,
        "text": "Johnny Weir: \"This free skate program is almost like running a full marathon and then 50 sprints right after\". No,\u2026 https://t.co/oafxiHWywu",
        "user.screen_name": "realdjm14"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894334239518720,
        "text": "RT @btschartdata: [!] Another BTS' song played at #Olympics , '21st Century Girl' was used as background music in Women Hockey Match, Canad\u2026",
        "user.screen_name": "JungKoo18767621"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894333585313793,
        "text": "RT @ABC: U.S. figure skater Mirai Nagasu makes history, becoming the first American woman - and third overall - to land a triple axel in th\u2026",
        "user.screen_name": "empresswenjing"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894333107204096,
        "text": "Game Changing Tech in action. The PyeongChang games have the most widespread use of 360-degree virtual reality... https://t.co/vw9fdyv7j4",
        "user.screen_name": "NextStepCincy"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894332834598912,
        "text": "@3L3V3NTH Well sort of, the Russians - who were kicked out for doping - still sent athletes under a code name.  The\u2026 https://t.co/WAAuoJr6l8",
        "user.screen_name": "MockingJayMom"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894332448550914,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "GaelFC"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894332356452352,
        "text": "RT @romania_sistas: @NBCOlympics From this younger age to a triple in the Olympics....so proud)))) https://t.co/dPmEmuy5OK",
        "user.screen_name": "BongioviSue"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894332259811328,
        "text": "Decision to hold women's snowboard slopestyle in windy conditions looks questionable after numerous wipeouts https://t.co/OZvY7VHSXK",
        "user.screen_name": "DanWolken"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894332243013637,
        "text": "@null Winter Olympics 2018: Windy conditions cause Aimee Fuller problems in first run   https://t.co/OF7pFUWCBc",
        "user.screen_name": "RAMOSSAVIOR"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894332037648384,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "YuravageGtrPlyr"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894331781685248,
        "text": "RT @chalanlexi: MIDORI-MAO-MIRAI --- Three women who landed the difficult triple axel in the Olympics #Midori, #MaoAsada and @mirai_nagasu.\u2026",
        "user.screen_name": "mizuesan"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894331756535808,
        "text": "Tonya Harding did it 3 decades ago, not at the Olympics! https://t.co/N8AEIrSJlb",
        "user.screen_name": "FitToPrint"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894331634946048,
        "text": "RT @VABVOX: This is the campaign from @Toyota for the Olympics &amp; Paralympics. \nAs a paralyzed person (and former athlete), I really appreci\u2026",
        "user.screen_name": "RenwriterRenee"
    },
    {
        "created_at": "Mon Feb 12 03:41:13 +0000 2018",
        "id": 962894331593089024,
        "text": "RT @my2k: LOOK AT THEIR FACES THEY'RE SO HAPPY OMG #olympics",
        "user.screen_name": "elknight20"
    },
    {
        "created_at": "Mon Feb 12 03:41:12 +0000 2018",
        "id": 962894331190349824,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "andreaxduarte"
    },
    {
        "created_at": "Mon Feb 12 03:41:12 +0000 2018",
        "id": 962894331114852352,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "kenbutnobarbie"
    },
    {
        "created_at": "Mon Feb 12 03:41:12 +0000 2018",
        "id": 962894331081363456,
        "text": "RT @RichOToole: Winter Olympics looking like The Hunger Games https://t.co/7sDAxeC9ir",
        "user.screen_name": "coffeetalkwc"
    },
    {
        "created_at": "Mon Feb 12 03:41:12 +0000 2018",
        "id": 962894330510811136,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "SteveHensonME"
    },
    {
        "created_at": "Mon Feb 12 03:41:12 +0000 2018",
        "id": 962894329755918337,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "suburbanmon"
    },
    {
        "created_at": "Mon Feb 12 03:41:12 +0000 2018",
        "id": 962894328610816001,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "justicelover"
    },
    {
        "created_at": "Mon Feb 12 03:41:12 +0000 2018",
        "id": 962894328522665984,
        "text": "RT @olympicchannel: Start your day right with the @Olympics \ud83e\udd5e\ud83d\ude0b #PyeongChang2018 https://t.co/MJYc7cyHjv",
        "user.screen_name": "llovejy0822"
    },
    {
        "created_at": "Mon Feb 12 03:41:12 +0000 2018",
        "id": 962894328166305792,
        "text": "that was better than LIFE IS BEAUTIFUL #Olympics",
        "user.screen_name": "nicksgoodtweets"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894327218307072,
        "text": "@jaketapper Seriously why are your cohorts falling all over themselves in praise of NK and it\u2019s representatives at the Olympics?",
        "user.screen_name": "djb_in_cbus"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894327117594625,
        "text": "RT @TheRickyDavila: It says something when our amazing athletes can so easily represent the United States with class, grace, honor, dignity\u2026",
        "user.screen_name": "Rmart0311"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894327033688064,
        "text": "RT @jongninied: EXO CHOSE NOT TO RECEIVE ANYTHING AS IT IS SUCH AN HONOR FOR THEM TO PERFORM AT THE CLOSING CEREMONY PYEONCHANG WINTER OLYM\u2026",
        "user.screen_name": "honeybear0114"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894326333231104,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "Gaudias1927"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894326153072641,
        "text": "Olympics Figure Skating Live Results: Canada Leads; US Third https://t.co/8P93NyGqkw",
        "user.screen_name": "esveerst0e"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894325976776704,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "witchybyun"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894325641134080,
        "text": "RT @saminseok: EXO chose not to receive compensation for performing at the Olympics\ud83d\ude2d \n\nHonor &gt; money \u2764\ufe0f We love the Nation's pick!\n\n#EXOL #\u2026",
        "user.screen_name": "tresyameiy"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894325565853696,
        "text": "RT @BayAreaKoreans: In 2002, Shin Hyo Sun &amp; Shim Misun, two 14 year old girls in South Korea, were killed when US soldiers ran a tank over\u2026",
        "user.screen_name": "brucezzhang"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894325465088001,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "xPa0lax"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894325439975424,
        "text": "RT @KAy_TIEmyshoes: I love the Olympics https://t.co/YarQnjbr9c",
        "user.screen_name": "HHuffhines"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894325330792448,
        "text": "RT @Lesdoggg: What. Is. This!!!!! @NBCOlympics @Olympics https://t.co/SQuWG7nVYZ",
        "user.screen_name": "troysteinmetz"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894324957507584,
        "text": "Dutch fans troll Trump at the Olympics with flag: \u201cSorry Mr. President. The Netherlands First\u2026 And 2nd\u2026 And 3rd\u201d\u2026 https://t.co/Zw4iSDWiIK",
        "user.screen_name": "Bunny_Godfather"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894324898856960,
        "text": "RT @HarryPotterMAGE: As #Olympics2018 shift to sports, what on Earth happened?  \nQuite simply, there were N and S Korea, side by side in th\u2026",
        "user.screen_name": "SoniaRo59106523"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894324580212736,
        "text": "RT @paulwaldman1: +1000. I've written before about how the diversity of our team is the coolest thing about the Olympics, and a quadrennial\u2026",
        "user.screen_name": "clrih9"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894324223520769,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "cjc708"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894324013944833,
        "text": "RT @hueber_sydney: FIRST US WOMAN TO LAND A TRIPLE AXEL AT THE #Olympics YES MY GIIIIIRL YOU DID IT ! ! \n#PyeongChang2018 #MiraiNagasu @mir\u2026",
        "user.screen_name": "thegazelle22"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894323946803200,
        "text": "RT @Maryland4Trump2: What's funny is liberals are against taking military action against North Korea, but if Kim was making insensitive com\u2026",
        "user.screen_name": "emfbd"
    },
    {
        "created_at": "Mon Feb 12 03:41:11 +0000 2018",
        "id": 962894323254665216,
        "text": "When I find out Canada won gold at the olympics #canada https://t.co/fjEjdLwjFf",
        "user.screen_name": "Sports6ix"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894322927628288,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "AMEMEGUY"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894322906497024,
        "text": "RT @billboard: Korean singers and K-pop acts get drawn into Pyeongchang 2018 Winter Olympics! EXO and CL are set to perform at the closing\u2026",
        "user.screen_name": "sehunnnn14"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894322898104320,
        "text": "There's another U.S. power couple at Olympics https://t.co/5UAms03BD7 via @yahoo",
        "user.screen_name": "JKamka"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894322483040256,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "harjjo"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894321136623621,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "BreanaJean"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894321052631040,
        "text": "RT @NBCOlympics: Quite the dramatic entrance for 2010 Olympic champion @Yunaaaa. #WinterOlympics #OpeningCeremony https://t.co/Ay5QOzAHZD h\u2026",
        "user.screen_name": "dabsorama"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894320960389120,
        "text": "RT @vlissful: i was simply reporting that the north korean cheering squad was dancing while a BTS song, blood sweat &amp; tears, was playing at\u2026",
        "user.screen_name": "lunetwt"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894320708800512,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "CeciliayueWang"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894320419434496,
        "text": "RT @AnnaApp91838450: https://t.co/E2yd8MEmn7\nLeave it to our Corrupt Bias Fake \nMedia To Put The Spot Light on North Korea Cheerleaders\ud83d\udc4e\ud83c\uddfa\ud83c\uddf8\u2026",
        "user.screen_name": "toiletman01"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894319609876480,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "Dev24Sev"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894319593156608,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Smelty246"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894319442042881,
        "text": "RT @RedTRaccoon: Showing a complete lack of respect and class, Mike Pence refuses to stand for any country other than the United States at\u2026",
        "user.screen_name": "michaelj45000"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894319362469888,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "pineappIemily"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894319307849728,
        "text": "Me waiting for #VirtueMoir to begin skating and thinking about their clearly platonic friendship:\n\n#Olympics\u2026 https://t.co/UHAkCyTIJc",
        "user.screen_name": "Lem0nade23"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894319232237568,
        "text": "RT @TheNewMusicBuzz: BUZZ BITES: K-Pop Was Celebrated at the Opening Ceremony as USA Comes out to @psy_oppa'Gangnam Style' and @bts_bighit\u2026",
        "user.screen_name": "elmafatika"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894319135928320,
        "text": "#digitaltransformation in action with the #olympics2018 Tech companies built infrastructure for billions to view https://t.co/ukgaCswWtp",
        "user.screen_name": "sakura280869"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894319119159296,
        "text": "If this was my NBC app fun fact while I was skating my damn ass off in the olympics I would get divorced.\u2026 https://t.co/pjfewY5JmO",
        "user.screen_name": "Alyssa_Dawn"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894319014342657,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "scuttling"
    },
    {
        "created_at": "Mon Feb 12 03:41:10 +0000 2018",
        "id": 962894318985007104,
        "text": "RT @DLoesch: Who determined this? They\u2019ve made no concessions, starve and torture their populace, threaten war, and all they have to do is\u2026",
        "user.screen_name": "SgtNickBristow"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894318917873664,
        "text": "@Lesdoggg @NBCOlympics @Olympics Begging for Tara and Johnny to host SNL...who do I need to contact?\nPlease and tha\u2026 https://t.co/dVlX9HszcU",
        "user.screen_name": "realthisgirl"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894318825623552,
        "text": "RT @TIME: Tara Lipinski and Johnny Weir's brutal skating commentary should be an Olympic sport https://t.co/cYf0Z0PTOH",
        "user.screen_name": "LetsGoHeather"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894318678749184,
        "text": "RT @BetteMidler: Yes, I\u2019m watching the Winter Olympics while grinding my teeth\nwatching our Government,  hurtling down a slippery slope unt\u2026",
        "user.screen_name": "rpj66"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894318062071809,
        "text": "RT @TorontoStar: Canada has won its first gold medal of the Pyeongchang Winter Olympics. https://t.co/QE8AbJ5gpG",
        "user.screen_name": "jesshwprince"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894317554511873,
        "text": "RT @Clefairyhyun: Acc to this article, the artists in the opening and closing of the Olympics ceremony, Exo included, receive little to no\u2026",
        "user.screen_name": "oviani0114"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894317391106048,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "rabbighiniVW"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894317101592576,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "Kkalihane"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894317068128258,
        "text": "RT @RepMarkMeadows: While some in the media look fondly upon North Korea during the Olympics, I can't help but recall this from 2 weeks ago\u2026",
        "user.screen_name": "Right_This_Ship"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894316757815301,
        "text": "RT @RachelRoseGold1: Adam Rippon and Mirai Nagasu are roomies at the Olympics. They ate In and Out Burger when they didn't make the 2014 Ol\u2026",
        "user.screen_name": "ouatlover468"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894315935621122,
        "text": "RT @NumbersMuncher: Kim Jong Un himself has to be shocked at how easy it is to win the media over after decades of murdering his own people\u2026",
        "user.screen_name": "beinpulse"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894315608530945,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Miguel_Yunda"
    },
    {
        "created_at": "Mon Feb 12 03:41:09 +0000 2018",
        "id": 962894314937430017,
        "text": "Being both Dutch and Canadian, I can safely say that the Winter Olympics are my jam. #sven",
        "user.screen_name": "_allard"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894314509549570,
        "text": "Nicely done Italy. I got a little teary eyed. #icedance #olympics",
        "user.screen_name": "SandiAdy"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894314153050112,
        "text": "RT @WBURartery: Trying to watch the #Olympics, but you #cutthecord? Here's how to watch: https://t.co/NRFZ1G5i3Y",
        "user.screen_name": "IronicMusic"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894314035601408,
        "text": "RT @HRC: RT to cheer on Adam Rippon (@AdaRipp) at the #Olympics! https://t.co/KIO5zX9z6i",
        "user.screen_name": "RainbowAurora88"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894313452552192,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Spa5m"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894313410658305,
        "text": "RT @RobbySpankme: @Quadrant4change I\u2019ll know they\u2019re serious about Winter Olympics when they add snow shoveling &amp; black ice driving",
        "user.screen_name": "starzwithfeet"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894313133715456,
        "text": "RT @DLoesch: She\u2019s such a good person because she showed up at the Olympics, right? That makes up for the labor camps; rapes; murder of men\u2026",
        "user.screen_name": "kerin_wotsirb"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312995516416,
        "text": "#TeamItalia pairs free skate for their team performance is an amazing display of artistry and story telling. So muc\u2026 https://t.co/nIo3WkqZwa",
        "user.screen_name": "Shoujothoughts"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312806608896,
        "text": "RT @TheRickyDavila: Adam Rippon was absolutely incredible. What a masterful routine and a beautiful display of artistry. Spellbinding. So p\u2026",
        "user.screen_name": "THEMissB_says"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312584364037,
        "text": "RT @saminseok: good morning, korean media says Olympics athletes and are all secretly/openly excited that the world stars EXO are performin\u2026",
        "user.screen_name": "smilechennieee"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312575942657,
        "text": "RT @CBCOlympics: Medal Alert \ud83d\udea8\n\nCanada guaranteed to win first gold medal in figure skating team event \ud83c\udde8\ud83c\udde6 \ud83e\udd47 #PyeongChang2018 \n\nWatch Tessa\u2026",
        "user.screen_name": "dana_abossi"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312542437376,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "that1pendeja"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312437682178,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "KeithAltarac"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312437633025,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "TalBG5"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312403955713,
        "text": "RT @seohyundaily: Imagine getting call from Blue House to perform historic concert same day for Olympics in presence of President....with n\u2026",
        "user.screen_name": "PastelRosePearl"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312328581120,
        "text": "RT @FearDept: At #Olympics opening ceremonies:\n- Kim Jong Un\u2019s sister stood &amp; clapped for Team America\n- VP Mike Pence didn't acknowledge N\u2026",
        "user.screen_name": "NotMeCharles"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312202821632,
        "text": "RT @NBCOlympics: Alina Zagitova was simply flawless, and her teammate Evgenia Medvedeva was LOVING IT! #WinterOlympics https://t.co/NsNuy9F\u2026",
        "user.screen_name": "inuyashas_"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312169246720,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "maisany"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894312089489408,
        "text": "RT @peachyblackgorl: as the winter Olympics begin....never forget about Surya Bonaly, a French figure skater who did a backflip and landed\u2026",
        "user.screen_name": "otrasIou"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894311330283521,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "fastwriter2"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894311229739009,
        "text": "RT @KHOU: Mirai Nagasu is first American woman to land triple axel during Olympics https://t.co/j1SV2Jsg2e #khou https://t.co/hqaASrv8jQ",
        "user.screen_name": "Like_A_Ross16"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894311149981696,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "SHeczko"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894311095455744,
        "text": "Mirai Nagasu Just Became the First American Woman to Land a Triple Axel in the Winter Olympics - Jezebel https://t.co/bfp5gRdjc0",
        "user.screen_name": "UserGlobal"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894311015829505,
        "text": "lesbuchanan: Summer Olympics: Who can run the fastest? :) Who can swim the fastest? :) Who can do the best... https://t.co/FgQKhzYDxk",
        "user.screen_name": "theESC"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894310952919040,
        "text": "Hard to believe that there are families that don\u2019t watch the Olympics together. It\u2019s literally our favorite thing.\u2026 https://t.co/jXptnKzf4i",
        "user.screen_name": "WPBCharlie"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894310818697216,
        "text": "Not an Olympics follower but I am so here for this https://t.co/4uGquztg0S",
        "user.screen_name": "BCWallin"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894310692683776,
        "text": "Yonghwa should have been at the Olympics but that was stolen from him by SBS and KHU. Give him justice!\u2026 https://t.co/qKcM2cKcLL",
        "user.screen_name": "PurpleInYrEyes"
    },
    {
        "created_at": "Mon Feb 12 03:41:08 +0000 2018",
        "id": 962894310613041153,
        "text": "RT @Rosie: beautiful man - beautiful soul \n#AdamRippon - national hero\n#Olympics https://t.co/MbjOoXJhP6",
        "user.screen_name": "sharilynns65"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894310114054145,
        "text": "RT @LanceUlanoff: Boom! 3.25\u2013 a first at the Winter #Olympics #nagasu #tripleaxel https://t.co/f5sG2pJVb8",
        "user.screen_name": "Aznmomma69"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894310017400832,
        "text": "RT @chalanlexi: MIDORI-MAO-MIRAI --- Three women who landed the difficult triple axel in the Olympics #Midori, #MaoAsada and @mirai_nagasu.\u2026",
        "user.screen_name": "lennan6"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894309778509825,
        "text": "Figure skating is like professional wrestling. When it\u2019s at its best, it\u2019s transcendent; it\u2019s sports entertainment. #Olympics #WWE",
        "user.screen_name": "TheCoachAdair"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894309442932739,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "Gabby_Zibell"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894308864090112,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "HelmsMedia"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894308440530944,
        "text": "I couldn\u2019t help but smile wth Capellini/Lanotte. #PyeongChang2018 #Olympics #FigureSkating",
        "user.screen_name": "NaiDarling"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894308322918401,
        "text": "It's Olympics season aka \"OHMIGOD you've been practicing your whole life to FALL IN THE FIRST 20 SECONDS WHAT THE F\u2026 https://t.co/fiLXSJ9RnQ",
        "user.screen_name": "kayfrizzz"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894308239073280,
        "text": "RT @donnyosmond: Debbie &amp; I are watching the @Olympics tonight and we think it's so cool that there's an Osmond in the Olympics. @kaetlyn_2\u2026",
        "user.screen_name": "BobbySudds"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894307576504321,
        "text": "That \"obscure\" sport has been around for 600 years and is quite popular in many parts of the world. You might want\u2026 https://t.co/NbDLE43KSl",
        "user.screen_name": "dreamsof2005"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894307488358405,
        "text": "RT @sidewalkangels: In the shadow of the Olympics, a brutal trade in dog meat (opinion) - CNN https://t.co/gFOY9So3ho",
        "user.screen_name": "YaRicher"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894307043758080,
        "text": "RT @Machaizelli: A figure skater just made American Olympic history and the NBC commentators still had to compare her to the men #Olympics\u2026",
        "user.screen_name": "MichelleHalm"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894306875977729,
        "text": "RT @CharlieDaniels: There\u2019s a Cowboy Olympics in Las Vegas every December\nIts called the National Finals Rodeo and its the toughest games i\u2026",
        "user.screen_name": "sonshineandrain"
    },
    {
        "created_at": "Mon Feb 12 03:41:07 +0000 2018",
        "id": 962894306829680640,
        "text": "The ice skaters in the olympics are soo good \ud83d\ude0d",
        "user.screen_name": "Danielle053101"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894306208989184,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "ModernMarvel_14"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894306112569345,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "megasorusrex"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894306045517824,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "victorialynn___"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894305915531264,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "Mr_LeRok"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894305860902912,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "maldy777"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894304619520000,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "carlysschaublin"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894304438992898,
        "text": "RT @MKBHD: Ok this drone light show during the opening ceremonies of the Olympics is definitely one of the coolest thing I've ever seen. HO\u2026",
        "user.screen_name": "amalaey"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894304380268544,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "DeepEndDining"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894303608623105,
        "text": "RT @reuterspictures: Snowboarder Mark McMorris of Canada celebrates winning bronze less than a year after after nearly dying in backcountry\u2026",
        "user.screen_name": "De94989504O"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894303348506629,
        "text": "RT @TechnicallyRon: Your definitive guide to the sports of the 2018 Winter Olympics https://t.co/Oyon5qfHBc",
        "user.screen_name": "doubleflutz"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894303176491008,
        "text": "RT @olympicchannel: That feeling when you land the first triple axel by a @TeamUSA woman at the #Olympics! \ud83e\udd29\ud83e\udd17 An incredible moment for @mir\u2026",
        "user.screen_name": "BluecosmosH"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894303059161088,
        "text": "RT @bleuvaIentine: naomi campbell, london olympics closing ceremony (2012) https://t.co/Jhj45iTf1e",
        "user.screen_name": "lisa_shwayze"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894303034003456,
        "text": "I enjoy figure skating at the #Olympics as much as the next casual fan, but I cannot wait for the day they allow queer skating pairs \ud83d\ude0d",
        "user.screen_name": "rachelhwrites"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894302840942593,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "JulieFrey10"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894302836940801,
        "text": "RT @olympicchannel: That feeling when you land the first triple axel by a @TeamUSA woman at the #Olympics! \ud83e\udd29\ud83e\udd17 An incredible moment for @mir\u2026",
        "user.screen_name": "Sandy_NM"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894302585044992,
        "text": "RT @NBCOlympics: COMING UP: @mirai_nagasu returns to the #WinterOlympics!\n\nSee it on @nbc or stream it here: https://t.co/NsNuy9F46h https:\u2026",
        "user.screen_name": "yuzurunrun357"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894302501392384,
        "text": "RT @jeantinb: Sorry #Trump @POTUS \nThe Netherlands First - Second and Thirth!! #Olympics #Iceskating https://t.co/KqUbBB3jE5",
        "user.screen_name": "EduardoPradoTV"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894302324998144,
        "text": "@mitchellvii I've got a USA Hockey hat - just waiting for the real games at the Olympics",
        "user.screen_name": "caarecengi"
    },
    {
        "created_at": "Mon Feb 12 03:41:06 +0000 2018",
        "id": 962894302258057216,
        "text": "RT @therebeccasun: Mirai Nagasu didn't need to redeem herself, because she always deserved to make the 2014 Olympic team. What she did was\u2026",
        "user.screen_name": "LorenLChen"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894301842804736,
        "text": "@jimmyfallon @FallonTonight here is our daughter, Bailey, competing in some at-home winter Olympics! #goldmedalbaby https://t.co/uVMMviplwh",
        "user.screen_name": "ElverKelsey"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894301566001154,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "SteveCalderon85"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894301490569221,
        "text": "Ahh this #Olympics #IceDancing is making me want an #OutlawQueen manip of Robin &amp; Regina as figure skaters,",
        "user.screen_name": "MediaKAT1912"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894300467159041,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "kelceycee"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894300022386689,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "910escape"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894300018221056,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "thewilliam"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894299879768065,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "neptuniabox"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894299850473472,
        "text": "These Winter Olympics are making me want to watch Yuri on Ice again!!",
        "user.screen_name": "kaymarie47"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894299791745025,
        "text": "@nolanfast @Olympics Valid point. You just have to do it at 60+ miles per hour",
        "user.screen_name": "thatgirlfromOH"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894299007504385,
        "text": "RT @CdnPress: BREAKING: Canada wins gold medal in team figure skating at #PyeongChang2018 Olympics\n\n#TeamCanada https://t.co/CMrTX8xsz1",
        "user.screen_name": "MaxColella1"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894298709557253,
        "text": "@ririkyos yo the winter olympics belong to Asians this year everyone is just tearing. this. shit. upppPPPPPppp",
        "user.screen_name": "T1mco"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894298432901121,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "ghayes221"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894298202042369,
        "text": "RT @CBCOlympics: When the event is delayed, women's slopestyle will play! \n\n@spencerobrien @LaurieBlouin Brooke Voigt @aimee_fuller \n\nLive\u2026",
        "user.screen_name": "TinDizzy"
    },
    {
        "created_at": "Mon Feb 12 03:41:05 +0000 2018",
        "id": 962894298004865025,
        "text": "Things I would like to see changed in Winter Olympics: 1. Put figure skating in its own channel so I don\u2019t ever hav\u2026 https://t.co/1GBiCzFzK8",
        "user.screen_name": "Tpstewart8"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894297648549889,
        "text": "The latest U.S. Flash Feed ! https://t.co/bbXJOLu8sI #olympics #winterolympics",
        "user.screen_name": "Flash_Feed"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894297598189569,
        "text": "RT @jewellwindrow: the figure skating olympics are so intense",
        "user.screen_name": "_laureneliz"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894297426141184,
        "text": "RT @wani_chenchen: Power play in Dubai Fountain \nEXO perform in Winter Olympics closing ceremony\nJunmyeon, Kyungsoo &amp; Sehun new drama/ film\u2026",
        "user.screen_name": "silverscky"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894297040281606,
        "text": "RT @Olympics: Anything is possible. @markmcmorris #NeverGiveUp #PyeongChang2018 #Olympics https://t.co/485NH8MJUq",
        "user.screen_name": "leona_banana"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894296897740806,
        "text": "RT @ABC: U.S. figure skater Mirai Nagasu makes history, becoming the first American woman - and third overall - to land a triple axel in th\u2026",
        "user.screen_name": "lindseykhale"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894296847237120,
        "text": "RT @CNN: Last year he almost died in a snowboarding accident. Now he's won bronze at the Olympics. https://t.co/S9Rf6QufiQ https://t.co/BiZ\u2026",
        "user.screen_name": "beaucarborundum"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894296771907584,
        "text": "RT @Maryland4Trump2: What's funny is liberals are against taking military action against North Korea, but if Kim was making insensitive com\u2026",
        "user.screen_name": "inittowinit007"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894296721457153,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "_khaleesikay_"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894296658710528,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "Stillsaucinmare"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894296532824064,
        "text": "RT @TheRickyDavila: It says something when our amazing athletes can so easily represent the United States with class, grace, honor, dignity\u2026",
        "user.screen_name": "candacemickey1"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894296369201154,
        "text": "RT @BetteMidler: Yes, I\u2019m watching the Winter Olympics while grinding my teeth\nwatching our Government,  hurtling down a slippery slope unt\u2026",
        "user.screen_name": "FoxxyGlamKitty"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894296163610624,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "kimprovising"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894295945523200,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "kenianotx"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894295605874688,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "luciahoff"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894294817259521,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "jimstamant"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894294687215616,
        "text": "RT @StandingDarrell: @ericbolling \ud83c\uddfa\ud83c\uddf8I\u2019d rather watch grass grow than either a leftist/muslim propaganda show or the self indulgent orgy of\u2026",
        "user.screen_name": "norvilgirl"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894294544613378,
        "text": "RT @rockerskating: From Muramoto/Reed's protocols, the calls seem to be less strict today - 5 lvl 4 elements, 1 lvl 3 on the diagonal step,\u2026",
        "user.screen_name": "as_a_ki"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894294439878657,
        "text": "RT @AmericaFirstPAC: Congrats @RedmondGerard on bringing home the first gold medal for @TeamUSA! #Olympics2018\ud83e\udd47https://t.co/zKVon8N5OY",
        "user.screen_name": "tnevilletx2"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894294435745793,
        "text": "@NBCOlympics reference wopeople's #snowboard competition at #Olympics tell you announcers that it's called the\u2026 https://t.co/i2nGCKRShN",
        "user.screen_name": "CarlSpry"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894293944938497,
        "text": "RT @pourmecoffee: Incredible double-jump by the Russian athlete at the Olympics. https://t.co/R2oftxmlsV",
        "user.screen_name": "chelleinchicago"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894293810659328,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "lizzifranceska"
    },
    {
        "created_at": "Mon Feb 12 03:41:04 +0000 2018",
        "id": 962894293781438465,
        "text": "RT @mamaloie: @brithume @kits54 Not watching the Olympics. I would rather miss the whole week than listen to our media\u2019s drivel.",
        "user.screen_name": "SabinaSweet16"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894293034774528,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "katie_6943"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894292892225537,
        "text": "Beautiful skate from Team Italy. #olympics",
        "user.screen_name": "Destini41"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894292820873216,
        "text": "@BenSuttonISP @TeamUSA @Olympics @pyeongchang2018 What\u2019s the old saying? Flying is easy, it\u2019s the landing that\u2019s tu\u2026 https://t.co/o7cP8FplIC",
        "user.screen_name": "Mark_CWilson"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894292678250502,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "savannah_jackk"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894292661493760,
        "text": "RT @Olympics: That moment when you win your country's first ever men's singles Olympic #luge medal in history! Congratulations @Mazdzer! \ud83d\udc4f\ud83d\udc4f\u2026",
        "user.screen_name": "laureenm01"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894292183379968,
        "text": "#Annacappellini and #LucaLanotte that was just breath taking!! #figureskating  #Olympics #PyeongChang2018 #Italy",
        "user.screen_name": "beakey3"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894291923238913,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "BMK0204"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894291919036416,
        "text": "RT @CBCNews: BREAKING: Canada's first gold in Pyeongchang will be in figure skating https://t.co/8wKDWpzISR",
        "user.screen_name": "_warriorstrongx"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894291763740672,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "RedTheTrucker"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894291302600704,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "gabbyrooo"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894290908139520,
        "text": "RT @RepMarkMeadows: While some in the media look fondly upon North Korea during the Olympics, I can't help but recall this from 2 weeks ago\u2026",
        "user.screen_name": "nickbarnesaus"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894290883174400,
        "text": "https://t.co/PaqtIc7kjF: \"Winter Olympics 2018: Windy conditions cause Aimee Fuller problems in first run\" https://t.co/2jMRxHLmdr",
        "user.screen_name": "SportsNewsBet"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894290585255936,
        "text": "RT @FoxNews: CNN slammed for glowing puff piece about Kim Jong Un's sister at Olympics https://t.co/OBkZEtFD15",
        "user.screen_name": "rp_robinson"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894290446835712,
        "text": "RT @GlobalBC: Do you care about the Olympics at all?\nhttps://t.co/maGeVrznKZ",
        "user.screen_name": "Mike49117484"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894290409132032,
        "text": "RT @USATODAY: It doesn\u2019t get much more impressive than this. https://t.co/La2NeZLE9J #Olympics",
        "user.screen_name": "anboyd0806"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894290161754112,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "silkyjoons"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894289645768704,
        "text": "RT @RealMAGASteve: RETWEET - If you believe @CNN should be recognized as North Korea's Official State Propaganda Network after their perver\u2026",
        "user.screen_name": "cindy_uzzell"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894289633124353,
        "text": "RT @btschartdata: [!] Another BTS' song played at #Olympics , '21st Century Girl' was used as background music in Women Hockey Match, Canad\u2026",
        "user.screen_name": "PinkVunny"
    },
    {
        "created_at": "Mon Feb 12 03:41:03 +0000 2018",
        "id": 962894289591291904,
        "text": "I\u2019m watching the partner ice skating Olympics at Apollo\u2019s and there\u2019s no sound so I\u2019m imagining all of them are ska\u2026 https://t.co/Wuw4HJnkbl",
        "user.screen_name": "JordanBillings1"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894289368899584,
        "text": "\ud83c\udf47 It's a damn shame McKayla Maroney isn't in the Olympics this year (27 Photos)\n\nhttps://t.co/V46adsI7xc",
        "user.screen_name": "eustoliagasser"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894289121488896,
        "text": "RT @Slate: Mirai Nagasu is the third woman to do a triple axel in the Olympics. Watch all three: https://t.co/gQO2lcL2Uh https://t.co/HveC5\u2026",
        "user.screen_name": "NigelHaarstad"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894289117241344,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Minion_Vale"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894288655929344,
        "text": "RT @nytimes: The Olympics in Pyeongchang are in full swing. Here's what you may have missed, from the perspective of our photographers. htt\u2026",
        "user.screen_name": "lolahwalker"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894288408363009,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "carmenyount"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894287829655552,
        "text": "RT @SInow: You can't fake this kind of chemistry https://t.co/rEsmxO8rHs",
        "user.screen_name": "Mayrely_Rojas"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894287439581184,
        "text": "Highkey gonna start saving for Tokyo 2020 Olympics at the end of this year.",
        "user.screen_name": "MilenaToro_"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894287095713792,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "RouhiJaan"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894287053770752,
        "text": "RT @ABC: U.S. figure skater Mirai Nagasu makes history, becoming the first American woman - and third overall - to land a triple axel in th\u2026",
        "user.screen_name": "PottstownNews"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894287041019904,
        "text": "RT @CBCAlerts: BREAKING: Canada's first gold in Pyeongchang will be in figure skating https://t.co/lZnL5HPwQT",
        "user.screen_name": "Toby1Kanobe"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894286831398912,
        "text": "RT @Lesdoggg: Then this outfit LORDT!!!!! @NBCOlympics @Olympics https://t.co/W6sMnrvuPg",
        "user.screen_name": "DJMKHennelz"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894286785261568,
        "text": "RT @KAy_TIEmyshoes: I love the Olympics https://t.co/YarQnjbr9c",
        "user.screen_name": "lovalle25"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894285971623937,
        "text": "RT @CNN: Last year he almost died in a snowboarding accident. Now he's won bronze at the Olympics. https://t.co/S9Rf6QufiQ https://t.co/BiZ\u2026",
        "user.screen_name": "KimiMom3"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894285594091521,
        "text": "This is what self confidence looks like. An exceptional performance! Outstanding! \n#Olympics #OlympicWinterGames https://t.co/CEb6ytuO3j",
        "user.screen_name": "prevostscifi"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894285593968640,
        "text": "RT @AlpineGarrison: Is everybody enjoying the Olympics?\n\nAlpine Garrison actually went through the trials but unfortunately didn't make the\u2026",
        "user.screen_name": "kindy0416"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894285589721088,
        "text": "RT @LegendsExoOT9: Dont forget to watch Nations Boygroup EXO who will perform as Koreas representatives in Olympics #ClosingCeremony on 25t\u2026",
        "user.screen_name": "mylordsehun"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894285564608512,
        "text": "RT @hotfunkytown: Race reared its ugly head at the Olympics.  Davis boycotted the opening ceremonies using #blackhistorymonth\n\nFor Shani Da\u2026",
        "user.screen_name": "cordia_83"
    },
    {
        "created_at": "Mon Feb 12 03:41:02 +0000 2018",
        "id": 962894285401042944,
        "text": "RT @vonhonkington: really excited for the olympics this year https://t.co/5UMAIoKh7U",
        "user.screen_name": "norimaro_game"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894285334081536,
        "text": "RT @TheEconomist: On some days during the 2016 Olympics almost half the tests were abandoned because the testers couldn't find the athletes\u2026",
        "user.screen_name": "stephaniekays"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894284998565889,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "MEG_nog98"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894284881096706,
        "text": "@NickyBlack17 Jason Belmonti pro bowler is from Australia I call him the thunder from down under he won championshi\u2026 https://t.co/VCJualUNK1",
        "user.screen_name": "TheRobertDennis"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894284826451968,
        "text": "@JKNo_emi @the50person It\u2019s the Olympics you will not get any calls...",
        "user.screen_name": "chiburahakkai"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894284725899264,
        "text": "RT @byrdinator: This story is literally \u201cKim Jong Un\u2019s sister got more media attention than Mike Pence!\u201d\n\nThere\u2019s something uniquely self-a\u2026",
        "user.screen_name": "SnarkActual"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894284545544192,
        "text": "RT @TechnicallyRon: Your definitive guide to the sports of the 2018 Winter Olympics https://t.co/Oyon5qfHBc",
        "user.screen_name": "RikkuPyon"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894284268634112,
        "text": "Figure skaters have nice ass's hahaha xD thanks Olympics !! \ud83c\udf51\ud83c\udf51\ud83c\udf51\ud83d\ude0d\ud83d\ude0d tight pants are great hehe",
        "user.screen_name": "JBawesome69"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894282871967745,
        "text": "RT @LauraEichsteadt: Rippon better get a medal after making me weep with that routine \ud83d\ude0d\ud83d\ude22 #Olympics",
        "user.screen_name": "Hhutchison23"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894282855272448,
        "text": ".@NBCSN #Olympics \"coverage\". Two minutes of actual competition, five minutes of commercials, three minute \"feature\u2026 https://t.co/6V7AS6YcK8",
        "user.screen_name": "retrofade"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894282746195969,
        "text": "RT @Lesdoggg: Shiiiiit like to see you give her a bad score!!! @NBCOlympics @Olympics https://t.co/0krtijP4vb",
        "user.screen_name": "hopscotchy"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894282515300352,
        "text": "RT @HarlanCoben: Me: I\u2019ve never watched luge. I know nothing about it. \n\nMe 20 minutes later: Turns 9 through 12 are really the key to vict\u2026",
        "user.screen_name": "DominicDs34"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894282368671744,
        "text": "RT @jigolden: All of these winter sports look incredibly hard. But, I think the scoring for figure skating is the most brutal by far. #Olym\u2026",
        "user.screen_name": "DiChristine"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894282142044160,
        "text": "RT @CBCOlympics: When the event is delayed, women's slopestyle will play! \n\n@spencerobrien @LaurieBlouin Brooke Voigt @aimee_fuller \n\nLive\u2026",
        "user.screen_name": "_angelaandrews"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894282112761862,
        "text": "RT @MKBHD: Ok this drone light show during the opening ceremonies of the Olympics is definitely one of the coolest thing I've ever seen. HO\u2026",
        "user.screen_name": "PavelBicu"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894281932328961,
        "text": "RT @TechnicallyRon: Your definitive guide to the sports of the 2018 Winter Olympics https://t.co/Oyon5qfHBc",
        "user.screen_name": "BGHilton"
    },
    {
        "created_at": "Mon Feb 12 03:41:01 +0000 2018",
        "id": 962894281424982017,
        "text": "Speaking of the Olympics, Is it normal for my TOES to hurt after a very long run because I feel like my body is rap\u2026 https://t.co/daSHwgbG4T",
        "user.screen_name": "StephLauren"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894280514850817,
        "text": "@AmazingArtist89 @RenOperative_ I'm not sure how this works...is the child racist...are the Olympics racist.....is\u2026 https://t.co/rWO2lUBbN6",
        "user.screen_name": "StryderHazuki"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894280070189056,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "fsfscarlett"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894279575207937,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "john14_15"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894279524999168,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "drgaynascully"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894279466192896,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "skrelp"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894279378112512,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "catwright17"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894279302696961,
        "text": "RT @ABC: U.S. figure skater Mirai Nagasu makes history, becoming the first American woman - and third overall - to land a triple axel in th\u2026",
        "user.screen_name": "ashwagners"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894279281725440,
        "text": "RT @KAy_TIEmyshoes: I love the Olympics https://t.co/YarQnjbr9c",
        "user.screen_name": "jazzt98"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894278740578305,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "SteveCalderon85"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894278648311810,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "tannerspearman"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894278568550400,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "peterakaspidey"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894278094704640,
        "text": "RT @RepMarkMeadows: While some in the media look fondly upon North Korea during the Olympics, I can't help but recall this from 2 weeks ago\u2026",
        "user.screen_name": "CwarkentinC"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894278077886464,
        "text": "RT @KAy_TIEmyshoes: I love the Olympics https://t.co/YarQnjbr9c",
        "user.screen_name": "Jenna0019"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894278031654913,
        "text": "This Italian figure skating lair did awesome themselves. \ud83d\udc4d\ud83c\udffb\u26f8 #olympics",
        "user.screen_name": "BriThibodeaux"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894277972983808,
        "text": "RT @fs_gossips: @CBCOlympics @Pchiddy There's no bigger justice today than Patrick becoming an Olympics Champion. Best present for Valentin\u2026",
        "user.screen_name": "H1STORYMAK3R"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894277775945730,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "itssdani23"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894277440430080,
        "text": "For how big of a sports fan i am. I truly hate the olympics with a passion \ud83e\udd37\ud83c\udffb\u200d\u2642\ufe0f #SorryNotSorry #Boring #SnoozeFest #WWEIsBetter",
        "user.screen_name": "Riffell_17"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894277280870400,
        "text": "RT @squishysoo0: ''exo only breaks exo's records''\n''like idol, like fans''\n\nour sister, evgenia medvedeva has proven those two sentences.\u2026",
        "user.screen_name": "zuali_94"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894277192929280,
        "text": "RT @carolynmaeee: dam when did the olympics get so intense?\ud83d\ude33\ud83d\ude33 https://t.co/IienOHy5uq",
        "user.screen_name": "BumblingBombus"
    },
    {
        "created_at": "Mon Feb 12 03:41:00 +0000 2018",
        "id": 962894277004075008,
        "text": "RT @94_degrees: Russian Figure Skater, Evgeniia Medvedeva who\u2019s an EXO-L set a new world record in the Pyeongchang Olympics &amp; mentioned EXO\u2026",
        "user.screen_name": "dyeolie61"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894276811198464,
        "text": "RT @barbs_cr8v: @MartinCox0155 @mariacilene212 @purpleamma1 @ardnasremmos @Lucretiasbear @geraghty_cheryl @mflemming185 Goodnight Martin! G\u2026",
        "user.screen_name": "mariacilene212"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894276211421184,
        "text": "RT @thejimpster: @JonAcuff To be fair, if you are throwing a person in the air.. I'd feel much better if you at least liked me. #ouch #Olym\u2026",
        "user.screen_name": "GenesisColema19"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894276156825600,
        "text": "RT @BetteMidler: Yes, I\u2019m watching the Winter Olympics while grinding my teeth\nwatching our Government,  hurtling down a slippery slope unt\u2026",
        "user.screen_name": "krisconner_"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894275456524289,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "rotchgates"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894275263565824,
        "text": "I think snowboarders might be the only athletes I believe when they say \"I'm just stoked to be here &amp; get in a grea\u2026 https://t.co/FISZiBWfBe",
        "user.screen_name": "ellebrownlee"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894275087396864,
        "text": "RT @dereklew: Watching Team Canada erupt into applause when American skater Mirai Nagasu became only the third woman to land a triple axel\u2026",
        "user.screen_name": "softandstrongly"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894274953207808,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "efilicetti_"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894274709766145,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "shebetheonelive"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894274407825408,
        "text": "RT @diehrd9: You eat more in a day then every North Korean at the Olympics eats annually \n\nYet you still think your words matter\n\n#FreetheT\u2026",
        "user.screen_name": "LindaAs04621507"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894274206543872,
        "text": "RT @thehill: Dutch fans troll Trump at the Olympics with flag: \"Sorry Mr. President. The Netherlands First... And 2nd... And 3rd\" https://t\u2026",
        "user.screen_name": "BlackLoisLane"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894274110074881,
        "text": "RT @ArthurSchwartz: CNN: Our puff piece on murderous dictator Kim Jong-un\u2019s sister is the most embarrassing piece of journalism that anyone\u2026",
        "user.screen_name": "Blake1x"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894273808134144,
        "text": "Beautiful, Italy.\n\n#olympics",
        "user.screen_name": "AquariusOnFire"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894273518678016,
        "text": "RT @tictoc: Redmond Gerard wins the first gold medal for Team USA at #PyeongChang2018 #Olympics for his performance at men's snowboard slop\u2026",
        "user.screen_name": "kristynaweh"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894273023590400,
        "text": "RT @insideskating: \u201cI am impressed with myself, if that makes sense\u201d - no better time to come back to our interview with @mirai_nagasu, don\u2026",
        "user.screen_name": "atsuko_kaineko"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894272876961792,
        "text": "Missed u @ winter Olympics",
        "user.screen_name": "Churra08"
    },
    {
        "created_at": "Mon Feb 12 03:40:59 +0000 2018",
        "id": 962894272792969217,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "jascnstcdd"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894272424022022,
        "text": "Ohhhhhhhh @EricaWFAN and @LRubinson feuding over #Olympics",
        "user.screen_name": "BGoody30"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894272381976576,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "ShaLongSr"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894272277241862,
        "text": "Ice dancing is so freaking mesmerizing. Eyes glued to the television all wrapped up in the story, lifts, moves. Agh\u2026 https://t.co/dG78TQTYSn",
        "user.screen_name": "rosefox13"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894272004546561,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "_xXxBabyy"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894271887101952,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "annieschenk"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894271698251777,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "sana_93"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894271492669440,
        "text": "RT @TheRickyDavila: It says something when our amazing athletes can so easily represent the United States with class, grace, honor, dignity\u2026",
        "user.screen_name": "claudiggs"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894271442509824,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "claudiameadows2"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894271371186176,
        "text": "RT @3L3V3NTH: Olympics have stricter rules than national elections",
        "user.screen_name": "phendricks71"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894271333335040,
        "text": "NASA Seeks the Gold in Winter season Olympics\u00a0Snow https://t.co/mmcnEobjSJ",
        "user.screen_name": "newsroundcom"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894271299883008,
        "text": "VONETTA FLOWERS\nthe first African-American person, of any gender, to win a gold medal at the Winter Olympics.  Vone\u2026 https://t.co/cvOPm4BVrD",
        "user.screen_name": "f_francavilla"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894271199240193,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "shaythag"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894270981201921,
        "text": "RT @imbeccable: if you were skating at the olympics, which song would you choose?",
        "user.screen_name": "Harshmelllo"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894270947627008,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "assthantics"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894270909661184,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "nikkigibala"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894270045749249,
        "text": "RT @JamesHasson20: Here are stories fawning over North Korea at the Olympics from:\n-Wapo\n-Wall Street Journal\n-NYT\n-CNN\n-ABC News\n-NBC News\u2026",
        "user.screen_name": "edwardjames7"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894269747904512,
        "text": "RT @Slate: Mirai Nagasu is the third woman to do a triple axel in the Olympics. Watch all three: https://t.co/gQO2lcL2Uh https://t.co/HveC5\u2026",
        "user.screen_name": "lilei2000"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894269697507328,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "___DrJ___"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894269441753088,
        "text": "RT @martyn_williams: So far, viewers of North Korea's main TV channel have seen just two still images of Olympic competition. Monitoring re\u2026",
        "user.screen_name": "AkikoFujita"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894269236232194,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "emxbye"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894269022392325,
        "text": "RT @WSJ: Adam Rippon is the first openly gay U.S. figure skater and leading up to the Winter Olympics found himself in a political drama wi\u2026",
        "user.screen_name": "CatrinaRazvan"
    },
    {
        "created_at": "Mon Feb 12 03:40:58 +0000 2018",
        "id": 962894268733034496,
        "text": "RT @NumbersMuncher: Me in 2017: I can't understand how people could be so stupid to fall for fake Facebook stories promoted by Russia.\n\nMe\u2026",
        "user.screen_name": "KayeHigh"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894268191911936,
        "text": "What Brands and Sponsored Athletes Can and Can\u2019t Say, Wear and Do During the Olympics https://t.co/HgVRqRFpFI",
        "user.screen_name": "egriffing"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894268053577729,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "NicoleNicole070"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894267894116352,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "_balloonsfly_"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894267642458117,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Maxlm22_"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894267445403648,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "jonowles88"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894267411726336,
        "text": "RT @AthleteSwag: Team USA figure skater Mirai Nagasu is the first American woman to land a triple axel at the Winter Olympics https://t.co/\u2026",
        "user.screen_name": "amdion13"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894267231252480,
        "text": "RT @AliciaAmin: Julian Yee is the first ever Malaysian to compete in the Winter Olympics &amp; so many of us sleeping on him (incl me)\n\nHe\u2019s wo\u2026",
        "user.screen_name": "ToxicHaiqal"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894266581291009,
        "text": "RT @morningpassages: Isn\u2019t EXO so sweet to send a signed album to Evgenia knowing that she is a world champion Eri competing in Olympics. T\u2026",
        "user.screen_name": "petite_soo"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894266526785537,
        "text": "RT @chr1sa: Best view of the @Intel drone swarm performance at the Olympics https://t.co/mCsILkq38Z",
        "user.screen_name": "livefromtheabys"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894266199572480,
        "text": "RT @iWatchiAm: It would be really nice if the NBC livestream didn't cut off the first half of everyone's routine tonight. #Olympics",
        "user.screen_name": "elknight20"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894266115739648,
        "text": "RT @redsteeze: Reuters looked strong in bringing home the gold for North Korea today but coming through late, the New York Times. Think Pro\u2026",
        "user.screen_name": "PeeteySDee"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894265637580801,
        "text": "RT @EXOVotingSquad: EXO's diary - 11th Feb 2018\n\nOur fellow EXOL, Evgenia Medvedeva has set a new world record of 81.06 in Pyeong Chang Oly\u2026",
        "user.screen_name": "exo60464427"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894265532801024,
        "text": "#QAnon #MAGA #FollowTheWhiteRabbit #Olympics \n\nLook at McCain's donor list. \n\nhttps://t.co/5cL9U5LL9p",
        "user.screen_name": "AngelaLily0501"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894265360662528,
        "text": "me linsey katey and cooper are sitting here literally screaming for these figure skaters on the olympics",
        "user.screen_name": "kelsiedanderson"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894265163624450,
        "text": "#Olympics Twitter is \ud83d\udd25right now.",
        "user.screen_name": "rob_blog"
    },
    {
        "created_at": "Mon Feb 12 03:40:57 +0000 2018",
        "id": 962894264597278720,
        "text": "You know the schedule for skating is arranged ahead of time.\nYou can work with that and move your training to suit\u2026 https://t.co/baPRzEh59k",
        "user.screen_name": "Jinath_Hyder"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894264098283520,
        "text": "Can\u2019t believe they still went ahead with the women\u2019s slope style event. Really unfair and unsafe for these women.\u2026 https://t.co/HiobEjcEEn",
        "user.screen_name": "sarsilvz"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894263842373632,
        "text": "RT @guybranum: The Winter Olympics and Aruba are the only remaining vestiges of the Dutch Empire.",
        "user.screen_name": "rachelmgiles"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894263276118017,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "g_birdslide"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894263095738368,
        "text": "RT @TeamUSA: Standings after the first #snowboard slopestyle run! \u2b07\ufe0f\n\n1 - @jamieasnow \ud83c\uddfa\ud83c\uddf8 \n2 - Silje Norendal \ud83c\uddf3\ud83c\uddf4\n3 - @jessika_jenson \ud83c\uddfa\ud83c\uddf8\n\nONE\u2026",
        "user.screen_name": "BPratto"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894262772928514,
        "text": "RT @VP: We are determined to make sure that even in the midst of the powerful background &amp; idealism of the Olympics, the World is reminded\u2026",
        "user.screen_name": "WhatSquinkyEye"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894262160388097,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "aquianakii"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894261950693376,
        "text": "RT @FoxNews: 'It's Absurd': @edhenry Blasts @CNN for 'Sucking Up' to Kim Jong Un's Sister https://t.co/9m6Lnh36LB",
        "user.screen_name": "Kaczbo1"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894261095198720,
        "text": "RT @AP_Sports: The fates of Lindsey Vonn, Mikaela Shiffrin and many of the best speed skiers at the Olympics are tied to the handiwork of a\u2026",
        "user.screen_name": "ChancePlett"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894260973527040,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "maryfrances1128"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894260969259009,
        "text": "RT @chalanlexi: MIDORI-MAO-MIRAI --- Three women who landed the difficult triple axel in the Olympics #Midori, #MaoAsada and @mirai_nagasu.\u2026",
        "user.screen_name": "kyasarin123"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894260717735936,
        "text": "RT @peachyblackgorl: as the winter Olympics begin....never forget about Surya Bonaly, a French figure skater who did a backflip and landed\u2026",
        "user.screen_name": "ThePrimadonna_k"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894260633767936,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "MuseAmicK"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894260524781568,
        "text": "RT @charliekirk11: South Korea only exists thanks to US troops sacrifice in the 1950\u2019s \n\n36,000 Americans died so South Korea could be free\u2026",
        "user.screen_name": "jjsjulia"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894260348575744,
        "text": "@hulu @NBCOlympics @nbc @olympics  (1/2) I'm sorry, I've really tried but your monopoly US Olympics coverage is UNW\u2026 https://t.co/7pp4lTaYru",
        "user.screen_name": "scottish_expat"
    },
    {
        "created_at": "Mon Feb 12 03:40:56 +0000 2018",
        "id": 962894260256301062,
        "text": "like I said, if anyone needs me I\u2019ll be watching the olympics for the next two weeks",
        "user.screen_name": "_paigesoria"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894259857838080,
        "text": "RT @Heritage: The perverse fawning over brutal Kim Jong-un\u2019s sister at the Olympics @bethanyshondark https://t.co/CTijmDXibJ https://t.co/O\u2026",
        "user.screen_name": "2smokytop"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894259434205184,
        "text": "RT @linzsports: Four years ago, Adam Rippon and MIrai Nagasu were eating in-n-out burger in California, crying and watching the Sochi Olymp\u2026",
        "user.screen_name": "ichi1054"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894259077529600,
        "text": "RT @vlissful: @jintellectually okay for those who are confused, read the article here\n\nthe nbc guy said \u201cEvery Korean will tell you that Ja\u2026",
        "user.screen_name": "JimIntenseStare"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894259035635714,
        "text": "RT @C_hodgy: Can we pause and take a second to appreciate the RIDICULOUSLY AWESOME amount of curling exposure to the world during the Olymp\u2026",
        "user.screen_name": "CurlingZone"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894258733711360,
        "text": "RT @McGrumpenstein: why isn't there a shovelling event in the winter olympics",
        "user.screen_name": "JD_Wisco"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894258708467712,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "citlalli861"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894258293239809,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "melakatweets"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894258016530433,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "_JamilaImani_"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894257836113920,
        "text": "RT @USFigureSkating: It\u2019s the FINAL segment of the #FigureSkating Team Event. @MaiaShibutani and @AlexShibutani are up for #TeamUSA. Let\u2019s\u2026",
        "user.screen_name": "csnyder887"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894257206968320,
        "text": "RT @GLValentine: me: this year i'll be able to handle the olympics!\n\nannouncer, casually, about a sidelined skier, \"All the work of the pas\u2026",
        "user.screen_name": "Kartos"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894257093775361,
        "text": "@Lesdoggg @NBCOlympics @Olympics WOO HOO!!!!!!!!!",
        "user.screen_name": "Nancyrussell"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894256993067008,
        "text": "RT @TheRickyDavila: It says something when our amazing athletes can so easily represent the United States with class, grace, honor, dignity\u2026",
        "user.screen_name": "suzan5150"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894256900685824,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "drkkyu"
    },
    {
        "created_at": "Mon Feb 12 03:40:55 +0000 2018",
        "id": 962894256238153728,
        "text": "RT @redsteeze: Reuters looked strong in bringing home the gold for North Korea today but coming through late, the New York Times. Think Pro\u2026",
        "user.screen_name": "k3rdann"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894255978176514,
        "text": "RT @tictoc: The #Olympics host nation, South Korea, earned its first gold medal in 2018 thanks to Lim Hyo-Jun in the men's short track 1500\u2026",
        "user.screen_name": "kristynaweh"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894255797751809,
        "text": "RT @ksannews: WATCH: Here's a great explainer about the differences between skates athletes use at the #Olympics https://t.co/ofrM5CBQv8",
        "user.screen_name": "FatherLarryR"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894255340642304,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Mellijuana"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894255311089664,
        "text": "RT @ABC: U.S. figure skater Mirai Nagasu makes history, becoming the first American woman - and third overall - to land a triple axel in th\u2026",
        "user.screen_name": "Eric_JamesSmith"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894254933602304,
        "text": "RT @ArthurSchwartz: CNN: Our puff piece on murderous dictator Kim Jong-un\u2019s sister is the most embarrassing piece of journalism that anyone\u2026",
        "user.screen_name": "Vanqaro"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894254916952064,
        "text": "RT @BetteMidler: Yes, I\u2019m watching the Winter Olympics while grinding my teeth\nwatching our Government,  hurtling down a slippery slope unt\u2026",
        "user.screen_name": "JoshuaDeck2"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894254740668416,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "kateyholland"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894254690525184,
        "text": "RT @ARSenMissyIrvin: NBC's political spin on a brutal dictator regime and country who is threatening the world with nuclear weapons is unbe\u2026",
        "user.screen_name": "laneighpfalser"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894254342361089,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "Xclusive_Ishyyy"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894254279405568,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "candygraham0813"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894253713248256,
        "text": "@jaketapper But then who will ABC be able to say will have stole the show when he hosts the Olympics?",
        "user.screen_name": "Tfalwell"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894253235097600,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "GittaSapiano"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894253205721088,
        "text": "RT @saskystewart: I'd be interested to see why (academically) our valuation of female athletes in sports sponsorship and media coverage shi\u2026",
        "user.screen_name": "ruthiefisher"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894252756951040,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "conoriburton"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894252652015616,
        "text": "RT @CBCOlympics: #CAN's @tessavirtue &amp; @ScottMoir skate 5th in the last event of the #FigureSkating Team Event. Even if they finish last, C\u2026",
        "user.screen_name": "Justin481"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894252375027712,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "ghoulgoulash"
    },
    {
        "created_at": "Mon Feb 12 03:40:54 +0000 2018",
        "id": 962894251943108608,
        "text": "RT @baekyeolangst: exols are amazing. exo's fans are actual surgeons, teachers, dentists (especially that one girl who checked pcy's teeth\u2026",
        "user.screen_name": "smilechennieee"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894251624312833,
        "text": "RT @Capital_Bromo: Periodic reminder that the Winter Olympics have arrived: https://t.co/va2xwNovCX",
        "user.screen_name": "allmodelguys1"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894251431522304,
        "text": "@cdbnyc @HeyGeek I AM. That's literally what I said!!! \" it always just looks like a bunch of ducklings sort of gli\u2026 https://t.co/eWicri1abF",
        "user.screen_name": "j_tak"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894251410509824,
        "text": "RT @peachyblackgorl: as the winter Olympics begin....never forget about Surya Bonaly, a French figure skater who did a backflip and landed\u2026",
        "user.screen_name": "Samie_thomps"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894250236137477,
        "text": "The Winter Olympics always makes me want to try and do ice skating but I know imma fall straight on my butt",
        "user.screen_name": "kelseythies1"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894250177454081,
        "text": "RT @JoyPuder: \u201cThis might be my first Olympics, but it\u2019s not my first rodeo.\u201d-@Adaripp \n\nThis is the perfect Housewives tagline. #Olympics\u2026",
        "user.screen_name": "peteratthepark"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894249590251520,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "four_ofthem"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894249409818624,
        "text": "RT @CloydRivers: Rollin' into the Olympics like.... Merica.\nhttps://t.co/ep2Qe5YCo1",
        "user.screen_name": "bgill7831"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894248868810752,
        "text": "RT @sportingnews: Mirai Nagasu becomes the first USA women's figure skater to land an extremely difficult jump in #olympics competition. ht\u2026",
        "user.screen_name": "AceSports11"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894248659079168,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "boldlyshuffle"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894248394698752,
        "text": "The #FigureSkating #TeamEvent isn't over yet, but #TeamCanada has the gold!!! #Congrats #Olympics https://t.co/hf4kfkELwT",
        "user.screen_name": "MegGregory"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894248357089281,
        "text": "#ShaniDavis apparently started his period at the Olympics, you lost the toss, break a leg or both",
        "user.screen_name": "scottmorehead"
    },
    {
        "created_at": "Mon Feb 12 03:40:53 +0000 2018",
        "id": 962894247920795648,
        "text": "RT @HarlanCoben: Me: I\u2019ve never watched luge. I know nothing about it. \n\nMe 20 minutes later: Turns 9 through 12 are really the key to vict\u2026",
        "user.screen_name": "cbns007"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894247220441088,
        "text": "@Lesdoggg @NBCOlympics @Olympics His hair!!! I\u2019ve never seen its equal.",
        "user.screen_name": "Drsteward"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894247203614721,
        "text": "RT @780613: ajhjhjh im screaminf @ how knets are calling the olympics speed skaters \ube59\ud0c4\uc18c\ub144\ub2e8",
        "user.screen_name": "yeahhzmin"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894247153291266,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "GabiNoel4"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894247077834753,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "IagosRavenWife"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894246792613888,
        "text": "RT @DylansFreshTake: Congrats to Mirai Nagasu on becoming the first American \ud83c\uddfa\ud83c\uddf8 woman to ever land a Triple Axel at the Olympics.\n\n#WinterO\u2026",
        "user.screen_name": "ToreeWit2Es"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894246691848192,
        "text": "RT @morningpassages: Isn\u2019t EXO so sweet to send a signed album to Evgenia knowing that she is a world champion Eri competing in Olympics. T\u2026",
        "user.screen_name": "dddyixing"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894246628896768,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "kerin_wotsirb"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894246574481409,
        "text": "RT @KPRC2: We're talking Bitcoins and why Houston could be a hotbed of activity for the cryptocurrency. Cha-ching! Tonight after the Olympi\u2026",
        "user.screen_name": "kymmer7691"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894246415032320,
        "text": "RT @hnltraveler: NBC's Olympics Asian Analyst Joshua Cooper Ramo says having the next three Olympics in Korea, Japan and China is an \"oppor\u2026",
        "user.screen_name": "rox_c"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894246167461888,
        "text": "RT @benshapiro: All you need to know about the media\u2019s not-so-secret love for Marxist dictatorships can be seen in their treatment of the c\u2026",
        "user.screen_name": "StellaLorenzo5"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894245991518208,
        "text": "@Lesdoggg @NBCOlympics @Olympics Ya, i didn\u2019t get it, but he looked incredible regardless",
        "user.screen_name": "lovlilady88"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894245878255617,
        "text": "ok...see i thought the ice dance free skate was gon have some....u know....LATIN RITMO!!! its like whats happpening\u2026 https://t.co/eJuuUlSbk8",
        "user.screen_name": "LilMissDiabla"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894245680971776,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "Wh1tneyyy"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894245664210944,
        "text": "When the event is delayed, women's slopestyle will play! \n\n@spencerobrien @LaurieBlouin Brooke Voigt @aimee_fuller\u2026 https://t.co/7QlCzChmvk",
        "user.screen_name": "CBCOlympics"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894245635022848,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "bourgeois_maci"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894245571907585,
        "text": "RT @FlowerPrince_CY: K-pop fan Medvedeva finds her groove to set record. #EXOL #BestFanArmy #iHeartAwards @weareoneexo  https://t.co/vah21T\u2026",
        "user.screen_name": "chanbaekoxygen"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894245559488512,
        "text": "RT @JoyPuder: \u201cThis might be my first Olympics, but it\u2019s not my first rodeo.\u201d-@Adaripp \n\nThis is the perfect Housewives tagline. #Olympics\u2026",
        "user.screen_name": "skylerzane"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894245181800448,
        "text": "RT @VictorianDamsel: AWESOME to see Tim Goddard, Adelaide fire spinner, interviewed by the official Olympic news. His contribution to the C\u2026",
        "user.screen_name": "loveracehorses1"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894245144047616,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "hmmjinseiwanani"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894244968108033,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "spino255"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894244926038016,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "julioatena"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894244691304448,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "Emassey678"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894244506632192,
        "text": "That feeling when you land the first triple axel by a @TeamUSA woman at the #Olympics! \ud83e\udd29\ud83e\udd17 An incredible moment for\u2026 https://t.co/VrQqxdHLkb",
        "user.screen_name": "olympicchannel"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894244296847360,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Julia_Huynh"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894244041150465,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "amber_g95"
    },
    {
        "created_at": "Mon Feb 12 03:40:52 +0000 2018",
        "id": 962894243844026368,
        "text": "This ice dance Italy is doing to the \u201cLife Is Beautiful\u201d soundtrack is incredible. I have the chills. So much emotion. #Olympics",
        "user.screen_name": "yesterdaysprize"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894243315544066,
        "text": "Anna and Luca are stunning, holy shit #PeyongChang2018 #olympics #Olympics2018",
        "user.screen_name": "Lady_Fantasmic"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894243315535872,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "bIueberryfarmer"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894242459697152,
        "text": "RT @94_degrees: Russian Figure Skater, Evgeniia Medvedeva who\u2019s an EXO-L set a new world record in the Pyeongchang Olympics &amp; mentioned EXO\u2026",
        "user.screen_name": "exoelyxion94"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894242447265792,
        "text": "RT @TechnicallyRon: Your definitive guide to the sports of the 2018 Winter Olympics https://t.co/Oyon5qfHBc",
        "user.screen_name": "gclaramunt"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894242443137024,
        "text": "I think instead of sending our best to the Olympics we should send our worst. Like do Hunger games style lotteries\u2026 https://t.co/0VEu0TQu1c",
        "user.screen_name": "GhostyGirl01"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894242132750336,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "alejandratimm"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894241956581376,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "blahtrbl"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894241692188672,
        "text": "NOOOOOOOOOOOOOOOO Muramoto &amp; Reed were doing so BEAUTIFULLY! Good God I really felt that fall...T~T' #Olympics #OlympicGames2018",
        "user.screen_name": "MMBCO_"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894241679773696,
        "text": "RT @Lesdoggg: Damn.. @NBCOlympics @Olympics https://t.co/rsfInnwNS1",
        "user.screen_name": "Untitled_84"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894241453215744,
        "text": "RT @jpbrammer: my favorite part of the Olympics so far was when Aja jumped off that box",
        "user.screen_name": "_zombiequeen"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894240815689728,
        "text": "RT @JayCostTWS: The Olympics pitch: \u201cHey you know that sport you don\u2019t really like ... well what if we combine it with 30 other sports you\u2026",
        "user.screen_name": "S_Wallace_"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894240790470656,
        "text": "Whose watching too? I just love it, the artristy and beauty... \u2014 watching Figure skating at the Winter Olympics",
        "user.screen_name": "CCsCelebrations"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894240333246464,
        "text": "RT @Slate: Mirai Nagasu is the third woman to do a triple axel in the Olympics. Watch all three: https://t.co/gQO2lcL2Uh https://t.co/HveC5\u2026",
        "user.screen_name": "UniteWomenOrg"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894240043823106,
        "text": "Kind of obsessed with the personalities of American ice dancing duo #ShibSibs (Maia and Alex Shibutani) - nice to s\u2026 https://t.co/AeD2DkYoUg",
        "user.screen_name": "MenoxMusic"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894239414730752,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "RhiannonRappel"
    },
    {
        "created_at": "Mon Feb 12 03:40:51 +0000 2018",
        "id": 962894239247060995,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "7CSkowronski"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894239175729157,
        "text": "RT @jhoeck: Surrounded by all the buzz for the Winter Olympics, we're about to have our own mini Olympics in Yankton for the next week...\u2026",
        "user.screen_name": "GHSD605"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894238953496576,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "martha__norton"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894238274019331,
        "text": "RT @jpbrammer: my favorite part of the Olympics so far was when Aja jumped off that box",
        "user.screen_name": "finlay_the_king"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894238257111040,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "deniseg1996"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894238135607296,
        "text": "RT @chr1sa: Best view of the @Intel drone swarm performance at the Olympics https://t.co/mCsILkq38Z",
        "user.screen_name": "william_vab"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894237938454528,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "algr95"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894237284134912,
        "text": "The #Olympics end right as #MarchMadness gets ready to crank up. I'm not sure I can catch up on enough #sleep in those few days. #spark",
        "user.screen_name": "MBHolder21"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894235719622656,
        "text": "RT @CloydRivers: The Olympics. Just another opportunity to prove America dominates the world. \ud83c\uddfa\ud83c\uddf8",
        "user.screen_name": "GavinPutnam15"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894235585470465,
        "text": "RT @charliekirk11: South Korea only exists thanks to US troops sacrifice in the 1950\u2019s \n\n36,000 Americans died so South Korea could be free\u2026",
        "user.screen_name": "cbfrasier13"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894235493072896,
        "text": "RT @barstoolhrtland: While watching Olympics.. \u201cI can do that, get the truck\u201d https://t.co/BOkY8l55w4",
        "user.screen_name": "Titan_lb_"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894235266564096,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "LindacoxCox"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894235224739840,
        "text": "Also, I\u2019m having a lot of feelings at seeing so many Asian Americans in the spotlight the Olympics. I remember what\u2026 https://t.co/R3IO8Dkv4G",
        "user.screen_name": "pronounced_ing"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894235170234368,
        "text": "RT @NBCOlympics: A performance for the record books by Mirai Nagasu, complete with a celebration we'll remember for a long time. #BestOfUS\u2026",
        "user.screen_name": "BongioviSue"
    },
    {
        "created_at": "Mon Feb 12 03:40:50 +0000 2018",
        "id": 962894235161767936,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "jess_ducky98"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894234855538688,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "CarlaJackson"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894234851389441,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "sarsbran"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894234834542593,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "peachymiriam"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894234826108928,
        "text": "RT @CP__12: It\u2019s really tough watching people significantly younger than you be in the Olympics. Especially when you\u2019re a giant piece of sh\u2026",
        "user.screen_name": "madeline_sayre"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894234683564032,
        "text": "RT @jensoo_xoxo: South Korea's first gold medalist at PyeongChang Olympics Lim Hyo-Jun mentioned majimakchoeroem and he likes Jennie https:\u2026",
        "user.screen_name": "era_moreugessda"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894234574643200,
        "text": "RT @womensmediacntr: 'Time's up': Women ski jumpers still battle for equality https://t.co/bkO4APotyF",
        "user.screen_name": "Viktor_DoKaren"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894234377445376,
        "text": "RT @SuSuLeEsq: I hope we can leave Tonya Harding in history now that Mirai Nagasu is the first American woman to land the triple axel in th\u2026",
        "user.screen_name": "kirdarearab"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894233844658176,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "michthebay"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894233702191104,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "crenita"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894232389234689,
        "text": "RT @InsideSoCalSpts: Mirai Nagasu (@mirai_nagasu) becomes the first American to land a triple axel at the Winter #Olympics. \n\nWATCH: \n\nhttp\u2026",
        "user.screen_name": "GlendoraChief"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894232359874560,
        "text": "RT @rockerskating: Because @mirai_nagasu is hella patriotic. #TeamUSA #athletictape #PyeongChang2018 #Olympics #figureskating https://t.co/\u2026",
        "user.screen_name": "MsIngaSpoke"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894231978229760,
        "text": "I'm always nervous to Tweet during the #Olympics  because what if Something Amazing Happens and I was Tweeting?\u2026 https://t.co/nnNpjPUguv",
        "user.screen_name": "OliviaGraceSP"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894231500148736,
        "text": "RT @DrMCar: Leslie Jones' Winter Olympics Twitter Game Keeps Killing It https://t.co/kKSRVAgA4l",
        "user.screen_name": "janetnews"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894231403749376,
        "text": "RT @TheRickyDavila: It says something when our amazing athletes can so easily represent the United States with class, grace, honor, dignity\u2026",
        "user.screen_name": "phendricks71"
    },
    {
        "created_at": "Mon Feb 12 03:40:49 +0000 2018",
        "id": 962894230950760449,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "jjuliannachen"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894230497751040,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "KellyLemke11"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894230183030784,
        "text": "RT @nytimes: Without a word, only flashing smiles, Kim Jong-un's sister outflanked Vice President Mike Pence in diplomacy https://t.co/c2gT\u2026",
        "user.screen_name": "hartsigns"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894230170501121,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "kimmy_rmz"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894229646147584,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "SoneAlyah"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894229256265728,
        "text": "RT @Education4Libs: CNN claims \u201cIf \u2018diplomatic dance\u2019 were an event at the Winter Olympics, Kim Jong Un\u2019s younger sister would be favored t\u2026",
        "user.screen_name": "mlpardew"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894228887097344,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "jknight908"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894228878708736,
        "text": "RT @pourmecoffee: Incredible double-jump by the Russian athlete at the Olympics. https://t.co/R2oftxmlsV",
        "user.screen_name": "kstansbu"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894228383813633,
        "text": "Wow, Italy was spectacular again! Beautiful storytelling. #Olympics",
        "user.screen_name": "NightoftheLark"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894228052422656,
        "text": "RT @MrT: I am really Pumped watching the Winter Olympics. I am watching events I never thought I would watch before, like curling. You hear\u2026",
        "user.screen_name": "mtking87"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894227985362944,
        "text": "RT @TheRickyDavila: It says something when our amazing athletes can so easily represent the United States with class, grace, honor, dignity\u2026",
        "user.screen_name": "jimbealjr"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894227226193920,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "laurahxc"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894227100393472,
        "text": "RT @online_shawn: Olympics reporter: You won a gold medal, are you happy? \nAthlete: oh yes. I am happy I won the gold medal",
        "user.screen_name": "IneptBisexual"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894226861281282,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "CassetteTape76"
    },
    {
        "created_at": "Mon Feb 12 03:40:48 +0000 2018",
        "id": 962894226735349760,
        "text": "RT @OwenBenjamin: Saranac Lake, NY just got a shout out on the olympics! The guy who just got gold in luge is from the tiny town i live in!\u2026",
        "user.screen_name": "Dsquared69"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894226617978880,
        "text": "man i love the olympics",
        "user.screen_name": "AARONR0DGERS"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894226588602368,
        "text": "RT @ArthurSchwartz: CNN: Our puff piece on murderous dictator Kim Jong-un\u2019s sister is the most embarrassing piece of journalism that anyone\u2026",
        "user.screen_name": "trumpgirl261"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894226068590592,
        "text": "RT @DearAuntCrabby: After Podium Sweep At The Olympics, The Netherlands Celebrated By Trolling Trump https://t.co/w0KIWT1wBn Bwaahaha!! Con\u2026",
        "user.screen_name": "ChangeAgent002"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894225934307328,
        "text": "I just found out yulia lipnitskaya retired from figure skating bc of anorexia and she had so much potential now I'm\u2026 https://t.co/yXf6buvS3i",
        "user.screen_name": "yIIeza"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894225124728834,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Sonic_Kurosaki"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894225024020481,
        "text": "RT @seohyundaily: Imagine getting call from Blue House to perform historic concert same day for Olympics in presence of President....with n\u2026",
        "user.screen_name": "tyron_triston"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894224713687044,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "miss_haileyj"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894224621428736,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "raconteurally"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894224369897472,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "emilyslayden"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894224281755648,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "ArinaArena"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894224193540096,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "gaeaearth"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894224122314753,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "infinityonloops"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894224042598400,
        "text": "RT @TechnicallyRon: Your definitive guide to the sports of the 2018 Winter Olympics https://t.co/Oyon5qfHBc",
        "user.screen_name": "wiggintontom"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894223984021504,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "soldierDtruth"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894223904329728,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "zackjones1994"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894223715590151,
        "text": "RT @HRC: RT to cheer on Adam Rippon (@AdaRipp) at the #Olympics! https://t.co/KIO5zX9z6i",
        "user.screen_name": "NicholasBiondo"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894223631704065,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Rodriguez8027"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894223602274304,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "SamVimesBoots"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894223505874947,
        "text": "This Italian ice dancer looks like Alexis Bledel. #Olympics #figureskating",
        "user.screen_name": "chickflick1979"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894223287771136,
        "text": "RT @JessieJaneDuff: This CNN International headline is poorly written:\n\nMurderous dictator Kim Jong Un, whose regime starves, tortures and\u2026",
        "user.screen_name": "PeterLe30125667"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894222939643904,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "novemberpoems"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894222620700678,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "SaithFigueroa8"
    },
    {
        "created_at": "Mon Feb 12 03:40:47 +0000 2018",
        "id": 962894222553690113,
        "text": "RT @chr1sa: Best view of the @Intel drone swarm performance at the Olympics https://t.co/mCsILkq38Z",
        "user.screen_name": "katherinekiewel"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894222092316674,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "Derrick16392665"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894221576429568,
        "text": "RT @gatewaypundit: OUTRAGE After CNN Compares Kim Jong Un's Sister To Ivanka Trump Amid Winter Olympics Media Frenzy https://t.co/Mu5jJ4mkFZ",
        "user.screen_name": "jemz1113"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894221505126400,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "Gorall007"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894221337415680,
        "text": "\"Mirai\" (\u672a\u6765) means \"the future\" in Japanese, and Mirai Nagasu lives up to her name, representing the future of US f\u2026 https://t.co/jBFXF4coCD",
        "user.screen_name": "poshprogrammer"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894220687265793,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "butchpa"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894220511121408,
        "text": "RT @CNN: Last year he almost died in a snowboarding accident. Now he's won bronze at the Olympics. https://t.co/S9Rf6QufiQ https://t.co/BiZ\u2026",
        "user.screen_name": "BGolpour"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894220318117888,
        "text": "Ok but how are they going to portray the man GETTING SHOT BY A NAZI IN A CONCENTRATION CAMP???? (Life Is Beautiful\u2026 https://t.co/tLzD6CMF3p",
        "user.screen_name": "pinklily7333"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894219512758274,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "saavedrar0717"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894219366010880,
        "text": "RT @chr1sa: Best view of the @Intel drone swarm performance at the Olympics https://t.co/mCsILkq38Z",
        "user.screen_name": "AwaretoBeware"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894219298910208,
        "text": "RT @FoxNews: 'It's Absurd': @edhenry Blasts CNN for 'Sucking Up' to Kim Jong Un's Sister https://t.co/u0H5YWhSYT",
        "user.screen_name": "PohligT"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894219085049866,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "livielives98"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894218518724608,
        "text": "So, whose watching the OLYMPICS?\nI am..",
        "user.screen_name": "BryanGarten"
    },
    {
        "created_at": "Mon Feb 12 03:40:46 +0000 2018",
        "id": 962894218338426881,
        "text": "Find you someone who will couple figure skate with you. #Olympics",
        "user.screen_name": "TylerJFrye"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894218174849026,
        "text": "RT @linzsports: Four years ago, Adam Rippon and MIrai Nagasu were eating in-n-out burger in California, crying and watching the Sochi Olymp\u2026",
        "user.screen_name": "EWasser17"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894217017286656,
        "text": "Ice skaters have a real appreciation of film, and I\u2019m eating it up. I can\u2019t believe they distilled Life is Beautiful so we\u2019ll. #olympics",
        "user.screen_name": "curiouslykat"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894216509739009,
        "text": "RT @mattstopera: This is one of the wildest things I have ever witnessed with my own two eyes!! A North Korean cheer sqaud at the Olympics\u2026",
        "user.screen_name": "Kaymatic_"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894216325222400,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "sasha_seckers"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894216199368704,
        "text": "Her triple axel was badass.  #Olympics https://t.co/DOGIIUL0d2",
        "user.screen_name": "belles_lettres"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894216081952768,
        "text": "RT @NBCOlympics: A performance for the record books by Mirai Nagasu, complete with a celebration we'll remember for a long time. #BestOfUS\u2026",
        "user.screen_name": "whitneyuland"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894216006217728,
        "text": "RT @ricoricoriiii: In 2 years;\n\nTwice had \u2018TT\u2019 written on the Tokyo Tower &amp; were called Asia\u2019s #1 GG there [&amp; in Korea]\n\nTwice had the whol\u2026",
        "user.screen_name": "fifthhormoneyy"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894215339565057,
        "text": "@CBCOlympics @Pchiddy There's no bigger justice today than Patrick becoming an Olympics Champion. Best present for\u2026 https://t.co/fwlDOIc0dt",
        "user.screen_name": "fs_gossips"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894215054110720,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "softyIove"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894214978818050,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "DJSHIRE"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894214852894720,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "troika10659"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894214458691584,
        "text": "Time for a cuppa whilst waiting for @aimee_fuller to take to the course. The wind is forever changing so hopefully\u2026 https://t.co/usQ2jZF2cN",
        "user.screen_name": "LukeJohnFrost"
    },
    {
        "created_at": "Mon Feb 12 03:40:45 +0000 2018",
        "id": 962894214445940737,
        "text": "LOOK AT THEIR FACES THEY'RE SO HAPPY OMG #olympics",
        "user.screen_name": "my2k"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894213984563200,
        "text": "RT @NBCOlympics: A performance for the record books by Mirai Nagasu, complete with a celebration we'll remember for a long time. #BestOfUS\u2026",
        "user.screen_name": "moonlightboobo"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894213921742848,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "Conwaytheseahag"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894213875732481,
        "text": "RT @billboard: Korean singers and K-pop acts get drawn into Pyeongchang 2018 Winter Olympics! EXO and CL are set to perform at the closing\u2026",
        "user.screen_name": "lovxlyeol"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894213812838401,
        "text": "RT @hancxck: russia being banned from the olympics and not being allowed to wear the nation's colors has produced an absolute miracle of gr\u2026",
        "user.screen_name": "lanadenzelrey"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894213338845189,
        "text": "RT @CHENGANSITO: Since the Olympics just started I'm bringing back this iconic moment\n\n#EXOL #BestFanArmy #iHeartAwards @weareoneEXO PUPPY\u2026",
        "user.screen_name": "TaekookieJimin"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894213120585728,
        "text": "RT @flwrpwr1969: Pence agreed to be VP bc no one else wanted the job &amp; he saw it as an avenue to be prez. He doesn\u2019t belong in WH any more\u2026",
        "user.screen_name": "AbandrewA"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894212642480128,
        "text": "RT @BuzzFeedNews: Mirai Nagasu just became the first American woman in history to land a triple axel at the Winter Olympics(!) https://t.co\u2026",
        "user.screen_name": "peanuts_2005"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894212185362432,
        "text": "Cigarette companies don't sponsor the Olympics. Why does Coca-Cola? | Ian D Caterson and Mychelle Farmer https://t.co/wEdDI6yVg7",
        "user.screen_name": "alyframpton"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894211996704769,
        "text": "RT @JonAcuff: Dear Olympics commentators, at the beginning of each figure skating couple please let us know if the couple loves each other\u2026",
        "user.screen_name": "leeeesie"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894211874930688,
        "text": "RT @HRC: RT to cheer on Adam Rippon (@AdaRipp) at the #Olympics! https://t.co/KIO5zX9z6i",
        "user.screen_name": "larrywhyudodis"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894211644211201,
        "text": "@Lesdoggg @NBCOlympics @Olympics \u201cSlay all day, damnit!\u201d \ud83d\udc4d\ud83c\udffc\u26f8",
        "user.screen_name": "Dotdogz"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894211581382656,
        "text": "RT @WestSBI4U: When you watch the Olympics you\u2019re seeing the results of different types of long-term training sessions &amp; little sacrifices\u2026",
        "user.screen_name": "MsWolinski"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894211258503169,
        "text": "RT @KristySwansonXO: I\u2019m not watching @NBCOlympics #figureskating anymore. I can not listen to #JohnnyWeir &amp; #TaraLipinski absolutely the w\u2026",
        "user.screen_name": "Olivia82756046"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894210943811589,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "1velvetexo"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894210813841408,
        "text": "Cappellini/Lanotte just pulled at all the heart strings! Very nice! #LaViteEBella #ITA #figureskating #PyeongChang2018 #Olympics",
        "user.screen_name": "the1stPYT"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894210734018561,
        "text": "RT @deray: Jordan Greenway will be the first black hockey player in history to play for the U.S Olympic hockey team https://t.co/ZHMb7MPmHO",
        "user.screen_name": "adrienne_kt"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894210058743808,
        "text": "RT @Slate: Mirai Nagasu is the third woman to do a triple axel in the Olympics. Watch all three: https://t.co/gQO2lcL2Uh https://t.co/HveC5\u2026",
        "user.screen_name": "dare2misbehave"
    },
    {
        "created_at": "Mon Feb 12 03:40:44 +0000 2018",
        "id": 962894210033700864,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "jen_jen0926"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894209865932801,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "PatriotProud45"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894209819832320,
        "text": "RT @Blackdi51264299: 'It's Absurd': Ed Henry Blasts CNN for 'Sucking Up' to Kim Jong Un's Sister | Fox News Insider  https://t.co/uZfUzznp9T",
        "user.screen_name": "lillyred29"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894209802952704,
        "text": "RT @CTO1ChipNagel: After Declaring NFL Kneeling Protests Disrespectful, Pence Protests Korean Unity By Refusing To Stand At Olympics Ceremo\u2026",
        "user.screen_name": "AvieAvie47"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894209635282944,
        "text": "2018 Winter Olympics: Riders wipe out in windy women's snowboard slopestyle conditions https://t.co/1hVznJcjPm via @usatoday",
        "user.screen_name": "ByJoeFleming"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894209526239232,
        "text": "@dfrank5 @Lesdoggg @NBCOlympics @Olympics 10x better! \ud83d\ude02\ud83d\ude02\ud83d\ude02 its sooo much more entertaining by far",
        "user.screen_name": "DaveLeeC3"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894209287061504,
        "text": "RT @MrT: I am really Pumped watching the Winter Olympics. I am watching events I never thought I would watch before, like curling. You hear\u2026",
        "user.screen_name": "GavinThompson"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894208741838848,
        "text": "RT @HarlanCoben: Me: I\u2019ve never watched luge. I know nothing about it. \n\nMe 20 minutes later: Turns 9 through 12 are really the key to vict\u2026",
        "user.screen_name": "Blues_Record"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894208657797121,
        "text": "Cappellini and Lanotte are just the cutest #Olympics #figureskating",
        "user.screen_name": "stephkatrina"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894208477605888,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "_terralu"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894208263585793,
        "text": "@AlibabaGroup @Olympics I\u2019ve tried to use Alibaba before it\u2019s not very US friendly.",
        "user.screen_name": "LindaLeeYou123"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894207395467270,
        "text": "RT @cupidcheol: his reaction of winning gold at the Olympics will always be the cutest thing ever  https://t.co/TggInSnaKB",
        "user.screen_name": "sunzshines"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894207198334977,
        "text": "How do I sign up to be that Italian Ice Dancer\u2019s partner???? (For skating or otherwise \ud83d\ude0f) #Olympics",
        "user.screen_name": "S_mannix"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894206577471488,
        "text": "RT @Carpedonktum: CNN unveils it's new logo. The logo is stealing the show at the Winter Olympics! https://t.co/TLL4GX1K4P",
        "user.screen_name": "sandam82"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894206548275200,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "renfroconnor"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894206472667136,
        "text": "Hail to immigrants! Mirai Nagasu has become the first U.S. woman to land a triple axel in the #Olympics.\u2026 https://t.co/dJFhW8zSEO",
        "user.screen_name": "alirezat"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894206464389120,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "alanipabz"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894206355296256,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "fbonacci"
    },
    {
        "created_at": "Mon Feb 12 03:40:43 +0000 2018",
        "id": 962894206330077184,
        "text": "RT @dumbbeezie: I could do that. \n\n-Me watching people eating at the Olympics",
        "user.screen_name": "homo_hammerhead"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894205533089793,
        "text": "We've got a #Gold!!!! #TeamCanada  \n#Can \n#Olympics \n#PyeongChang2018",
        "user.screen_name": "MrNuxfan1"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894204912525312,
        "text": "I REALLY like Capellini &amp; Lanotte. They bring such great emotion and beauty to their skates. #Olympics",
        "user.screen_name": "poisontaster"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894204904108032,
        "text": "RT @JoyPuder: \u201cThis might be my first Olympics, but it\u2019s not my first rodeo.\u201d-@Adaripp \n\nThis is the perfect Housewives tagline. #Olympics\u2026",
        "user.screen_name": "katie_rudder"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894204472123392,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "RubySegura29"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894204195278848,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "jena_jordan"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894203738042368,
        "text": "Italian ice dancing couple just STUNNED #Lanotte #Olympics",
        "user.screen_name": "dsyelxic_"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894203339640832,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "MEG_nog98"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894203176062977,
        "text": "Any sport that requires judges has no business in the Olympics, be it winter or summer. Events that are decided by\u2026 https://t.co/zA2Sdlg3ei",
        "user.screen_name": "Kenz_aFan"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894203050254336,
        "text": "@WhatCassieDid Regrets that you missed what you wanted to see! You can watch our earlier coverage of the Figure Ska\u2026 https://t.co/wI0MsuLe4p",
        "user.screen_name": "CBC"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894202630586368,
        "text": "Watching the Olympics reminds me of the only time I snowboarded...fell getting off the chair lift and laid there wh\u2026 https://t.co/fbz4zbCS6U",
        "user.screen_name": "MacadyMoe"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894202609729537,
        "text": "RT @JeonMicDrop: BTS are so powerful they didnt even need to attend the Olympics &amp; DNA was played as background music during opening ceremo\u2026",
        "user.screen_name": "dearminpd"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894202404245505,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "mandab__"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894202358046722,
        "text": "RT @OmarMinayaFan: The Olympics make me so happy. Reminds you that -- despite all the bad news, and all the evil stuff we hear about -- mos\u2026",
        "user.screen_name": "bhavesh0128"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894202051944448,
        "text": "RT @DLoesch: Who determined this? They\u2019ve made no concessions, starve and torture their populace, threaten war, and all they have to do is\u2026",
        "user.screen_name": "Debbiefullam"
    },
    {
        "created_at": "Mon Feb 12 03:40:42 +0000 2018",
        "id": 962894201833664512,
        "text": "As the Olympics are going on. We give medals \ud83c\udfc5for placing do the others get participation \ud83c\udfc5?",
        "user.screen_name": "burnindaylight5"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894201171206145,
        "text": "RT @hancinema: Ok Taecyeon at the Olympics https://t.co/E1ScoPTqSo https://t.co/MgYmxdU3li",
        "user.screen_name": "hennyprscl"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894200890167296,
        "text": "So let me get this straight you can fall 2 to 3 times a and get first if your name is Chan.  Rippon got ripped off\u2026 https://t.co/Kc1YhRdaNZ",
        "user.screen_name": "theycallmegurch"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894200751755264,
        "text": "This year's Winter Olympics debuts doubles curling. American siblings relish in the opportunity to compete together\u2026 https://t.co/z8zFFBcoj1",
        "user.screen_name": "ggibitgiles2"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894200521089025,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "katieguezille"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894199891922945,
        "text": "RT @booksnbigideas: Mirai is so happy I love her!! #Olympics",
        "user.screen_name": "gillyraebean"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894199510073344,
        "text": "RT @chr1sa: Best view of the @Intel drone swarm performance at the Olympics https://t.co/mCsILkq38Z",
        "user.screen_name": "Andy_S2017"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894199300509697,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "mo_pletch"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894198935502848,
        "text": "RT @carlquintanilla: When you sit next to #NorthKorea\u2019s cheering squad at speedskating.\n\n#PyeongChang2018 \n#olympics @NBCOlympics https://t\u2026",
        "user.screen_name": "mrjake805"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894198109241344,
        "text": "OLYMPICS: ITALY's skating couple have just done the most beautiful dance so far! LOVELY \ud83c\uddee\ud83c\uddf9",
        "user.screen_name": "BillofRightsKin"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894198042226688,
        "text": "RT @CBCOlympics: John Morris and Kaitlyn Lawes looking for redemption against Team Norway come out the gate haaarrrrrrdddd! #curling #Pyeon\u2026",
        "user.screen_name": "OGDonCalderon"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894197949739008,
        "text": "RT @intel: Experience the moment the world came together under a sky of #drones. See more of the Team in Flight at https://t.co/Jkxn9vTpOt.\u2026",
        "user.screen_name": "selvat15"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894197945749504,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "Michael23921465"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894197824065536,
        "text": "RT @julia_mccoy17: Me: critiques people in the olympics\nAlso me: can\u2019t stand on ice skates for more than 2 seconds without falling",
        "user.screen_name": "ashhanson_"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894197811482624,
        "text": "RT @guskenworthy: We're here. We're queer. Get used to it. @Adaripp #Olympics #OpeningCeremony https://t.co/OCeiqiY6BN",
        "user.screen_name": "nick_burford"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894197672919040,
        "text": "RT @lolacoaster: olympics drinking game rules\nsomeone falls: do a shot\nsomeone cries when they get their score: do a shot\na koch industries\u2026",
        "user.screen_name": "KGBclaire"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894197639573506,
        "text": "RT @joshrogin: Did I photobomb the North Korea cheer squad? Absolutely. #PyeongChang #Olympics H/T: @W7VOA https://t.co/q8WnOK7hhF",
        "user.screen_name": "K8TDidToo"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894197572489216,
        "text": "RT @vlissful: @jintellectually okay for those who are confused, read the article here\n\nthe nbc guy said \u201cEvery Korean will tell you that Ja\u2026",
        "user.screen_name": "adoringlikeari"
    },
    {
        "created_at": "Mon Feb 12 03:40:41 +0000 2018",
        "id": 962894197476003846,
        "text": "RT @SwedeStats: Sweden, Norway, Finland, Denmark and Iceland should just go together as \"The Nordics\" and sweep everything that has to do w\u2026",
        "user.screen_name": "SonnAvWoden"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894196683300864,
        "text": "RT @LaurlynB: Spent the day Ice Skating at the Utah Olympic Oval with Olympian hopeful -Jason Brown! @AdeccoUSA @TeamUSA #goforthegold #Oly\u2026",
        "user.screen_name": "AngieCollege"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894196595027968,
        "text": "RT @PhilipRucker: Still can\u2019t get over that Adam Rippon\u2019s flawless, magical skate was edged out by a Russian Elvis who fell and whose progr\u2026",
        "user.screen_name": "AnaamiOne"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894196192538624,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Nadds11015"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894196154671105,
        "text": "Hey @NBCSports I know there are other sports going on besides figure skating. Can we see some of those? #Olympics",
        "user.screen_name": "CoxWebDev"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894195932520448,
        "text": "#MSM no sense of history insults anyone anywhere anytime: NBC apologizes to Korean people after correspondent's 'ig\u2026 https://t.co/L6WYtmQ3FS",
        "user.screen_name": "ellenjharris"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894195915550720,
        "text": "RT @btschartdata: [!] Another BTS' song played at #Olympics , '21st Century Girl' was used as background music in Women Hockey Match, Canad\u2026",
        "user.screen_name": "Yoongibbies"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894195743698944,
        "text": "wait when do nct perform at the olympics",
        "user.screen_name": "smolsicheng"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894195504463872,
        "text": "RT @NBCOlympics: A performance for the record books by Mirai Nagasu, complete with a celebration we'll remember for a long time. #BestOfUS\u2026",
        "user.screen_name": "CSchozer"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894195412287488,
        "text": "RT @daxshepard1: I always keep my eyes peeled for an event that I may be able to compete in the Olympics. No luck so far.",
        "user.screen_name": "davidthe_2nd"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894195299094528,
        "text": "red gerard looks like a discount jeff spicoli #Olympics https://t.co/ttICDMaUR3",
        "user.screen_name": "marypuchalski"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894194686611458,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "001Canales"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894194393145344,
        "text": "RT @Rosie: beautiful man - beautiful soul \n#AdamRippon - national hero\n#Olympics https://t.co/MbjOoXJhP6",
        "user.screen_name": "jhayden214"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894194233655298,
        "text": "@ClayTravis I'd rather watch curling \"teams\" throw down w/ their brooms gladiator style! #Olympics",
        "user.screen_name": "mooseknuckle406"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894193935953922,
        "text": "RT @tedlieu: Congratulations to Mirai Nagasu for being the first American in history to land a triple axle at the Winter Olympics! https://\u2026",
        "user.screen_name": "andrewstark02"
    },
    {
        "created_at": "Mon Feb 12 03:40:40 +0000 2018",
        "id": 962894193369563136,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "timie_"
    },
    {
        "created_at": "Mon Feb 12 03:40:39 +0000 2018",
        "id": 962894192946110470,
        "text": "RT @melrosaa: Italy skating to soundtrack of Life is Beautiful \ud83d\ude2d #Olympics So good!",
        "user.screen_name": "Avila1Emily"
    },
    {
        "created_at": "Mon Feb 12 03:40:39 +0000 2018",
        "id": 962894192115556352,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "foldzombie"
    },
    {
        "created_at": "Mon Feb 12 03:40:39 +0000 2018",
        "id": 962894190836420609,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "AVAndyist"
    },
    {
        "created_at": "Mon Feb 12 03:40:39 +0000 2018",
        "id": 962894190643331072,
        "text": "How can such an astoundingly ignorant person be a director of Starbucks and FedEx and be on Kissinger\u2019s board?!\nHe\u2026 https://t.co/3061Nsm3Nn",
        "user.screen_name": "itismedesu"
    },
    {
        "created_at": "Mon Feb 12 03:40:39 +0000 2018",
        "id": 962894190366441472,
        "text": "RT @rockerskating: From Muramoto/Reed's protocols, the calls seem to be less strict today - 5 lvl 4 elements, 1 lvl 3 on the diagonal step,\u2026",
        "user.screen_name": "The3rdName"
    },
    {
        "created_at": "Mon Feb 12 03:40:39 +0000 2018",
        "id": 962894189729079297,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "katiejaynie"
    },
    {
        "created_at": "Mon Feb 12 03:40:39 +0000 2018",
        "id": 962894189158633475,
        "text": "RT @cnni: As day 3 at #PyeongChang2018 Winter Olympics kicks off, keep up to date with the latest updates here: https://t.co/Y8pMjhRClq htt\u2026",
        "user.screen_name": "airnation"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894188588171265,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "monotrees"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894188403724288,
        "text": "@eftinkville @jk_powerup Nope.. you can enjoy all you want.   I just find the Olympics very strange.   And mostly boring.",
        "user.screen_name": "sogoodsosoon"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894188189835264,
        "text": "RT @caroshoults: Screw super bowl commercials, these olympics commercials are making me feel like I can accomplish anything.",
        "user.screen_name": "JJmuniz_"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894187543764992,
        "text": "RT @CBCOlympics: #CAN's @tessavirtue &amp; @ScottMoir skate 5th in the last event of the #FigureSkating Team Event. Even if they finish last, C\u2026",
        "user.screen_name": "msanadouglas"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894187413889024,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "TripleMLitz"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894187287867392,
        "text": "RT @chalanlexi: MIDORI-MAO-MIRAI --- Three women who landed the difficult triple axel in the Olympics #Midori, #MaoAsada and @mirai_nagasu.\u2026",
        "user.screen_name": "xaorin"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894186386161666,
        "text": "RT @espnW: This is @lindseyvonn's last Olympics, and she's going to make every single second count. https://t.co/cbLWJ2JoWH",
        "user.screen_name": "Studley"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894186318938112,
        "text": "Well, the Italians just slayed the team freelance figure skating is a sentence I can say now. #Olympics",
        "user.screen_name": "shellymonstr"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894186184720385,
        "text": "RT @olympicchannel: Start your day right with the @Olympics \ud83e\udd5e\ud83d\ude0b #PyeongChang2018 https://t.co/MJYc7cyHjv",
        "user.screen_name": "A1216_exo04"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894185954193408,
        "text": "RT @BStunner31: I love how Johnny and Tara blatantly refuse to even give ice dancing a platform #olympics",
        "user.screen_name": "elknight20"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894185119412224,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "mavissss__"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894185069035520,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "AliKira"
    },
    {
        "created_at": "Mon Feb 12 03:40:38 +0000 2018",
        "id": 962894184930840581,
        "text": "RT @peachyblackgorl: as the winter Olympics begin....never forget about Surya Bonaly, a French figure skater who did a backflip and landed\u2026",
        "user.screen_name": "belalababe"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894184704303104,
        "text": "watching the olympics inspires me to be better and try to learn these sports wowza if only i could ice skate",
        "user.screen_name": "revelexo"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894184167419904,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "katereitman"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894184075137025,
        "text": "RT @kalynkahler: \"That was shiny, sparkling redemption.\" - @JohnnyGWeir \nMirai was eating In and Out with @Adaripp and watching the last Ol\u2026",
        "user.screen_name": "CNPowers2018"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894183529877504,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "chris_randolph1"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894183030837248,
        "text": "RT @tictoc: Chris @Mazdzer wins the first men\u2019s singles luge medal in U.S. history #PyeongChang2018 #Olympics https://t.co/tw566a72pw https\u2026",
        "user.screen_name": "kristynaweh"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894182938566656,
        "text": "RT @Lesdoggg: What. Is. This!!!!! @NBCOlympics @Olympics https://t.co/SQuWG7nVYZ",
        "user.screen_name": "ClassicMiguel"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894182330245120,
        "text": "RT @saminseok: Aww look at these North Koreans cheering during the Olympics! A great step for korea tbh even if others may think it's small\u2026",
        "user.screen_name": "oviani0114"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894181910814720,
        "text": "RT @USATODAY: Mirai Nagasu lands a triple axel, the first American to do it at Winter Olympics https://t.co/KnWZspOFbE",
        "user.screen_name": "RealLeoAlbano"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894181571100672,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Ioonylovegood"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894181529157632,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "mafeux"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894181407576064,
        "text": "RT @TechnicallyRon: Your definitive guide to the sports of the 2018 Winter Olympics https://t.co/Oyon5qfHBc",
        "user.screen_name": "wundernerd8"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894181105618945,
        "text": "@whitneybalmer The olympics are in Korea, so we may see it.\n\nhttps://t.co/SXkVyacIse",
        "user.screen_name": "ISugg"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894180857991168,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "tobyjamessharp"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894180606447617,
        "text": "Aaaaand the freakin Italians killed it.... AGAIN! #Olympics2018 #olympics #FigureSkating  #IceDancing",
        "user.screen_name": "jillylove"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894180572979200,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "homo_hammerhead"
    },
    {
        "created_at": "Mon Feb 12 03:40:37 +0000 2018",
        "id": 962894180543541248,
        "text": "Based on my Twitter feed, race tracks should throw credit cards, multi-leg ticket buy back programs, and parlay car\u2026 https://t.co/g8VBYIfAVE",
        "user.screen_name": "ShotTakingTime"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894180455452672,
        "text": "Honest to god thought the Italians were about to pull off the Iron Lotus. #olympics",
        "user.screen_name": "JerryScherwin"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894180400771072,
        "text": "RT @exoelle88: @soompi We have a VS Model, a World Record-Setting golfer &amp; a 2x Olympics champion who just recently set a new world record\u2026",
        "user.screen_name": "mklprlexo"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894180245786624,
        "text": "RT @carlizuhl: Can someone who understands ice skating explain to me why Kolyada is in first place ahead of the Italian and Adam Rippon lik\u2026",
        "user.screen_name": "kheirigs"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894180115734528,
        "text": "RT @Devin_Heroux: This was Mark McMorris 11 months ago. \n\nHe\u2019s a bronze medallist at the #Olympics today. \n\nRemarkable. https://t.co/UnhBs9\u2026",
        "user.screen_name": "Kenziehocking12"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894179889242112,
        "text": "we watchin the olympics. chip gets gold in being a cute bitch. https://t.co/kaDxzuoGX2",
        "user.screen_name": "emmettkcampbell"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894179214020609,
        "text": "I don't think I'll ever trust anyone enough to let them hold me by one foot while we're on skating on ice. #olympics",
        "user.screen_name": "notrachel"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894179062841344,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "Vera_Chok"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894178979143680,
        "text": "RT @jpbrammer: my favorite part of the Olympics so far was when Aja jumped off that box",
        "user.screen_name": "DimeCharlotte"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894178710630405,
        "text": "RT @cmclymer: Another thought: when he retires someday, Adam Rippon is going to be the greatest Olympics commentator ever.\n\n#PyeongChang2018",
        "user.screen_name": "friskeyp"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894178647764993,
        "text": "RT @DjLots3: .@CNN there are hundreds of protestors outside Olympics that have 1st hand knowledge of the cruel N.Korean regime.Where's that\u2026",
        "user.screen_name": "toiletman01"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894178266083329,
        "text": "RT @paulwaldman1: +1000. I've written before about how the diversity of our team is the coolest thing about the Olympics, and a quadrennial\u2026",
        "user.screen_name": "mikalvision"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894177745940480,
        "text": "RT @Chet_Cannon: Imagine being so far left and anti-Trump that you praise a child-torturing, teen-raping, murderous dictatorship just to sp\u2026",
        "user.screen_name": "CreedWHS"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894177523597313,
        "text": "RT @jenikooooooo: Alina has a mind of steel and solid jump technique. But how else can anyone call out the scoring system without using her\u2026",
        "user.screen_name": "DiChristine"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894177297051648,
        "text": "Winter Olympics 2018: Windy conditions cause Aimee Fuller problems in first run https://t.co/4CPDzzDMeK https://t.co/VQnfylbS4R",
        "user.screen_name": "globalnews312"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894176688984064,
        "text": "RT @Trumpfan1995: CNN thinks this woman is a star at the Winter Olympics.\n\nShe is not a young woman promoting democracy and human rights.\u2026",
        "user.screen_name": "travdoggy"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894176688865280,
        "text": "RT @Clefairyhyun: Acc to this article, the artists in the opening and closing of the Olympics ceremony, Exo included, receive little to no\u2026",
        "user.screen_name": "cyt_sara"
    },
    {
        "created_at": "Mon Feb 12 03:40:36 +0000 2018",
        "id": 962894176386863104,
        "text": "RT @AliciaAmin: Julian Yee is the first ever Malaysian to compete in the Winter Olympics &amp; so many of us sleeping on him (incl me)\n\nHe\u2019s wo\u2026",
        "user.screen_name": "exorydalis_"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894176286158849,
        "text": "RT @Clefairyhyun: Acc to this article, the artists in the opening and closing of the Olympics ceremony, Exo included, receive little to no\u2026",
        "user.screen_name": "chanwooyaahh"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894176135335936,
        "text": "RT @angryasianman: Somebody, give us the gif of Mirai Nagasu\u2019s \u201cFUCK YEAH!\u201d face when she finished her skate. #Olympics",
        "user.screen_name": "cookiesofine"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894175816638465,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "bakedpotatoe123"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894175569108992,
        "text": "@AsianAdidasGirl Lol Olympics always promote peace, you know. No need to be rude. You called BS, I gave you facts. It's all good though \ud83d\udc4c",
        "user.screen_name": "fromPortmay"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894175422296065,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "AshNicole55"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894175279763456,
        "text": "@popculturenerd @tedlieu Brian Orser is not an American man--well, *North* American, yes, but he's Canadian. He *wa\u2026 https://t.co/6XzPXUxeVB",
        "user.screen_name": "hotincleveland"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894174566735872,
        "text": "RT @DLoesch: Who determined this? They\u2019ve made no concessions, starve and torture their populace, threaten war, and all they have to do is\u2026",
        "user.screen_name": "Ballsokyle"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894174453411840,
        "text": "RT @PhilipRucker: Still can\u2019t get over that Adam Rippon\u2019s flawless, magical skate was edged out by a Russian Elvis who fell and whose progr\u2026",
        "user.screen_name": "SaraKosiorek"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894174352789504,
        "text": "RT @BTS__Europe: \ud83c\uddf7\ud83c\uddfa \ud83c\udfd2 \ud83c\udde8\ud83c\udde6 \n\n@BTS_twt - ' 21st Century Girl ' played during the Canada VS Russia Ladies hockey game at the Pyeongchang Olympi\u2026",
        "user.screen_name": "Regginahh"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894174151479296,
        "text": "Winter Olympics 2018: Windy conditions cause Aimee Fuller problems in... https://t.co/Y0pLd9ssT3 Aimee Fuller's final run in the women's",
        "user.screen_name": "Follow_Finance"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894173778120704,
        "text": "RT @USATODAY: It doesn\u2019t get much more impressive than this. https://t.co/La2NeZLE9J #Olympics",
        "user.screen_name": "CJWarner1"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894173635407873,
        "text": "RT @Adaripp: WHEN YOURE RIGHT, YOURE RIGHT, @RWitherspoon \u2764\ufe0f\u2764\ufe0f\u2764\ufe0f Also!! Quick movie idea for you: You (played by you) tweet me in the middl\u2026",
        "user.screen_name": "SavannahBayBVI"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894173400543232,
        "text": "To me the Olympics are special and give me an opportunity to watch sports I normally wouldn't watch. I admire the d\u2026 https://t.co/q26qXOGapa",
        "user.screen_name": "Gaychel22"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894173157371904,
        "text": "RT @peachyblackgorl: as the winter Olympics begin....never forget about Surya Bonaly, a French figure skater who did a backflip and landed\u2026",
        "user.screen_name": "lusauce1293"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894173031583744,
        "text": "RT @ArthurSchwartz: CNN: Our puff piece on murderous dictator Kim Jong-un\u2019s sister is the most embarrassing piece of journalism that anyone\u2026",
        "user.screen_name": "rainbear00"
    },
    {
        "created_at": "Mon Feb 12 03:40:35 +0000 2018",
        "id": 962894172461174784,
        "text": "RT @JonAcuff: Dear Olympics commentators, at the beginning of each figure skating couple please let us know if the couple loves each other\u2026",
        "user.screen_name": "GenesisColema19"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894171450298368,
        "text": "I wish I could figure skate. I love it so much. \ud83d\ude2d\ud83d\ude2d\u26f8 #Olympics",
        "user.screen_name": "WLW916"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894171135602688,
        "text": "RT @dereklew: Watching Team Canada erupt into applause when American skater Mirai Nagasu became only the third woman to land a triple axel\u2026",
        "user.screen_name": "aaashketchum"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894170716327936,
        "text": "RT @jesswitkins: So happy for and proud of @mirai_nagasu making history tonight for #teamusa at the 2018 #Olympics! Enjoy your moment!! You\u2026",
        "user.screen_name": "AmberNicole226"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894170703704064,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "harmonizercm"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894170556981249,
        "text": "RT @rockerskating: From Muramoto/Reed's protocols, the calls seem to be less strict today - 5 lvl 4 elements, 1 lvl 3 on the diagonal step,\u2026",
        "user.screen_name": "abzeronow"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894170397519872,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "yellowdog625"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894170296786944,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "TimPosition"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894169713856512,
        "text": "Leslie Jones' Winter Olympics Twitter Game Keeps Killing It https://t.co/kKSRVAgA4l",
        "user.screen_name": "DrMCar"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894169554477056,
        "text": "RT @Lesdoggg: Um did Adam need to fall to his routine wtf?! Very confused right now. @NBCOlympics @Olympics https://t.co/KGiGW4OUrs",
        "user.screen_name": "LouisTomlickson"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894169466462208,
        "text": "RT @DavidShaunBurke: Congratulations Snowboarder Red Gerard, winning 1st U.S. Gold Medal \ud83e\udd47 of 2018 Winter Olympics! https://t.co/ZILmrsuw92",
        "user.screen_name": "stonemanatl"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894168824647680,
        "text": "Get Ready for the Winter Olympics\u2026Yoga Style! https://t.co/CPGMCZD53w",
        "user.screen_name": "CV_DXB"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894168510124032,
        "text": "RT @TechnicallyRon: Your definitive guide to the sports of the 2018 Winter Olympics https://t.co/Oyon5qfHBc",
        "user.screen_name": "HymTheGrimeGod"
    },
    {
        "created_at": "Mon Feb 12 03:40:34 +0000 2018",
        "id": 962894168484872192,
        "text": "I think I've seen 2 thirty second snowboarding runs in the past 40 minutes. Tons of commercials though. Hershey's g\u2026 https://t.co/Sl73XLvY2J",
        "user.screen_name": "day_man"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894167465713664,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "CharmHawthorn"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894167306272768,
        "text": "Anna and Luca \u2764\ufe0f\u2764\ufe0f\u2764\ufe0f #Olympics",
        "user.screen_name": "KritiSarker"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894167184674816,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "fallynforyou_"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894166735966208,
        "text": "RT @SoSportsNation: This South Korean gentleman just won the entire Olympics. #PyeongChang2018 #Olympics https://t.co/ZW7ZOwIZ4G",
        "user.screen_name": "ZacharyThomas_F"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894166702329858,
        "text": "Me after watching the Olympics: #OlympicWinterGames https://t.co/fhlum2AJF7",
        "user.screen_name": "faultinmypizza"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894166299525120,
        "text": "RT @SaraKellar: Tessa and Scott is already trending and we truly have no chill, as a nation, do we\n\n#figureskating #Olympics",
        "user.screen_name": "gerbersgerber"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894166236848128,
        "text": "How you fall in ice dancing #Olympics",
        "user.screen_name": "MimiC1019"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894166186315777,
        "text": "RT @chalanlexi: MIDORI-MAO-MIRAI --- Three women who landed the difficult triple axel in the Olympics #Midori, #MaoAsada and @mirai_nagasu.\u2026",
        "user.screen_name": "uzutoracat"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894166157070337,
        "text": "RT @IngrahamAngle: For ANY U.S. media outlet to praise North Korea for propaganda coup at the Olympics is truly sick.",
        "user.screen_name": "Laner67"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894165947441152,
        "text": "How does one skater stand on another skater\u2019s thigh and not slice his leg open? Beautiful skate from the Italian pair. #Olympics",
        "user.screen_name": "emsheehanwrites"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894165813219328,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "kaitlynpettey"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894165360218112,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "mary_pitts"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894165108408320,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "tindergrandma"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894164928102400,
        "text": "RT @kalynkahler: \"That was shiny, sparkling redemption.\" - @JohnnyGWeir \nMirai was eating In and Out with @Adaripp and watching the last Ol\u2026",
        "user.screen_name": "the_casshole"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894164923858944,
        "text": "RT @traciglee: This @ringer profile of the #ShibSibs is wonderful: https://t.co/5b9JSPZ982 #Olympics",
        "user.screen_name": "tankohh"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894164705685505,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "MARSY_twt"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894164282130432,
        "text": "RT @Machaizelli: A figure skater just made American Olympic history and the NBC commentators still had to compare her to the men #Olympics\u2026",
        "user.screen_name": "Peace38513"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894164089233409,
        "text": "RT @94_degrees: Russian Figure Skater, Evgeniia Medvedeva who\u2019s an EXO-L set a new world record in the Pyeongchang Olympics &amp; mentioned EXO\u2026",
        "user.screen_name": "keyyanuh"
    },
    {
        "created_at": "Mon Feb 12 03:40:33 +0000 2018",
        "id": 962894163795521536,
        "text": "Super disappointing to see Ladies' Slopestyle not postponed. #Olympics",
        "user.screen_name": "Elbareth11"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894163669786624,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "shhmiguel"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894163363749889,
        "text": "RT @NBCOlympics: SHE GOT IT! @mirai_nagasu is now the first American woman to land a triple axel at the #Olympics! #WinterOlympics https://\u2026",
        "user.screen_name": "twiDAQ"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894163220967424,
        "text": "RT @CBCOlympics: Medal Alert \ud83d\udea8\n\nCanada guaranteed to win first gold medal in figure skating team event \ud83c\udde8\ud83c\udde6 \ud83e\udd47 #PyeongChang2018 \n\nWatch Tessa\u2026",
        "user.screen_name": "kaattciaravella"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894163162386432,
        "text": "RT @TwitterMoments: Team USA figure skater @mirai_nagasu is the first American woman to land a triple axel at the Winter Olympics. #PyeongC\u2026",
        "user.screen_name": "DomD1000"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894162948485121,
        "text": "RT @KAy_TIEmyshoes: I love the Olympics https://t.co/YarQnjbr9c",
        "user.screen_name": "pele_manaku"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894162893864960,
        "text": "RT @SInow: WATCH: Mirai Nagasu becomes the first American woman in Olympic history to\nland the triple axel https://t.co/epZANcHMQF",
        "user.screen_name": "awittenberg11"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894162650718208,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "AndreiwKim21"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894162575142912,
        "text": "RT @michellebhasin: Before every Olympic event they should send out one average person to perform the upcoming event. To fall on their face\u2026",
        "user.screen_name": "kreerpro"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894162197667840,
        "text": "RT @TheRickyDavila: It says something when our amazing athletes can so easily represent the United States with class, grace, honor, dignity\u2026",
        "user.screen_name": "TheMariahRamsey"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894161560059905,
        "text": "RT @theCaGuard: Four #NewYork National Guard soldiers are competing for #TeamUSA in bobsled and luge during the #WinterOlympics. @USNationa\u2026",
        "user.screen_name": "RandySink7"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894161199300608,
        "text": "italy\u2019s is so cute \ud83e\udd27\ud83e\udd27\ud83e\udd27 #olympics",
        "user.screen_name": "junghoseoks"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894160972754944,
        "text": "RT @charliekirk11: South Korea only exists thanks to US troops sacrifice in the 1950\u2019s \n\n36,000 Americans died so South Korea could be free\u2026",
        "user.screen_name": "DianeMo24012416"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894160582803456,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "gracemarrero6"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894160310296577,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "laurxnr"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894159819440130,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "JustDebnCali"
    },
    {
        "created_at": "Mon Feb 12 03:40:32 +0000 2018",
        "id": 962894159567835143,
        "text": "RT @thehill: Dutch fans troll Trump at the Olympics with flag: \"Sorry Mr. President. The Netherlands First... And 2nd... And 3rd\" https://t\u2026",
        "user.screen_name": "stshinn"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894159022645248,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "DrClarkIPresume"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894158682820609,
        "text": "RT @thehill: Dutch fans troll Trump at the Olympics with flag: \"Sorry Mr. President. The Netherlands First... And 2nd... And 3rd\" https://t\u2026",
        "user.screen_name": "PurgatoryEMS"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894158372499456,
        "text": "Sports reporter: Mirai you are the first American woman to land the triple axel at the Olympics so what was it like\u2026 https://t.co/zDFlO52uHf",
        "user.screen_name": "dvwz"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894158338834432,
        "text": "RT @theillustrious: Me my entire life: Barely realizes snowboarding exists\n\nMe 2 days into the Olympics: If McMorris thinks he's getting on\u2026",
        "user.screen_name": "jbeq_"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894158032666624,
        "text": "That was an exquisite free dance from #CappelliniLanotte , much better than they did at the #EuropeanChamps\n\n#FigureSkating \n#Olympics",
        "user.screen_name": "JamesSemaj1220"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894157940367365,
        "text": "RT @ABC: U.S. figure skater Mirai Nagasu makes history, becoming the first American woman - and third overall - to land a triple axel in th\u2026",
        "user.screen_name": "Iris_gh"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894157831385089,
        "text": "@Miamiblues @NBCOlympics That is my point....all they hear mixing Xanax and Alcohol encouraged by an Olympic athlet\u2026 https://t.co/wuNYxQPJhv",
        "user.screen_name": "ebenfrederick"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894157500076039,
        "text": "RT @Clefairyhyun: Acc to this article, the artists in the opening and closing of the Olympics ceremony, Exo included, receive little to no\u2026",
        "user.screen_name": "NatRV74"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894157198118913,
        "text": "Olympics don\u2019t really start until its USA vs Canada in the Men\u2019s Gold Medal hockey game",
        "user.screen_name": "Ethanpaints"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894157000990720,
        "text": "5 Rings Daily-PyeongChang 2018, Day 2 Curling Talk with Ben Massey and Our GSBWP Medals for Day 2\u2026 https://t.co/EC9DU8xnu4",
        "user.screen_name": "5RingsPodcast"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894156992516099,
        "text": "RT @NBCOlympics: A performance for the record books by Mirai Nagasu, complete with a celebration we'll remember for a long time. #BestOfUS\u2026",
        "user.screen_name": "hoIdtightrauhl"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894156824682497,
        "text": "RT @peachyblackgorl: as the winter Olympics begin....never forget about Surya Bonaly, a French figure skater who did a backflip and landed\u2026",
        "user.screen_name": "kirkitcrazy"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894156795400192,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "ashleymimicx"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894156506042368,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "QueenBertRoyal"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894155897810947,
        "text": "They were so good, but when her skate was on his thigh I got scared. #Olympics",
        "user.screen_name": "NeoEnding"
    },
    {
        "created_at": "Mon Feb 12 03:40:31 +0000 2018",
        "id": 962894155457449985,
        "text": "LMAO YEAH I WOULD SAY \u270c\ud83c\udffb Olympic figure skating duo forced to change routine because it is 'too sexy' https://t.co/MNZzWQtzIJ",
        "user.screen_name": "achoohorsey"
    },
    {
        "created_at": "Mon Feb 12 03:40:30 +0000 2018",
        "id": 962894155184779264,
        "text": "I'm not watching the #Olympics but I bet Jeffrey Dahmer would have won if there was an olympic category for the crime of murder",
        "user.screen_name": "notthepunter"
    },
    {
        "created_at": "Mon Feb 12 03:40:30 +0000 2018",
        "id": 962894154752606208,
        "text": "RT @KathleenHileman: @HarlanCoben @benshapiro Son, 14: There should be a control group in the #Olympics\u00a0\nM: So the couch potatoes at home s\u2026",
        "user.screen_name": "ehoustman"
    },
    {
        "created_at": "Mon Feb 12 03:40:30 +0000 2018",
        "id": 962894154538905600,
        "text": "#Olympics Watching Ice dance and all I can think about \"but how did the girl from Japan change the look of her dress? How? When?",
        "user.screen_name": "WilkenTara"
    },
    {
        "created_at": "Mon Feb 12 03:40:30 +0000 2018",
        "id": 962894154232512517,
        "text": "RT @mikeyerxa: Tessa and Scott are skating to Moulin Rouge.  I can't wait! #Olympics https://t.co/VYh0En9gOw",
        "user.screen_name": "MaeghanArchie"
    },
    {
        "created_at": "Mon Feb 12 03:40:30 +0000 2018",
        "id": 962894153783812097,
        "text": "RT @BuzzFeed: Mirai Nagasu just became the first US woman to land the triple axel at the Olympics https://t.co/JLdvT17Q9t https://t.co/T4mX\u2026",
        "user.screen_name": "NiceSelu"
    },
    {
        "created_at": "Mon Feb 12 03:40:30 +0000 2018",
        "id": 962894153737801728,
        "text": "I adore #AdamRippon \ud83d\ude02 Wasn\u2019t he incredible tonight?! #olympics https://t.co/paviACubLN",
        "user.screen_name": "explorethesouth"
    },
    {
        "created_at": "Mon Feb 12 03:40:30 +0000 2018",
        "id": 962894153523884032,
        "text": "RT @reallyhoffman: Y'all are stuck in 2018 watching the Olympics in 2D while I'm in the future watching it in 3D https://t.co/CsKHpbZQki",
        "user.screen_name": "breaa_nichole"
    },
    {
        "created_at": "Mon Feb 12 03:40:30 +0000 2018",
        "id": 962894152278081536,
        "text": "RT @nytimes: Mike Pence denied a report that Adam Rippon, a gay American figure skater, had refused to meet with him. But the Olympic athle\u2026",
        "user.screen_name": "damonbethea1"
    },
    {
        "created_at": "Mon Feb 12 03:40:30 +0000 2018",
        "id": 962894152089288704,
        "text": "RT @vlissful: the north korean cheering squad dancing to blood sweat &amp; tears at the olympics women\u2019s ice hockey game\n\n#iHeartAwards #BestFa\u2026",
        "user.screen_name": "Riskafj95"
    },
    {
        "created_at": "Mon Feb 12 03:40:30 +0000 2018",
        "id": 962894151439339525,
        "text": "Rocky, like me, doesn't appear to give a damn about the Olympics.\n\nGood for Rocky. He's has better things to do. https://t.co/cJ8ouoGIpg",
        "user.screen_name": "petey_schwartz"
    },
    {
        "created_at": "Mon Feb 12 03:40:30 +0000 2018",
        "id": 962894151271395328,
        "text": "RT @NBCOlympics: \"HOLY COW!\" You just witnessed a historic triple axel from Mirai Nagasu. #WinterOlympics https://t.co/NsNuy9F46h https://t\u2026",
        "user.screen_name": "moopointspod"
    },
    {
        "created_at": "Mon Feb 12 03:40:29 +0000 2018",
        "id": 962894151141543936,
        "text": "Winter Olympics sheds light on dog meat farms\nhttps://t.co/wtPFLQk56A",
        "user.screen_name": "beark10"
    },
    {
        "created_at": "Mon Feb 12 03:40:29 +0000 2018",
        "id": 962894151133036549,
        "text": "Mirai Nagasu is the third woman to do a triple axel in the Olympics. Watch all three: https://t.co/gQO2lcL2Uh https://t.co/HveC5XwYvH",
        "user.screen_name": "Slate"
    },
    {
        "created_at": "Mon Feb 12 03:40:29 +0000 2018",
        "id": 962894150973644800,
        "text": "RT @NBCOlympics: COMING UP: @mirai_nagasu returns to the #WinterOlympics!\n\nSee it on @nbc or stream it here: https://t.co/NsNuy9F46h https:\u2026",
        "user.screen_name": "da67honey"
    },
    {
        "created_at": "Mon Feb 12 03:40:29 +0000 2018",
        "id": 962894150810120192,
        "text": "Very movie-like #figureskating  #olympics",
        "user.screen_name": "iDorisV"
    },
    {
        "created_at": "Mon Feb 12 03:40:29 +0000 2018",
        "id": 962894150743089152,
        "text": "Give Anna &amp; Luca a gold for choreography #olympics",
        "user.screen_name": "TriflenTara"
    },
    {
        "created_at": "Mon Feb 12 03:40:29 +0000 2018",
        "id": 962894148201336832,
        "text": "@BrianLockhart @LukeDashjr @LuckDragon69 @WeathermanIam @maxkeisor @mecampbellsoup @mikeinspace @derose\u2026 https://t.co/vjX8tTCRg3",
        "user.screen_name": "DanielKrawisz"
    },
    {
        "created_at": "Mon Feb 12 03:40:29 +0000 2018",
        "id": 962894147433635841,
        "text": "RT @News_Cryptos: Some of the smartest #crypto traders I've met are from this discord group. Join for the PnDs, stay for the conversations!\u2026",
        "user.screen_name": "bui_enedina"
    },
    {
        "created_at": "Mon Feb 12 03:40:26 +0000 2018",
        "id": 962894136952045568,
        "text": "Who says there is no real world value of Bitcoin and other cryptocurrencies? Let me show you how I use my mining... https://t.co/IWcORCOeQc",
        "user.screen_name": "sgindextrader"
    },
    {
        "created_at": "Mon Feb 12 03:40:25 +0000 2018",
        "id": 962894131004452864,
        "text": "Son: Economists say that the value of Bitcoin will decline\nFriend: Oh, communists say?\nMe: No, economists\ud83d\ude02\nSon: The\u2026 https://t.co/I9nt9HdIIw",
        "user.screen_name": "sewimperfect"
    },
    {
        "created_at": "Mon Feb 12 03:40:24 +0000 2018",
        "id": 962894129570156544,
        "text": "RT @AnkorusGlobal: Ankorus bringing bitcoin futures to CRYPTO, no need for banks or fiat. https://t.co/P3HUX8OULT     #Ankorus #ANK #bitcoi\u2026",
        "user.screen_name": "antemenut1976"
    },
    {
        "created_at": "Mon Feb 12 03:40:24 +0000 2018",
        "id": 962894126646792192,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "shotgunn28"
    },
    {
        "created_at": "Mon Feb 12 03:40:23 +0000 2018",
        "id": 962894125623255041,
        "text": "#Bitcoin Cash $BCH price: $1265.17\n\nRegister Binance and start trading $BCH.\n\n-&gt; https://t.co/NHtNjjQl3G",
        "user.screen_name": "binance_aff"
    },
    {
        "created_at": "Mon Feb 12 03:40:23 +0000 2018",
        "id": 962894124604039168,
        "text": "RT @CryptoCopy: We have published a new version of our whitepaper! \ud83d\udcc8\ud83d\udcc8\ud83d\udcc8\nTake a look here: https://t.co/5JtwNVCj9h #ico #ethereum #bitcoin #c\u2026",
        "user.screen_name": "menjest09"
    },
    {
        "created_at": "Mon Feb 12 03:40:21 +0000 2018",
        "id": 962894113602441216,
        "text": "RT @litecoindad: There are two types of people in #Crypto \ud83d\ude02\n\n#Bitcoin #Litecoin #Ethereum #PayWithLitecoin #CryptoCulture #HODL https://t.c\u2026",
        "user.screen_name": "Silverkokuryuu"
    },
    {
        "created_at": "Mon Feb 12 03:40:19 +0000 2018",
        "id": 962894106191052800,
        "text": "RT @noodlefactorysg: Looking to profit in the Digital Economy? \nJoin us tomorrow evening for the low-down on the #FourthIndustrialRevolutio\u2026",
        "user.screen_name": "SharerUssharing"
    },
    {
        "created_at": "Mon Feb 12 03:40:16 +0000 2018",
        "id": 962894093671071746,
        "text": "Am I the only person that wishes someone would figure skate in a bitcoin outfit? #bitcoin #OlympicGames",
        "user.screen_name": "Skyline1224"
    },
    {
        "created_at": "Mon Feb 12 03:40:15 +0000 2018",
        "id": 962894091829829632,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "honecks85"
    },
    {
        "created_at": "Mon Feb 12 03:40:14 +0000 2018",
        "id": 962894087295852544,
        "text": "How does bitcoin work and why is it valuable. https://t.co/iAofoRYjma",
        "user.screen_name": "TheWisecracking"
    },
    {
        "created_at": "Mon Feb 12 03:40:14 +0000 2018",
        "id": 962894085571973120,
        "text": "RT @wheelswordsmith: while she never actually wrote it into the books jk rowling has confirmed that draco malfoy was a libertarian vape ent\u2026",
        "user.screen_name": "spoot_fire"
    },
    {
        "created_at": "Mon Feb 12 03:40:14 +0000 2018",
        "id": 962894084837851138,
        "text": "RT @OfficialXAOS: LETS GET #XAOS TRENDING!\nRetweet, Like &amp; Follow!\n#crypto #altcoin #dogecoin #freecoins #giveaway #Airdrop #ethereum #ico\u2026",
        "user.screen_name": "ranaminty"
    },
    {
        "created_at": "Mon Feb 12 03:40:13 +0000 2018",
        "id": 962894083193753601,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "KirkwoodTalon"
    },
    {
        "created_at": "Mon Feb 12 03:40:13 +0000 2018",
        "id": 962894080463253506,
        "text": "New post (Bitcoin, Ethereum, Bitcoin Cash, Ripple, Stellar, Litecoin, Cardano, NEO, EOS: Price Analysis, Feb. 09) h\u2026 https://t.co/yWvtarSuVn",
        "user.screen_name": "ccryptoventures"
    },
    {
        "created_at": "Mon Feb 12 03:40:13 +0000 2018",
        "id": 962894080148729861,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "Berardinelli3"
    },
    {
        "created_at": "Mon Feb 12 03:40:13 +0000 2018",
        "id": 962894079901208577,
        "text": "RT @WeAreYourBlock: YourBlock Bounty Campaign now Live https://t.co/CGrgymVBpL\n#bountyprogram #Bounty #TokenSale #ICOs #ICO #blockchain #we\u2026",
        "user.screen_name": "suitcaseeland"
    },
    {
        "created_at": "Mon Feb 12 03:40:12 +0000 2018",
        "id": 962894077808316417,
        "text": "RT @Denaro_io: Today, we have more good news for you. The Denaro referral contest begins this Friday at 12pm UTC. \n\nThe best part: 1st plac\u2026",
        "user.screen_name": "RabailGilanii"
    },
    {
        "created_at": "Mon Feb 12 03:40:12 +0000 2018",
        "id": 962894076868734977,
        "text": "RT @CryptoKang: Big step for $CRYPTO adoption, thanks @coinbase. (Notice Bitcoin Cash is the first option)\ud83d\ude0a https://t.co/tWBYp4Bgms",
        "user.screen_name": "hopetrustgood"
    },
    {
        "created_at": "Mon Feb 12 03:40:12 +0000 2018",
        "id": 962894075962712064,
        "text": "RT @NimbusToken: Buying product #tokens during the store\u2019s pre-sale period gives the customer a range of options that just aren\u2019t present i\u2026",
        "user.screen_name": "jole_raisa"
    },
    {
        "created_at": "Mon Feb 12 03:40:10 +0000 2018",
        "id": 962894069201485825,
        "text": "GekkoScience 2pac USB Bitcoin Miner 15+GHs \"seconds stick\" ASIC https://t.co/hp0OxYCKTB https://t.co/yowPDtiLv1",
        "user.screen_name": "bitcoinnews9"
    },
    {
        "created_at": "Mon Feb 12 03:40:10 +0000 2018",
        "id": 962894068433944576,
        "text": "How To Keep Your Crypto Coins Safe?\n The Right Way &gt;&gt;&gt; https://t.co/cA7crhX2DL\n#btc #usd #bitcoin #btcusd #crypto\u2026 https://t.co/nVnEihzkFp",
        "user.screen_name": "moneyorface"
    },
    {
        "created_at": "Mon Feb 12 03:40:10 +0000 2018",
        "id": 962894068228308992,
        "text": "RT @Denaro_io: Today, we have more good news for you. The Denaro referral contest begins this Friday at 12pm UTC. \n\nThe best part: 1st plac\u2026",
        "user.screen_name": "yahyayyas_"
    },
    {
        "created_at": "Mon Feb 12 03:40:10 +0000 2018",
        "id": 962894068085919746,
        "text": "#Beer #bostonteaparty #Stockmarketcrash2018 $tee $earth $dirt $stem #stem $roots $riot #Blockchaine #Bitcoin Listen\u2026 https://t.co/e3wYXEa8aA",
        "user.screen_name": "BeefEnt"
    },
    {
        "created_at": "Mon Feb 12 03:40:10 +0000 2018",
        "id": 962894067662315520,
        "text": "RT @PMbeers: Russia Arrests Nuclear Scientists for Mining #Bitcoin With Top-Secret Supercomputer https://t.co/WnQPbZRKkD",
        "user.screen_name": "facebookretiree"
    },
    {
        "created_at": "Mon Feb 12 03:40:07 +0000 2018",
        "id": 962894055020482560,
        "text": "@wavecounter\nDon`t believe in the Bitcoin hype.\nSHORT OIL HERE with DWT at $12.66 this stock can goto $40 easy.\nAll\u2026 https://t.co/hMpKpTLRFJ",
        "user.screen_name": "sunghyun7yoon"
    },
    {
        "created_at": "Mon Feb 12 03:40:06 +0000 2018",
        "id": 962894052675944449,
        "text": "No heavy equipment needed to mine Bitcoin or Ethereum, in-fact none is needed at all...\n\nhttps://t.co/PQWjZ7G6oa\u2026 https://t.co/cCO1drEonS",
        "user.screen_name": "city_bitcoin"
    },
    {
        "created_at": "Mon Feb 12 03:40:05 +0000 2018",
        "id": 962894049723240448,
        "text": "RT @Remi_Vladuceanu: CG Blockchain and FactSet Team Up to Enhance Investors\u2019 Interaction with Crypto Assets https://t.co/jHAaPn40Z7 \n#newso\u2026",
        "user.screen_name": "ninacrypto"
    },
    {
        "created_at": "Mon Feb 12 03:40:05 +0000 2018",
        "id": 962894047366049792,
        "text": "Iceland is expected to use more energy mining `#bitcoin than powering its homes this year. Large virtual currency m\u2026 https://t.co/ljOz6WOBOg",
        "user.screen_name": "TheSohoLoft"
    },
    {
        "created_at": "Mon Feb 12 03:40:05 +0000 2018",
        "id": 962894047286382592,
        "text": "Iceland is expected to use more energy mining `#bitcoin than powering its homes this year. Large virtual currency m\u2026 https://t.co/TP35djmPos",
        "user.screen_name": "LDJCapital"
    },
    {
        "created_at": "Mon Feb 12 03:40:05 +0000 2018",
        "id": 962894047001108486,
        "text": "RT @francispouliot_: Neat trick: if you own a Blockchain analytics company and you\u2019re looking for more data points to track bitcoins users,\u2026",
        "user.screen_name": "metamarcdw"
    },
    {
        "created_at": "Mon Feb 12 03:40:04 +0000 2018",
        "id": 962894044580995073,
        "text": "$SFEG News https://t.co/7Gcfkv6C8R @intlMonty #wsj #nytimes #reuters #bloomberg #thestreet #jimmyfallon #forbes\u2026 https://t.co/VKZnEq4pbw",
        "user.screen_name": "ssn4marketing"
    },
    {
        "created_at": "Mon Feb 12 03:40:04 +0000 2018",
        "id": 962894044266250240,
        "text": "RT @StreamNetworksc: Website launch. This is our only site, we do not have another domain. XSN token distribution is coming soon, please be\u2026",
        "user.screen_name": "jasiery2005"
    },
    {
        "created_at": "Mon Feb 12 03:40:04 +0000 2018",
        "id": 962894043536674816,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "DeryaGaby"
    },
    {
        "created_at": "Mon Feb 12 03:40:04 +0000 2018",
        "id": 962894042349686784,
        "text": "RT @ArminVanBitcoin: Friend: \"Where do you see #bitcoin going this year?\"\nMe: \"I see first big merchants accepting $BTC using lightning cha\u2026",
        "user.screen_name": "comcentrate1"
    },
    {
        "created_at": "Mon Feb 12 03:40:03 +0000 2018",
        "id": 962894041724719105,
        "text": "$SFEG News https://t.co/Wy3q7iWo1B @intlMonty #wsj #nytimes #reuters #bloomberg #thestreet #jimmyfallon #forbes\u2026 https://t.co/LQ9bFNJ2Qy",
        "user.screen_name": "ssn3media"
    },
    {
        "created_at": "Mon Feb 12 03:40:03 +0000 2018",
        "id": 962894041212968960,
        "text": "Iceland is expected to use more energy mining `#bitcoin than powering its homes this year. Large virtual currency m\u2026 https://t.co/u5UtFwtrqY",
        "user.screen_name": "DavidDrakeVC"
    },
    {
        "created_at": "Mon Feb 12 03:40:03 +0000 2018",
        "id": 962894041162633217,
        "text": "Midnight Gaming announce pro COD players wanted for CWL Atlanta \nhttps://t.co/9CrYO81DCu #activision #games\u2026 https://t.co/qaQ2NPtbUg",
        "user.screen_name": "socialstocksnow"
    },
    {
        "created_at": "Mon Feb 12 03:40:03 +0000 2018",
        "id": 962894040625745920,
        "text": "$SFEG News https://t.co/EZd76uYQnV @intlMonty #wsj #nytimes #reuters #bloomberg #thestreet #jimmyfallon #forbes\u2026 https://t.co/QNke627CiN",
        "user.screen_name": "RandallGoulding"
    },
    {
        "created_at": "Mon Feb 12 03:40:03 +0000 2018",
        "id": 962894040424382464,
        "text": "$SFEG News https://t.co/pbbtqqYQO8 @intlMonty #wsj #nytimes #reuters #bloomberg #thestreet #jimmyfallon #forbes\u2026 https://t.co/oTFOqrHhFt",
        "user.screen_name": "socialprnews"
    },
    {
        "created_at": "Mon Feb 12 03:40:03 +0000 2018",
        "id": 962894039623221248,
        "text": "@perplextus @AlexPickard @toomuch72 And yes, theoretically, I think if Bitcoin was practically free to mine, it wou\u2026 https://t.co/SAG8m8aBYD",
        "user.screen_name": "SeatacBCH"
    },
    {
        "created_at": "Mon Feb 12 03:40:03 +0000 2018",
        "id": 962894038851510272,
        "text": "id::959996929072615425:Today we find web applications in every environment independent of https://t.co/NgplWdWFlW #Cybersecurity #Bitcoin ht",
        "user.screen_name": "And_Or_R"
    },
    {
        "created_at": "Mon Feb 12 03:40:03 +0000 2018",
        "id": 962894038780317696,
        "text": "RT @AcoCollective: Do you have a Crypto Addiction? \n\n#Bitcoin #Cryptocurrency #Crypto #Ethereum #Litecoin #BTC #ETH #Blockchain #Ripple #Cr\u2026",
        "user.screen_name": "UtarSystems"
    },
    {
        "created_at": "Mon Feb 12 03:40:03 +0000 2018",
        "id": 962894038004371457,
        "text": "RT @CryptKeeperBTT: Arizona Senate Passes Bill To Allow Tax Payments In Bitcoin | Zero Hedge https://t.co/y62z6qcO4e",
        "user.screen_name": "CryptoAustin"
    },
    {
        "created_at": "Mon Feb 12 03:40:02 +0000 2018",
        "id": 962894037559795712,
        "text": "$SFEG News https://t.co/uHkWVn9G4N @intlMonty #wsj #nytimes #reuters #bloomberg #thestreet #jimmyfallon #forbes\u2026 https://t.co/a3N322GPgZ",
        "user.screen_name": "itsastart1"
    },
    {
        "created_at": "Mon Feb 12 03:40:02 +0000 2018",
        "id": 962894033805701121,
        "text": "RT @NimbusToken: \ud83d\udcdc WHITEPAPER CHANGES \ud83d\udcdc We made some changes to the whitepaper this morning - additions to staff. https://t.co/A515Y8uEvW #\u2026",
        "user.screen_name": "jole_raisa"
    },
    {
        "created_at": "Mon Feb 12 03:40:01 +0000 2018",
        "id": 962894033478733824,
        "text": "$SFEG News https://t.co/qUTtmXsw3p @intlMonty #wsj #nytimes #reuters #bloomberg #thestreet #jimmyfallon #forbes\u2026 https://t.co/hO7yLQnOoY",
        "user.screen_name": "socialstartnews"
    },
    {
        "created_at": "Mon Feb 12 03:40:01 +0000 2018",
        "id": 962894033067696128,
        "text": "$SFEG News https://t.co/lFU79vtSPY @intlMonty #wsj #nytimes #reuters #bloomberg #thestreet #jimmyfallon #forbes\u2026 https://t.co/nBWJdueRx8",
        "user.screen_name": "socialirnews"
    },
    {
        "created_at": "Mon Feb 12 03:40:01 +0000 2018",
        "id": 962894032824397824,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "suzieqnelson"
    },
    {
        "created_at": "Mon Feb 12 03:40:01 +0000 2018",
        "id": 962894032769822720,
        "text": "$SFEG News https://t.co/3i36NmVhLg @intlMonty #wsj #nytimes #reuters #bloomberg #thestreet #jimmyfallon #forbes\u2026 https://t.co/P9UOiZHiij",
        "user.screen_name": "ssn1tweet"
    },
    {
        "created_at": "Mon Feb 12 03:40:01 +0000 2018",
        "id": 962894032119705600,
        "text": "$SFEG News https://t.co/mpCpVwUWDV @intlMonty #wsj #nytimes #reuters #bloomberg #thestreet #jimmyfallon #forbes\u2026 https://t.co/9a6wdYYQaE",
        "user.screen_name": "ssn5marketing"
    },
    {
        "created_at": "Mon Feb 12 03:40:01 +0000 2018",
        "id": 962894031960399872,
        "text": "RT @giftzcard: Giftz.io chosen Top 10 #ICOs To Watch Heading Into 2018 by Inc. Magazine  Notable investors, Linda Giambrone (NBC), Emilio D\u2026",
        "user.screen_name": "EnlightenedCole"
    },
    {
        "created_at": "Mon Feb 12 03:40:00 +0000 2018",
        "id": 962894025895415808,
        "text": "RT @BTCTN: New Jersey Sends Cease &amp; Desist to Crypto-Investment Pool https://t.co/Z9FZ6OXO8a #Bitcoin https://t.co/TnTxxnwpxs",
        "user.screen_name": "ejpmonline"
    },
    {
        "created_at": "Mon Feb 12 03:39:58 +0000 2018",
        "id": 962894020136591360,
        "text": "RT @whaleclubco: Bitcoin - What's Next? #bitcoin \u00b7 Trade $BTCUSD with up to 20x leverage: https://t.co/ogeEs8zK82 https://t.co/muZdrOrsxW",
        "user.screen_name": "EnlightenedCole"
    },
    {
        "created_at": "Mon Feb 12 03:39:56 +0000 2018",
        "id": 962894011773145089,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "elizabethlswai"
    },
    {
        "created_at": "Mon Feb 12 03:39:56 +0000 2018",
        "id": 962894009839636481,
        "text": "RT @Ronald_vanLoon: 6 Advantages of #Blockchain [#INFOGRAPHICS]\nby @mikequindazzi @pwc |\n\n#Cryptocurrency #Bitcoin #IoT #InternetOfThings #\u2026",
        "user.screen_name": "jalbanc"
    },
    {
        "created_at": "Mon Feb 12 03:39:54 +0000 2018",
        "id": 962894000318570501,
        "text": "RT @BigCheds: $BTC #bitcoin strong break of 8480 area",
        "user.screen_name": "Parmigiani_S"
    },
    {
        "created_at": "Mon Feb 12 03:39:53 +0000 2018",
        "id": 962893999580344325,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "AndersonJohn74"
    },
    {
        "created_at": "Mon Feb 12 03:39:53 +0000 2018",
        "id": 962893996296085504,
        "text": "Right? Instead of attacking Bitcoin all the time. Had they gone with Bcash and promoted and focused on it without c\u2026 https://t.co/Uleu4Gspyp",
        "user.screen_name": "embilysays"
    },
    {
        "created_at": "Mon Feb 12 03:39:48 +0000 2018",
        "id": 962893977082122240,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "jayjohannes24"
    },
    {
        "created_at": "Mon Feb 12 03:39:48 +0000 2018",
        "id": 962893975542685697,
        "text": "RT @NAR: Chinese traders' key link to cryptocurrency market in trouble https://t.co/mZHICYRp4Q https://t.co/oXaEV8DZKC",
        "user.screen_name": "Silver_Watchdog"
    },
    {
        "created_at": "Mon Feb 12 03:39:45 +0000 2018",
        "id": 962893965874753536,
        "text": "#litecoin can be a great #HODL till the end of March!! Target - $230 \n Great time to buy!! Until there not another\u2026 https://t.co/TV5xqgR9mt",
        "user.screen_name": "SuggestCoin"
    },
    {
        "created_at": "Mon Feb 12 03:39:45 +0000 2018",
        "id": 962893964411056128,
        "text": "RT @Fractalwatch: From bitcoin archives. https://t.co/R8JxUq2pwK",
        "user.screen_name": "zmann8531"
    },
    {
        "created_at": "Mon Feb 12 03:39:43 +0000 2018",
        "id": 962893957880565760,
        "text": "RT @AcoCollective: Do you have a Crypto Addiction? \n\n#Bitcoin #Cryptocurrency #Crypto #Ethereum #Litecoin #BTC #ETH #Blockchain #Ripple #Cr\u2026",
        "user.screen_name": "ZekDaniyal"
    },
    {
        "created_at": "Mon Feb 12 03:39:42 +0000 2018",
        "id": 962893952255852545,
        "text": "RT @CrowdCoinage: There is a lot of controversial ideas about cryptocurrencies. Now the tricky subject of cryptocurrencies is tackled by gl\u2026",
        "user.screen_name": "NurHanif03"
    },
    {
        "created_at": "Mon Feb 12 03:39:40 +0000 2018",
        "id": 962893944735465472,
        "text": "RT @IanLJones98: What is Blockchain? Why does it matter? Why is it so disruptive? How does it work? All in 60 seconds\n\n#AI #ML #Blockchain\u2026",
        "user.screen_name": "GoldCommIndia"
    },
    {
        "created_at": "Mon Feb 12 03:39:40 +0000 2018",
        "id": 962893944391479297,
        "text": "TODAY WE TALK ABOUT THE PROJECT - #FLOGMALL. \nI hope to see this project moon beyond expectations. Good team. Good\u2026 https://t.co/sg3coQX3HG",
        "user.screen_name": "Destje"
    },
    {
        "created_at": "Mon Feb 12 03:39:40 +0000 2018",
        "id": 962893943850463232,
        "text": "RT @zerohedge: bitcoin technicals from JPM https://t.co/SoBzF6Mghv",
        "user.screen_name": "hedging_reality"
    },
    {
        "created_at": "Mon Feb 12 03:39:39 +0000 2018",
        "id": 962893940180561921,
        "text": "Bitcoin Price Technical Analysis for 02/12/2018 \u2013 Make or Break\u00a0Level https://t.co/KHCnSsGLQu https://t.co/edle7Z8Q8l",
        "user.screen_name": "rajputcoool"
    },
    {
        "created_at": "Mon Feb 12 03:39:38 +0000 2018",
        "id": 962893933666848768,
        "text": "Interesting Video:\n#Bitcoin Price on Wild Rise -\n https://t.co/4KPiwdUsWd\n\n#yourdigitalcurrency",
        "user.screen_name": "yourdigitalcash"
    },
    {
        "created_at": "Mon Feb 12 03:39:37 +0000 2018",
        "id": 962893932685295621,
        "text": "1: Bitcoin average price is $8525.63 (0.76% 1h)\n2: Ethereum average price is $850.364 (0.75% 1h)\n3: Ripple average\u2026 https://t.co/3p6ybEhrZU",
        "user.screen_name": "TickerTop"
    },
    {
        "created_at": "Mon Feb 12 03:39:37 +0000 2018",
        "id": 962893932505042944,
        "text": "Why U.S Restrictions on #ICOs and Exchanges Is Likely #blockchain\n#bitcoin #cryptocurrency https://t.co/KnTz93Ai5O",
        "user.screen_name": "Ed_Lemieux"
    },
    {
        "created_at": "Mon Feb 12 03:39:36 +0000 2018",
        "id": 962893925546647552,
        "text": "ACR Million Dollar Sunday overlays https://t.co/sSYaY2kdk8 #poker #acr #bitcoin",
        "user.screen_name": "recentpoker"
    },
    {
        "created_at": "Mon Feb 12 03:39:35 +0000 2018",
        "id": 962893922845577217,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "SofiaMiller0"
    },
    {
        "created_at": "Mon Feb 12 03:39:33 +0000 2018",
        "id": 962893914259820544,
        "text": "RT @mazen2051991: Bitcoin - BTC\nPrice: $6,915.51\nChange in 1h: -2.14%\nMarket cap: $116,524,960,398.00\nRanking: 1\n#Bitcoin #BTC",
        "user.screen_name": "tttragg"
    },
    {
        "created_at": "Mon Feb 12 03:39:33 +0000 2018",
        "id": 962893913655689216,
        "text": "RT @zerohedge: Bitcoin ETFs pending approval https://t.co/2dS9l4Ggsw",
        "user.screen_name": "hedging_reality"
    },
    {
        "created_at": "Mon Feb 12 03:39:33 +0000 2018",
        "id": 962893912082755585,
        "text": "Register for an account on our dashboard and purchase tokens now to receive 30% bonus. 12 hours left until this dro\u2026 https://t.co/BuwEy0XzL8",
        "user.screen_name": "Wordcoin3"
    },
    {
        "created_at": "Mon Feb 12 03:39:32 +0000 2018",
        "id": 962893911776612352,
        "text": "@dan_abramov still not enough to process a bitcoin transaction",
        "user.screen_name": "JeremyBarbe1"
    },
    {
        "created_at": "Mon Feb 12 03:39:31 +0000 2018",
        "id": 962893906915528704,
        "text": "RT @MyICONews: What is Bitcoin? https://t.co/VN7MkGIFi1",
        "user.screen_name": "yuettefranzese3"
    },
    {
        "created_at": "Mon Feb 12 03:39:30 +0000 2018",
        "id": 962893903383932928,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "carterjamss"
    },
    {
        "created_at": "Mon Feb 12 03:39:30 +0000 2018",
        "id": 962893902687727616,
        "text": "RT @OfficialXAOS: LETS GET #XAOS TRENDING!\nRetweet, Like &amp; Follow!\n#crypto #altcoin #dogecoin #freecoins #giveaway #Airdrop #ethereum #ico\u2026",
        "user.screen_name": "abolfaz00539412"
    },
    {
        "created_at": "Mon Feb 12 03:39:29 +0000 2018",
        "id": 962893896970833920,
        "text": "RT @TheIBMMSPTeam: The huge surge of interest in #cryptocurrencies like #Bitcoin has made major news around the globe over the last few mon\u2026",
        "user.screen_name": "S_Wallace_"
    },
    {
        "created_at": "Mon Feb 12 03:39:27 +0000 2018",
        "id": 962893887072292864,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "RimboltBlack"
    },
    {
        "created_at": "Mon Feb 12 03:39:26 +0000 2018",
        "id": 962893886040375296,
        "text": "RT @JonasHavering: I'm giving away 20 000 TRX\n\nWinner will be chosen FRIDAY\n\nRETWEET and FOLLOW to participate\n #Bitcoin #dogecoin #Ethereu\u2026",
        "user.screen_name": "arktctakki"
    },
    {
        "created_at": "Mon Feb 12 03:39:26 +0000 2018",
        "id": 962893884773847040,
        "text": "RT @iamjosephyoung: Oh wait, so bitcoin wasn't for criminals after all?\n\nNope. Banks are the safe haven for money launderers and criminals.\u2026",
        "user.screen_name": "jahrastar_ivxx"
    },
    {
        "created_at": "Mon Feb 12 03:39:26 +0000 2018",
        "id": 962893884631248897,
        "text": "RT @Crypto_Bitlord: Bitcoin will pump so hard that one day, we will be calling satoshis \u201cbitcoins\u201d",
        "user.screen_name": "cameronrfox"
    },
    {
        "created_at": "Mon Feb 12 03:39:25 +0000 2018",
        "id": 962893882148212736,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "docdavis77"
    },
    {
        "created_at": "Mon Feb 12 03:39:20 +0000 2018",
        "id": 962893861197631488,
        "text": "Are Bitcoin Price And Equity Markets Returns Correlated? https://t.co/ZasyLlpOHN #bitcoin #crypto https://t.co/slPKL3KjKe",
        "user.screen_name": "betbybitcoins"
    },
    {
        "created_at": "Mon Feb 12 03:39:20 +0000 2018",
        "id": 962893860123955201,
        "text": "UK press - Bitcoin hackers hijack thousands of government computers for mining: The article\u2026 https://t.co/YhDlt7lfje",
        "user.screen_name": "Forex_warrior"
    },
    {
        "created_at": "Mon Feb 12 03:39:20 +0000 2018",
        "id": 962893857632403456,
        "text": "RT @Bitcoin_Friend: Energy riches fuel #Bitcoin craze for speculation-shy Iceland https://t.co/XBGBnfKD9m https://t.co/38OaNWpkuP",
        "user.screen_name": "S_Wallace_"
    },
    {
        "created_at": "Mon Feb 12 03:39:19 +0000 2018",
        "id": 962893856822972418,
        "text": "@coldchainlogix Depends. Bitcoin.  Another alt or tether",
        "user.screen_name": "BigCheds"
    },
    {
        "created_at": "Mon Feb 12 03:39:19 +0000 2018",
        "id": 962893855023656960,
        "text": "Bitcoin Stocks thanks for following me on Twitter! https://t.co/AwVw3EcTVI",
        "user.screen_name": "boutthatbitcoin"
    },
    {
        "created_at": "Mon Feb 12 03:39:18 +0000 2018",
        "id": 962893850686697472,
        "text": "RT @cryptodailyuk: J.P. Morgan \"#Cryptocurrencies are here to stay\"\nJ.P. Morgan's CEO Jamie Dimon changed his voice of tune on #Bitcoin fro\u2026",
        "user.screen_name": "trader954"
    },
    {
        "created_at": "Mon Feb 12 03:39:18 +0000 2018",
        "id": 962893849382260736,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "KathyEnzerink"
    },
    {
        "created_at": "Mon Feb 12 03:39:17 +0000 2018",
        "id": 962893845397626880,
        "text": "This seems like a big development! #Bitcoin #cryptocurrency #Credit #creditcard #banks https://t.co/9NhrejBxEK",
        "user.screen_name": "stevesarner"
    },
    {
        "created_at": "Mon Feb 12 03:39:16 +0000 2018",
        "id": 962893844193800192,
        "text": "RT @BigCheds: $BTC #bitcoin is a Rorschach test right now. Inverse head and shoulders bottom or head and shoulders top https://t.co/bViAuqf\u2026",
        "user.screen_name": "hanquoc69"
    },
    {
        "created_at": "Mon Feb 12 03:39:15 +0000 2018",
        "id": 962893836866478080,
        "text": "@nytimes Did NK buy your paper with Bitcoin?",
        "user.screen_name": "typeswithfinger"
    },
    {
        "created_at": "Mon Feb 12 03:39:14 +0000 2018",
        "id": 962893834056355841,
        "text": "RT @NigeriaSnake: Why bother trading in bitcoin or doing Yahoo Yahoo when I can swallow millions for you?",
        "user.screen_name": "jennyiphy007"
    },
    {
        "created_at": "Mon Feb 12 03:39:14 +0000 2018",
        "id": 962893833431285760,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "HeavenGianna"
    },
    {
        "created_at": "Mon Feb 12 03:39:11 +0000 2018",
        "id": 962893823788625922,
        "text": "Energy riches fuel bitcoin craze for speculation-shy Iceland https://t.co/8MWAvXeOOb #tech",
        "user.screen_name": "filidecotz"
    },
    {
        "created_at": "Mon Feb 12 03:39:09 +0000 2018",
        "id": 962893812413751297,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "PurvisRobinson"
    },
    {
        "created_at": "Mon Feb 12 03:39:08 +0000 2018",
        "id": 962893811088273408,
        "text": "RT @GroganAlgo: This article on #blockchain &amp; #fintech is the best summation I have ever read. The sacred will lose to the profane, the #Fe\u2026",
        "user.screen_name": "tiffanieamuah81"
    },
    {
        "created_at": "Mon Feb 12 03:39:07 +0000 2018",
        "id": 962893805111447557,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "Theresa21Young"
    },
    {
        "created_at": "Mon Feb 12 03:39:06 +0000 2018",
        "id": 962893800967426048,
        "text": "Install CryptoTab and mine Bitcoin! https://t.co/17p8vCRnG5",
        "user.screen_name": "bookinglilmike"
    },
    {
        "created_at": "Mon Feb 12 03:39:06 +0000 2018",
        "id": 962893799004430337,
        "text": "All Bitcoin and Litecoin payments will get 20% aditionally off!\n\nhttps://t.co/euflCCLZLz",
        "user.screen_name": "BoostedServers"
    },
    {
        "created_at": "Mon Feb 12 03:39:04 +0000 2018",
        "id": 962893794336296961,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "BloggerLeeWhite"
    },
    {
        "created_at": "Mon Feb 12 03:39:02 +0000 2018",
        "id": 962893783405940736,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "UtarSystems"
    },
    {
        "created_at": "Mon Feb 12 03:39:01 +0000 2018",
        "id": 962893779681325058,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "AudreyPullman5"
    },
    {
        "created_at": "Mon Feb 12 03:39:00 +0000 2018",
        "id": 962893775046676480,
        "text": "RT @BTCTN: Japan Cracks Down on Foreign ICO Agency Operating Without License https://t.co/cGkzl1LZNW #Bitcoin https://t.co/NDg7LjkytD",
        "user.screen_name": "TheCryptoInvest"
    },
    {
        "created_at": "Mon Feb 12 03:39:00 +0000 2018",
        "id": 962893774945964033,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "AsiliaZinsha"
    },
    {
        "created_at": "Mon Feb 12 03:38:59 +0000 2018",
        "id": 962893772458618881,
        "text": "RT @zerohedge: We have officially gone from \"Bitcoin is a fraud\" to \"cryptocurrencies could potentially have a role in diversifying one\u2019s g\u2026",
        "user.screen_name": "Jblk8"
    },
    {
        "created_at": "Mon Feb 12 03:38:58 +0000 2018",
        "id": 962893768562225152,
        "text": "RT @JonasHavering: I'm giving away 20 000 TRX\n\nWinner will be chosen FRIDAY\n\nRETWEET and FOLLOW to participate\n #Bitcoin #dogecoin #Ethereu\u2026",
        "user.screen_name": "shakshak41"
    },
    {
        "created_at": "Mon Feb 12 03:38:57 +0000 2018",
        "id": 962893764279898112,
        "text": "RT @TacoPvP_: \u26cf\ufe0f        1 BITCOIN GIVEAWAY       \u26cf\ufe0f\n\ud83d\udcb5  8000$ WORTH OF BITCOINS  \ud83d\udcb5\n\ud83d\udcdd LIKE, RT &amp; FOLLOW TO ENTER \ud83d\udcdd\n\ud83d\udd12      ENDS AT 500 RETWEET\u2026",
        "user.screen_name": "_Adam88THFC"
    },
    {
        "created_at": "Mon Feb 12 03:38:57 +0000 2018",
        "id": 962893762551693312,
        "text": "@perplextus @AlexPickard @toomuch72 PoW for Bitcoin is computing power which = capital, You can see the amount of c\u2026 https://t.co/TFuJCDOKRn",
        "user.screen_name": "SeatacBCH"
    },
    {
        "created_at": "Mon Feb 12 03:38:56 +0000 2018",
        "id": 962893760924454912,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "SamKelly63"
    },
    {
        "created_at": "Mon Feb 12 03:38:55 +0000 2018",
        "id": 962893756818182144,
        "text": "RT @zerohedge: We have officially gone from \"Bitcoin is a fraud\" to \"cryptocurrencies could potentially have a role in diversifying one\u2019s g\u2026",
        "user.screen_name": "_mesientojevi"
    },
    {
        "created_at": "Mon Feb 12 03:38:54 +0000 2018",
        "id": 962893752661696512,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "HarmonyEmilie"
    },
    {
        "created_at": "Mon Feb 12 03:38:54 +0000 2018",
        "id": 962893749369044992,
        "text": "RT @adryenn: Russian authorities have arrested engineers at one of the country's top-secret\u2026 https://t.co/LQCtr5O0l9 #bitcoin by #India_Bit\u2026",
        "user.screen_name": "koren_marybeth"
    },
    {
        "created_at": "Mon Feb 12 03:38:53 +0000 2018",
        "id": 962893748349763584,
        "text": "@rogerkver BCash is the real Bitcoin. https://t.co/ZatWzKRWJi",
        "user.screen_name": "AliyahCandy"
    },
    {
        "created_at": "Mon Feb 12 03:38:53 +0000 2018",
        "id": 962893747959803904,
        "text": "RT @RonnieMoas: $BTC currently ranked # 28 ... was at # 18 in December. I now see a best case scenario of #bitcoin hitting # 6 by 2023 (at\u2026",
        "user.screen_name": "millbury01"
    },
    {
        "created_at": "Mon Feb 12 03:38:53 +0000 2018",
        "id": 962893747330666496,
        "text": "#putmoneyinyourpocket Why is bitcoin better than money https://t.co/5pNIzfhVCG https://t.co/P1k759dTq0",
        "user.screen_name": "AidenMrdwyav"
    },
    {
        "created_at": "Mon Feb 12 03:38:53 +0000 2018",
        "id": 962893744319148033,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "JenniferAlsop7"
    },
    {
        "created_at": "Mon Feb 12 03:38:52 +0000 2018",
        "id": 962893744134598657,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "AlomoraSimslens"
    },
    {
        "created_at": "Mon Feb 12 03:38:52 +0000 2018",
        "id": 962893743253794818,
        "text": "$BTC #bitcoin is a Rorschach test right now. Inverse head and shoulders bottom or head and shoulders top https://t.co/bViAuqfwWB",
        "user.screen_name": "BigCheds"
    },
    {
        "created_at": "Mon Feb 12 03:38:52 +0000 2018",
        "id": 962893740749852672,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "DavidHardacre7"
    },
    {
        "created_at": "Mon Feb 12 03:38:51 +0000 2018",
        "id": 962893738258378753,
        "text": "RT @ypayeu: YouPay - The cheapest fee around the world wide web\n#airdrop #ypay #youpay #cryptocurrency #ethereum #bitcoin https://t.co/jKdD\u2026",
        "user.screen_name": "Dezzykoko"
    },
    {
        "created_at": "Mon Feb 12 03:38:51 +0000 2018",
        "id": 962893736727535618,
        "text": "RT @eth_classic: Ethereum Classic Today https://t.co/RU09WVAPiF\nYour source for Bitcoin, Blockchain, and Everything Ethereum Classic.\n\n#Eth\u2026",
        "user.screen_name": "jahrastar_ivxx"
    },
    {
        "created_at": "Mon Feb 12 03:38:50 +0000 2018",
        "id": 962893732587687936,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "Steph56Renee"
    },
    {
        "created_at": "Mon Feb 12 03:38:49 +0000 2018",
        "id": 962893731618795520,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "Raphaelle_Smith"
    },
    {
        "created_at": "Mon Feb 12 03:38:49 +0000 2018",
        "id": 962893731434237952,
        "text": "RT @Fansxpress: #Cryptocurrencies #Bitcoin #BitcoinCash #DASH #XRP #Ripple #TRON #TRX #BTC #ETH #BCH #LTC #XLM #ADA #XVG #ETH #cryptocurren\u2026",
        "user.screen_name": "nanu1685"
    },
    {
        "created_at": "Mon Feb 12 03:38:48 +0000 2018",
        "id": 962893726195638279,
        "text": "RT @M_A_N_Corp: #XRP is SURGING. \nMake some MONEY\n\n1000 #XRP #Giveaway\n-Retweet This Tweet\n-Follow\n-Visit @M_A_N_Corp to ENTER 1000 #Ripple\u2026",
        "user.screen_name": "shakshak41"
    },
    {
        "created_at": "Mon Feb 12 03:38:46 +0000 2018",
        "id": 962893719014985729,
        "text": "RT @ypayeu: We are glad to inform you that we started AirDrop, the first 100 users that will fill the form + another 100 randomly selected\u2026",
        "user.screen_name": "Dezzykoko"
    },
    {
        "created_at": "Mon Feb 12 03:38:46 +0000 2018",
        "id": 962893718721265665,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "MarkWhite1983"
    },
    {
        "created_at": "Mon Feb 12 03:38:46 +0000 2018",
        "id": 962893716930420736,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "StewartJaxson"
    },
    {
        "created_at": "Mon Feb 12 03:38:46 +0000 2018",
        "id": 962893716565393410,
        "text": "my brain is too small to understand bitcoin",
        "user.screen_name": "internetuser82"
    },
    {
        "created_at": "Mon Feb 12 03:38:46 +0000 2018",
        "id": 962893715395305473,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "VictorSmith67"
    },
    {
        "created_at": "Mon Feb 12 03:38:44 +0000 2018",
        "id": 962893708441112576,
        "text": "RT @izx_io: Kazakhstan, we are coming!\n\n#izx #izetex #ico #blockchain #cryptocurrency #conference #cryptoevent #bitcoin #ethereum https://t\u2026",
        "user.screen_name": "finickycam"
    },
    {
        "created_at": "Mon Feb 12 03:38:44 +0000 2018",
        "id": 962893708420173825,
        "text": "RT @zerohedge: We have officially gone from \"Bitcoin is a fraud\" to \"cryptocurrencies could potentially have a role in diversifying one\u2019s g\u2026",
        "user.screen_name": "JacksonJennings"
    },
    {
        "created_at": "Mon Feb 12 03:38:44 +0000 2018",
        "id": 962893706566230017,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "PaulRees45"
    },
    {
        "created_at": "Mon Feb 12 03:38:41 +0000 2018",
        "id": 962893695753207808,
        "text": "RT @ImLisaO: Coinbase, one of the biggest #Crypto exchanges, has launched a service for merchants - allowing them to integrate #cryptocurre\u2026",
        "user.screen_name": "kydyzyx"
    },
    {
        "created_at": "Mon Feb 12 03:38:40 +0000 2018",
        "id": 962893692905361408,
        "text": "Bitcoin looks bullish for tomorrow(Feb 12) Day traders Buy today and sell tomorrow.",
        "user.screen_name": "sureshmohan1"
    },
    {
        "created_at": "Mon Feb 12 03:38:39 +0000 2018",
        "id": 962893689289920512,
        "text": "RT @CryptoKang: Big step for $CRYPTO adoption, thanks @coinbase. (Notice Bitcoin Cash is the first option)\ud83d\ude0a https://t.co/tWBYp4Bgms",
        "user.screen_name": "JLLOYD30TRADER"
    },
    {
        "created_at": "Mon Feb 12 03:38:39 +0000 2018",
        "id": 962893687930974209,
        "text": "RT @Cointelegraph: .@MichelleMone and her partner Douglas Barrowman sold 50 flats for #Bitcoin in Dubai, more apartments promised to come.\u2026",
        "user.screen_name": "TheCryptoInvest"
    },
    {
        "created_at": "Mon Feb 12 03:38:39 +0000 2018",
        "id": 962893686660063233,
        "text": "RT @francispouliot_: Right now is a REALLY good time to consolidate your Bitcoin UTXOs into segwit addresses and do all the small transacti\u2026",
        "user.screen_name": "MartdeMontigny"
    },
    {
        "created_at": "Mon Feb 12 03:38:39 +0000 2018",
        "id": 962893686345314304,
        "text": "RT @GroganAlgo: This article on #blockchain &amp; #fintech is the best summation I have ever read. The sacred will lose to the profane, the #Fe\u2026",
        "user.screen_name": "marvelpieracci6"
    },
    {
        "created_at": "Mon Feb 12 03:38:37 +0000 2018",
        "id": 962893677935972352,
        "text": "RT @PlanetZiggurat: https://t.co/VOEUjnISk5  Referral Program Every participant will get unique referral code also unique link with this co\u2026",
        "user.screen_name": "StarKay3"
    },
    {
        "created_at": "Mon Feb 12 03:38:37 +0000 2018",
        "id": 962893677818458112,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "JacobGrant31"
    },
    {
        "created_at": "Mon Feb 12 03:38:36 +0000 2018",
        "id": 962893677101232128,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "BellaRoberts181"
    },
    {
        "created_at": "Mon Feb 12 03:38:35 +0000 2018",
        "id": 962893672982503424,
        "text": "RT @ManjeetRege: #BigData Comes to Dieting https://t.co/vtIJUJFKb7 #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience #D\u2026",
        "user.screen_name": "StevenDavidso3"
    },
    {
        "created_at": "Mon Feb 12 03:38:35 +0000 2018",
        "id": 962893669991964678,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "andrewstark02"
    },
    {
        "created_at": "Mon Feb 12 03:38:35 +0000 2018",
        "id": 962893669706731520,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "JonesRj1964"
    },
    {
        "created_at": "Mon Feb 12 03:38:35 +0000 2018",
        "id": 962893669203435520,
        "text": "Can\u2019t wait till my bitcoin takes off \ud83d\ude24 https://t.co/0VRFOqAys0",
        "user.screen_name": "Sta_nge"
    },
    {
        "created_at": "Mon Feb 12 03:38:34 +0000 2018",
        "id": 962893668582674434,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "Metatro46077255"
    },
    {
        "created_at": "Mon Feb 12 03:38:34 +0000 2018",
        "id": 962893668347711488,
        "text": "The National Security Agency is the world\u2019s most powerful, most fa https://t.co/BPNjBEsdsL #Cybersecurity #Bitcoin https://t.co/d082SobiAb",
        "user.screen_name": "CyberDomain"
    },
    {
        "created_at": "Mon Feb 12 03:38:34 +0000 2018",
        "id": 962893666711953413,
        "text": "RT @Blockchainlife: But idk tho.. #Bitcoin https://t.co/QoTof7QhyC",
        "user.screen_name": "Brayanpinilla16"
    },
    {
        "created_at": "Mon Feb 12 03:38:33 +0000 2018",
        "id": 962893664241381376,
        "text": "RT @DigitalLawrence: BREAKING - US \ud83c\uddfa\ud83c\uddf8 Crypto Adoption: The great state of Arizona is paving the way by passing a bill in Senate to allow #B\u2026",
        "user.screen_name": "CryptoCrate"
    },
    {
        "created_at": "Mon Feb 12 03:38:32 +0000 2018",
        "id": 962893660294656000,
        "text": "I liked a @YouTube video https://t.co/FFHlgjXBtd The 1 Bitcoin Show- Bprivate momentum? Ethereum, Bgold, phone storage thoughts, the",
        "user.screen_name": "luellen041"
    },
    {
        "created_at": "Mon Feb 12 03:38:32 +0000 2018",
        "id": 962893659254304770,
        "text": "RT @BTCTN: New Jersey Sends Cease &amp; Desist to Crypto-Investment Pool https://t.co/Z9FZ6OXO8a #Bitcoin https://t.co/TnTxxnwpxs",
        "user.screen_name": "Ascadian1776"
    },
    {
        "created_at": "Mon Feb 12 03:38:31 +0000 2018",
        "id": 962893654921830400,
        "text": "Protect your network and web sites from malicious attacks with hel https://t.co/T42MDXzLw3 #Cybersecurity #Bitcoin https://t.co/GyFkDEym1z",
        "user.screen_name": "CyberDomain"
    },
    {
        "created_at": "Mon Feb 12 03:38:31 +0000 2018",
        "id": 962893654233841670,
        "text": "@LukeDashjr @DanielKrawisz @LuckDragon69 @WeathermanIam @maxkeisor @mikeinspace @derose @georgevaccaro\u2026 https://t.co/MDuWKrbv8w",
        "user.screen_name": "mecampbellsoup"
    },
    {
        "created_at": "Mon Feb 12 03:38:30 +0000 2018",
        "id": 962893651549532160,
        "text": "Check out @thedigitaledger's crypto merch shop on @threadless.\n\nDesigns by #XRPstreetTEAM members @dreventures\u2026 https://t.co/IngTerYvYr",
        "user.screen_name": "XRPstreetTEAM"
    },
    {
        "created_at": "Mon Feb 12 03:38:30 +0000 2018",
        "id": 962893649993486337,
        "text": "RT @aantonop: While the banks are busy building their permissioned private 'Bubble Boy' blockchains, #Bitcoin has survived more than nine y\u2026",
        "user.screen_name": "MarkMarkafv"
    },
    {
        "created_at": "Mon Feb 12 03:38:30 +0000 2018",
        "id": 962893648177197057,
        "text": "RT @btc_green: Did you know that #Bitcoin uses more energy than all of the orange countries? We need to build a sustainable future for #cry\u2026",
        "user.screen_name": "lucilecassubha2"
    },
    {
        "created_at": "Mon Feb 12 03:38:28 +0000 2018",
        "id": 962893643366445056,
        "text": "RT @ErikVoorhees: What you may not understand about crypto\u2019s millionaires https://t.co/TxdjAvdk29 via @VentureBeat #bitcoin #ethereum #bloc\u2026",
        "user.screen_name": "gonayiga"
    },
    {
        "created_at": "Mon Feb 12 03:38:28 +0000 2018",
        "id": 962893641210646528,
        "text": "These high-quality aluminum enclosures (or aluminium, for our mate https://t.co/ikoCMrIYdR #Cybersecurity #Bitcoin https://t.co/0FoqHyWc2r",
        "user.screen_name": "CyberDomain"
    },
    {
        "created_at": "Mon Feb 12 03:38:28 +0000 2018",
        "id": 962893640862445569,
        "text": "RT @RFERL: Employees at a Russian top-secret nuclear facility have reportedly been detained after trying to use one of Russia's most powerf\u2026",
        "user.screen_name": "ditord"
    },
    {
        "created_at": "Mon Feb 12 03:38:25 +0000 2018",
        "id": 962893629319778306,
        "text": "/u/slowmoon: \n\nIt's always the same thing over and over. It's a bubble. Greater fools. No intrinsic value. Nothing\u2026 https://t.co/VCCRBwPBH9",
        "user.screen_name": "BTC_Traders"
    },
    {
        "created_at": "Mon Feb 12 03:38:25 +0000 2018",
        "id": 962893628145156096,
        "text": "RT @skychainglobal: Meet us at #Blockchain &amp; #Bitcoin Conference #Gibraltar 2018! \n#skychainglobal #ico #live #medicine #AI #NeuralNetworks\u2026",
        "user.screen_name": "Praditaraheel"
    },
    {
        "created_at": "Mon Feb 12 03:38:25 +0000 2018",
        "id": 962893627818151936,
        "text": "A collection useful programming advice the author has collected ov https://t.co/1T4jhf4iEq #Cybersecurity #Bitcoin https://t.co/s3VCELVUpN",
        "user.screen_name": "CyberDomain"
    },
    {
        "created_at": "Mon Feb 12 03:38:24 +0000 2018",
        "id": 962893626706718725,
        "text": "#bitcoin price $8511.36",
        "user.screen_name": "FYICrypto"
    },
    {
        "created_at": "Mon Feb 12 03:38:24 +0000 2018",
        "id": 962893623988690944,
        "text": "RT @flogmall: #FLOGmallteam\n\nContinuing making acquaintance with the team, we\u2019d like to introduce you our technical unit team members of FL\u2026",
        "user.screen_name": "Bernard32029161"
    },
    {
        "created_at": "Mon Feb 12 03:38:23 +0000 2018",
        "id": 962893618632626176,
        "text": "RT @RealSexyCyborg: This shit again.\nhttps://t.co/8x3dw7rioI",
        "user.screen_name": "rnelson0"
    },
    {
        "created_at": "Mon Feb 12 03:38:22 +0000 2018",
        "id": 962893616141230081,
        "text": "#Blockchaine #ipo #BITCOIN #beefent #etfs $ustc $mjmj $mjna Listen to Beef - I Put In Work Feat. Ox Storm by Beef\u2026 https://t.co/fnMBQxVmfi",
        "user.screen_name": "BeefEnt"
    },
    {
        "created_at": "Mon Feb 12 03:38:22 +0000 2018",
        "id": 962893616103510016,
        "text": "How do the weak defeat the strong? Ivan Arregu\u00edn-Toft argues that, https://t.co/33v9jVpIJ5 #Cybersecurity #Bitcoin https://t.co/BstoFg0wmG",
        "user.screen_name": "CyberDomain"
    },
    {
        "created_at": "Mon Feb 12 03:38:19 +0000 2018",
        "id": 962893604703428608,
        "text": "@DonaldJTrumpJr NK must have bought the New York Times with Bitcoin",
        "user.screen_name": "typeswithfinger"
    },
    {
        "created_at": "Mon Feb 12 03:38:19 +0000 2018",
        "id": 962893601913974785,
        "text": "@crypt0e @mikeinspace @georgevaccaro @maxkeisor @jordanbpeterson @jaltucher @derose @aantonop He didn\u2019t even believ\u2026 https://t.co/V2oD7WRKPR",
        "user.screen_name": "AlexPickard"
    },
    {
        "created_at": "Mon Feb 12 03:38:17 +0000 2018",
        "id": 962893595253469185,
        "text": "RT @flogmall: FLOGmall video presentation for sellers...\nTo see more\u00a0https://t.co/sjLWubqZI9\n\n#FLOGmall #ico #blockchain #bitcoin #btc #eth\u2026",
        "user.screen_name": "Bernard32029161"
    },
    {
        "created_at": "Mon Feb 12 03:38:17 +0000 2018",
        "id": 962893594951651328,
        "text": "RT @WeAreYourBlock: YourBlock Bounty Campaign now Live https://t.co/CGrgymVBpL\n#bountyprogram #Bounty #TokenSale #ICOs #ICO #blockchain #we\u2026",
        "user.screen_name": "resistorgrowlin"
    },
    {
        "created_at": "Mon Feb 12 03:38:16 +0000 2018",
        "id": 962893593265438720,
        "text": "RT @OxfordCrypto: $500 BITCOIN GIVEAWAY.  Must:\n1. FOLLOW @OxfordCrypto\n2. SHARE this tweet\n3. Leave your bitcoin wallet in the comments.\u2026",
        "user.screen_name": "hayats72"
    },
    {
        "created_at": "Mon Feb 12 03:38:16 +0000 2018",
        "id": 962893592753725441,
        "text": "RT @EthyoloCoin: Another usage of YOLO.. Aside from you can use YOLO as payment to buy products, you can also use it for Sports betting! #Y\u2026",
        "user.screen_name": "JuhriaMindo"
    },
    {
        "created_at": "Mon Feb 12 03:38:16 +0000 2018",
        "id": 962893591017291777,
        "text": "Bitcoin Mining Now Consuming More Electricity Than 159 Countries Including Ireland &amp; Most Countries In Africa https://t.co/dFZ0yJKrFs",
        "user.screen_name": "JTechpreneur"
    },
    {
        "created_at": "Mon Feb 12 03:38:15 +0000 2018",
        "id": 962893585627668483,
        "text": "US: Arizona Senate Passes Bill To Allow Tax Payments In Bitcoin https://t.co/QnDAnO7jDS via @Cointelegraph",
        "user.screen_name": "LeDylanfreddo"
    },
    {
        "created_at": "Mon Feb 12 03:38:14 +0000 2018",
        "id": 962893584159555584,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "janet8588"
    },
    {
        "created_at": "Mon Feb 12 03:38:12 +0000 2018",
        "id": 962893576102469632,
        "text": "RT @Crypticsup: Cryptocurrency forecast for 11.02.2018\n\nhttps://t.co/KijTjaAG6U\n\n#Cryptics #crowdsale #bitcoin  #ico  #Cryptocurrencies #cr\u2026",
        "user.screen_name": "cefewefWhi"
    },
    {
        "created_at": "Mon Feb 12 03:38:12 +0000 2018",
        "id": 962893572579065856,
        "text": "@TuurDemeester @starkness Bitcoin was just the beginning haha",
        "user.screen_name": "icodewebdesign"
    },
    {
        "created_at": "Mon Feb 12 03:38:11 +0000 2018",
        "id": 962893572184911873,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "JamesYoung1986"
    },
    {
        "created_at": "Mon Feb 12 03:38:11 +0000 2018",
        "id": 962893572105220097,
        "text": "Beyond the Bitcoin Bubble (via @Pocket) #longreads https://t.co/NLcRKoay0f",
        "user.screen_name": "David_Sher"
    },
    {
        "created_at": "Mon Feb 12 03:38:11 +0000 2018",
        "id": 962893572054888448,
        "text": "How many letter tiles does one need to build any 24 word mnemonic? https://t.co/Yg3Cmr3vVm",
        "user.screen_name": "cryptoflashn1"
    },
    {
        "created_at": "Mon Feb 12 03:38:10 +0000 2018",
        "id": 962893565209739265,
        "text": "RT @BTCTN: Bitcoin Private Fork Aiming to Make Bitcoin Anonymous https://t.co/wKng4RlO5u #Bitcoin https://t.co/cO9xeVoMT5",
        "user.screen_name": "TheCryptoInvest"
    },
    {
        "created_at": "Mon Feb 12 03:38:10 +0000 2018",
        "id": 962893564375117824,
        "text": "There\u2019s Now a Girl Pop Group Dedicated to Bitcoin and Other Cryptocurrencies https://t.co/7jFTGVocSk",
        "user.screen_name": "omanizen"
    },
    {
        "created_at": "Mon Feb 12 03:38:07 +0000 2018",
        "id": 962893553809543169,
        "text": "RT @Applancer_pro: Model with Bitcoin-themed Shirt catwalks in the New York Fashion Week https://t.co/4lZ5YoCUzH  #Bitcoin #Fashion  #inves\u2026",
        "user.screen_name": "otiliaflener141"
    },
    {
        "created_at": "Mon Feb 12 03:38:06 +0000 2018",
        "id": 962893551146172416,
        "text": "RT @kitttenqueen: i take paypal, venmo, apple pay and bitcoin https://t.co/5pOcLGvU7K",
        "user.screen_name": "cxmicsams"
    },
    {
        "created_at": "Mon Feb 12 03:38:06 +0000 2018",
        "id": 962893551133589504,
        "text": "Here is some light hearted #SundayReading on the future of blockchain technology.  https://t.co/g45036t9t6",
        "user.screen_name": "proteumio"
    },
    {
        "created_at": "Mon Feb 12 03:38:06 +0000 2018",
        "id": 962893550538100737,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "fairlane500"
    },
    {
        "created_at": "Mon Feb 12 03:38:05 +0000 2018",
        "id": 962893545765064705,
        "text": "RT @Blockchainlife: Always do your own research. #Bitcoin #Nimiq #Ardor #Litecoin https://t.co/mEpILI95NR",
        "user.screen_name": "Brayanpinilla16"
    },
    {
        "created_at": "Mon Feb 12 03:38:05 +0000 2018",
        "id": 962893543382667264,
        "text": "RT @iamjosephyoung: Oh wait, so bitcoin wasn't for criminals after all?\n\nNope. Banks are the safe haven for money launderers and criminals.\u2026",
        "user.screen_name": "MartdeMontigny"
    },
    {
        "created_at": "Mon Feb 12 03:38:04 +0000 2018",
        "id": 962893542417985541,
        "text": "Sign up to Binance \u27a1\ufe0f https://t.co/FlPtYbM7Si \"Binance Vs. McAfee: Hack Rumors Refuted, Cryptocurrency Trading Resu\u2026 https://t.co/x0AGOf4vvQ",
        "user.screen_name": "Actu_crypto"
    },
    {
        "created_at": "Mon Feb 12 03:38:04 +0000 2018",
        "id": 962893541088243712,
        "text": "RT @DigitalKeith: Every 60 sec on #Internet.\n#DigitalMarketing #InternetMarketing #SocialMedia #SEO #SMM #Mpgvip #defstar5 #BigData #bitcoi\u2026",
        "user.screen_name": "sevilje8pap"
    },
    {
        "created_at": "Mon Feb 12 03:38:03 +0000 2018",
        "id": 962893538383007744,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "Galaxi162"
    },
    {
        "created_at": "Mon Feb 12 03:38:03 +0000 2018",
        "id": 962893538273955840,
        "text": "Sign up to Binance \u27a1\ufe0f https://t.co/FlPtYbM7Si \"Breaking: Crypto Exchange Binance Relaunches After Upg... | News ...\u2026 https://t.co/L91L8BRnDw",
        "user.screen_name": "Actu_crypto"
    },
    {
        "created_at": "Mon Feb 12 03:38:03 +0000 2018",
        "id": 962893537565011968,
        "text": "RT @gramcointoken: \u26cf\ufe0f          1 BITCOIN GIVEAWAY         \u26cf\ufe0f\n\ud83d\udcb5  9000$ WORTH OF BITCOINS  \ud83d\udcb5\n\ud83d\udcdd LIKE, RT &amp; FOLLOW TO ENTER \ud83d\udcdd\n\ud83d\udd12       ENDS AT 5\u2026",
        "user.screen_name": "burtjeffersonp"
    },
    {
        "created_at": "Mon Feb 12 03:38:02 +0000 2018",
        "id": 962893532964052992,
        "text": "RT @izx_io: Kazakhstan, we are coming!\n\n#izx #izetex #ico #blockchain #cryptocurrency #conference #cryptoevent #bitcoin #ethereum https://t\u2026",
        "user.screen_name": "burritosneulog"
    },
    {
        "created_at": "Mon Feb 12 03:38:01 +0000 2018",
        "id": 962893527754649600,
        "text": "RT @Denaro_io: Do you like to be a winner \ud83d\ude32?\n\nWin $ 50,000 with our referral contest that has started \ud83d\udc47\n\nhttps://t.co/l9cXSqg1N4 \n \nContest\u2026",
        "user.screen_name": "mpb1505"
    },
    {
        "created_at": "Mon Feb 12 03:38:00 +0000 2018",
        "id": 962893525233930240,
        "text": "Two Hour Lull Update: CryptoCompare Bitcoin price: $8517.65 #bitcoin",
        "user.screen_name": "Winkdexer"
    },
    {
        "created_at": "Mon Feb 12 03:38:00 +0000 2018",
        "id": 962893523195396096,
        "text": "Actual footage of the government trying to regulate #cryptocurrency #Bitcoin #altcoin\u2026 https://t.co/flCP5iu8Xj",
        "user.screen_name": "TheRealJPeyton"
    },
    {
        "created_at": "Mon Feb 12 03:37:59 +0000 2018",
        "id": 962893520448172033,
        "text": "@SasgoraBooks @DanDarkPill Wait a minute...you believe the 8/1/2017 Hard Fork was carried out by one man, who  has\u2026 https://t.co/c9ylhsf8v3",
        "user.screen_name": "scottphall44"
    },
    {
        "created_at": "Mon Feb 12 03:37:57 +0000 2018",
        "id": 962893510901841920,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "AbandrewA"
    },
    {
        "created_at": "Mon Feb 12 03:37:54 +0000 2018",
        "id": 962893498428088320,
        "text": "RT @ricare: Top story: Linux and Open Source, Senate Candidate Accepts Largest Contribution\u2026 https://t.co/52YvLQ1f0k, see more https://t.co\u2026",
        "user.screen_name": "Ashygoyal"
    },
    {
        "created_at": "Mon Feb 12 03:37:53 +0000 2018",
        "id": 962893494028251136,
        "text": "RT @aantonop: While the banks are busy building their permissioned private 'Bubble Boy' blockchains, #Bitcoin has survived more than nine y\u2026",
        "user.screen_name": "idan503"
    },
    {
        "created_at": "Mon Feb 12 03:37:50 +0000 2018",
        "id": 962893483483828224,
        "text": "RT @zerohedge: We have officially gone from \"Bitcoin is a fraud\" to \"cryptocurrencies could potentially have a role in diversifying one\u2019s g\u2026",
        "user.screen_name": "Jay_Havs"
    },
    {
        "created_at": "Mon Feb 12 03:37:49 +0000 2018",
        "id": 962893479444729856,
        "text": "RT @Cointelegraph: Wandering #Bitcoin price starts and ends the week at $8300. https://t.co/JEHHNql0lt",
        "user.screen_name": "TheCryptoInvest"
    },
    {
        "created_at": "Mon Feb 12 03:37:48 +0000 2018",
        "id": 962893475682422784,
        "text": "RT @HeyTaiZen: .@leoncfu &amp; I spoke briefly on why we support @decredproject cuz it solves a huge problem in bitcoin that is not going to be\u2026",
        "user.screen_name": "jackliv3r"
    },
    {
        "created_at": "Mon Feb 12 03:37:47 +0000 2018",
        "id": 962893469378203648,
        "text": "Higher #interestrates, do not affect $SING: #strongbuy, #billiondollarmarket, #buy, #potstocks, #blockchain,\u2026 https://t.co/dA5lmlImaC",
        "user.screen_name": "Apex_Capital"
    },
    {
        "created_at": "Mon Feb 12 03:37:47 +0000 2018",
        "id": 962893468510117888,
        "text": "Bitcoin CRASH: Cryptocurrency PLUMMETS 60 per cent in MONTH as market continues to tumble https://t.co/P1vtOY6v4S",
        "user.screen_name": "pekingikakuya"
    },
    {
        "created_at": "Mon Feb 12 03:37:46 +0000 2018",
        "id": 962893467310489600,
        "text": "Bitcoin CRASH: Cryptocurrency PLUMMETS 60 per cent in MONTH as market continues to tumble https://t.co/CL7ldLiTpc",
        "user.screen_name": "saitatatekide"
    },
    {
        "created_at": "Mon Feb 12 03:37:46 +0000 2018",
        "id": 962893466098388992,
        "text": "RT @YarmolukDan: Google is now using #MachineLearning to predict flight delays https://t.co/PcBKloGFpg #Bitcoin #Ethereum #Cryptocurrency #\u2026",
        "user.screen_name": "SteakUtsee"
    },
    {
        "created_at": "Mon Feb 12 03:37:46 +0000 2018",
        "id": 962893463988547584,
        "text": "RT @BankXRP: A potential Amazon cryptocurrency exchange: Everyone is wondering about this move (AMZN)\n\nhttps://t.co/IzKqe5KnD6\n\n #Ripple #X\u2026",
        "user.screen_name": "pollawit2515"
    },
    {
        "created_at": "Mon Feb 12 03:37:44 +0000 2018",
        "id": 962893458976501760,
        "text": "@vergecurrency @CryptoEmporium_ Love it",
        "user.screen_name": "rick_bitcoin"
    },
    {
        "created_at": "Mon Feb 12 03:37:44 +0000 2018",
        "id": 962893458699702272,
        "text": "After Bitcoin craze, Swedish investors succumb to reefer stock madness https://t.co/BDyDCZotvu",
        "user.screen_name": "beritsubunkoro"
    },
    {
        "created_at": "Mon Feb 12 03:37:44 +0000 2018",
        "id": 962893456887730176,
        "text": "RT @derekmagill: Bitcoin Core does not have a \"proven track record.\" We have absolutely no proof that a high fee coin that sometimes takes\u2026",
        "user.screen_name": "accretionist"
    },
    {
        "created_at": "Mon Feb 12 03:37:43 +0000 2018",
        "id": 962893453691629570,
        "text": "@LukeDashjr @LuckDragon69 @WeathermanIam @maxkeisor @mecampbellsoup @mikeinspace @derose @georgevaccaro\u2026 https://t.co/1hNh8tnc5U",
        "user.screen_name": "DanielKrawisz"
    },
    {
        "created_at": "Mon Feb 12 03:37:42 +0000 2018",
        "id": 962893448067076096,
        "text": "RT @Quantstamp: \"The market for software, services and hardware to secure blockchain activity should grow to $355 billion as the digital ec\u2026",
        "user.screen_name": "simone_franzi"
    },
    {
        "created_at": "Mon Feb 12 03:37:40 +0000 2018",
        "id": 962893439745523717,
        "text": "RT @IsaFX_Trading: #GIVEAWAY of 0.20BTC simply follow, retweet &amp;  comment your BTC add \n10 Winners will be picked randomly among all RTs on\u2026",
        "user.screen_name": "maxitremblay"
    },
    {
        "created_at": "Mon Feb 12 03:37:40 +0000 2018",
        "id": 962893439200309253,
        "text": "RT @BTCTN: Roles of Regulators Decided in India, Rules on Bitcoin Coming Soon https://t.co/qEUx4TDs34 #Bitcoin https://t.co/Fnj9A3pBvn",
        "user.screen_name": "TheCryptoInvest"
    },
    {
        "created_at": "Mon Feb 12 03:37:39 +0000 2018",
        "id": 962893437132472320,
        "text": "Bitcoin Snaps Slide as Crypto Markets Dodge Push for Regulation https://t.co/YNxRJs88vi",
        "user.screen_name": "betsuorutozai"
    },
    {
        "created_at": "Mon Feb 12 03:37:39 +0000 2018",
        "id": 962893434213167105,
        "text": "RT @jblefevre60: 10 benefits of #CloudComputing?\n\n#DataScience #Bigdata #IoT #CIO #blockchain #fintech #Deeplearning #Cloud #Bitcoin #Disru\u2026",
        "user.screen_name": "michellezaftig"
    },
    {
        "created_at": "Mon Feb 12 03:37:38 +0000 2018",
        "id": 962893433458348032,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "queenymom"
    },
    {
        "created_at": "Mon Feb 12 03:37:38 +0000 2018",
        "id": 962893432179093504,
        "text": "Millennials are afraid stocks are too risky, so they\u2019re investing in bitcoin https://t.co/E9a7uq2B8B",
        "user.screen_name": "rainonyakui"
    },
    {
        "created_at": "Mon Feb 12 03:37:38 +0000 2018",
        "id": 962893431151489024,
        "text": "RT @YarmolukDan: Google is now using #MachineLearning to predict flight delays https://t.co/PcBKloGFpg #Bitcoin #Ethereum #Cryptocurrency #\u2026",
        "user.screen_name": "DavidHardacre7"
    },
    {
        "created_at": "Mon Feb 12 03:37:38 +0000 2018",
        "id": 962893429939187713,
        "text": "@SeatacBCH @AlexPickard @toomuch72 So, theoretically, if someone found a way to mine Bitcoin using 1/100th the ener\u2026 https://t.co/PB2ptZH3JT",
        "user.screen_name": "perplextus"
    },
    {
        "created_at": "Mon Feb 12 03:37:37 +0000 2018",
        "id": 962893429607948289,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "JimRHenson"
    },
    {
        "created_at": "Mon Feb 12 03:37:37 +0000 2018",
        "id": 962893428190318598,
        "text": "Demystifying blockchain and Bitcoin https://t.co/rEmJhUexdJ",
        "user.screen_name": "denkomufuritsu"
    },
    {
        "created_at": "Mon Feb 12 03:37:37 +0000 2018",
        "id": 962893425988292608,
        "text": "Bitcoin Price Analysis - Regulators warm to cryptocurrencies \u00bb Brave New Coin https://t.co/QzjcQBhOjo",
        "user.screen_name": "yugamiyokosasa"
    },
    {
        "created_at": "Mon Feb 12 03:37:35 +0000 2018",
        "id": 962893419377934337,
        "text": "RT @giveawaysBTC: 7000 Follower Giveaway\n\nPrize: .5BTC (1 Winner)\n\nTo enter retweet, like, and follow!\n\n#btc #bitcoin #crypto #cryptocurren\u2026",
        "user.screen_name": "NicaBertPO"
    },
    {
        "created_at": "Mon Feb 12 03:37:35 +0000 2018",
        "id": 962893417352192000,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "BenNatureAddict"
    },
    {
        "created_at": "Mon Feb 12 03:37:34 +0000 2018",
        "id": 962893416584560640,
        "text": "RT @wheelswordsmith: while she never actually wrote it into the books jk rowling has confirmed that draco malfoy was a libertarian vape ent\u2026",
        "user.screen_name": "kris_collinson"
    },
    {
        "created_at": "Mon Feb 12 03:37:34 +0000 2018",
        "id": 962893415548702721,
        "text": "RT @ArminVanBitcoin: U.S. Senate passes bill allowing Arizona citizens to pay their taxes in #bitcoin. \n\nhttps://t.co/a5IyFflU6u",
        "user.screen_name": "8itpreneur"
    },
    {
        "created_at": "Mon Feb 12 03:37:32 +0000 2018",
        "id": 962893407248158721,
        "text": "RT @YarmolukDan: Google is now using #MachineLearning to predict flight delays https://t.co/PcBKloGFpg #Bitcoin #Ethereum #Cryptocurrency #\u2026",
        "user.screen_name": "AudreyPullman5"
    },
    {
        "created_at": "Mon Feb 12 03:37:32 +0000 2018",
        "id": 962893405301936129,
        "text": "RT @YarmolukDan: Google is now using #MachineLearning to predict flight delays https://t.co/PcBKloGFpg #Bitcoin #Ethereum #Cryptocurrency #\u2026",
        "user.screen_name": "SamKelly63"
    },
    {
        "created_at": "Mon Feb 12 03:37:31 +0000 2018",
        "id": 962893404072898561,
        "text": "RT @gramcointoken: TWO winner Thursday! (2x) Winners of .1BTC \n\nLike, Retweet, and Follow to enter!\n\n#btc #bitcoin #bitcoins #crypto #crypt\u2026",
        "user.screen_name": "burtjeffersonp"
    },
    {
        "created_at": "Mon Feb 12 03:37:31 +0000 2018",
        "id": 962893403540328448,
        "text": "No shock there.  Only an idiot would do something illegal with bitcoin and leave a record of the transaction for th\u2026 https://t.co/vsw3MUFunQ",
        "user.screen_name": "bkunzi01"
    },
    {
        "created_at": "Mon Feb 12 03:37:31 +0000 2018",
        "id": 962893400985960448,
        "text": "RT @zerohedge: We have officially gone from \"Bitcoin is a fraud\" to \"cryptocurrencies could potentially have a role in diversifying one\u2019s g\u2026",
        "user.screen_name": "MinorJewrley"
    },
    {
        "created_at": "Mon Feb 12 03:37:29 +0000 2018",
        "id": 962893395709456384,
        "text": "RT @willcole: Read this proto-money paper by @NickSzabo4 in 2012.  Despite it not mentioning Bitcoin (it was originally published in 2002 a\u2026",
        "user.screen_name": "_ritviksingh"
    },
    {
        "created_at": "Mon Feb 12 03:37:29 +0000 2018",
        "id": 962893393994178560,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "BouviesMom"
    },
    {
        "created_at": "Mon Feb 12 03:37:29 +0000 2018",
        "id": 962893392328970240,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "rmsitz"
    },
    {
        "created_at": "Mon Feb 12 03:37:28 +0000 2018",
        "id": 962893389879562240,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "mustardmary7"
    },
    {
        "created_at": "Mon Feb 12 03:37:28 +0000 2018",
        "id": 962893388528877568,
        "text": "RT @YarmolukDan: Google is now using #MachineLearning to predict flight delays https://t.co/PcBKloGFpg #Bitcoin #Ethereum #Cryptocurrency #\u2026",
        "user.screen_name": "JenniferAlsop7"
    },
    {
        "created_at": "Mon Feb 12 03:37:27 +0000 2018",
        "id": 962893387690053632,
        "text": "Bitcoin $BTC price is: $8525.63 \n\nBinance is TEMPORARILY accepting new users! GO! \ud83e\udd14 \ud83e\udd11  \n\n\u27a1\ufe0f https://t.co/YXpzwakZF7\u2026 https://t.co/CzexdIoUzp",
        "user.screen_name": "RoboJenron"
    },
    {
        "created_at": "Mon Feb 12 03:37:27 +0000 2018",
        "id": 962893387622838272,
        "text": "RT @BitcoinWrld: JPM: 'cryptocurrencies could potentially have a role in diversifying one\u2019s global bond and equity portfolio. Someone is ge\u2026",
        "user.screen_name": "SOCIALCURRENCIE"
    },
    {
        "created_at": "Mon Feb 12 03:37:27 +0000 2018",
        "id": 962893387291533313,
        "text": "U.K. government sites helping run scripts that mine crypto #Cryptocurrency #Bitcoin #Hacked #CyberSecurity\u2026 https://t.co/zgZmRigYVQ",
        "user.screen_name": "Inverselogic"
    },
    {
        "created_at": "Mon Feb 12 03:37:27 +0000 2018",
        "id": 962893387287347201,
        "text": "RT @CyberDomain: Israeli intelligence has embarked on the most widespread cyber esp https://t.co/lo9xYcLs6d #Cybersecurity #Bitcoin https:/\u2026",
        "user.screen_name": "saraswati_79"
    },
    {
        "created_at": "Mon Feb 12 03:37:27 +0000 2018",
        "id": 962893386658340865,
        "text": "RT @Remi_Vladuceanu: What Is Emercoin? https://t.co/S2CY9v8Bef \n#newsoftheweek #Bitcoin #blockchain #crypto #cryptocurrency #news https://t\u2026",
        "user.screen_name": "quantumlucy"
    },
    {
        "created_at": "Mon Feb 12 03:37:27 +0000 2018",
        "id": 962893386431819776,
        "text": "RT @JamesFourM: @LincolnsBible @Eiggam5955 @KellyannePolls \"A yearlong Senate investigation found that American buyers of the illegal drugs\u2026",
        "user.screen_name": "gardengirlove"
    },
    {
        "created_at": "Mon Feb 12 03:37:27 +0000 2018",
        "id": 962893384770834432,
        "text": "RT @YarmolukDan: Google is now using #MachineLearning to predict flight delays https://t.co/PcBKloGFpg #Bitcoin #Ethereum #Cryptocurrency #\u2026",
        "user.screen_name": "VictorSmith67"
    },
    {
        "created_at": "Mon Feb 12 03:37:26 +0000 2018",
        "id": 962893382086529025,
        "text": "RT @BTCTN: THIS WEEK IN BITCOIN | Subscribe on iTunes https://t.co/ftOqgh43Q4 The most important news in the Bitcoin world, delivered in ju\u2026",
        "user.screen_name": "TheCryptoInvest"
    },
    {
        "created_at": "Mon Feb 12 03:37:25 +0000 2018",
        "id": 962893379389542400,
        "text": "March Holiday Programs and What Students Can Learn From Bitcoin - https://t.co/TCH5xdCuRh",
        "user.screen_name": "BrightCulture"
    },
    {
        "created_at": "Mon Feb 12 03:37:25 +0000 2018",
        "id": 962893376386486272,
        "text": "RT @YarmolukDan: Google is now using #MachineLearning to predict flight delays https://t.co/PcBKloGFpg #Bitcoin #Ethereum #Cryptocurrency #\u2026",
        "user.screen_name": "JacobGrant31"
    },
    {
        "created_at": "Mon Feb 12 03:37:25 +0000 2018",
        "id": 962893375216201728,
        "text": "The 1 Bitcoin Show- Bprivate momentum? Ethereum, Bgold, phone storage th... https://t.co/onnl8chEKy via @YouTube",
        "user.screen_name": "TempestEikyuu"
    },
    {
        "created_at": "Mon Feb 12 03:37:24 +0000 2018",
        "id": 962893372863143936,
        "text": "Some hackers have tied string to a bitcoin and I'm running through cyberspace trying to catch while they pull it aw\u2026 https://t.co/zn1oEW8uFY",
        "user.screen_name": "cashbonez"
    },
    {
        "created_at": "Mon Feb 12 03:37:24 +0000 2018",
        "id": 962893371789295616,
        "text": "How to make money mining bitcoin and other cryptocurrencies without knowing anything about it\u2026 https://t.co/YnrWMupszI",
        "user.screen_name": "startupcrunch"
    },
    {
        "created_at": "Mon Feb 12 03:37:23 +0000 2018",
        "id": 962893369121767424,
        "text": "RT @zerohedge: We have officially gone from \"Bitcoin is a fraud\" to \"cryptocurrencies could potentially have a role in diversifying one\u2019s g\u2026",
        "user.screen_name": "arrington"
    },
    {
        "created_at": "Mon Feb 12 03:37:23 +0000 2018",
        "id": 962893368035393536,
        "text": "RT @giveawaysBTC: 7000 Follower Giveaway\n\nPrize: .5BTC (1 Winner)\n\nTo enter retweet, like, and follow!\n\n#btc #bitcoin #crypto #cryptocurren\u2026",
        "user.screen_name": "ALFzie"
    },
    {
        "created_at": "Mon Feb 12 03:37:22 +0000 2018",
        "id": 962893366269759489,
        "text": "RT @kickcity_io: Our KickCity Explainer Video is out. The video provides the details of our product in less than 3 mins. Watch and let us k\u2026",
        "user.screen_name": "nezumenorasei"
    },
    {
        "created_at": "Mon Feb 12 03:37:22 +0000 2018",
        "id": 962893365879730177,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "WandererMegan"
    },
    {
        "created_at": "Mon Feb 12 03:37:22 +0000 2018",
        "id": 962893363606253568,
        "text": "Show me the money.  In Episode 2 of Giftcoin: The Launch, how do you go about disrupting a half trillion dollar sec\u2026 https://t.co/2tl8xKKDSC",
        "user.screen_name": "bitcoin_army"
    },
    {
        "created_at": "Mon Feb 12 03:37:22 +0000 2018",
        "id": 962893362977296385,
        "text": "RT @BTCTN: Republican Candidate Austin Petersen Accepts the Largest Campaign Contribution Paid in BTC https://t.co/13LXmgh21K #Bitcoin http\u2026",
        "user.screen_name": "TheCryptoInvest"
    },
    {
        "created_at": "Mon Feb 12 03:37:21 +0000 2018",
        "id": 962893360699654144,
        "text": "RT @The1000pClub: ATH (Athenian Warrior Token) is really picking up on Cryptopia. The whole market is bleeding and still can\u2019t stop this co\u2026",
        "user.screen_name": "Caplan2990"
    },
    {
        "created_at": "Mon Feb 12 03:37:21 +0000 2018",
        "id": 962893358740967426,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "Alexia_Lavoie"
    },
    {
        "created_at": "Mon Feb 12 03:37:20 +0000 2018",
        "id": 962893355024830464,
        "text": "RT @YarmolukDan: Google is now using #MachineLearning to predict flight delays https://t.co/PcBKloGFpg #Bitcoin #Ethereum #Cryptocurrency #\u2026",
        "user.screen_name": "PaulRees45"
    },
    {
        "created_at": "Mon Feb 12 03:37:20 +0000 2018",
        "id": 962893354316062720,
        "text": "RT @Remi_Vladuceanu: XRP Price Surges to $1.20 Thanks to Solid 50% Overnight Gain https://t.co/hWD9yAO2jV \n#newsoftheweek #Bitcoin #blockch\u2026",
        "user.screen_name": "quantumlucy"
    },
    {
        "created_at": "Mon Feb 12 03:37:19 +0000 2018",
        "id": 962893354198593537,
        "text": "Bitcoin clawed its way back from the four-month low of $5,922 it touched on Tuesday. https://t.co/oqcWczaVVz via @BloombergQuint",
        "user.screen_name": "wisejayofficial"
    },
    {
        "created_at": "Mon Feb 12 03:37:19 +0000 2018",
        "id": 962893352202104833,
        "text": "What Is Emercoin? https://t.co/S2CY9v8Bef \n#newsoftheweek #Bitcoin #blockchain #crypto #cryptocurrency #news https://t.co/Zp21McZzMy",
        "user.screen_name": "Remi_Vladuceanu"
    },
    {
        "created_at": "Mon Feb 12 03:37:19 +0000 2018",
        "id": 962893350662758400,
        "text": "RT @YarmolukDan: Google is now using #MachineLearning to predict flight delays https://t.co/PcBKloGFpg #Bitcoin #Ethereum #Cryptocurrency #\u2026",
        "user.screen_name": "StevenDavidso3"
    },
    {
        "created_at": "Mon Feb 12 03:37:19 +0000 2018",
        "id": 962893350172020736,
        "text": "RT @zerohedge: We have officially gone from \"Bitcoin is a fraud\" to \"cryptocurrencies could potentially have a role in diversifying one\u2019s g\u2026",
        "user.screen_name": "boxing1111"
    },
    {
        "created_at": "Mon Feb 12 03:37:18 +0000 2018",
        "id": 962893349878317061,
        "text": "Massive Coincheck heist fails to curb Japan's enthusiasm for Bitcoin and other cryptocurrencies\u2026 https://t.co/SksHMUb4Bz",
        "user.screen_name": "startupcrunch"
    },
    {
        "created_at": "Mon Feb 12 03:37:18 +0000 2018",
        "id": 962893347290574849,
        "text": "RT @singhal_harsh: Doing 100 $XRP giveaway in 2 days!\n5 lucky winners will win.\n\nTo enter:\n1. RETWEET AND LIKE THIS \n2. FOLLOW ME\n\n$BTC #cr\u2026",
        "user.screen_name": "smith_sm1th"
    },
    {
        "created_at": "Mon Feb 12 03:37:18 +0000 2018",
        "id": 962893346682241024,
        "text": "RT @ReutersUK: U.S., UK government websites infected with crypto-mining malware - report https://t.co/mNR9eZ95BT https://t.co/4774GvtCIg",
        "user.screen_name": "Gyggy"
    },
    {
        "created_at": "Mon Feb 12 03:37:17 +0000 2018",
        "id": 962893342651703296,
        "text": "Bitcoin Price Analysis: Bearish Continuation Pattern Could Signal End of Bullish Rally https://t.co/9arlfXrMqn",
        "user.screen_name": "peirokukazen"
    },
    {
        "created_at": "Mon Feb 12 03:37:17 +0000 2018",
        "id": 962893342366470145,
        "text": "RT @YarmolukDan: Google is now using #MachineLearning to predict flight delays https://t.co/PcBKloGFpg #Bitcoin #Ethereum #Cryptocurrency #\u2026",
        "user.screen_name": "BellaRoberts181"
    },
    {
        "created_at": "Mon Feb 12 03:37:16 +0000 2018",
        "id": 962893340193804290,
        "text": "@rogerkver Stop spreading #FUD! $BTC is #Bitcoin and don\u2019t forget #LightningNetwork \ud83d\ude0e",
        "user.screen_name": "KnightCrypto"
    },
    {
        "created_at": "Mon Feb 12 03:37:16 +0000 2018",
        "id": 962893337744281600,
        "text": "RT @SecurityNews: https://t.co/kS2bV6fSqa :  Bitcoin MLM Software 1.0.2 Cross Site Scripting https://t.co/oT9JuGJMB9",
        "user.screen_name": "bitclubbitcoin"
    },
    {
        "created_at": "Mon Feb 12 03:37:15 +0000 2018",
        "id": 962893337220001793,
        "text": "RT @davidgokhshtein: Update: $BTC \u2014 why you not dip yet? #Cryptos #crypto #bitcoin #cryptonews #cryptosignals #cryptomamba #HODLgang https:\u2026",
        "user.screen_name": "JWill954"
    },
    {
        "created_at": "Mon Feb 12 03:37:15 +0000 2018",
        "id": 962893334946738176,
        "text": "Bitcoin Price Technical Analysis for 02/12/2018 \u2013 Make or Break Level https://t.co/P14Y4J40so\n\nBitcoin Price Key Hi\u2026 https://t.co/wqYqiwXC3S",
        "user.screen_name": "abrahammia01"
    },
    {
        "created_at": "Mon Feb 12 03:37:14 +0000 2018",
        "id": 962893330148446208,
        "text": "RT @Coin_Source: Coinsource leading the way as the World's Largest #BitcoinATM Operator offering the industry's lowest rates, exclusive fee\u2026",
        "user.screen_name": "lionbitcoin"
    },
    {
        "created_at": "Mon Feb 12 03:37:12 +0000 2018",
        "id": 962893324565622785,
        "text": "Bitcoin steady as cryptocurrencies take a back seat to the stock market for another session https://t.co/5qNeAkCvDD\u2026 https://t.co/sjLQLEVdcM",
        "user.screen_name": "startupcrunch"
    },
    {
        "created_at": "Mon Feb 12 03:37:12 +0000 2018",
        "id": 962893324427313152,
        "text": "RT @CryptoKang: Big step for $CRYPTO adoption, thanks @coinbase. (Notice Bitcoin Cash is the first option)\ud83d\ude0a https://t.co/tWBYp4Bgms",
        "user.screen_name": "uruururiri"
    },
    {
        "created_at": "Mon Feb 12 03:37:12 +0000 2018",
        "id": 962893323152363525,
        "text": "@paulvlad34 @CryptoCoinNewz You will have to buy Bitcoin or Ethereum(Eth has lower transaction fees) on Coinbase an\u2026 https://t.co/q60jGpMAVU",
        "user.screen_name": "Hola12373621876"
    },
    {
        "created_at": "Mon Feb 12 03:37:12 +0000 2018",
        "id": 962893322351267840,
        "text": "$UBQ is currently so undervalued\nThe real ones know #UBIQ 's potential.\n \n#ubq #ubiq #cryptocurrency #bitcoin $ubq $ubiq @ubiqsmart",
        "user.screen_name": "CryptoKarn"
    },
    {
        "created_at": "Mon Feb 12 03:37:12 +0000 2018",
        "id": 962893322204405760,
        "text": "Feds Seize $4.7 Million in Bitcoins in Fake ID Sting https://t.co/Kxt8bknIaG \n#newsoftheweek #Bitcoin #blockchain\u2026 https://t.co/8gTJWpY7Bd",
        "user.screen_name": "Remi_Vladuceanu"
    },
    {
        "created_at": "Mon Feb 12 03:37:12 +0000 2018",
        "id": 962893321965219840,
        "text": "RT @CryptoMarauder: If you need some perspective on the general direction of $BTC... Read this AWESOME technical analysis by LewisGlasgow o\u2026",
        "user.screen_name": "parabolicpam"
    },
    {
        "created_at": "Mon Feb 12 03:37:12 +0000 2018",
        "id": 962893320795062272,
        "text": "RT @BitcoinEdu: Give a modest amount of bitcoin to new colleagues and explain how it operates, then assist them get secure to spend it for\u2026",
        "user.screen_name": "ScKae007"
    },
    {
        "created_at": "Mon Feb 12 03:37:11 +0000 2018",
        "id": 962893317418622977,
        "text": "Let government money compete with cryptocurrencies https://t.co/zRL5aBbrAk #crypto https://t.co/8beML1ZdMG",
        "user.screen_name": "startupcrunch"
    },
    {
        "created_at": "Mon Feb 12 03:37:10 +0000 2018",
        "id": 962893315908755456,
        "text": "RT @CryptoBoomNews: Do you panic sell or buy more? #cryptocurrency #bitcoin #crypto https://t.co/dNfHh2GO1h",
        "user.screen_name": "rexsanders2010"
    },
    {
        "created_at": "Mon Feb 12 03:37:10 +0000 2018",
        "id": 962893312574271489,
        "text": "Oil company announces to sell Bitcoin ATMs to Casinos, Stocks Shoot 60% https://t.co/QzKLX5UxM2 #technology",
        "user.screen_name": "SGBmedia"
    },
    {
        "created_at": "Mon Feb 12 03:37:09 +0000 2018",
        "id": 962893311139659776,
        "text": "RT @zerohedge: We have officially gone from \"Bitcoin is a fraud\" to \"cryptocurrencies could potentially have a role in diversifying one\u2019s g\u2026",
        "user.screen_name": "hedging_reality"
    },
    {
        "created_at": "Mon Feb 12 03:37:09 +0000 2018",
        "id": 962893308186931201,
        "text": "CRYPTO \u2b55 Bitcoin Plus (XBC) Hits Market Cap of $7.03 Million https://t.co/lhHVftuX0h \ud83d\ude80 HowToBuy BTS via \u2192 https://t.co/ezGO5ULdtG",
        "user.screen_name": "PennyStocksMomo"
    },
    {
        "created_at": "Mon Feb 12 03:37:08 +0000 2018",
        "id": 962893306609917952,
        "text": "CRYPTO \u2b55 Bitcoin Atom Trading 12.9% Higher This Week (BCA) https://t.co/E0k8WVbu3A \ud83d\ude80 HowToBuy BTS via \u2192 https://t.co/ezGO5ULdtG",
        "user.screen_name": "PennyStocksMomo"
    },
    {
        "created_at": "Mon Feb 12 03:37:06 +0000 2018",
        "id": 962893296774168577,
        "text": "#Bitcoin #bitcoin #iceland #mining Iceland May Implement Bitcoin Mining Tax Due to Energy Consumption\u2026 https://t.co/PDwTA7M7td",
        "user.screen_name": "BtcFastFree"
    },
    {
        "created_at": "Mon Feb 12 03:37:06 +0000 2018",
        "id": 962893296589787137,
        "text": "Bitcoin Price Technical Analysis for 02/12/2018 \u2013 Make or Break Level https://t.co/CDyfrbyBuK #bitcoin",
        "user.screen_name": "BitcoinBolt"
    },
    {
        "created_at": "Mon Feb 12 03:37:06 +0000 2018",
        "id": 962893295587229696,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "jamaicatouch"
    },
    {
        "created_at": "Mon Feb 12 03:37:00 +0000 2018",
        "id": 962893274213240832,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "tinadsm"
    },
    {
        "created_at": "Mon Feb 12 03:37:00 +0000 2018",
        "id": 962893273990909953,
        "text": "RT @CryptoBoomNews: Do you panic sell or buy more? #cryptocurrency #bitcoin #crypto https://t.co/dNfHh2GO1h",
        "user.screen_name": "AnimePumps"
    },
    {
        "created_at": "Mon Feb 12 03:37:00 +0000 2018",
        "id": 962893273726566400,
        "text": "RT @IsaFX_Trading: #GIVEAWAY of 0.20BTC simply follow, retweet &amp;  comment your BTC add  10 Winners will be picked randomly among all RTs on\u2026",
        "user.screen_name": "cryptoabhi1809"
    },
    {
        "created_at": "Mon Feb 12 03:37:00 +0000 2018",
        "id": 962893272648568833,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "eodelt81"
    },
    {
        "created_at": "Mon Feb 12 03:36:59 +0000 2018",
        "id": 962893266550075392,
        "text": "RT @zerohedge: We have officially gone from \"Bitcoin is a fraud\" to \"cryptocurrencies could potentially have a role in diversifying one\u2019s g\u2026",
        "user.screen_name": "moniology"
    },
    {
        "created_at": "Mon Feb 12 03:36:59 +0000 2018",
        "id": 962893266461933568,
        "text": "RT @aantonop: While the banks are busy building their permissioned private 'Bubble Boy' blockchains, #Bitcoin has survived more than nine y\u2026",
        "user.screen_name": "kydyzyx"
    },
    {
        "created_at": "Mon Feb 12 03:36:58 +0000 2018",
        "id": 962893265157677056,
        "text": "RT @BTCTN: Japan\u2019s DMM Launches Large-Scale Domestic Cryptocurrency Mining Farm and Showroom https://t.co/VDXzFOSt3f #Bitcoin https://t.co/\u2026",
        "user.screen_name": "TheCryptoInvest"
    },
    {
        "created_at": "Mon Feb 12 03:36:58 +0000 2018",
        "id": 962893263991705600,
        "text": "I liked a @YouTube video https://t.co/WXRQKxAc5a The 1 Bitcoin Show- Bprivate momentum? Ethereum, Bgold, phone storage thoughts, the",
        "user.screen_name": "BiGChinGSdotCOM"
    },
    {
        "created_at": "Mon Feb 12 03:36:58 +0000 2018",
        "id": 962893262997438464,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "irishgilly"
    },
    {
        "created_at": "Mon Feb 12 03:36:56 +0000 2018",
        "id": 962893256857137152,
        "text": "RT @RiconaOfficial: Countdown for the #ICO launch Begins...\nDate of Launch: 11th Feb 2018\nRegister now: https://t.co/elfHgHCDZ3\n#upcomingic\u2026",
        "user.screen_name": "Vrabac68"
    },
    {
        "created_at": "Mon Feb 12 03:36:56 +0000 2018",
        "id": 962893254491561985,
        "text": "RT @ElixiumCrypto: Phat #Bitcoin Loot &amp; Sick Gainz Are Now Available Exclusively @\n\nhttps://t.co/xVmu7aXO64\n\n\u2705 Up To 100x Leverage!\n\u2705 Easy\u2026",
        "user.screen_name": "clemens_twain"
    },
    {
        "created_at": "Mon Feb 12 03:36:53 +0000 2018",
        "id": 962893244081287169,
        "text": "RT @ATEKAssetScan: #BigData Comes to Dieting https://t.co/G3PsUrtdlt #Bitcoin #Ethereum #Cryptocurrency #Blockchain #Altcoins #DataScience\u2026",
        "user.screen_name": "GeekJimiLee"
    },
    {
        "created_at": "Mon Feb 12 03:36:51 +0000 2018",
        "id": 962893235067785216,
        "text": "RT @BTCTN: Coingeek Launches \u00a35 Million Bitcoin Cash Tokenization Contest https://t.co/tSaVae5RQj #Bitcoin https://t.co/qBnpdJvCj5",
        "user.screen_name": "TheCryptoInvest"
    },
    {
        "created_at": "Mon Feb 12 03:36:50 +0000 2018",
        "id": 962893228671488000,
        "text": "@Hhazardless I accept bitcoin, paypal, Moneygram, cash on arrival or Western Union",
        "user.screen_name": "luke_smiff"
    },
    {
        "created_at": "Mon Feb 12 03:36:50 +0000 2018",
        "id": 962893228470161408,
        "text": "RT @DigitalKeith: Every 60 sec on #Internet.\n#DigitalMarketing #InternetMarketing #SocialMedia #SEO #SMM #Mpgvip #defstar5 #BigData #bitcoi\u2026",
        "user.screen_name": "pangamabeitsu"
    },
    {
        "created_at": "Mon Feb 12 03:36:49 +0000 2018",
        "id": 962893227815616517,
        "text": "RT @iamjosephyoung: Oh wait, so bitcoin wasn't for criminals after all?\n\nNope. Banks are the safe haven for money launderers and criminals.\u2026",
        "user.screen_name": "JakerSor21"
    },
    {
        "created_at": "Mon Feb 12 03:36:47 +0000 2018",
        "id": 962893218906910720,
        "text": "RT @giveawaysBTC: 7000 Follower Giveaway\n\nPrize: .5BTC (1 Winner)\n\nTo enter retweet, like, and follow!\n\n#btc #bitcoin #crypto #cryptocurren\u2026",
        "user.screen_name": "fanney_aketch"
    },
    {
        "created_at": "Mon Feb 12 03:36:47 +0000 2018",
        "id": 962893218647105536,
        "text": "RT @davidamesoregan: This can be done on telegram...\n\ud83e\udd14\nInterested in litecoin, take a look at this great opportunity...\n\ud83e\udd14\ud83e\udd14\ud83e\udd14\niCenter Lite Bo\u2026",
        "user.screen_name": "davidamesoregan"
    },
    {
        "created_at": "Mon Feb 12 03:36:46 +0000 2018",
        "id": 962893214821896192,
        "text": "RT @FatBTC: ReTweet To Vote, show the COMMUNITY POWER of your coin:\n\nStep 1: Follow @FatBTC on Twitter\nStep 2: Retweet this post for @bitco\u2026",
        "user.screen_name": "mosplus27"
    },
    {
        "created_at": "Mon Feb 12 03:36:42 +0000 2018",
        "id": 962893198514323456,
        "text": "RT @notgrubles: You are technically proficient and want to run a #Bitcoin Lightning Network node to improve decentralization and maybe earn\u2026",
        "user.screen_name": "notgrubles"
    },
    {
        "created_at": "Mon Feb 12 03:36:42 +0000 2018",
        "id": 962893196228513792,
        "text": "RT @FupoofCoin: Retweet to earn 200 fupoofcoin.Need a min of a 1000 twitter followers .Comment waves address to get paid  To hell with payp\u2026",
        "user.screen_name": "CryptoBisma"
    },
    {
        "created_at": "Mon Feb 12 03:36:41 +0000 2018",
        "id": 962893193573552128,
        "text": "Bitcoin SURGE: Cryptocurrency could reward investors and hit $25,000 THIS YEAR THE NEWS - GROUP OF WORLD -\u2026 https://t.co/FkkG6EpmoQ",
        "user.screen_name": "newsgwcom"
    },
    {
        "created_at": "Mon Feb 12 03:36:41 +0000 2018",
        "id": 962893191019024384,
        "text": "RT @HotCryptoCoins: Check it out!\nWe're giving away 2500 Stellar XLM to a lucky follower when we reach 5k followers!\nTo Enter to WIN you mu\u2026",
        "user.screen_name": "tunmyintaung"
    },
    {
        "created_at": "Mon Feb 12 03:36:41 +0000 2018",
        "id": 962893190691991552,
        "text": "Will #Bitcoin Crash to Zero? Yes, Says Dr. Doom Calling Bitcoin th\u2026 #Blockchain #News The post Will Bitcoin Crash t\u2026 https://t.co/eUUXSuAi89",
        "user.screen_name": "shopseasonal"
    },
    {
        "created_at": "Mon Feb 12 03:36:38 +0000 2018",
        "id": 962893181825273856,
        "text": "RT @PhilakoneCrypto: Please see this 3 minute tip that will drastically improve your shorting game with a 10 minute live trade for $90 prof\u2026",
        "user.screen_name": "itscryptorick"
    },
    {
        "created_at": "Mon Feb 12 03:36:37 +0000 2018",
        "id": 962893175672188930,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "good_wifey"
    },
    {
        "created_at": "Mon Feb 12 03:36:37 +0000 2018",
        "id": 962893175160422400,
        "text": "RT @Landm_Marius: BITCOIN UPDATE:\nCrypto Friends - There is a new UPDATE on website - FREE to Crypto Friends.\n\nI give you the date the STOC\u2026",
        "user.screen_name": "Landm_Marius"
    },
    {
        "created_at": "Mon Feb 12 03:36:30 +0000 2018",
        "id": 962893147570393089,
        "text": "RT @WeAreYourBlock: YourBlock Bounty Campaign now Live https://t.co/CGrgymVBpL\n#bountyprogram #Bounty #TokenSale #ICOs #ICO #blockchain #we\u2026",
        "user.screen_name": "Alvar0_Terra"
    },
    {
        "created_at": "Mon Feb 12 03:36:30 +0000 2018",
        "id": 962893147159257088,
        "text": "RT @Freetoken_: 1 $ETH giveaway \n\nJoin https://t.co/eu3dZmPrX0\n\nRETWEET+ Follow to participate \n\nWinner will be announced the 15st of Febru\u2026",
        "user.screen_name": "MrinalShrivast5"
    },
    {
        "created_at": "Mon Feb 12 03:36:28 +0000 2018",
        "id": 962893139559243776,
        "text": "RT @bitcoin_token: #BTKtotheMoon #Giveaway of 59,999  $BTK \nThere will be 250 winners [rules]\n1) Follow &gt; @fatbtc AND @bitcoin_token\n2) ReT\u2026",
        "user.screen_name": "mosplus27"
    },
    {
        "created_at": "Mon Feb 12 03:36:28 +0000 2018",
        "id": 962893137948610560,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "bluesolitaire"
    },
    {
        "created_at": "Mon Feb 12 03:36:25 +0000 2018",
        "id": 962893127731179520,
        "text": "RT @PeterSchiff: Ivan on Tech debates Peter Schiff - Bitcoin vs Gold, US Dollar Crash https://t.co/fpBeHPA01s via @YouTube",
        "user.screen_name": "LuisKAP5"
    },
    {
        "created_at": "Mon Feb 12 03:36:23 +0000 2018",
        "id": 962893116251561984,
        "text": "RT @ok_appy: What #digital money really means for our #future... https://t.co/bYxwQshzUc #cryptocurrency #blockchain",
        "user.screen_name": "creative_safari"
    },
    {
        "created_at": "Mon Feb 12 03:36:21 +0000 2018",
        "id": 962893108118618112,
        "text": "RT @Lochm1807: \u26cf\ufe0f        1 BITCOIN GIVEAWAY       \u26cf\ufe0f\n\ud83d\udcb5  8000$ WORTH OF BITCOINS  \ud83d\udcb5\n\ud83d\udcdd LIKE, RT &amp; FOLLOW TO ENTER \ud83d\udcdd\n\ud83d\udd12      ENDS AT 500 RETWEE\u2026",
        "user.screen_name": "agparkoreman"
    },
    {
        "created_at": "Mon Feb 12 03:36:19 +0000 2018",
        "id": 962893102406025216,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "msallen2u"
    },
    {
        "created_at": "Mon Feb 12 03:36:18 +0000 2018",
        "id": 962893097721049088,
        "text": "RT @giftzcard: Learn more at https://t.co/IghWOoy46H #blockchain #bitcoin #ico #tokensale https://t.co/331AzPs3KU",
        "user.screen_name": "EnlightenedCole"
    },
    {
        "created_at": "Mon Feb 12 03:36:18 +0000 2018",
        "id": 962893097008066560,
        "text": "You, proletariat: Fuck crypto. \n\nJP Morgan, bank: https://t.co/tmcqRrrAsZ",
        "user.screen_name": "Judetruth"
    },
    {
        "created_at": "Mon Feb 12 03:36:17 +0000 2018",
        "id": 962893091165351938,
        "text": "RT @bitcoin_token: #BTKtotheMoon #Giveaway of 59,999  $BTK \nThere will be 250 winners [rules]\n1) Follow &gt; @fatbtc AND @bitcoin_token\n2) ReT\u2026",
        "user.screen_name": "Giftycrypto"
    },
    {
        "created_at": "Mon Feb 12 03:36:15 +0000 2018",
        "id": 962893084920025090,
        "text": "RT @zerohedge: Bitcoin ETFs pending approval https://t.co/2dS9l4Ggsw",
        "user.screen_name": "provendirection"
    },
    {
        "created_at": "Mon Feb 12 03:36:14 +0000 2018",
        "id": 962893080922873856,
        "text": "RT @Crypticsup: Cryptocurrency forecast for 10.02.2018\n\nhttps://t.co/LwPT4xW4ln\n\n#Cryptics #crowdsale #bitcoin  #ico  #Cryptocurrencies #cr\u2026",
        "user.screen_name": "cefewefWhi"
    },
    {
        "created_at": "Mon Feb 12 03:36:14 +0000 2018",
        "id": 962893079593259008,
        "text": "RT @krassenstein: America seems to have the most backwards president in a century, when we really need the most forward thinking President.\u2026",
        "user.screen_name": "pedi_suzanne"
    },
    {
        "created_at": "Mon Feb 12 03:35:19 +0000 2018",
        "id": 962892847136391169,
        "text": "Started in 2008 by a Yale &amp; MIT grad who became an entrepreneur at age 10, 40Billion is... https://t.co/lXYCv3bORN",
        "user.screen_name": "40Billion_com"
    },
    {
        "created_at": "Mon Feb 12 03:35:10 +0000 2018",
        "id": 962892810234970112,
        "text": "Is tech dividing America? https://t.co/WT2JJD4UXV",
        "user.screen_name": "mirabellous"
    },
    {
        "created_at": "Mon Feb 12 03:35:08 +0000 2018",
        "id": 962892802995744768,
        "text": "MIT Launches Initiative To Develop #ArtificialIntelligence That Learns Like Children | Edify #AI #IA #BigData https://t.co/h6UqjYMyXG",
        "user.screen_name": "nschaetti"
    },
    {
        "created_at": "Mon Feb 12 03:35:00 +0000 2018",
        "id": 962892770431176710,
        "text": "RT @TraDove_ICO: Breakfast with our team, board member Gordon Kaufman, and Professor Emeritus from the MIT Sloan School of Management. Big\u2026",
        "user.screen_name": "GoBracket"
    },
    {
        "created_at": "Mon Feb 12 03:34:43 +0000 2018",
        "id": 962892698561732608,
        "text": "Annina Ucatis #hat harten Sex #mit #einem seiner Cousins #Inzest #xxx #hviaklqs https://t.co/0qxcF2hq7I",
        "user.screen_name": "Tanner538Tanner"
    },
    {
        "created_at": "Mon Feb 12 03:34:22 +0000 2018",
        "id": 962892608887574529,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "RajivKm19"
    },
    {
        "created_at": "Mon Feb 12 03:33:07 +0000 2018",
        "id": 962892294729777152,
        "text": "RT @BillAulet: .@jockowillink on fire at Brisbane MIT Global Entrepreneurship Bootcamp talking about #extremeleadership @MITBootcamps @QUT\u2026",
        "user.screen_name": "Change_2020"
    },
    {
        "created_at": "Mon Feb 12 03:32:08 +0000 2018",
        "id": 962892047362355200,
        "text": "https://t.co/kS2bV6fSqa :  Eric Schmidt Lands at MIT To Help Answer Deep Questions https://t.co/Fdyq9d9rqm",
        "user.screen_name": "SecurityNews"
    },
    {
        "created_at": "Mon Feb 12 03:32:03 +0000 2018",
        "id": 962892028697894914,
        "text": "Distinctive brain pattern helps habits form: Study identifies neurons that fire at the beginning and end of a behav\u2026 https://t.co/hAn38PZ6um",
        "user.screen_name": "BenZviGroup"
    },
    {
        "created_at": "Mon Feb 12 03:31:40 +0000 2018",
        "id": 962891928730767360,
        "text": "RT @MSFTImagine: Imagine a world with faster, cheaper #AI! @MIT researchers say we're closer to #computers that work like our brains: https\u2026",
        "user.screen_name": "devfever"
    },
    {
        "created_at": "Mon Feb 12 03:31:29 +0000 2018",
        "id": 962891884958973952,
        "text": "MIT Professor requires students to watch Black Mirror episodes to learn lessons for the future #BlackMirror\u2026 https://t.co/ajGA9CItvJ",
        "user.screen_name": "top10newsonline"
    },
    {
        "created_at": "Mon Feb 12 03:30:52 +0000 2018",
        "id": 962891729799143424,
        "text": "RT @MITevents: Tomorrow: BetterMIT #Innovation Week: A week-long program promoting leadership, entrepreneurship, and action for a better fu\u2026",
        "user.screen_name": "MIT_Innovation"
    },
    {
        "created_at": "Mon Feb 12 03:30:19 +0000 2018",
        "id": 962891588597776384,
        "text": "@FoxNews No Doubt that CROOK #TRUMP Not only sold 2RUSSIA but as well Sold 2 Oil&amp;Gas, Weapons, Construction lobbies\u2026 https://t.co/NUjrAHX0EK",
        "user.screen_name": "annedelim"
    },
    {
        "created_at": "Mon Feb 12 03:30:07 +0000 2018",
        "id": 962891542020132864,
        "text": "MIT Professor requires students to watch Black Mirror episodes to learn lessons for the future #BlackMirror\u2026 https://t.co/1AdUuBlqHB",
        "user.screen_name": "HealthRanger"
    },
    {
        "created_at": "Mon Feb 12 03:30:03 +0000 2018",
        "id": 962891521782702081,
        "text": "Trying to play in MPBA MIT and upcoming season.... 6'11 Sharp Athletic Finisher PF.... 91 overall, 32 badges.... st\u2026 https://t.co/vhzxhcNAFw",
        "user.screen_name": "djmadefx4"
    },
    {
        "created_at": "Mon Feb 12 03:30:01 +0000 2018",
        "id": 962891516111933440,
        "text": "MIT Professor requires students to watch Black Mirror episodes to learn lessons for the future #BlackMirror\u2026 https://t.co/seX2RVnW0s",
        "user.screen_name": "RealNaturalNews"
    },
    {
        "created_at": "Mon Feb 12 03:29:15 +0000 2018",
        "id": 962891320955228161,
        "text": "https://t.co/Tfh5hMLNIq Anyone know the computer science blogger who archived a chatroom discussion comparing Harva\u2026 https://t.co/iixpTFAKOq",
        "user.screen_name": "reddit4devs"
    },
    {
        "created_at": "Mon Feb 12 03:28:46 +0000 2018",
        "id": 962891200771641344,
        "text": "RT @TheTastingBoard: Two MIT grads created an algorithm to reveal your cheese preferences. Take the quiz below to find yours for free! \n ht\u2026",
        "user.screen_name": "JustOneVoice43"
    },
    {
        "created_at": "Mon Feb 12 03:28:39 +0000 2018",
        "id": 962891173189754880,
        "text": "@lesmis_mit hoooy follow back \ud83d\ude02",
        "user.screen_name": "MarkOdever"
    },
    {
        "created_at": "Mon Feb 12 03:28:34 +0000 2018",
        "id": 962891151538663424,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "EricMackC"
    },
    {
        "created_at": "Mon Feb 12 03:28:29 +0000 2018",
        "id": 962891127811649536,
        "text": "RT @mitsmr: \u201cJournalists often check a CEO\u2019s Twitter account before covering the CEO or the company.\u201d https://t.co/er59CY71Vg",
        "user.screen_name": "ruisilva"
    },
    {
        "created_at": "Mon Feb 12 03:28:08 +0000 2018",
        "id": 962891042256310273,
        "text": "RT @WALLACHLEGAL: I\u2019ll be joining Ted Olson, Laila Mintas (@DrMintas), Chad Millman and Jeff Ma next week at the MIT Sloan Sports Analytics\u2026",
        "user.screen_name": "StatementGames"
    },
    {
        "created_at": "Mon Feb 12 03:27:45 +0000 2018",
        "id": 962890946466795520,
        "text": "RT @drronstrand: Distinctive brain pattern helps habits form https://t.co/JprHWns0hw https://t.co/VQUcuoHIPC",
        "user.screen_name": "JolieC"
    },
    {
        "created_at": "Mon Feb 12 03:27:34 +0000 2018",
        "id": 962890897020026881,
        "text": "RT @mitsmr: Digital innovation can bring renewal to established companies \u2014 but requires careful planning https://t.co/SnYTwEZMXJ https://t\u2026",
        "user.screen_name": "rsepulveda8"
    },
    {
        "created_at": "Mon Feb 12 03:27:32 +0000 2018",
        "id": 962890890648862720,
        "text": "RT @hildabast: Day 2 #BlackHistoryMonth: Physicist, Carolyn Beatrice Parker - a remarkable woman, whose long-lost story shows how much work\u2026",
        "user.screen_name": "JChrisPires"
    },
    {
        "created_at": "Mon Feb 12 03:27:14 +0000 2018",
        "id": 962890816476909568,
        "text": "https://t.co/bYGfywA6sz Pres Bacow PLEASE INSTILL a higher level of patriotism &amp; social responsibility into Harvard\u2026 https://t.co/XCYWnFbrHp",
        "user.screen_name": "AmeriMadeHeroes"
    },
    {
        "created_at": "Mon Feb 12 03:27:12 +0000 2018",
        "id": 962890807647678464,
        "text": "SUPERDRY Angebote Superdry Orange Label Vintage T-Shirt mit Stickerei: Category: Herren / T-Shirts / Langarmshirt I\u2026 https://t.co/Xxkc8gfXaH",
        "user.screen_name": "SparVolltreffer"
    },
    {
        "created_at": "Mon Feb 12 03:27:10 +0000 2018",
        "id": 962890796897849344,
        "text": "RT @MITSloan: The idea of a universal basic income is not new, but the theory has never been thoroughly tested. A massive new study is abou\u2026",
        "user.screen_name": "ruisilva"
    },
    {
        "created_at": "Mon Feb 12 03:27:09 +0000 2018",
        "id": 962890792925765632,
        "text": "SUPERDRY Angebote Superdry SD Sport Rundhalspullover mit Farbblock-Design: Category: Damen / Sport-Sweatshirts / Sw\u2026 https://t.co/DwmquRQGRH",
        "user.screen_name": "SparVolltreffer"
    },
    {
        "created_at": "Mon Feb 12 03:26:50 +0000 2018",
        "id": 962890713628401665,
        "text": "RT @KrisKoles: Harvard names an MIT graduate and son of immigrants, Lawrence S. Bacow, as its 29th president.....\nhttps://t.co/6812AcxHNG",
        "user.screen_name": "akateach1"
    },
    {
        "created_at": "Mon Feb 12 03:26:22 +0000 2018",
        "id": 962890594442973184,
        "text": "Solid aims to radically change the way web applications work https://t.co/qUID3kaD1W",
        "user.screen_name": "tmcpro"
    },
    {
        "created_at": "Mon Feb 12 03:26:19 +0000 2018",
        "id": 962890582791090176,
        "text": "RT @DrHughHarvey: Didn\u2019t study deep learning at MIT?\n\nDon\u2019t worry - here\u2019s the entire course \n\nhttps://t.co/HTONtKKWWz https://t.co/bmbxY5u\u2026",
        "user.screen_name": "kayan2727"
    },
    {
        "created_at": "Mon Feb 12 03:26:16 +0000 2018",
        "id": 962890569662869504,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "all_that_is"
    },
    {
        "created_at": "Mon Feb 12 03:25:59 +0000 2018",
        "id": 962890501748854785,
        "text": "RT @mitsmr: RT @MITSloan: Not-so-light reading from last year, courtesy of MIT Sloan faculty. https://t.co/8VEnCacpJG https://t.co/znyZ0eRs\u2026",
        "user.screen_name": "RoshaundaDGreen"
    },
    {
        "created_at": "Mon Feb 12 03:25:39 +0000 2018",
        "id": 962890416373735424,
        "text": "Facial recognition software is biased towards white men, researcher finds\nBiases are seeping into software\u2026 https://t.co/RR86Ga0BGj",
        "user.screen_name": "minisharma018"
    },
    {
        "created_at": "Mon Feb 12 03:25:37 +0000 2018",
        "id": 962890408962408448,
        "text": "#science #technology #News &gt;&gt;  12 years since John Durant took the helm at the MIT Museu... For More LIKE &amp; FOLLOW @JPPMsolutions",
        "user.screen_name": "JPPMsolutions"
    },
    {
        "created_at": "Mon Feb 12 03:25:01 +0000 2018",
        "id": 962890256474361857,
        "text": "RT @BrightCellars: 2 MIT grads built an algorithm to match you with wine. Take the quiz to see your matches! https://t.co/LdIvB7sY05 https:\u2026",
        "user.screen_name": "AdriannaMead"
    },
    {
        "created_at": "Mon Feb 12 03:24:38 +0000 2018",
        "id": 962890158252089347,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "Law_Purush"
    },
    {
        "created_at": "Mon Feb 12 03:24:14 +0000 2018",
        "id": 962890059249803264,
        "text": "#harte #fickszenen #mit #bonnie #rotton und co https://t.co/MDSEwiOfhr",
        "user.screen_name": "BWo6yxxsNDDr0rf"
    },
    {
        "created_at": "Mon Feb 12 03:24:10 +0000 2018",
        "id": 962890043290394624,
        "text": "Harvard names an MIT graduate and son of immigrants, Lawrence S. Bacow, as its 29th president.....\nhttps://t.co/6812AcxHNG",
        "user.screen_name": "KrisKoles"
    },
    {
        "created_at": "Mon Feb 12 03:24:01 +0000 2018",
        "id": 962890003448606720,
        "text": "RT @brunelldonald: Shirley Ann Jackson innovated the telecommunications industry by contributing to the inventions of the touchtone phone,\u2026",
        "user.screen_name": "pressbuddy"
    },
    {
        "created_at": "Mon Feb 12 03:23:58 +0000 2018",
        "id": 962889994456182784,
        "text": "Hey guys! Sigma Alpha Iota is trying to raise some money for the initiate class (me!) to help pay our dues and our\u2026 https://t.co/h2E4VuPJtY",
        "user.screen_name": "laurenrose1012"
    },
    {
        "created_at": "Mon Feb 12 03:23:48 +0000 2018",
        "id": 962889948654321665,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "Kuttchimadu"
    },
    {
        "created_at": "Mon Feb 12 03:23:40 +0000 2018",
        "id": 962889915435380736,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "SaisonFemme"
    },
    {
        "created_at": "Mon Feb 12 03:23:34 +0000 2018",
        "id": 962889891515285504,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "Kazarelth"
    },
    {
        "created_at": "Mon Feb 12 03:23:02 +0000 2018",
        "id": 962889757498978304,
        "text": "Distinctive brain pattern helps habits form https://t.co/JprHWns0hw https://t.co/VQUcuoHIPC",
        "user.screen_name": "drronstrand"
    },
    {
        "created_at": "Mon Feb 12 03:22:50 +0000 2018",
        "id": 962889707297353728,
        "text": "RT @dandyliving: Fasching mit @namenlos4 \ud83d\ude0d https://t.co/2hRAjHhXUS",
        "user.screen_name": "dfmboy"
    },
    {
        "created_at": "Mon Feb 12 03:22:44 +0000 2018",
        "id": 962889681103998978,
        "text": "RT @_Cjboogie_: Left colder but the right more smooth https://t.co/wkd0ud8c0T",
        "user.screen_name": "Taylor_Mit"
    },
    {
        "created_at": "Mon Feb 12 03:22:26 +0000 2018",
        "id": 962889605543493632,
        "text": "RT @mitsmr: \u201cThe \u2018blame\u2019 culture that permeates most organizations paralyzes decision makers so much that they don\u2019t take chances and they\u2026",
        "user.screen_name": "RoshaundaDGreen"
    },
    {
        "created_at": "Mon Feb 12 03:21:39 +0000 2018",
        "id": 962889409615028224,
        "text": "RT @Chronicle5: \"My first 6 books were medical thrillers that nobody's ever heard of\" Then along came the book that broke @benmezrich big \"\u2026",
        "user.screen_name": "kevintounie"
    },
    {
        "created_at": "Mon Feb 12 03:21:16 +0000 2018",
        "id": 962889311761903616,
        "text": "RT @mitsmr: People who are \u201cdifferent\u201d \u2014whether behaviorally or neurologically\u2014 don\u2019t always fit into standard job categories. But if you c\u2026",
        "user.screen_name": "RoshaundaDGreen"
    },
    {
        "created_at": "Mon Feb 12 03:21:12 +0000 2018",
        "id": 962889297153220608,
        "text": "\u201cOur institutions are very much under threat at a time when they\u2019re arguably most needed.\u201d https://t.co/tWEIOZorjL https://t.co/45SvfAGGnm",
        "user.screen_name": "jbrancha"
    },
    {
        "created_at": "Mon Feb 12 03:21:11 +0000 2018",
        "id": 962889291616718854,
        "text": "RT @asus10mm: Now live\u27a1\ufe0fhttps://t.co/GJNYSDc3fa\n#porn #sex #naked #bbbh\n@hellosquirty @ASummersXXX @HotMaleStuds @Cam4_GayFR @aligais75 @Lo\u2026",
        "user.screen_name": "asus10mm"
    },
    {
        "created_at": "Mon Feb 12 03:21:00 +0000 2018",
        "id": 962889247064842240,
        "text": "sex pics opa mit oma fun sex questions to ask your boyfriend https://t.co/2KvWWhHXfT",
        "user.screen_name": "JahirBN"
    },
    {
        "created_at": "Mon Feb 12 03:20:59 +0000 2018",
        "id": 962889239695446016,
        "text": "RT @mitsmr: Unbundling Procter &amp; Gamble https://t.co/5lBGpPiaJf @htaneja @kmaney @proctorgamble #Business https://t.co/Ef5exU7fjj",
        "user.screen_name": "basole"
    },
    {
        "created_at": "Mon Feb 12 03:20:40 +0000 2018",
        "id": 962889162385866752,
        "text": "@pnut always been curious about how u guys came up with the title \u201cSilver\u201d. Love what miT and Chad did with the phr\u2026 https://t.co/HjWxQ7GwE2",
        "user.screen_name": "ADay36"
    },
    {
        "created_at": "Mon Feb 12 03:20:18 +0000 2018",
        "id": 962889071520514048,
        "text": "RT @elanazeide: \"Facial recognition software is biased towards white men\" https://t.co/el4r2qhxsr. Sad that this no longer seems out of the\u2026",
        "user.screen_name": "MasonMarksMD"
    },
    {
        "created_at": "Mon Feb 12 03:20:14 +0000 2018",
        "id": 962889054332301312,
        "text": "RT @mitsmr: \"Great strategists are like great chess players or great game theorists: They need to think several steps ahead towards the end\u2026",
        "user.screen_name": "RoshaundaDGreen"
    },
    {
        "created_at": "Mon Feb 12 03:19:40 +0000 2018",
        "id": 962888910157250560,
        "text": "RT @authoritydata: #buynow Data Science (The MIT Press Essential Knowledge series) https://t.co/g70f2FimEy #BigData #Dataviz https://t.co/Z\u2026",
        "user.screen_name": "bdt_systems"
    },
    {
        "created_at": "Mon Feb 12 03:19:23 +0000 2018",
        "id": 962888837189062656,
        "text": "RT @asus10mm: @cam4_gayDE @sk8er_dude_FFM @Silas_Rise @KevinKlose61 @XFuckboy1 @MisterMac80 @skinny22cm @gr8stxxxcock @Mit_Bewohner @LeidiG\u2026",
        "user.screen_name": "asus10mm"
    },
    {
        "created_at": "Mon Feb 12 03:19:08 +0000 2018",
        "id": 962888774450425856,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "HemantPatel32"
    },
    {
        "created_at": "Mon Feb 12 03:18:40 +0000 2018",
        "id": 962888660738719744,
        "text": "RT @skocharlakota: One of the important vision and focus of @ArvindKejriwal sarkar is rightly depicted in these pictures here  - Education,\u2026",
        "user.screen_name": "rajkovvali"
    },
    {
        "created_at": "Mon Feb 12 03:18:27 +0000 2018",
        "id": 962888602685452288,
        "text": "RT @MITSloan: Design thinking can be applied to any problem in any industry. Here's how. https://t.co/tE8Q21t1Cs https://t.co/wBYILC483w",
        "user.screen_name": "johnny_agt"
    },
    {
        "created_at": "Mon Feb 12 03:18:03 +0000 2018",
        "id": 962888505167958016,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee\nhttps://t.co/G5REhKIBcp",
        "user.screen_name": "_7m26"
    },
    {
        "created_at": "Mon Feb 12 03:17:54 +0000 2018",
        "id": 962888464755777537,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "MridulaK"
    },
    {
        "created_at": "Mon Feb 12 03:17:46 +0000 2018",
        "id": 962888430966452230,
        "text": "#buynow Data Science (The MIT Press Essential Knowledge series) https://t.co/g70f2FimEy #BigData #Dataviz https://t.co/ZuNG36al8l",
        "user.screen_name": "authoritydata"
    },
    {
        "created_at": "Mon Feb 12 03:17:44 +0000 2018",
        "id": 962888425056690177,
        "text": "Imagine a world with faster, cheaper #AI! @MIT researchers say we're closer to #computers that work like our brains\u2026 https://t.co/gOTDx89ijo",
        "user.screen_name": "AydinIPV6"
    },
    {
        "created_at": "Mon Feb 12 03:17:14 +0000 2018",
        "id": 962888296975208449,
        "text": "RT @AI__Newz: Facial recognition software is biased towards white men, researcher finds https://t.co/hDbUoSvIvF https://t.co/o6Ve2EzuRy",
        "user.screen_name": "VickiJo95367827"
    },
    {
        "created_at": "Mon Feb 12 03:16:39 +0000 2018",
        "id": 962888152573767681,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "Pushkarr"
    },
    {
        "created_at": "Mon Feb 12 03:16:39 +0000 2018",
        "id": 962888151307038721,
        "text": "RT @karenfoelz: MIT Bootcampers receiving lessons in leadership and managing your ego from @jockowillink at @MITBootcamps @QUT #MITbootcamp\u2026",
        "user.screen_name": "QUT"
    },
    {
        "created_at": "Mon Feb 12 03:16:34 +0000 2018",
        "id": 962888128745889793,
        "text": "RT @mitsmr: Applying Dynamic Work Design\n1. Separate well-defined + ambiguous work\n2. Break processes into smaller units of work \n3. Identi\u2026",
        "user.screen_name": "Moosi007"
    },
    {
        "created_at": "Mon Feb 12 03:16:08 +0000 2018",
        "id": 962888022336458753,
        "text": "4) T\u2019Challa has a PhD in Physics from Oxford University. His nemesis in the film Erik Killmonger has his PhD in Engineering from MIT.",
        "user.screen_name": "MosGenThePoet"
    },
    {
        "created_at": "Mon Feb 12 03:15:49 +0000 2018",
        "id": 962887939528232960,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "samir_knit"
    },
    {
        "created_at": "Mon Feb 12 03:15:48 +0000 2018",
        "id": 962887937376571392,
        "text": "RT @mitsmr: \"Even with rapid advances,\" says @erikbryn, \"AI won\u2019t be able to replace most jobs anytime soon. But in almost every industry,\u2026",
        "user.screen_name": "JakeSchweich"
    },
    {
        "created_at": "Mon Feb 12 03:15:35 +0000 2018",
        "id": 962887881646919680,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "b0yblunder"
    },
    {
        "created_at": "Mon Feb 12 03:15:15 +0000 2018",
        "id": 962887798343831552,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "asfaqullahkhan9"
    },
    {
        "created_at": "Mon Feb 12 03:15:03 +0000 2018",
        "id": 962887747429117952,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "pun_in_the_ass"
    },
    {
        "created_at": "Mon Feb 12 03:15:01 +0000 2018",
        "id": 962887739795484672,
        "text": "RT @psb_dc: Six Ways Americans View Automation  \n\n#automation #machines #futureofwork  #AI #AutonomousVehicles \n@mit_ide \n\nhttps://t.co/WS9\u2026",
        "user.screen_name": "psb_dc"
    },
    {
        "created_at": "Mon Feb 12 03:14:45 +0000 2018",
        "id": 962887671214497792,
        "text": "RT @mitsmr: Applying Dynamic Work Design\n1. Separate well-defined + ambiguous work\n2. Break processes into smaller units of work \n3. Identi\u2026",
        "user.screen_name": "RoshaundaDGreen"
    },
    {
        "created_at": "Mon Feb 12 03:14:18 +0000 2018",
        "id": 962887561331945472,
        "text": "Trump's bud get contract @ ! Di$-play. Your$ com mit ted, hon ey.",
        "user.screen_name": "JusticeNASA"
    },
    {
        "created_at": "Mon Feb 12 03:14:17 +0000 2018",
        "id": 962887555002912768,
        "text": "Facial recognition software is biased towards white men, researcher finds - The Verge https://t.co/ez8pnSJ5n4",
        "user.screen_name": "justseenthistec"
    },
    {
        "created_at": "Mon Feb 12 03:14:17 +0000 2018",
        "id": 962887554113486849,
        "text": "@BryanLunduke @facebook completely unrelated but this new Berners-Lee project out of MIT might pique your (concern|\u2026 https://t.co/WlESq0woI4",
        "user.screen_name": "disc0__"
    },
    {
        "created_at": "Mon Feb 12 03:14:10 +0000 2018",
        "id": 962887524195553281,
        "text": "RT @ParveenKaswan: In #Sikkim, you can now adopt a tree as your child or sibling. \nThe Sikkim Forest Tree (Amity &amp; Reverence) Rules 2017, a\u2026",
        "user.screen_name": "Shakti_Shetty"
    },
    {
        "created_at": "Mon Feb 12 03:13:45 +0000 2018",
        "id": 962887419908542465,
        "text": "Briana Banderas fucking #mit #ihrem #Mann in #Heimvideo #egzqkvar https://t.co/FsGaq1cgRs",
        "user.screen_name": "corey_westall"
    },
    {
        "created_at": "Mon Feb 12 03:13:30 +0000 2018",
        "id": 962887359472824321,
        "text": "RT @DrHughHarvey: Didn\u2019t study deep learning at MIT?\n\nDon\u2019t worry - here\u2019s the entire course \n\nhttps://t.co/HTONtKKWWz https://t.co/bmbxY5u\u2026",
        "user.screen_name": "iamlaksh1"
    },
    {
        "created_at": "Mon Feb 12 03:13:14 +0000 2018",
        "id": 962887290916884480,
        "text": "RT @siddarth_vyas: Artificial Intelligence...From $282 million in 2011 to more than $5 billion in 2016. https://t.co/kBq5NVxe7n #AI #innova\u2026",
        "user.screen_name": "TechnoJeder"
    },
    {
        "created_at": "Mon Feb 12 03:13:03 +0000 2018",
        "id": 962887243340824576,
        "text": "Well damn. https://t.co/7FVqBdDQRC",
        "user.screen_name": "Mit_ch_ell"
    },
    {
        "created_at": "Mon Feb 12 03:12:57 +0000 2018",
        "id": 962887220678897666,
        "text": "RT @TraDove_ICO: Breakfast with our team, board member Gordon Kaufman, and Professor Emeritus from the MIT Sloan School of Management. Big\u2026",
        "user.screen_name": "Destje"
    },
    {
        "created_at": "Mon Feb 12 03:12:48 +0000 2018",
        "id": 962887184012345344,
        "text": "MIT Bootcampers receiving lessons in leadership and managing your ego from @jockowillink at @MITBootcamps @QUT\u2026 https://t.co/XmKVDjzDsF",
        "user.screen_name": "karenfoelz"
    },
    {
        "created_at": "Mon Feb 12 03:12:34 +0000 2018",
        "id": 962887123870371840,
        "text": "RT @dormash: The MIT Venture Capital and Innovation conference is on!  So glad to be hosting @LindiweEM. She will give a talk on coding thr\u2026",
        "user.screen_name": "glenmpani"
    },
    {
        "created_at": "Mon Feb 12 03:12:33 +0000 2018",
        "id": 962887121282437120,
        "text": "RT @mitsmr: RT @MITSloan: Analytics are driving more and more business decisions in sports. 3 from the industry reveal what's next. https:/\u2026",
        "user.screen_name": "RoshaundaDGreen"
    },
    {
        "created_at": "Mon Feb 12 03:12:30 +0000 2018",
        "id": 962887105511763968,
        "text": "How concerned is your org about what the impact of #digitaldisruption might be? https://t.co/aULDsMoqmb\u2026 https://t.co/1chhq18LUG",
        "user.screen_name": "siddarth_vyas"
    },
    {
        "created_at": "Mon Feb 12 03:12:29 +0000 2018",
        "id": 962887101229551617,
        "text": "I\u2019ll be joining Ted Olson, Laila Mintas (@DrMintas), Chad Millman and Jeff Ma next week at the MIT Sloan Sports Ana\u2026 https://t.co/w1JPjG6Lyl",
        "user.screen_name": "WALLACHLEGAL"
    },
    {
        "created_at": "Mon Feb 12 03:12:13 +0000 2018",
        "id": 962887033944354816,
        "text": "Artificial Intelligence...From $282 million in 2011 to more than $5 billion in 2016. https://t.co/kBq5NVxe7n #AI\u2026 https://t.co/5xxMeOPjJV",
        "user.screen_name": "siddarth_vyas"
    },
    {
        "created_at": "Mon Feb 12 03:12:00 +0000 2018",
        "id": 962886982635540481,
        "text": "The latest Business Blueprint Daily! https://t.co/Ma47PbOG9l Thanks to @mit_cmsw @andrewhargadon @MeetEdgar #marketing #business",
        "user.screen_name": "BusBlueprint"
    },
    {
        "created_at": "Mon Feb 12 03:11:58 +0000 2018",
        "id": 962886971554189312,
        "text": "Someday all those people you're(I'm) waiting for and goals you're(I'm) holding on to will be gone or out of reach.\u2026 https://t.co/NiWjGsgtsG",
        "user.screen_name": "ffulC_miT"
    },
    {
        "created_at": "Mon Feb 12 03:11:21 +0000 2018",
        "id": 962886819321966593,
        "text": "SPIELEN  #Casino - 300% up to euro1200 on first 3 deposits mit #Timesquare - https://t.co/kxRpC4IB5R https://t.co/h3zzMnvWyU",
        "user.screen_name": "atticagambling"
    },
    {
        "created_at": "Mon Feb 12 03:11:21 +0000 2018",
        "id": 962886816872484864,
        "text": "SPIELEN  #Casino - 300% up to euro1200 on first 3 deposits mit #Timesquare - https://t.co/7LPT6ZLm1h https://t.co/GvWVOw7f6R",
        "user.screen_name": "bestbetforyou"
    },
    {
        "created_at": "Mon Feb 12 03:10:06 +0000 2018",
        "id": 962886503675322368,
        "text": "RT @TamaraMcCleary: Mastering the Digital #Innovation Challenge https://t.co/4jbLqULxfg #leadership #digitaltransformation MT @jglass8 via\u2026",
        "user.screen_name": "jglass8"
    },
    {
        "created_at": "Mon Feb 12 03:09:44 +0000 2018",
        "id": 962886411513819136,
        "text": "@andreadiaz37 Cool \ud83d\ude0e",
        "user.screen_name": "mit_alexa"
    },
    {
        "created_at": "Mon Feb 12 03:09:24 +0000 2018",
        "id": 962886327661486080,
        "text": "#Nur #geile #blonde fucking mit #Nacho Vidal https://t.co/UTQI4Ho2Tv",
        "user.screen_name": "dZoqiARwYHzITTh"
    },
    {
        "created_at": "Mon Feb 12 03:09:20 +0000 2018",
        "id": 962886311832059905,
        "text": "SPIELEN  #Casino - UP to GBP200 bonus  18+,Ts&amp;Cs apply mit #Karamba - https://t.co/TGFW5TK5TQ https://t.co/Ay0aMVOaGh",
        "user.screen_name": "atticagambling"
    },
    {
        "created_at": "Mon Feb 12 03:09:20 +0000 2018",
        "id": 962886309365846016,
        "text": "SPIELEN  #Casino - UP to GBP200 bonus  18+,Ts&amp;Cs apply mit #Karamba - https://t.co/7SE0mNsTdz https://t.co/65ufoTLNnv",
        "user.screen_name": "bestbetforyou"
    },
    {
        "created_at": "Mon Feb 12 03:09:06 +0000 2018",
        "id": 962886251929010177,
        "text": "RT @mitsmr: \u201cJournalists often check a CEO\u2019s Twitter account before covering the CEO or the company.\u201d https://t.co/er59CY71Vg",
        "user.screen_name": "RoshaundaDGreen"
    },
    {
        "created_at": "Mon Feb 12 03:09:03 +0000 2018",
        "id": 962886239065198594,
        "text": "RT @JensRoehrich: Interesting article: The Unique Challenges of Cross-Boundary #Collaboration https://t.co/EXelhBmrId You may also find my\u2026",
        "user.screen_name": "NourFreeBird"
    },
    {
        "created_at": "Mon Feb 12 03:09:02 +0000 2018",
        "id": 962886233838968832,
        "text": "RT @skocharlakota: In the streets of Boston cutting thru MIT and Harvard universities, @msisodia walks with @AamAadmiParty volunteers &amp; wel\u2026",
        "user.screen_name": "AAPlogical"
    },
    {
        "created_at": "Mon Feb 12 03:08:48 +0000 2018",
        "id": 962886175995265024,
        "text": "@Mindcite_US @Google @CarnegieMellon @Cambridge_Uni @MIT @UniofOxford @Caltech @TechnionLive @Princeton @Yale\u2026 https://t.co/hQ0HgCl43g",
        "user.screen_name": "4GodsWillBeDone"
    },
    {
        "created_at": "Mon Feb 12 03:08:42 +0000 2018",
        "id": 962886151416684545,
        "text": "RT @mitsmr: Unbundling Procter &amp; Gamble https://t.co/5lBGpPiaJf @htaneja @kmaney @proctorgamble #Business https://t.co/Ef5exU7fjj",
        "user.screen_name": "nancyrubin"
    },
    {
        "created_at": "Mon Feb 12 03:08:29 +0000 2018",
        "id": 962886096773410816,
        "text": "Life as an MBA Student | Ryan from https://t.co/XQkR8Pg79L, MIT Sloan https://t.co/MbrNmPqURE #gmat #mba #bschool",
        "user.screen_name": "30DAYGMAT"
    },
    {
        "created_at": "Mon Feb 12 03:08:10 +0000 2018",
        "id": 962886015747837953,
        "text": "RT @StanM3: Germany- Afghan(19) stabbed his ex-girlfriend(23) in the shoulder and fled. The police had been called because of domestic viol\u2026",
        "user.screen_name": "jenkinskeith9"
    },
    {
        "created_at": "Mon Feb 12 03:07:40 +0000 2018",
        "id": 962885891327852544,
        "text": "\u2554\u2557 \n\u256c\u2554\u2557\u2551\u2551\u2554\u2557\u2557\u2566\u2554 \u2605\n\u255d\u255a\u255d\u255a\u255a\u255a\u255d\u255a\u2569\u255d\n\u2605\u2b50\u2605\u2b50\u2605\n\u2570\u22b6\ud83c\udd51\u22b6\u256e\n\u256d\u22b6\ud83c\udd54\u22b6\u256f\n\u2570\u22b6\ud83c\udd62\u22b6\u256e\n\u256d\u22b6\ud83c\udd63\u22b6\u256f\n\u2570\u261b \u2605 @Mit_bogorDP \u2605\n\nArea: #BOGOR\n\u2570\u261b Avail Include or Exc\u2026 https://t.co/PFyNGVrSbV",
        "user.screen_name": "_DaJhonn"
    },
    {
        "created_at": "Mon Feb 12 03:07:34 +0000 2018",
        "id": 962885863603654657,
        "text": "@benance_2017 @binance_2017 Scam",
        "user.screen_name": "anir_mit"
    },
    {
        "created_at": "Mon Feb 12 03:07:32 +0000 2018",
        "id": 962885857295454208,
        "text": "RT @itskac: Need to interview a #musician, a #freelancer, a #smallbiz owner (or someone who wants to start one) &amp; a #tech #startup #founder\u2026",
        "user.screen_name": "AskVMC"
    },
    {
        "created_at": "Mon Feb 12 03:07:19 +0000 2018",
        "id": 962885804161949696,
        "text": "SPIELEN  #Casino - Up to GBP1000 Welcome bonus  18+,Ts&amp;Cs apply mit #Affpower - https://t.co/nY4UwB6IAC https://t.co/8b4JdLMuhg",
        "user.screen_name": "atticagambling"
    },
    {
        "created_at": "Mon Feb 12 03:07:19 +0000 2018",
        "id": 962885801800593409,
        "text": "SPIELEN  #Casino - Up to GBP1000 Welcome bonus  18+,Ts&amp;Cs apply mit #Affpower - https://t.co/AkIJ6dBq69 https://t.co/9Khp1YX8Xj",
        "user.screen_name": "bestbetforyou"
    },
    {
        "created_at": "Mon Feb 12 03:06:08 +0000 2018",
        "id": 962885505791741952,
        "text": "RT @mitsmr: RT @MITSloan: Analytics are driving more and more business decisions in sports. 3 from the industry reveal what's next. https:/\u2026",
        "user.screen_name": "Neel__C"
    },
    {
        "created_at": "Mon Feb 12 03:06:06 +0000 2018",
        "id": 962885497277304835,
        "text": "\"Facial recognition software is biased towards white men\" https://t.co/el4r2qhxsr. Sad that this no longer seems ou\u2026 https://t.co/tDpGVQmZTc",
        "user.screen_name": "elanazeide"
    },
    {
        "created_at": "Mon Feb 12 03:06:02 +0000 2018",
        "id": 962885479757729797,
        "text": "Corporate Transformation - \"the optimal playbook for transformation should involve... reorienting strategy for the\u2026 https://t.co/O76aHLoYUw",
        "user.screen_name": "TheIOSummit"
    },
    {
        "created_at": "Mon Feb 12 03:05:59 +0000 2018",
        "id": 962885466432339968,
        "text": "RT @CupcakKe_rapper: I got to sit by the window with my legs open cause with these thick thighs my pussy like Jordan sparks it gets no air\u2026",
        "user.screen_name": "damn_mit"
    },
    {
        "created_at": "Mon Feb 12 03:05:19 +0000 2018",
        "id": 962885297393618945,
        "text": "SPIELEN  #Casino - Get up to GBP2000 Welcome bonus  18+,Ts&amp;Cs apply mit #Affpower - https://t.co/n6JE8kkvuv https://t.co/xsq58Zq4ag",
        "user.screen_name": "atticagambling"
    },
    {
        "created_at": "Mon Feb 12 03:05:18 +0000 2018",
        "id": 962885294570770432,
        "text": "SPIELEN  #Casino - Get up to GBP2000 Welcome bonus  18+,Ts&amp;Cs apply mit #Affpower - https://t.co/BCTDq1ieuw https://t.co/tgBxysbMJe",
        "user.screen_name": "bestbetforyou"
    },
    {
        "created_at": "Mon Feb 12 03:05:04 +0000 2018",
        "id": 962885234244096000,
        "text": "Unbundling Procter &amp; Gamble https://t.co/5lBGpPiaJf @htaneja @kmaney @proctorgamble #Business https://t.co/Ef5exU7fjj",
        "user.screen_name": "mitsmr"
    },
    {
        "created_at": "Mon Feb 12 03:04:34 +0000 2018",
        "id": 962885112139534336,
        "text": "Show Time Mit ciscoherrera1 roderickjlp greg_melodia \ud83d\udd25\ud83c\udf4b\ud83c\udf34\ud83d\udc45 en El Hatillo https://t.co/soZRbvyat2",
        "user.screen_name": "LsRankiaos"
    },
    {
        "created_at": "Mon Feb 12 03:04:31 +0000 2018",
        "id": 962885098033987584,
        "text": "That's the C.E.O, Eximius Konceptz. https://t.co/khuWvecjwY",
        "user.screen_name": "mit_chelle8"
    },
    {
        "created_at": "Mon Feb 12 03:04:24 +0000 2018",
        "id": 962885066497011714,
        "text": "A project led by sir Tim berners-Lee\nhttps://t.co/U8EzoMf3M1",
        "user.screen_name": "NagendraSanu"
    },
    {
        "created_at": "Mon Feb 12 03:03:22 +0000 2018",
        "id": 962884807872204800,
        "text": "RT @techreview: Which technologies are making significant progress? We have the answers. Subscribe to MIT Technology Review today for unpar\u2026",
        "user.screen_name": "qiming82"
    },
    {
        "created_at": "Mon Feb 12 03:02:58 +0000 2018",
        "id": 962884705854083072,
        "text": "RT @mitsmr: \u201cJournalists often check a CEO\u2019s Twitter account before covering the CEO or the company.\u201d https://t.co/er59CY71Vg",
        "user.screen_name": "CrespoRamiro"
    },
    {
        "created_at": "Mon Feb 12 03:02:38 +0000 2018",
        "id": 962884623243141125,
        "text": "RT @psb_dc: In the world of 1s and 0s, soft skills matter.\n\n4 things you need to know about soft skills \n\n#leadership #culture #innovation\u2026",
        "user.screen_name": "talk2_priya"
    },
    {
        "created_at": "Mon Feb 12 03:01:17 +0000 2018",
        "id": 962884285052022785,
        "text": "RT @danieldennett: Notice anything unusual about the Edward Gorey cover on the 40th anniversary edition of BRAINSTORMS? (MIT Press). I adde\u2026",
        "user.screen_name": "ChampionACause2"
    },
    {
        "created_at": "Mon Feb 12 03:01:17 +0000 2018",
        "id": 962884283814875136,
        "text": "@WillGordonAgain FWIW Larry was the only administrator who wasn't a giant pile of shit when I was at MIT. My even m\u2026 https://t.co/4KQLLhH25K",
        "user.screen_name": "TheDrewStarr"
    },
    {
        "created_at": "Mon Feb 12 03:01:15 +0000 2018",
        "id": 962884274859909120,
        "text": "SUPERDRY Angebote Superdry Vintage Logo Fade T-Shirt: Category: Damen / T-Shirts / T-Shirt mit Print Item number: 2\u2026 https://t.co/pQ6uexMKyh",
        "user.screen_name": "SparVolltreffer"
    },
    {
        "created_at": "Mon Feb 12 03:00:58 +0000 2018",
        "id": 962884205095997441,
        "text": "Applying philosophy for a better democracy https://t.co/Dp90q2eFV7",
        "user.screen_name": "skydog811"
    },
    {
        "created_at": "Mon Feb 12 03:00:43 +0000 2018",
        "id": 962884142819094528,
        "text": "Pace Layering: How Complex Systems Learn and Keep Learning https://t.co/66GZCyMuLY",
        "user.screen_name": "hackernewsrobot"
    },
    {
        "created_at": "Mon Feb 12 03:00:36 +0000 2018",
        "id": 962884114155294720,
        "text": "RT @Toijuin: MIT Will start this week! Still spots available! Contact me if interested",
        "user.screen_name": "A3ria7Assau7t"
    },
    {
        "created_at": "Mon Feb 12 03:00:23 +0000 2018",
        "id": 962884056408121344,
        "text": "#Innovation-Based #Technology #Standards Are Under Threat - via @mitsmr    | https://t.co/XeJ4y8CDbX #RandD #Strategy  #ProductDevelopment",
        "user.screen_name": "arjenvanberkum"
    },
    {
        "created_at": "Mon Feb 12 03:00:21 +0000 2018",
        "id": 962884047356690432,
        "text": "Solid aims to radically change the way web applications work: https://t.co/FaTEKHmW3I ( https://t.co/290eZLco2w )",
        "user.screen_name": "HighSNHN"
    },
    {
        "created_at": "Mon Feb 12 03:00:00 +0000 2018",
        "id": 962883961331552256,
        "text": "RT @TerryUm_ML: A series of lectures for deep learning given by MIT\nhttps://t.co/9xMZe50Biw https://t.co/TFN2k0LdWu",
        "user.screen_name": "MotazAlfarraj"
    },
    {
        "created_at": "Mon Feb 12 02:59:36 +0000 2018",
        "id": 962883861129543680,
        "text": "RT @BillAulet: .@jockowillink on fire at Brisbane MIT Global Entrepreneurship Bootcamp talking about #extremeleadership @MITBootcamps @QUT\u2026",
        "user.screen_name": "amanda_dunne8"
    },
    {
        "created_at": "Mon Feb 12 02:58:40 +0000 2018",
        "id": 962883625372016641,
        "text": "Daryaganj Sunday Book Bazar!!! I hope it never shuts down. https://t.co/aJ7SvEx0Rt",
        "user.screen_name": "mit_sood"
    },
    {
        "created_at": "Mon Feb 12 02:58:40 +0000 2018",
        "id": 962883623685935104,
        "text": "RT @thebaemarcus: That\u2019s Lil Boat and mini boat https://t.co/DRXFhaglMO",
        "user.screen_name": "Mit_540"
    },
    {
        "created_at": "Mon Feb 12 02:57:58 +0000 2018",
        "id": 962883449408442368,
        "text": "RT @MITSloan: In a recent study, soft skills delivered a 250% ROI. Here's what else to know about them. https://t.co/Nh8hgLmC0y",
        "user.screen_name": "shaks77"
    },
    {
        "created_at": "Mon Feb 12 02:57:46 +0000 2018",
        "id": 962883397105233921,
        "text": "Is tech dividing America? https://t.co/2IVMmmlolg",
        "user.screen_name": "knittingknots"
    },
    {
        "created_at": "Mon Feb 12 02:57:36 +0000 2018",
        "id": 962883355359490048,
        "text": "RT @MITSloan: Soft skills are underrated. Here's how they can bridge the economic divide and bring big ROI to any org. https://t.co/Nh8hgLm\u2026",
        "user.screen_name": "Pato1979"
    },
    {
        "created_at": "Mon Feb 12 02:57:33 +0000 2018",
        "id": 962883345368596480,
        "text": "RT @BillAulet: .@jockowillink on fire at Brisbane MIT Global Entrepreneurship Bootcamp talking about #extremeleadership @MITBootcamps @QUT\u2026",
        "user.screen_name": "ProfBarrett"
    },
    {
        "created_at": "Mon Feb 12 02:56:55 +0000 2018",
        "id": 962883183304892417,
        "text": "RT @nerdlypainter: Heretical Musings On Heuristic Mechanisms by Regina Valluzzi https://t.co/npnbRzm4z4 #sciart #MIT #geometric #lines #Bos\u2026",
        "user.screen_name": "DZaag"
    },
    {
        "created_at": "Mon Feb 12 02:56:46 +0000 2018",
        "id": 962883147938652160,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "VRANYwinston"
    },
    {
        "created_at": "Mon Feb 12 02:56:44 +0000 2018",
        "id": 962883139029950465,
        "text": "RT @mitsmr: Keep this chart handy when you're Identifying potential #leaders in your company.  https://t.co/WHj7CM39AJ #management https://\u2026",
        "user.screen_name": "DRLeszcynski"
    },
    {
        "created_at": "Mon Feb 12 02:56:12 +0000 2018",
        "id": 962883003008667648,
        "text": "@davewiner @gilduran76 Good Lard.  Bring it. \n\nGeorge Lakoff has been studying linguistics since MIT in the '60's.\u2026 https://t.co/8747yhzM56",
        "user.screen_name": "Hoi_Pollois"
    },
    {
        "created_at": "Mon Feb 12 02:56:07 +0000 2018",
        "id": 962882981873451008,
        "text": "RT @World_Wide_Wob: Meanwhile at the Pistons/Hawks game https://t.co/3Q6Ic7kZCX",
        "user.screen_name": "Mit_540"
    },
    {
        "created_at": "Mon Feb 12 02:56:03 +0000 2018",
        "id": 962882966727766017,
        "text": "RT @techreview: Which technologies are making significant progress? We have the answers. Subscribe to MIT Technology Review today for unpar\u2026",
        "user.screen_name": "Kobayashi_Isao"
    },
    {
        "created_at": "Mon Feb 12 02:55:55 +0000 2018",
        "id": 962882935128035329,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "gmlavern"
    },
    {
        "created_at": "Mon Feb 12 02:55:39 +0000 2018",
        "id": 962882866727223297,
        "text": "RT @thesavoyshow: Black Man G-CHECKS his little brothers for trying to join a gang! https://t.co/fxrGUrED5H",
        "user.screen_name": "Mit_540"
    },
    {
        "created_at": "Mon Feb 12 02:55:30 +0000 2018",
        "id": 962882829158899712,
        "text": "RT @BrightCellars: 2 MIT grads built an algorithm to match you with wine. Take the quiz to see your matches! https://t.co/LdIvB7sY05 https:\u2026",
        "user.screen_name": "PahouseHouse"
    },
    {
        "created_at": "Mon Feb 12 02:55:24 +0000 2018",
        "id": 962882802978119681,
        "text": "RT @FreddyAmazin: If this isn\u2019t how you and your Bestfriend describe each other, you ain\u2019t BESTFRIENDS. https://t.co/ZGUxZvyRkr",
        "user.screen_name": "Mit_540"
    },
    {
        "created_at": "Mon Feb 12 02:54:59 +0000 2018",
        "id": 962882697935970304,
        "text": "RT @World_Wide_Wob: When the trade deadline is over https://t.co/P3jhF9K9Ti",
        "user.screen_name": "Mit_540"
    },
    {
        "created_at": "Mon Feb 12 02:54:32 +0000 2018",
        "id": 962882586136760320,
        "text": "RT @NeilKBrand: As my score for #Hitchcock's #Blackmail is being played live tonight by the #N\u00fcrnberg Symphony Orchestra tonight (https://t\u2026",
        "user.screen_name": "THEAGENTAPSLEY"
    },
    {
        "created_at": "Mon Feb 12 02:53:44 +0000 2018",
        "id": 962882384881504256,
        "text": "@BJP4India gr8 decision. Such motormouths shd be sent to oblivion https://t.co/uhsAifL9XJ",
        "user.screen_name": "anurag_mit"
    },
    {
        "created_at": "Mon Feb 12 02:53:22 +0000 2018",
        "id": 962882293349212166,
        "text": "@4GodsWillBeDone @Google @CarnegieMellon @Cambridge_Uni @MIT @UniofOxford @Caltech @TechnionLive @Princeton @Yale\u2026 https://t.co/4wqxgtLaGw",
        "user.screen_name": "Mindcite_US"
    },
    {
        "created_at": "Mon Feb 12 02:53:05 +0000 2018",
        "id": 962882221689339904,
        "text": "The Technological Singularity (The MIT Press Essential Knowledge series) https://t.co/ga2CxzBY6B",
        "user.screen_name": "DD_Serena_"
    },
    {
        "created_at": "Mon Feb 12 02:52:58 +0000 2018",
        "id": 962882192035729409,
        "text": "Solid aims to radically change the way web applications work https://t.co/pYILXPgxnU (https://t.co/Y5cCSw8gHQ)",
        "user.screen_name": "newsyc150"
    },
    {
        "created_at": "Mon Feb 12 02:52:38 +0000 2018",
        "id": 962882109164675072,
        "text": "Solid aims to radically change the way web applications work https://t.co/wKRqEGaLVJ (https://t.co/3RPoPPJRB8)",
        "user.screen_name": "Hn150"
    },
    {
        "created_at": "Mon Feb 12 02:52:30 +0000 2018",
        "id": 962882073462738944,
        "text": "RT @SeldumSeen5: Need a Pure SS will be six man and fighting for starting spot 4 MPBA MIT for proam we are 66-7 E4 @2kProAmReport @2KProAmI\u2026",
        "user.screen_name": "DelshunYoung"
    },
    {
        "created_at": "Mon Feb 12 02:52:14 +0000 2018",
        "id": 962882008023052288,
        "text": "Technology is great for making our lives easier but also replacing jobs as well. #pols341digital \nhttps://t.co/GDw4Npm6PK",
        "user.screen_name": "ezekio_"
    },
    {
        "created_at": "Mon Feb 12 02:52:12 +0000 2018",
        "id": 962881998929977344,
        "text": "Which technologies are making significant progress? We have the answers. Subscribe to MIT Technology Review today f\u2026 https://t.co/gYryRsq0DJ",
        "user.screen_name": "bubb13_b0y"
    },
    {
        "created_at": "Mon Feb 12 02:52:11 +0000 2018",
        "id": 962881992630132736,
        "text": "Like it or not, the future of cryptocurrency will be determined by bureaucrats - MIT Technology Review https://t.co/95UbHdFs1b",
        "user.screen_name": "bit_daily"
    },
    {
        "created_at": "Mon Feb 12 02:52:00 +0000 2018",
        "id": 962881949877465094,
        "text": "\u201cAlumni call on MIT to champion artificial intelligence education\u201d\n\n#AI #Education via @MIT https://t.co/Bd9N4h6WXA",
        "user.screen_name": "rzembo"
    },
    {
        "created_at": "Mon Feb 12 02:51:35 +0000 2018",
        "id": 962881843598151682,
        "text": "@ARossP Oh, this looks relevant to your interests. https://t.co/IBfvR5OMpB",
        "user.screen_name": "badger_lifts"
    },
    {
        "created_at": "Mon Feb 12 02:50:59 +0000 2018",
        "id": 962881691093106688,
        "text": "RT @techreview: Which technologies are making significant progress? We have the answers. Subscribe to MIT Technology Review today for unpar\u2026",
        "user.screen_name": "dik_erwin"
    },
    {
        "created_at": "Mon Feb 12 02:50:43 +0000 2018",
        "id": 962881625037115392,
        "text": "RT @SeldumSeen5: Need a Pure SS will be six man and fighting for starting spot 4 MPBA MIT for proam we are 66-7 E4 @2kProAmReport @2KProAmI\u2026",
        "user.screen_name": "Kbizz1988"
    },
    {
        "created_at": "Mon Feb 12 02:50:23 +0000 2018",
        "id": 962881541088083968,
        "text": "RT @techreview: Which technologies are making significant progress? We have the answers. Subscribe to MIT Technology Review today for unpar\u2026",
        "user.screen_name": "Esist_Me"
    },
    {
        "created_at": "Mon Feb 12 02:50:09 +0000 2018",
        "id": 962881481713635328,
        "text": "RT @techreview: Which technologies are making significant progress? We have the answers. Subscribe to MIT Technology Review today for unpar\u2026",
        "user.screen_name": "gixtools"
    },
    {
        "created_at": "Mon Feb 12 02:50:07 +0000 2018",
        "id": 962881473635323904,
        "text": "Which technologies are making significant progress? We have the answers. Subscribe to MIT Technology Review today f\u2026 https://t.co/F6Jr3Ruf8a",
        "user.screen_name": "techreview"
    },
    {
        "created_at": "Mon Feb 12 02:49:14 +0000 2018",
        "id": 962881251626557441,
        "text": "RT @farnazfassihi: If @Harvard &amp; @MIT want to invite an #Iran intelligence agent in the name of academic exchange, do so. Just don't make a\u2026",
        "user.screen_name": "SMohyeddin"
    },
    {
        "created_at": "Mon Feb 12 02:49:11 +0000 2018",
        "id": 962881240683593728,
        "text": "RT @SeldumSeen5: Need a Pure SS will be six man and fighting for starting spot 4 MPBA MIT for proam we are 66-7 E4 @2kProAmReport @2KProAmI\u2026",
        "user.screen_name": "UnknownElites2k"
    },
    {
        "created_at": "Mon Feb 12 02:48:56 +0000 2018",
        "id": 962881177823592448,
        "text": "Need a Pure SS will be six man and fighting for starting spot 4 MPBA MIT for proam we are 66-7 E4 @2kProAmReport\u2026 https://t.co/abBt0WRY1t",
        "user.screen_name": "SeldumSeen5"
    },
    {
        "created_at": "Mon Feb 12 02:48:19 +0000 2018",
        "id": 962881022001074176,
        "text": "Like it or not, the future of cryptocurrency will be determined by bureaucrats - MIT Technology Review https://t.co/SUMY6bhf4y",
        "user.screen_name": "consumer_daily"
    },
    {
        "created_at": "Mon Feb 12 02:48:02 +0000 2018",
        "id": 962880949351432192,
        "text": "from a patmed raider to a MIT, congrats Noellia \u2764\ufe0f\ud83c\udf39 @ Sigma Alpha Iota-Gamma Delta Chapter https://t.co/HD8BPygBIQ",
        "user.screen_name": "v_durao"
    },
    {
        "created_at": "Mon Feb 12 02:47:31 +0000 2018",
        "id": 962880820158615552,
        "text": "He also wrote the first book on electric lighting and patented 2 more inventions: the 1st on train W.C. and precurs\u2026 https://t.co/LAhHLNhEAJ",
        "user.screen_name": "lexaEhayes713"
    },
    {
        "created_at": "Mon Feb 12 02:47:19 +0000 2018",
        "id": 962880769369755648,
        "text": "RT @TheTastingBoard: Two MIT grads built an algorithm to match your taste preferences with cheese. Click the link below &amp; take the quiz! ht\u2026",
        "user.screen_name": "mysterykatz87"
    },
    {
        "created_at": "Mon Feb 12 02:47:10 +0000 2018",
        "id": 962880730996109312,
        "text": "RT @newsycombinator: Solid aims to radically change the way web applications work https://t.co/x1xBfqvs2v",
        "user.screen_name": "the_mcnaveen"
    },
    {
        "created_at": "Mon Feb 12 02:46:50 +0000 2018",
        "id": 962880646476681216,
        "text": "RT @mitsmr: Now That Your Products Can Talk, What Will They Tell You? https://t.co/3LhZSc4mrj @Eric_GERVET @ATKearney's Suketu Gandhi   #IoT",
        "user.screen_name": "AssiaWirth"
    },
    {
        "created_at": "Mon Feb 12 02:45:15 +0000 2018",
        "id": 962880250832076800,
        "text": "Amazon \"Sneaker\" FIND Damen Sneaker mit Material-Mix , Schwarz (Black), 39 EU: Company: FIND List Price: EUR 36,00\u2026 https://t.co/GQ0wE6aVG4",
        "user.screen_name": "SparVolltreffer"
    },
    {
        "created_at": "Mon Feb 12 02:44:39 +0000 2018",
        "id": 962880099551936517,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "MuyodiSara"
    },
    {
        "created_at": "Mon Feb 12 02:44:12 +0000 2018",
        "id": 962879985441701888,
        "text": "@Mighty_Ginge @DrPhiltill There are already multiple alternatives. If schools like MIT refused to submit to non-ope\u2026 https://t.co/gG0MlwaQDV",
        "user.screen_name": "Robotbeat"
    },
    {
        "created_at": "Mon Feb 12 02:43:39 +0000 2018",
        "id": 962879845674954752,
        "text": "Edle Whiskeykaraffe mit Gravur \u201cWhiskey\u201d Whisky-Flasche\u00a0graviert https://t.co/aCRnN74yuL",
        "user.screen_name": "hauckiswelt"
    },
    {
        "created_at": "Mon Feb 12 02:43:23 +0000 2018",
        "id": 962879778444341254,
        "text": "RT @DrHughHarvey: Didn\u2019t study deep learning at MIT?\n\nDon\u2019t worry - here\u2019s the entire course \n\nhttps://t.co/HTONtKKWWz https://t.co/bmbxY5u\u2026",
        "user.screen_name": "kmathan"
    },
    {
        "created_at": "Mon Feb 12 02:42:25 +0000 2018",
        "id": 962879535858536448,
        "text": "@itskac @MIT @matthewumstead @AskVMC @elonmusk @justinbieber I\u2019m going to be out for another couple of hours but le\u2026 https://t.co/jua9nvanUZ",
        "user.screen_name": "JingleBeau4"
    },
    {
        "created_at": "Mon Feb 12 02:41:43 +0000 2018",
        "id": 962879358187855872,
        "text": "RT @stunning_global: BIT STUNNING FOREVER. MIT DEN STUNNING-YOU.\nPlastic &amp; Aesthetic Surgery\nDr. med. univ. Kamil Akhundov\nTel:+4930 921238\u2026",
        "user.screen_name": "stunning_global"
    },
    {
        "created_at": "Mon Feb 12 02:41:41 +0000 2018",
        "id": 962879351267233795,
        "text": "RT @xJustMonika: Sneak peaks......\nIf want to check it out go to\nhttps://t.co/TUqYR9rwOX https://t.co/whdzDjiDHB",
        "user.screen_name": "SorenatorShips"
    },
    {
        "created_at": "Mon Feb 12 02:41:26 +0000 2018",
        "id": 962879286721089536,
        "text": "RT @stunning_global: BIT STUNNING FOREVER. MIT DEN STUNNING-YOU.\nPlastic &amp; Aesthetic Surgery\nDr. med. univ. Kamil Akhundov\nTel:+4930 921238\u2026",
        "user.screen_name": "stunning_global"
    },
    {
        "created_at": "Mon Feb 12 02:41:22 +0000 2018",
        "id": 962879273278365696,
        "text": "RT @stunning_global: BIT STUNNING FOREVER. MIT DEN STUNNING-YOU.    \nStunning You\nPlastic &amp; Aesthetic Surgery\nDr. med. univ. Kamil Akhundov\u2026",
        "user.screen_name": "stunning_global"
    },
    {
        "created_at": "Mon Feb 12 02:41:22 +0000 2018",
        "id": 962879270597963776,
        "text": "RT @gbaucom: Meet the biologist who got MIT to examine its treatment of women researchers - via @techreview https://t.co/c6JqibvhkQ //I rec\u2026",
        "user.screen_name": "Ann_Neighbors"
    },
    {
        "created_at": "Mon Feb 12 02:41:06 +0000 2018",
        "id": 962879205749870592,
        "text": "RT @BillAulet: .@jockowillink on fire at Brisbane MIT Global Entrepreneurship Bootcamp talking about #extremeleadership @MITBootcamps @QUT\u2026",
        "user.screen_name": "karenfoelz"
    },
    {
        "created_at": "Mon Feb 12 02:40:44 +0000 2018",
        "id": 962879110463635456,
        "text": "RT @BrightCellars: 2 MIT grads built an algorithm to match you with wine. Take the quiz to see your matches! https://t.co/LdIvB7sY05 https:\u2026",
        "user.screen_name": "NOvieraLE"
    },
    {
        "created_at": "Mon Feb 12 02:40:32 +0000 2018",
        "id": 962879064036929536,
        "text": "Leading with integrity, part 1: Does a hard line lead to a slippery slope? https://t.co/zEEGaKybr0",
        "user.screen_name": "Vanellus_PAG"
    },
    {
        "created_at": "Mon Feb 12 02:40:16 +0000 2018",
        "id": 962878995091124224,
        "text": "RT @TurkHeritage: On International #WomenInScience Day, listen to Turkish MIT @medialab faculty member Dr. Canan Dagdeviren talk at the UN\u2026",
        "user.screen_name": "magoriumsworld"
    },
    {
        "created_at": "Mon Feb 12 02:40:14 +0000 2018",
        "id": 962878986828374016,
        "text": "RT @BillAulet: .@jockowillink on fire at Brisbane MIT Global Entrepreneurship Bootcamp talking about #extremeleadership @MITBootcamps @QUT\u2026",
        "user.screen_name": "QUTmedia"
    },
    {
        "created_at": "Mon Feb 12 02:39:47 +0000 2018",
        "id": 962878875247267840,
        "text": "RT @lildurk: So much fake love in the air now days you don\u2019t kno who love you Forreal",
        "user.screen_name": "flyass_mit"
    },
    {
        "created_at": "Mon Feb 12 02:39:34 +0000 2018",
        "id": 962878818292785152,
        "text": "RT @Qdafool_RS: \"100KEYS\" prod: @zaytovenbeatz \ud83c\udfb9\u203c\ufe0fBEST BELIEVE IM THE REALIST IN THE CITY\u2705AND IM THE RICHEST UNSIGNED ARTIST IN MY CITY\u2705 HA\u2026",
        "user.screen_name": "flyass_mit"
    },
    {
        "created_at": "Mon Feb 12 02:39:29 +0000 2018",
        "id": 962878796356440064,
        "text": "Study reveals molecular mechanisms of memory formation https://t.co/st0YvS5hoA",
        "user.screen_name": "Johnson37975725"
    },
    {
        "created_at": "Mon Feb 12 02:39:23 +0000 2018",
        "id": 962878771731644416,
        "text": "RT @mitsmr: \"Even with rapid advances,\" says @erikbryn, \"AI won\u2019t be able to replace most jobs anytime soon. But in almost every industry,\u2026",
        "user.screen_name": "Impactoftech"
    },
    {
        "created_at": "Mon Feb 12 02:39:10 +0000 2018",
        "id": 962878719357607937,
        "text": "RT @newsycombinator: Solid aims to radically change the way web applications work https://t.co/x1xBfqvs2v",
        "user.screen_name": "katchwreck"
    },
    {
        "created_at": "Mon Feb 12 02:39:03 +0000 2018",
        "id": 962878688508481536,
        "text": "RT @JPPMsolutions: #science #technology #News &gt;&gt;  Weiss \u201955, PhD \u201962, professor emeritus of physics at MIT,... For More LIKE &amp; FOLLOW @JPPM\u2026",
        "user.screen_name": "vlics"
    },
    {
        "created_at": "Mon Feb 12 02:38:57 +0000 2018",
        "id": 962878664772866049,
        "text": "#Ficken mit #meiner #Freundin in #Yogahosen #Altenburg https://t.co/hKhnETHmHK",
        "user.screen_name": "NfyDcmr3qmyobzA"
    },
    {
        "created_at": "Mon Feb 12 02:38:57 +0000 2018",
        "id": 962878662323220480,
        "text": "RT @BillAulet: .@jockowillink on fire at Brisbane MIT Global Entrepreneurship Bootcamp talking about #extremeleadership @MITBootcamps @QUT\u2026",
        "user.screen_name": "MariusUrsache"
    },
    {
        "created_at": "Mon Feb 12 02:38:34 +0000 2018",
        "id": 962878565929902080,
        "text": "RT @BAP_US: Dr. #ShirleyJackson the first African-American woman to have earned a doctorate at the MIT.\n\n#BlackAndProud #BlackWomen #BlackE\u2026",
        "user.screen_name": "Jameski61861578"
    },
    {
        "created_at": "Mon Feb 12 02:38:32 +0000 2018",
        "id": 962878559114035200,
        "text": "RT @Ohworditspeter: I can\u2019t decide on who I hate more... \n\n1. The person who changed Snapchat. \n2. The person who took away instagrams chro\u2026",
        "user.screen_name": "Mit_ch_ell"
    },
    {
        "created_at": "Mon Feb 12 02:38:29 +0000 2018",
        "id": 962878547743461382,
        "text": "Contact Eximius Konceptz today......at eximius konceptz, we are ten times better. https://t.co/Ud9KGt4BPv",
        "user.screen_name": "mit_chelle8"
    },
    {
        "created_at": "Mon Feb 12 02:38:17 +0000 2018",
        "id": 962878497231441920,
        "text": "Solid aims to radically change the way web applications work https://t.co/sjGtgIPgsH",
        "user.screen_name": "dachelc"
    },
    {
        "created_at": "Mon Feb 12 02:38:06 +0000 2018",
        "id": 962878450452217857,
        "text": "Keynote Neri Oxman of Sony Corporation and MIT Media Lab at LIGHTFAIR International 2018: \u00a0 ATLANTA, GA \u2014Keynote Ne\u2026 https://t.co/kzzsEswA2h",
        "user.screen_name": "CurrentPowerINC"
    },
    {
        "created_at": "Mon Feb 12 02:38:02 +0000 2018",
        "id": 962878432861401089,
        "text": ".@jockowillink on fire at Brisbane MIT Global Entrepreneurship Bootcamp talking about #extremeleadership\u2026 https://t.co/57vOOYmqTd",
        "user.screen_name": "BillAulet"
    },
    {
        "created_at": "Mon Feb 12 02:37:37 +0000 2018",
        "id": 962878329765355520,
        "text": "#science #technology #News &gt;&gt;  Weiss \u201955, PhD \u201962, professor emeritus of physics at MIT,... For More LIKE &amp; FOLLOW @JPPMsolutions",
        "user.screen_name": "JPPMsolutions"
    },
    {
        "created_at": "Mon Feb 12 02:37:12 +0000 2018",
        "id": 962878221611077632,
        "text": "RT @ThisIsMyStream: MIT Technology Review - The Best of the Physics arXiv (week ending February 10, 2018) https://t.co/Zi61SDFZw1",
        "user.screen_name": "JDRedding"
    },
    {
        "created_at": "Mon Feb 12 02:36:54 +0000 2018",
        "id": 962878146872860673,
        "text": "#Steffi Double Penetration mit #einer #blonden XXX #Jena https://t.co/P5HNyuiHwp",
        "user.screen_name": "jessica10548987"
    },
    {
        "created_at": "Mon Feb 12 02:36:48 +0000 2018",
        "id": 962878121170161664,
        "text": "The way analytics is reshaping sports https://t.co/y0OFK5HqtS",
        "user.screen_name": "OneLinders"
    },
    {
        "created_at": "Mon Feb 12 02:35:47 +0000 2018",
        "id": 962877867783852034,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "StpdAmerHaiku"
    },
    {
        "created_at": "Mon Feb 12 02:35:00 +0000 2018",
        "id": 962877669036777473,
        "text": "RT @itskac: Need to interview a #musician, a #freelancer, a #smallbiz owner (or someone who wants to start one) &amp; a #tech #startup #founder\u2026",
        "user.screen_name": "biconnections"
    },
    {
        "created_at": "Mon Feb 12 02:34:58 +0000 2018",
        "id": 962877660123758593,
        "text": "Harvard picks ultimate insider who has degrees from Harvard, MIT, and led Tufts and who was originally on search co\u2026 https://t.co/y26I83B7wU",
        "user.screen_name": "SkipMarcucciMD"
    },
    {
        "created_at": "Mon Feb 12 02:34:56 +0000 2018",
        "id": 962877652309823488,
        "text": "RT @IlvesToomas: Is tech dividing America? https://t.co/jzbapAFS7s",
        "user.screen_name": "oroande"
    },
    {
        "created_at": "Mon Feb 12 02:34:40 +0000 2018",
        "id": 962877583955144704,
        "text": "Keynote Neri Oxman of Sony Corporation and MIT Media Lab at LIGHTFAIR International 2018 https://t.co/P7Wrmep6mZ https://t.co/GksM08rnK2",
        "user.screen_name": "ReliElectrician"
    },
    {
        "created_at": "Mon Feb 12 02:34:12 +0000 2018",
        "id": 962877470142853120,
        "text": "Is tech dividing America? https://t.co/6nMjZUXQNC",
        "user.screen_name": "bluespiderwasp"
    },
    {
        "created_at": "Mon Feb 12 02:34:03 +0000 2018",
        "id": 962877430523355136,
        "text": "RT @jdlovejoy: I\u2019m in love with this story about designing the \u201c+\u201d in the Human + AI augmentation loop. It\u2019s like discovering an oasis for\u2026",
        "user.screen_name": "artwithMI"
    },
    {
        "created_at": "Mon Feb 12 02:33:18 +0000 2018",
        "id": 962877243881074688,
        "text": "RT @IlvesToomas: Is tech dividing America? https://t.co/jzbapAFS7s",
        "user.screen_name": "Sakpol_SE"
    },
    {
        "created_at": "Mon Feb 12 02:33:13 +0000 2018",
        "id": 962877222297243649,
        "text": "RT @IlvesToomas: Is tech dividing America? https://t.co/jzbapAFS7s",
        "user.screen_name": "Cuprikorn66"
    },
    {
        "created_at": "Mon Feb 12 02:33:03 +0000 2018",
        "id": 962877176906313729,
        "text": "RT @MIT_alumni: Co-founded by @nevadasanchez '10, SM '11, @ButterflyNetInc creates low cost, clinical-quality ultrasounds on a smartphone h\u2026",
        "user.screen_name": "idaveg"
    },
    {
        "created_at": "Mon Feb 12 02:32:33 +0000 2018",
        "id": 962877054856265728,
        "text": "Pace Layering: How Complex Systems Learn and Keep Learning https://t.co/rqBtpjahaB",
        "user.screen_name": "learnlinksfeed"
    },
    {
        "created_at": "Mon Feb 12 02:32:18 +0000 2018",
        "id": 962876989794217985,
        "text": "Is tech dividing America? https://t.co/jzbapAFS7s",
        "user.screen_name": "IlvesToomas"
    },
    {
        "created_at": "Mon Feb 12 02:32:02 +0000 2018",
        "id": 962876923868274693,
        "text": "\u270c @Reading \"Solid\" https://t.co/8FUXh51m58",
        "user.screen_name": "caseyisreading"
    },
    {
        "created_at": "Mon Feb 12 02:32:00 +0000 2018",
        "id": 962876915936890881,
        "text": "RT @OnlyInBOS: The @NicheSocial Top Party Schools in Massachusetts:\n\n1 UMass Amherst\n2 MIT\n3 BU\n4 BC\n5 Berklee\n6 Northeastern\n7 Bentley\n8 U\u2026",
        "user.screen_name": "MarymilGonzalez"
    },
    {
        "created_at": "Mon Feb 12 02:31:58 +0000 2018",
        "id": 962876907405668352,
        "text": "\u270c @Reading \"Solid\" https://t.co/hll0uD9mKH",
        "user.screen_name": "caseyisreading"
    },
    {
        "created_at": "Mon Feb 12 02:31:37 +0000 2018",
        "id": 962876817018298369,
        "text": "Will Anybody Buy a Drone Large Enough to Carry a Person? - MIT Technology Review https://t.co/jk7bGluhw2",
        "user.screen_name": "ConeDrones"
    },
    {
        "created_at": "Mon Feb 12 02:30:34 +0000 2018",
        "id": 962876553528037376,
        "text": "Facial recognition software is biased towards white men, researcher finds - The Verge https://t.co/Pnaes4YLqC #Google #News #Tech",
        "user.screen_name": "DailyNewTech"
    },
    {
        "created_at": "Mon Feb 12 02:30:08 +0000 2018",
        "id": 962876446665474048,
        "text": "This new company wants to sequence your genome and let you share it on a blockchain. People will be able to earn cr\u2026 https://t.co/DIQYd8MTWP",
        "user.screen_name": "CTIChicago"
    },
    {
        "created_at": "Mon Feb 12 02:30:06 +0000 2018",
        "id": 962876435332550657,
        "text": "@itsmattward Cool article on nature and blockchains. Eduardo Castello Ferrer from MIT media lab has a paper on swar\u2026 https://t.co/eMBaXz87Cf",
        "user.screen_name": "sapien_sam"
    },
    {
        "created_at": "Mon Feb 12 02:29:57 +0000 2018",
        "id": 962876400364638208,
        "text": "RT @itskac: Need to interview a #musician, a #freelancer, a #smallbiz owner (or someone who wants to start one) &amp; a #tech #startup #founder\u2026",
        "user.screen_name": "WesPlattTweets"
    },
    {
        "created_at": "Mon Feb 12 02:29:56 +0000 2018",
        "id": 962876395994206208,
        "text": "RT @itskac: Need to interview a #musician, a #freelancer, a #smallbiz owner (or someone who wants to start one) &amp; a #tech #startup #founder\u2026",
        "user.screen_name": "matageli"
    },
    {
        "created_at": "Mon Feb 12 02:29:36 +0000 2018",
        "id": 962876310543482880,
        "text": "RT @skocharlakota: Happening now - @msisodia taking questions from MIT students. https://t.co/bArfCC0SFu",
        "user.screen_name": "MdAsik60605794"
    },
    {
        "created_at": "Mon Feb 12 02:29:35 +0000 2018",
        "id": 962876306106003456,
        "text": "RT @carlcarrie: MIT Behavioral Trading Cryptocurrency Research Paper -excitation, herding and peer-influence across cryptocurrency Executio\u2026",
        "user.screen_name": "aoi_cap"
    },
    {
        "created_at": "Mon Feb 12 02:29:10 +0000 2018",
        "id": 962876202691133441,
        "text": "RT @itskac: Need to interview a #musician, a #freelancer, a #smallbiz owner (or someone who wants to start one) &amp; a #tech #startup #founder\u2026",
        "user.screen_name": "kitty4hawks"
    },
    {
        "created_at": "Mon Feb 12 02:28:49 +0000 2018",
        "id": 962876112236789761,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "Unibloo"
    },
    {
        "created_at": "Mon Feb 12 02:28:48 +0000 2018",
        "id": 962876109716164609,
        "text": "RT @cosmobiologist: Professor Danielle Wood of the Space Enabled Research Lab at the MIT Media Group on how we can use space exploration te\u2026",
        "user.screen_name": "tracy_karin"
    },
    {
        "created_at": "Mon Feb 12 02:28:42 +0000 2018",
        "id": 962876084248178689,
        "text": "RT @mitsmr: \"Great strategists are like great chess players or great game theorists: They need to think several steps ahead towards the end\u2026",
        "user.screen_name": "TheCerebrus"
    },
    {
        "created_at": "Mon Feb 12 02:28:26 +0000 2018",
        "id": 962876015780548610,
        "text": "RT @StanM3: Germany- Afghan(19) stabbed his ex-girlfriend(23) in the shoulder and fled. The police had been called because of domestic viol\u2026",
        "user.screen_name": "Cookiemuffen"
    },
    {
        "created_at": "Mon Feb 12 02:28:02 +0000 2018",
        "id": 962875914769092609,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "gsngl"
    },
    {
        "created_at": "Mon Feb 12 02:27:51 +0000 2018",
        "id": 962875868363161600,
        "text": "'Facial recognition software is biased towards white men, researcher finds' from @theverge: https://t.co/8RQBlPCL2A #algorithmicbias",
        "user.screen_name": "jpgreenwood"
    },
    {
        "created_at": "Mon Feb 12 02:27:42 +0000 2018",
        "id": 962875832451682305,
        "text": "\u23ec watch \u23ec\n\nhttps://t.co/MKcbCgSlax\n\nbignaturaltits porn bignaturalbreast mom deutsche mother german hd oldyoung big\u2026 https://t.co/MkVto0RC8l",
        "user.screen_name": "Donna9Phyllis"
    },
    {
        "created_at": "Mon Feb 12 02:27:36 +0000 2018",
        "id": 962875805335371776,
        "text": "RT @ProfBarrett: The MIT Innovation and Entrepreneurship Bootcamp is well underway. https://t.co/xyNaozuPaw",
        "user.screen_name": "brizfagan"
    },
    {
        "created_at": "Mon Feb 12 02:27:28 +0000 2018",
        "id": 962875773060251649,
        "text": "Need to interview a #musician, a #freelancer, a #smallbiz owner (or someone who wants to start one) &amp; a #tech\u2026 https://t.co/K6Yzmslj0Y",
        "user.screen_name": "itskac"
    },
    {
        "created_at": "Mon Feb 12 02:27:04 +0000 2018",
        "id": 962875674347409408,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "JoseRamonVille6"
    },
    {
        "created_at": "Mon Feb 12 02:26:46 +0000 2018",
        "id": 962875596538826753,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "fj_newman"
    },
    {
        "created_at": "Mon Feb 12 02:26:38 +0000 2018",
        "id": 962875564792016896,
        "text": "Distinctive brain pattern helps habits form https://t.co/ufC3X8r0bt",
        "user.screen_name": "Johnson37975725"
    },
    {
        "created_at": "Mon Feb 12 02:25:57 +0000 2018",
        "id": 962875393006022656,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "BulletinLoft"
    },
    {
        "created_at": "Mon Feb 12 02:25:47 +0000 2018",
        "id": 962875351834611712,
        "text": "RT @MITSloan: \"Let us aspire to these kinds of businesses that create value across stakeholders, rather than settling for value only to sha\u2026",
        "user.screen_name": "bdean_"
    },
    {
        "created_at": "Mon Feb 12 02:25:43 +0000 2018",
        "id": 962875334960885760,
        "text": "@gbaucom @techreview I read that article this morning and retweeted on twitter - but not on Facebook #mit #WomeninScience",
        "user.screen_name": "JChrisPires"
    },
    {
        "created_at": "Mon Feb 12 02:25:31 +0000 2018",
        "id": 962875281215193089,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "SueLeugers"
    },
    {
        "created_at": "Mon Feb 12 02:25:12 +0000 2018",
        "id": 962875204153282561,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "NicoletteMpls"
    },
    {
        "created_at": "Mon Feb 12 02:25:07 +0000 2018",
        "id": 962875181793533952,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "DarthStarks"
    },
    {
        "created_at": "Mon Feb 12 02:24:32 +0000 2018",
        "id": 962875034028183555,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "jeremiahgraves"
    },
    {
        "created_at": "Mon Feb 12 02:24:24 +0000 2018",
        "id": 962875003279585281,
        "text": "RT @gbaucom: Meet the biologist who got MIT to examine its treatment of women researchers - via @techreview https://t.co/c6JqibvhkQ //I rec\u2026",
        "user.screen_name": "JChrisPires"
    },
    {
        "created_at": "Mon Feb 12 02:24:23 +0000 2018",
        "id": 962874997416124416,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "AnalyzedLabs"
    },
    {
        "created_at": "Mon Feb 12 02:24:22 +0000 2018",
        "id": 962874994047897600,
        "text": "RT @politico: Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/N\u2026",
        "user.screen_name": "Kiwigirl58"
    },
    {
        "created_at": "Mon Feb 12 02:24:13 +0000 2018",
        "id": 962874954046984197,
        "text": "Divided states of America. Expectations vs Reality. #MIT https://t.co/mg0CzOcODz",
        "user.screen_name": "PepPuigRos"
    },
    {
        "created_at": "Mon Feb 12 02:24:04 +0000 2018",
        "id": 962874919909494784,
        "text": "Is tech dividing America? POLITICO\u2019s @nancyscola interviews MIT researcher David Autor https://t.co/5bOrOCQ0EF https://t.co/Nyx6ZDoLpl",
        "user.screen_name": "politico"
    },
    {
        "created_at": "Mon Feb 12 02:23:38 +0000 2018",
        "id": 962874807900606464,
        "text": "RT @DevinGloGod: when i use the \ud83d\ude17 emoji it\u2019s not a kiss it\u2019s this: https://t.co/O9IoJLnWkc",
        "user.screen_name": "Taylor_Mit"
    },
    {
        "created_at": "Mon Feb 12 02:22:44 +0000 2018",
        "id": 962874584474226688,
        "text": "@jeremiefrechet2 That\u2019s actually why MIT has a better rating. More students get in and pretty much if you graduate\u2026 https://t.co/RTymh7XBTy",
        "user.screen_name": "alexiajordan24"
    },
    {
        "created_at": "Mon Feb 12 02:22:37 +0000 2018",
        "id": 962874551922315264,
        "text": "RT @MITSloan: \"Let us aspire to these kinds of businesses that create value across stakeholders, rather than settling for value only to sha\u2026",
        "user.screen_name": "vestedventures"
    },
    {
        "created_at": "Mon Feb 12 02:22:06 +0000 2018",
        "id": 962874421445910528,
        "text": "RT @mitsmr: RT @MITSloan: Analytics are driving more and more business decisions in sports. 3 from the industry reveal what's next. https:/\u2026",
        "user.screen_name": "vestedventures"
    },
    {
        "created_at": "Mon Feb 12 02:21:59 +0000 2018",
        "id": 962874392249282560,
        "text": "sex mit teenie sensual adult greeting cards https://t.co/0vOWeLdVbK",
        "user.screen_name": "lauramilenaceti"
    },
    {
        "created_at": "Mon Feb 12 02:21:56 +0000 2018",
        "id": 962874379464974338,
        "text": "RT @skocharlakota: In the streets of Boston cutting thru MIT and Harvard universities, @msisodia walks with @AamAadmiParty volunteers &amp; wel\u2026",
        "user.screen_name": "deshmukh_vinesh"
    },
    {
        "created_at": "Mon Feb 12 02:21:42 +0000 2018",
        "id": 962874323189952512,
        "text": "RT @mitsmr: RT @MITSloan: Analytics are driving more and more business decisions in sports. 3 from the industry reveal what's next. https:/\u2026",
        "user.screen_name": "iSocialFanz"
    },
    {
        "created_at": "Mon Feb 12 02:21:41 +0000 2018",
        "id": 962874319528345600,
        "text": "RT @karoly_zsolnai: SLAC Dataset From MIT and Facebook  | Two Minute Papers #227 - https://t.co/yt00nS5kXp #ai https://t.co/EX709i7mOH",
        "user.screen_name": "KageKirin"
    },
    {
        "created_at": "Mon Feb 12 02:21:17 +0000 2018",
        "id": 962874217250349057,
        "text": "RT @BartekKsieski: Originally \"cracker\" was associated with the \"bad, dark side\" of hacking. #hacking #hackers #hacker #computers #technolo\u2026",
        "user.screen_name": "Crucial_Recruit"
    },
    {
        "created_at": "Mon Feb 12 02:21:14 +0000 2018",
        "id": 962874205015609344,
        "text": "RT @mitsmr: RT @MITSloan: Analytics are driving more and more business decisions in sports. 3 from the industry reveal what's next. https:/\u2026",
        "user.screen_name": "rautsan"
    },
    {
        "created_at": "Mon Feb 12 02:21:12 +0000 2018",
        "id": 962874195221893120,
        "text": "RT @misswolfiee: Beware this auction and seller who goes by Ritsu/Muttritsu. Theyre selling an already paid commission of a finished head o\u2026",
        "user.screen_name": "mit_ouo"
    },
    {
        "created_at": "Mon Feb 12 02:21:09 +0000 2018",
        "id": 962874185637875714,
        "text": "RT @mcsantacaterina: 2 MIT grads built an algorithm to pair you with wine. Take the quiz to see your wine matches https://t.co/tsKDg0Vkl7 h\u2026",
        "user.screen_name": "Kish33"
    },
    {
        "created_at": "Mon Feb 12 02:20:27 +0000 2018",
        "id": 962874006574530560,
        "text": "Originally \"cracker\" was associated with the \"bad, dark side\" of hacking. #hacking #hackers #hacker #computers\u2026 https://t.co/VfcIJHwgZx",
        "user.screen_name": "BartekKsieski"
    },
    {
        "created_at": "Mon Feb 12 02:20:10 +0000 2018",
        "id": 962873935384768512,
        "text": "Solid aims to radically change the way web applications work https://t.co/hJnQ6zZfe5",
        "user.screen_name": "_mangesh_tekale"
    },
    {
        "created_at": "Mon Feb 12 02:18:13 +0000 2018",
        "id": 962873445200560128,
        "text": "@chesscom @HuffPost @JohnCUrschel @MIT Saw him on stream training with Chessbrah's GM Aman Hambleton. He's taking t\u2026 https://t.co/O2yvUmAexF",
        "user.screen_name": "Lman92GTR"
    },
    {
        "created_at": "Mon Feb 12 02:17:46 +0000 2018",
        "id": 962873334735060992,
        "text": "@oliverdarcy @michaelmalice Nothing",
        "user.screen_name": "numbut_mit"
    },
    {
        "created_at": "Mon Feb 12 02:17:40 +0000 2018",
        "id": 962873305995898880,
        "text": "RT @MITSloan: \"Let us aspire to these kinds of businesses that create value across stakeholders, rather than settling for value only to sha\u2026",
        "user.screen_name": "bwilcoxwrites"
    },
    {
        "created_at": "Mon Feb 12 02:17:14 +0000 2018",
        "id": 962873198906953728,
        "text": "12-year study looks at effects of universal basic income https://t.co/nIkwn3M6sX",
        "user.screen_name": "marcosplarruda"
    },
    {
        "created_at": "Mon Feb 12 02:17:13 +0000 2018",
        "id": 962873195589193728,
        "text": "Why am I not surprised about this? https://t.co/eeEkbsWSqH",
        "user.screen_name": "tehabe"
    },
    {
        "created_at": "Mon Feb 12 02:16:46 +0000 2018",
        "id": 962873081218977792,
        "text": "i don't get why y'all be saying i have trash taste in music when i b listening to gems like this https://t.co/zjJuHTt8UR",
        "user.screen_name": "damn_mit"
    },
    {
        "created_at": "Mon Feb 12 02:16:19 +0000 2018",
        "id": 962872966655725569,
        "text": "RT @ncasenmare: My first academic journal article! hooray, i'm a Serious Grown-Up\u2122 now.\n\nAbout AI (Artificial Intelligence) and its forgott\u2026",
        "user.screen_name": "adrepd"
    },
    {
        "created_at": "Mon Feb 12 02:15:59 +0000 2018",
        "id": 962872884829065218,
        "text": "Mit Echo Sound Test Service skypen",
        "user.screen_name": "KenshinXV_Bot"
    },
    {
        "created_at": "Mon Feb 12 02:15:59 +0000 2018",
        "id": 962872883067441157,
        "text": "RT @bobvids: because they want to die https://t.co/Xankr6kjxF",
        "user.screen_name": "Punk_mit_Brille"
    },
    {
        "created_at": "Mon Feb 12 02:15:38 +0000 2018",
        "id": 962872797629382656,
        "text": "RT @ncasenmare: My first academic journal article! hooray, i'm a Serious Grown-Up\u2122 now.\n\nAbout AI (Artificial Intelligence) and its forgott\u2026",
        "user.screen_name": "samim"
    },
    {
        "created_at": "Mon Feb 12 02:15:37 +0000 2018",
        "id": 962872792420151296,
        "text": "MIT Technology Review https://t.co/RbrQ2pleS9",
        "user.screen_name": "inayoyurukoga"
    },
    {
        "created_at": "Mon Feb 12 02:15:37 +0000 2018",
        "id": 962872790289403904,
        "text": "MIT Technology Review https://t.co/ot33bmUDnL",
        "user.screen_name": "tekigakidanne"
    },
    {
        "created_at": "Mon Feb 12 02:15:35 +0000 2018",
        "id": 962872781452075008,
        "text": "MIT Technology Review https://t.co/El2KoUbfi8",
        "user.screen_name": "patsugizaeibu"
    },
    {
        "created_at": "Mon Feb 12 02:15:13 +0000 2018",
        "id": 962872689550491648,
        "text": "RT @mitsmr: RT @MITSloan: Analytics are driving more and more business decisions in sports. 3 from the industry reveal what's next. https:/\u2026",
        "user.screen_name": "nancyrubin"
    },
    {
        "created_at": "Mon Feb 12 02:15:08 +0000 2018",
        "id": 962872671150264320,
        "text": "RT @MPBorman: Using #Analytics to Improve #CustomerEngagement https://t.co/QudJPaK8eD @mitsmr @SASsoftware #corpgov #CEO #CFO #CIO #CMO #Bo\u2026",
        "user.screen_name": "lfpazmino"
    },
    {
        "created_at": "Mon Feb 12 02:15:03 +0000 2018",
        "id": 962872651109711874,
        "text": "IoT Voices with WIRED MIT Director, MIT IBM Watson AI Lab https://t.co/fpGQkvZw7z #AI https://t.co/voqbTiLAep",
        "user.screen_name": "RPA_AI"
    },
    {
        "created_at": "Mon Feb 12 02:15:00 +0000 2018",
        "id": 962872636429627393,
        "text": "What to watch besides the athletes at #WinterOlympics.  (MIT Management)  #Analytics   #PyeongchangOlympics\u2026 https://t.co/NCFovQbqG5",
        "user.screen_name": "jamesvgingerich"
    },
    {
        "created_at": "Mon Feb 12 02:13:48 +0000 2018",
        "id": 962872334007881729,
        "text": "RT @MaldenHS_Sports: Breaking News...Kevin Ochoa's time in the 200 Freestyle today at the Division 1 North Sectionals at MIT is a New MHS S\u2026",
        "user.screen_name": "sebascries"
    },
    {
        "created_at": "Mon Feb 12 02:13:13 +0000 2018",
        "id": 962872186729041920,
        "text": "RT @EconoScribe: \u201cA Reddit mob came after 16-year-old Harshita Arora, claiming she didn\u2019t make her Crypto Price Tracker app. Turns out she\u2026",
        "user.screen_name": "ifindinternship"
    },
    {
        "created_at": "Mon Feb 12 02:12:41 +0000 2018",
        "id": 962872052800675840,
        "text": "RT @TraDove_ICO: Breakfast with our team, board member Gordon Kaufman, and Professor Emeritus from the MIT Sloan School of Management. Big\u2026",
        "user.screen_name": "HunterBTC1"
    },
    {
        "created_at": "Mon Feb 12 02:12:33 +0000 2018",
        "id": 962872018755563520,
        "text": "@jeremiefrechet2 I know. I\u2019m just saying. Your argument would\u2019ve been hell of a lot better had you said MIT.",
        "user.screen_name": "alexiajordan24"
    },
    {
        "created_at": "Mon Feb 12 02:11:59 +0000 2018",
        "id": 962871875599765505,
        "text": "RT @DurfeeAthletics: Jaelin Jang represented Durfee today in the Women's MA South Sec. Swim Meet at MIT in Boston, competing in the 200 Yar\u2026",
        "user.screen_name": "Poliseno_PE"
    },
    {
        "created_at": "Mon Feb 12 02:11:44 +0000 2018",
        "id": 962871815004618752,
        "text": "RT @Durfee_Aquatics: Jaelin Jang represented Durfee today in the Women's MA South Sectionals Swim Meet at MIT in\u2026 https://t.co/zDpSCYHKdf",
        "user.screen_name": "Poliseno_PE"
    },
    {
        "created_at": "Mon Feb 12 02:11:01 +0000 2018",
        "id": 962871634284761088,
        "text": "\u201cA Reddit mob came after 16-year-old Harshita Arora, claiming she didn\u2019t make her Crypto Price Tracker app. Turns o\u2026 https://t.co/pcxDFUAGw4",
        "user.screen_name": "EconoScribe"
    },
    {
        "created_at": "Mon Feb 12 02:10:58 +0000 2018",
        "id": 962871621903093761,
        "text": "Pace Layering: How Complex Systems Learn and Keep Learning https://t.co/rL4yxPFVDa (https://t.co/Ic6nLJRPPw)",
        "user.screen_name": "newsyc50"
    },
    {
        "created_at": "Mon Feb 12 02:10:53 +0000 2018",
        "id": 962871599346192384,
        "text": "#Phoenix #mi\u00dfbraucht #Abella #Danger mit #einem strapon #Emden https://t.co/G6oIR7CJ6S",
        "user.screen_name": "robertson2555"
    },
    {
        "created_at": "Mon Feb 12 02:10:41 +0000 2018",
        "id": 962871549387665408,
        "text": "RT @alesiamorris: #BlackHistoryMonth \nShirley Ann Jackson PhD was the first African-American woman to earn a doctorate @MIT  \nhttps://t.co/\u2026",
        "user.screen_name": "charlesjo"
    },
    {
        "created_at": "Mon Feb 12 02:10:28 +0000 2018",
        "id": 962871494731845632,
        "text": "#nowplaying #xaviernaidoo ~ Xavier Naidoo | Nimm Mich Mit ||| Radio TEDDY - That's fun - makes clever!",
        "user.screen_name": "RadioTeddyMusic"
    },
    {
        "created_at": "Mon Feb 12 02:10:27 +0000 2018",
        "id": 962871489879072768,
        "text": "RT @BourseetTrading: \ud83d\udd34\" Harvard Geneticist Launches DNA-Fueled #Blockchain #Startup \" :\nhttps://t.co/leTmNo2t0K @CryptoCoinsNews \n@Harvard\u2026",
        "user.screen_name": "CarlHansenMD"
    },
    {
        "created_at": "Mon Feb 12 02:10:05 +0000 2018",
        "id": 962871401194704897,
        "text": "#BlackHistoryMonth \nShirley Ann Jackson PhD was the first African-American woman to earn a doctorate @MIT  \nhttps://t.co/y94x70mjDR",
        "user.screen_name": "alesiamorris"
    },
    {
        "created_at": "Mon Feb 12 02:09:51 +0000 2018",
        "id": 962871338582134784,
        "text": "Wow, mi primer essay en purEEE english. Me siento bien MIT.",
        "user.screen_name": "p4rtypeople"
    },
    {
        "created_at": "Mon Feb 12 02:09:34 +0000 2018",
        "id": 962871269648683008,
        "text": "RT @MaldenHS_Sports: Breaking News...Kevin Ochoa's time in the 200 Freestyle today at the Division 1 North Sectionals at MIT is a New MHS S\u2026",
        "user.screen_name": "kevinocho19"
    },
    {
        "created_at": "Mon Feb 12 02:09:12 +0000 2018",
        "id": 962871178196111360,
        "text": "Solid aims to radically change the way web applications work https://t.co/IV0HIvRYmI",
        "user.screen_name": "hn_uniq"
    },
    {
        "created_at": "Mon Feb 12 02:09:04 +0000 2018",
        "id": 962871143400062976,
        "text": "RT @mitsmr: Keep this chart handy when you're Identifying potential #leaders in your company.  https://t.co/WHj7CM39AJ #management https://\u2026",
        "user.screen_name": "Michael_Oyakojo"
    },
    {
        "created_at": "Mon Feb 12 02:09:03 +0000 2018",
        "id": 962871139570601984,
        "text": "RT @mitsmr: \"Even with rapid advances,\" says @erikbryn, \"AI won\u2019t be able to replace most jobs anytime soon. But in almost every industry,\u2026",
        "user.screen_name": "fundataminsolo"
    },
    {
        "created_at": "Mon Feb 12 02:08:15 +0000 2018",
        "id": 962870938462294016,
        "text": "50 \u2013 Pace Layering: How Complex Systems Learn and Keep Learning https://t.co/OZXgtiFYnr",
        "user.screen_name": "betterhn50"
    },
    {
        "created_at": "Mon Feb 12 02:07:59 +0000 2018",
        "id": 962870872741617664,
        "text": "Underground News Inc.: MIT expert claims latest chemical weapons attack i... https://t.co/O7DjsofTxR",
        "user.screen_name": "XXXTCPorno"
    },
    {
        "created_at": "Mon Feb 12 02:07:58 +0000 2018",
        "id": 962870866001432576,
        "text": "@jeremiefrechet2 You choose to go for Harvard and not MIT which is the #1 college in the world. Harvard is #3. Stan\u2026 https://t.co/rOESXSU4QZ",
        "user.screen_name": "alexiajordan24"
    },
    {
        "created_at": "Mon Feb 12 02:07:53 +0000 2018",
        "id": 962870847429111808,
        "text": "RT @Global_Renewal: #Reflecting on \"overcoming #resistance to #DiffusionOfInnovation &amp; #AdoptionOfInnovation\"&gt;&gt;&gt;\nhttps://t.co/YsOjNCb2mF\n\nh\u2026",
        "user.screen_name": "Global_Renewal"
    },
    {
        "created_at": "Mon Feb 12 02:07:53 +0000 2018",
        "id": 962870846904721408,
        "text": "@ajax_mit Five Guys &gt;",
        "user.screen_name": "TrailerParkGoon"
    },
    {
        "created_at": "Mon Feb 12 02:07:27 +0000 2018",
        "id": 962870735059456006,
        "text": "@Twitter \n@TwitterSupport \n@TwitterSafety \nWhat is Twitter doing to ID &amp; block bots and other antagonistic posts us\u2026 https://t.co/4RngbBbQkh",
        "user.screen_name": "countmeout11"
    },
    {
        "created_at": "Mon Feb 12 02:07:22 +0000 2018",
        "id": 962870714528354304,
        "text": "RT @skocharlakota: One of the important vision and focus of @ArvindKejriwal sarkar is rightly depicted in these pictures here  - Education,\u2026",
        "user.screen_name": "PrasunKaliB"
    },
    {
        "created_at": "Mon Feb 12 02:07:14 +0000 2018",
        "id": 962870682148376576,
        "text": "Be a futurist. Check out this cool six-step forecasting methodology created by amywebb.  https://t.co/TlWDANYEIg  via &gt;mitsmr",
        "user.screen_name": "savia_digital"
    },
    {
        "created_at": "Mon Feb 12 02:07:11 +0000 2018",
        "id": 962870669968072704,
        "text": "@cjzero What software do you use to grab video? I enjoy your content, and wanted to try to experiment on my own a bit.",
        "user.screen_name": "ffulC_miT"
    },
    {
        "created_at": "Mon Feb 12 02:06:40 +0000 2018",
        "id": 962870537822396416,
        "text": "@hyperhydration Bei mir mit kid cudi",
        "user.screen_name": "KevMescudi"
    },
    {
        "created_at": "Mon Feb 12 02:05:45 +0000 2018",
        "id": 962870307374714881,
        "text": "RT @55true4u: James Woods had near-perfect SAT scores, and an IQ of 184.\nWoods was a brilliant student who achieved a perfect 800 on the ve\u2026",
        "user.screen_name": "James90972633"
    },
    {
        "created_at": "Mon Feb 12 02:05:18 +0000 2018",
        "id": 962870194837352451,
        "text": "RT @newsycombinator: Solid aims to radically change the way web applications work https://t.co/x1xBfqvs2v",
        "user.screen_name": "martin1975"
    },
    {
        "created_at": "Mon Feb 12 02:03:20 +0000 2018",
        "id": 962869699221614592,
        "text": "Solid aims to radically change the way web applications work https://t.co/T2KxlLsJN7",
        "user.screen_name": "TridzOnline"
    },
    {
        "created_at": "Mon Feb 12 02:03:07 +0000 2018",
        "id": 962869645366607872,
        "text": "Solid aims to radically change the way web applications work https://t.co/pgd9lz9M6i https://t.co/pmlgcW4wwp",
        "user.screen_name": "hn_responder"
    },
    {
        "created_at": "Mon Feb 12 02:03:02 +0000 2018",
        "id": 962869626718715905,
        "text": "Der Dom ist mit vielen Statuen verziert. The dome is decorated with many statues.",
        "user.screen_name": "deutschbot1"
    },
    {
        "created_at": "Mon Feb 12 02:03:02 +0000 2018",
        "id": 962869624445591552,
        "text": "Solid aims to radically change the way web applications work https://t.co/x1xBfqvs2v",
        "user.screen_name": "newsycombinator"
    },
    {
        "created_at": "Mon Feb 12 02:02:50 +0000 2018",
        "id": 962869575099473920,
        "text": "RT @mitsmr: \"Even with rapid advances,\" says @erikbryn, \"AI won\u2019t be able to replace most jobs anytime soon. But in almost every industry,\u2026",
        "user.screen_name": "B2Bbizbuilder"
    },
    {
        "created_at": "Mon Feb 12 02:02:36 +0000 2018",
        "id": 962869517058654209,
        "text": "RT @TensorFlow: Thanks @MIT for sharing your Intro to Deep Learning class online! \ud83d\ude4c They include slides and videos, as well as labs in Tens\u2026",
        "user.screen_name": "2mo_hamisme"
    },
    {
        "created_at": "Mon Feb 12 02:02:21 +0000 2018",
        "id": 962869455008272386,
        "text": "MIT (Manager in Training) - NEW WAVE WIRELESS - Hot Springs, AR\u00a0\u00a0https://t.co/ptnJqX4mlO",
        "user.screen_name": "supra1Bqteam"
    },
    {
        "created_at": "Mon Feb 12 02:02:19 +0000 2018",
        "id": 962869445675724800,
        "text": "RT @MITSloan: \"Let us aspire to these kinds of businesses that create value across stakeholders, rather than settling for value only to sha\u2026",
        "user.screen_name": "neospacefnd"
    },
    {
        "created_at": "Mon Feb 12 02:02:17 +0000 2018",
        "id": 962869437761191937,
        "text": "RT @HarvardDivinity: \u201cSince meeting and befriending Larry Bacow over 25 years ago at MIT, I have had the privilege of working with one of t\u2026",
        "user.screen_name": "elhombremelena"
    },
    {
        "created_at": "Mon Feb 12 02:02:17 +0000 2018",
        "id": 962869434749726721,
        "text": "#bbw #mit massiven #titten #fickt #geck in der sauna https://t.co/OjAjXKMC8G",
        "user.screen_name": "O9WQBDn6iku9Rq7"
    },
    {
        "created_at": "Mon Feb 12 02:01:51 +0000 2018",
        "id": 962869325114650625,
        "text": "Solid aims to radically change the way web applications work\nhttps://t.co/gE2bcx4juK\nArticle URL: https://t.co/U0elKpRSwY URL: https:",
        "user.screen_name": "M157q_News_RSS"
    },
    {
        "created_at": "Mon Feb 12 02:01:34 +0000 2018",
        "id": 962869257888464897,
        "text": "Solid aims to radically change the way web applications work https://t.co/8qtZrjJ0dR",
        "user.screen_name": "betterhn100"
    },
    {
        "created_at": "Mon Feb 12 02:01:25 +0000 2018",
        "id": 962869216427855872,
        "text": "@rockerskating I have 3 degrees from MIT and can't entirely decipher this",
        "user.screen_name": "jodiecongirl"
    },
    {
        "created_at": "Mon Feb 12 02:01:13 +0000 2018",
        "id": 962869168264527872,
        "text": "Facial recognition software is biased towards white men, researcher finds https://t.co/knzIaaQN3U https://t.co/8RmzoF898x",
        "user.screen_name": "grenhall"
    },
    {
        "created_at": "Mon Feb 12 02:01:12 +0000 2018",
        "id": 962869163277672448,
        "text": "RT @conangray: bi is short for bitchwhatthefuckkissmealready",
        "user.screen_name": "mit_ouo"
    },
    {
        "created_at": "Mon Feb 12 02:01:08 +0000 2018",
        "id": 962869148559773696,
        "text": "RT @Smatterbrain: This is really horrible. Abandoning an animal in the hopes that someone finds it and cares for it is beyond disgusting an\u2026",
        "user.screen_name": "mit_ouo"
    },
    {
        "created_at": "Mon Feb 12 02:01:04 +0000 2018",
        "id": 962869129530064896,
        "text": "RT @mitsmr: \"Even with rapid advances,\" says @erikbryn, \"AI won\u2019t be able to replace most jobs anytime soon. But in almost every industry,\u2026",
        "user.screen_name": "bdean_"
    },
    {
        "created_at": "Mon Feb 12 02:00:54 +0000 2018",
        "id": 962869089034227712,
        "text": "\"\ud83d\udd25NEUES UPDATE\ud83d\udd25OverWatch Unlimited Loot Boxes Glitch 2018 - Kostenlose Beutelboxen *Mit Live Proof*\"\u00a0: https://t.co/zXSViycZsT",
        "user.screen_name": "RedoneTweets"
    },
    {
        "created_at": "Mon Feb 12 02:00:39 +0000 2018",
        "id": 962869024991391745,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "TeacherDrSarah"
    },
    {
        "created_at": "Mon Feb 12 02:00:34 +0000 2018",
        "id": 962869003478806529,
        "text": "RT @MITSloan: \"Let us aspire to these kinds of businesses that create value across stakeholders, rather than settling for value only to sha\u2026",
        "user.screen_name": "beatmeyer"
    },
    {
        "created_at": "Mon Feb 12 02:00:14 +0000 2018",
        "id": 962868921488564225,
        "text": "RT @MITSloan: Analytics are driving more and more business decisions in sports. 3 from the industry reveal what's n\u2026 https://t.co/HTtCyUlB1Y",
        "user.screen_name": "mitsmr"
    },
    {
        "created_at": "Mon Feb 12 02:00:09 +0000 2018",
        "id": 962868900282191874,
        "text": "RT @MaldenHS_Sports: Breaking News...Kevin Ochoa's time in the 200 Freestyle today at the Division 1 North Sectionals at MIT is a New MHS S\u2026",
        "user.screen_name": "Joanneee528"
    },
    {
        "created_at": "Mon Feb 12 02:00:01 +0000 2018",
        "id": 962868865095970817,
        "text": "Solid aims to radically change the way web applications work https://t.co/2eTJ3kq9qY",
        "user.screen_name": "hackernewsfeed"
    },
    {
        "created_at": "Mon Feb 12 01:59:55 +0000 2018",
        "id": 962868841926877184,
        "text": "RT @MaldenHS_Sports: Breaking News...Kevin Ochoa's time in the 200 Freestyle today at the Division 1 North Sectionals at MIT is a New MHS S\u2026",
        "user.screen_name": "mschistorymhs"
    },
    {
        "created_at": "Mon Feb 12 01:59:34 +0000 2018",
        "id": 962868752823005184,
        "text": "@Bobby_Corwin Even if you are alone, candy under the nails is yucky",
        "user.screen_name": "mit_ouo"
    },
    {
        "created_at": "Mon Feb 12 01:59:30 +0000 2018",
        "id": 962868736469344256,
        "text": "RT @MITSloan: Integrating analytics is crucial. Start with these 8 articles. https://t.co/3hxWVgHY9q",
        "user.screen_name": "cjvalladares_57"
    },
    {
        "created_at": "Mon Feb 12 01:59:00 +0000 2018",
        "id": 962868610594148352,
        "text": "\"Let us aspire to these kinds of businesses that create value across stakeholders, rather than settling for value o\u2026 https://t.co/HHUrj7aqBk",
        "user.screen_name": "MITSloan"
    },
    {
        "created_at": "Mon Feb 12 01:58:56 +0000 2018",
        "id": 962868592814514176,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "PriscaDujardin"
    },
    {
        "created_at": "Mon Feb 12 01:57:50 +0000 2018",
        "id": 962868315201748992,
        "text": "RT @mitsmr: \u201cJournalists often check a CEO\u2019s Twitter account before covering the CEO or the company.\u201d https://t.co/er59CY71Vg",
        "user.screen_name": "Michael_Oyakojo"
    },
    {
        "created_at": "Mon Feb 12 01:57:41 +0000 2018",
        "id": 962868278547816448,
        "text": "RT @MITSloan: \u201cThe Olympic host city loses money on the venture.\u201d https://t.co/JoFh4VZF8x https://t.co/sioocepgZj",
        "user.screen_name": "Michael_Oyakojo"
    },
    {
        "created_at": "Mon Feb 12 01:57:18 +0000 2018",
        "id": 962868183672684544,
        "text": "RT @LemelsonMIT: Our website is full of free resources, perfect for helping #teachers to inspire their students about #invention. Take your\u2026",
        "user.screen_name": "tonyperry"
    },
    {
        "created_at": "Mon Feb 12 01:57:18 +0000 2018",
        "id": 962868181789528064,
        "text": "RT @deeplearning4j: Pace Layering: How Complex Systems Learn and Keep Learning https://t.co/XysTbEoVZG",
        "user.screen_name": "PaaSDev"
    },
    {
        "created_at": "Mon Feb 12 01:57:18 +0000 2018",
        "id": 962868180778733574,
        "text": "RT @FrRonconi: Meet the 'Copenhagen Wheel', the first smart #bike wheel. It makes your bike an electric bicycle that synchronizes with your\u2026",
        "user.screen_name": "luisharoldo"
    },
    {
        "created_at": "Mon Feb 12 01:57:04 +0000 2018",
        "id": 962868123639730177,
        "text": "RT @mitsmr: RT @joannecanderson: How to achieve \"extreme #productivity\" from @mitsmr  : \"Hours are a traditional way of tracking employee p\u2026",
        "user.screen_name": "s_fogle"
    },
    {
        "created_at": "Mon Feb 12 01:56:49 +0000 2018",
        "id": 962868062046248960,
        "text": "Synchronize your crotches! 24hr until VALENSTEINS ...mit HEiNO! \u2665\ufe0f\u23f1\u2665\ufe0f\n#heino #oldweirdeyes\u2026 https://t.co/AQ6RDVOEN8",
        "user.screen_name": "HeinoHappyHour"
    },
    {
        "created_at": "Mon Feb 12 01:56:43 +0000 2018",
        "id": 962868033453731841,
        "text": "@jeremiefrechet2 Assuming you mean MIT. UCLA has a better Civil Engineering program and several other programs. MIT\u2026 https://t.co/mWQYmIDXx7",
        "user.screen_name": "alexiajordan24"
    },
    {
        "created_at": "Mon Feb 12 01:56:37 +0000 2018",
        "id": 962868010510938113,
        "text": "RT @TamaraMcCleary: Mastering the Digital #Innovation Challenge https://t.co/4jbLqULxfg #leadership #digitaltransformation MT @jglass8 via\u2026",
        "user.screen_name": "InnoForbes"
    },
    {
        "created_at": "Mon Feb 12 01:56:24 +0000 2018",
        "id": 962867955846602752,
        "text": "RT @StanM3: Italy- Media silence after a Sudanese man threatens people with knives and axes!\nhttps://t.co/DVlW1hZnrg https://t.co/L4v4xE4l5r",
        "user.screen_name": "Do666999"
    },
    {
        "created_at": "Mon Feb 12 01:55:46 +0000 2018",
        "id": 962867795196305408,
        "text": "#Blockchain Decoded - #MIT Technology Review https://t.co/azJqt6dcHJ",
        "user.screen_name": "laurentlequien"
    },
    {
        "created_at": "Mon Feb 12 01:55:17 +0000 2018",
        "id": 962867675973042176,
        "text": "The @MITBootcamps @QUT is underway. MIT Bootcamp draws environmental entrepreneurs to QUT https://t.co/X2ZyxphqEF",
        "user.screen_name": "ProfBarrett"
    },
    {
        "created_at": "Mon Feb 12 01:55:09 +0000 2018",
        "id": 962867641504403456,
        "text": "#Harvard names Lawrence S. Bacow as 29th president: Widely admired higher education leader, who previously served a\u2026 https://t.co/UjHlYTNGTv",
        "user.screen_name": "SoundsFromSound"
    },
    {
        "created_at": "Mon Feb 12 01:54:59 +0000 2018",
        "id": 962867600698028032,
        "text": "RT @BAP_US: Dr. #ShirleyJackson the first African-American woman to have earned a doctorate at the MIT.\n\n#BlackAndProud #BlackWomen #BlackE\u2026",
        "user.screen_name": "dj_moe1300"
    },
    {
        "created_at": "Mon Feb 12 01:54:41 +0000 2018",
        "id": 962867524164493312,
        "text": "RT @mitsmr: Be a futurist. Check out this cool six-step forecasting methodology created by @amywebb.  https://t.co/dGU8wKsCaH https://t.co/\u2026",
        "user.screen_name": "checklistmedic"
    },
    {
        "created_at": "Mon Feb 12 01:54:21 +0000 2018",
        "id": 962867439393533953,
        "text": "RT @mitsmr: \u201cJournalists often check a CEO\u2019s Twitter account before covering the CEO or the company.\u201d https://t.co/er59CY71Vg",
        "user.screen_name": "erez_kaminski"
    },
    {
        "created_at": "Mon Feb 12 01:54:05 +0000 2018",
        "id": 962867371827519488,
        "text": "(CNN)I'm a 19-year-old developer at an MIT-backed startup called dot Learn in Lagos, living in the bustle of... https://t.co/HQci4TEueu",
        "user.screen_name": "WigginAndrew"
    },
    {
        "created_at": "Mon Feb 12 01:53:24 +0000 2018",
        "id": 962867201622487047,
        "text": "@ASU @MayoClinic @MayoClinicSOM @ASUCollegeOfLaw .\nThe public health emergency in that are the idiots @ASU deliver\u2026 https://t.co/uWguG6HkgA",
        "user.screen_name": "____iyr_MAS____"
    },
    {
        "created_at": "Mon Feb 12 01:53:21 +0000 2018",
        "id": 962867189278756864,
        "text": "Solid aims to radically change the way web applications work https://t.co/bhlVuUtiGE",
        "user.screen_name": "hackernews100"
    },
    {
        "created_at": "Mon Feb 12 01:52:53 +0000 2018",
        "id": 962867070827249664,
        "text": "RT @mitsmr: A focus on execution is undermining managers\u2019 ability to develop strategy and leadership skills https://t.co/5uYtpdCfNR",
        "user.screen_name": "checklistmedic"
    },
    {
        "created_at": "Mon Feb 12 01:51:59 +0000 2018",
        "id": 962866846146772992,
        "text": "RT @smorebunnies: @marxistmariah @biselinakyle Tony hasnt been a weapons dealer since 2008 and has since changed entirely? He personally fu\u2026",
        "user.screen_name": "spidey_snark"
    },
    {
        "created_at": "Mon Feb 12 01:51:55 +0000 2018",
        "id": 962866829415903232,
        "text": "RT @garoukike: Mattis admits there was no evidence Assad used gas.\n\nWell, the last year, Theodore Postol, MIT Professor &amp; leading CW expert\u2026",
        "user.screen_name": "christophjlheer"
    },
    {
        "created_at": "Mon Feb 12 01:51:09 +0000 2018",
        "id": 962866636314222593,
        "text": "RT @seattletimes: Several top schools \u2014 including Carnegie Mellon, Cornell, Duke, and MIT \u2014 have added or are rushing to add classes about\u2026",
        "user.screen_name": "0x04b1d"
    },
    {
        "created_at": "Mon Feb 12 01:50:30 +0000 2018",
        "id": 962866470958043136,
        "text": "RT @SJPSwimCoach: A man of few words: Senior Max Scalley tells us the best part about diving at the 2018 MIAA North Sectionals at MIT.  Go\u2026",
        "user.screen_name": "Asilvestri17"
    },
    {
        "created_at": "Mon Feb 12 01:50:19 +0000 2018",
        "id": 962866424061587456,
        "text": "RT @lexiblackbriar: AU: she fakes her death when the FBI try to force her to work for them to avoid charges for her hacktivist activities i\u2026",
        "user.screen_name": "arrowoverwatch"
    },
    {
        "created_at": "Mon Feb 12 01:49:52 +0000 2018",
        "id": 962866311243227138,
        "text": "RT @HaroldSinnott: The Hard Truth About Business Model Innovation \n\nhttps://t.co/SpecpDoRWd @claychristensen \n @HarvardBiz via @mitsmr\n#Lea\u2026",
        "user.screen_name": "Armando_Ribeiro"
    },
    {
        "created_at": "Mon Feb 12 01:48:56 +0000 2018",
        "id": 962866074835300352,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/lg2RZ9eUnd\u2026",
        "user.screen_name": "EdgarTodd10"
    },
    {
        "created_at": "Mon Feb 12 01:48:50 +0000 2018",
        "id": 962866050885996544,
        "text": "Hate to admit it but this is the demographic I have the most trouble recognizing, so thanks! https://t.co/H0O6j4tYUL via @Verge",
        "user.screen_name": "mokojumbee"
    },
    {
        "created_at": "Mon Feb 12 01:48:35 +0000 2018",
        "id": 962865989258960896,
        "text": "RT @skocharlakota: Happening now - @msisodia taking questions from MIT students. https://t.co/bArfCC0SFu",
        "user.screen_name": "tarakgoradia"
    },
    {
        "created_at": "Mon Feb 12 01:48:30 +0000 2018",
        "id": 962865967486459904,
        "text": "RT @mitsmr: Keep this chart handy when you're Identifying potential #leaders in your company.  https://t.co/WHj7CM39AJ #management https://\u2026",
        "user.screen_name": "bipinjha96"
    },
    {
        "created_at": "Mon Feb 12 01:48:18 +0000 2018",
        "id": 962865915946729472,
        "text": "i am reminded by https://t.co/tw1miy3SnP of a quote \"the w3c cannot do something as simple as bake bread without se\u2026 https://t.co/m9tAv82viT",
        "user.screen_name": "4dieJungs"
    },
    {
        "created_at": "Mon Feb 12 01:47:58 +0000 2018",
        "id": 962865833050390529,
        "text": "RT @ProfBarrett: The MIT Innovation and Entrepreneurship Bootcamp is well underway. https://t.co/xyNaozuPaw",
        "user.screen_name": "QUTfoundry"
    },
    {
        "created_at": "Mon Feb 12 01:47:44 +0000 2018",
        "id": 962865775609606144,
        "text": "RT @NA_SwimAndDive: Good luck to Dylan Walsh and David O'Leary who compete in individual events at North Sectionals at MIT, as well as in r\u2026",
        "user.screen_name": "chetjackson22"
    },
    {
        "created_at": "Mon Feb 12 01:47:40 +0000 2018",
        "id": 962865755934089217,
        "text": "RT @BourseetTrading: \ud83d\udd34\" Harvard Geneticist Launches DNA-Fueled #Blockchain #Startup \" :\nhttps://t.co/leTmNo2t0K @CryptoCoinsNews \n@Harvard\u2026",
        "user.screen_name": "Info_Data_Mgmt"
    },
    {
        "created_at": "Mon Feb 12 01:47:21 +0000 2018",
        "id": 962865678603649030,
        "text": "How to achieve extreme productivity https://t.co/dteZOVIf1n via @mitsloan",
        "user.screen_name": "Paul_Brinkman"
    },
    {
        "created_at": "Mon Feb 12 01:47:21 +0000 2018",
        "id": 962865678133940225,
        "text": "MIT 6.S191: Introduction to Deep Learning https://t.co/EstVtZDKpL",
        "user.screen_name": "learnlinksfeed"
    },
    {
        "created_at": "Mon Feb 12 01:46:45 +0000 2018",
        "id": 962865525486338048,
        "text": "RT @garoukike: Mattis admits there was no evidence Assad used gas.\n\nWell, the last year, Theodore Postol, MIT Professor &amp; leading CW expert\u2026",
        "user.screen_name": "Occupy007"
    },
    {
        "created_at": "Mon Feb 12 01:46:44 +0000 2018",
        "id": 962865521791188992,
        "text": "RT @skocharlakota: One of the important vision and focus of @ArvindKejriwal sarkar is rightly depicted in these pictures here  - Education,\u2026",
        "user.screen_name": "SreenivasaBilla"
    },
    {
        "created_at": "Mon Feb 12 01:46:15 +0000 2018",
        "id": 962865402610094080,
        "text": "@sfreynolds @WhosoeverMike @ReignOfApril Those three men talk about person responsibility, hard work, logic and fai\u2026 https://t.co/LV7hJ2qMgB",
        "user.screen_name": "socratictimes"
    },
    {
        "created_at": "Mon Feb 12 01:46:10 +0000 2018",
        "id": 962865379080130560,
        "text": "RT @medialab: \u201cWhen we have more inclusive innovators, we have more inclusive innovation.\u201d @civicMIT PhD student Joy Buolamwini (@AJLUnited\u2026",
        "user.screen_name": "idavar"
    },
    {
        "created_at": "Mon Feb 12 01:46:03 +0000 2018",
        "id": 962865352039268352,
        "text": "Mountain Hardwear free shipping!: Promotion at Mountain Hardwear: Free shipping for elevated rewards members. free\u2026 https://t.co/gEkvTnovN4",
        "user.screen_name": "coupons_u_need"
    },
    {
        "created_at": "Mon Feb 12 01:46:03 +0000 2018",
        "id": 962865350642515968,
        "text": "Keetsa Discount Code 5%!: Promotion at Keetsa: 5% Off Keetsa Plus Mattress. Discount Code 5%! A Keetsa Coupon, Deal\u2026 https://t.co/1HGu3dg02v",
        "user.screen_name": "coupons_u_need"
    },
    {
        "created_at": "Mon Feb 12 01:45:42 +0000 2018",
        "id": 962865261933187073,
        "text": "@gbaucom @techreview I saw the MIT 150th anniversary exhibit at their museum a few years back, and they had the fir\u2026 https://t.co/F41aZwV5TV",
        "user.screen_name": "PlantLearner"
    },
    {
        "created_at": "Mon Feb 12 01:45:19 +0000 2018",
        "id": 962865167888416770,
        "text": "i found my pink cap on my desk and now i am wondering if I just dreamt this all ...",
        "user.screen_name": "damn_mit"
    },
    {
        "created_at": "Mon Feb 12 01:45:18 +0000 2018",
        "id": 962865160619618304,
        "text": "The MIT Innovation and Entrepreneurship Bootcamp is well underway. https://t.co/xyNaozuPaw",
        "user.screen_name": "ProfBarrett"
    },
    {
        "created_at": "Mon Feb 12 01:45:11 +0000 2018",
        "id": 962865133990105088,
        "text": "@erkam30dakika @erkamtufan MiT hesabi; the account run by Turkish intelligence https://t.co/7GvtWdIZ6Y",
        "user.screen_name": "hasan_yaglidere"
    },
    {
        "created_at": "Mon Feb 12 01:45:08 +0000 2018",
        "id": 962865118789931008,
        "text": "RT @petercoffee: \u201cAll of those businesses evolve from looking forward, reasoning back, figuring out what to do; making some big bets; build\u2026",
        "user.screen_name": "muneerkazmi"
    },
    {
        "created_at": "Mon Feb 12 01:44:46 +0000 2018",
        "id": 962865028264316933,
        "text": "RT @BAP_US: Dr. #ShirleyJackson the first African-American woman to have earned a doctorate at the MIT.\n\n#BlackAndProud #BlackWomen #BlackE\u2026",
        "user.screen_name": "UniversalCowboy"
    },
    {
        "created_at": "Mon Feb 12 01:43:50 +0000 2018",
        "id": 962864792829661184,
        "text": "RT @SJPSwimCoach: A man of few words: Senior Max Scalley tells us the best part about diving at the 2018 MIAA North Sectionals at MIT.  Go\u2026",
        "user.screen_name": "SJPSwimCoach"
    },
    {
        "created_at": "Mon Feb 12 01:43:46 +0000 2018",
        "id": 962864774659919873,
        "text": "dance with my dogs in the night time!",
        "user.screen_name": "damn_mit"
    },
    {
        "created_at": "Mon Feb 12 01:42:51 +0000 2018",
        "id": 962864546665832454,
        "text": "@MikeJMika All will get crushed by testing and never see light of day. I\u2019m not optimistic. MIT invented DRACO that\u2026 https://t.co/WWJw6TsZsU",
        "user.screen_name": "sean697"
    },
    {
        "created_at": "Mon Feb 12 01:42:37 +0000 2018",
        "id": 962864486951432192,
        "text": "RT @topnotifier: Solid aims to radically change the way web applications work (31 points on Hacker News): https://t.co/mAi3KjgLmO",
        "user.screen_name": "narulama"
    },
    {
        "created_at": "Mon Feb 12 01:41:58 +0000 2018",
        "id": 962864325445656576,
        "text": "RT @seattletimes: Several top schools \u2014 including Carnegie Mellon, Cornell, Duke, and MIT \u2014 have added or are rushing to add classes about\u2026",
        "user.screen_name": "L0veL1fe__Z"
    },
    {
        "created_at": "Mon Feb 12 01:41:58 +0000 2018",
        "id": 962864323461828608,
        "text": "Solid aims to radically change the way web applications work https://t.co/owz6oa3frC (https://t.co/RB44JjZdNk)",
        "user.screen_name": "newsyc100"
    },
    {
        "created_at": "Mon Feb 12 01:41:01 +0000 2018",
        "id": 962864084612923393,
        "text": "Cops have toppled a $530 million cybercrime empire MIT Technology Review https://t.co/spLKpbmu5t",
        "user.screen_name": "AiNewsCurrents"
    },
    {
        "created_at": "Mon Feb 12 01:40:31 +0000 2018",
        "id": 962863960327417856,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "LARRYIRBY6"
    },
    {
        "created_at": "Mon Feb 12 01:40:18 +0000 2018",
        "id": 962863904756936704,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/fQ1IKfcpVW\u2026",
        "user.screen_name": "J3nTyrell"
    },
    {
        "created_at": "Mon Feb 12 01:39:47 +0000 2018",
        "id": 962863774049939457,
        "text": "Several top schools \u2014 including Carnegie Mellon, Cornell, Duke, and MIT \u2014 have added or are rushing to add classes\u2026 https://t.co/wkWnAXv5gZ",
        "user.screen_name": "seattletimes"
    },
    {
        "created_at": "Mon Feb 12 01:39:03 +0000 2018",
        "id": 962863588279975936,
        "text": "RT @HaroldSinnott: The Hard Truth About Business Model Innovation \n\nhttps://t.co/SpecpDoRWd @claychristensen \n @HarvardBiz via @mitsmr\n#Lea\u2026",
        "user.screen_name": "Neel__C"
    },
    {
        "created_at": "Mon Feb 12 01:38:59 +0000 2018",
        "id": 962863574585454593,
        "text": "RT @QUTBusiness: MIT\u2019s #Innovation &amp; #Entrepreneurship Bootcamp steps up #environmental effort with #QUT https://t.co/LFY6zN83Oa",
        "user.screen_name": "DrRimmer"
    },
    {
        "created_at": "Mon Feb 12 01:38:54 +0000 2018",
        "id": 962863551714017280,
        "text": "@mithayst Wokaay Mit",
        "user.screen_name": "thecontenderz"
    },
    {
        "created_at": "Mon Feb 12 01:38:37 +0000 2018",
        "id": 962863481707028481,
        "text": "RT @mitsmr: \u201cJournalists often check a CEO\u2019s Twitter account before covering the CEO or the company.\u201d https://t.co/er59CY71Vg",
        "user.screen_name": "Neel__C"
    },
    {
        "created_at": "Mon Feb 12 01:38:23 +0000 2018",
        "id": 962863423045427201,
        "text": "New coating for hip implants could prevent premature failure - \n\nNanoscale films developed at MIT promote bone... https://t.co/coqOaeVMLw",
        "user.screen_name": "StemCellsNews"
    },
    {
        "created_at": "Mon Feb 12 01:38:13 +0000 2018",
        "id": 962863379848318976,
        "text": "Facial recognition software is biased towards white men, researcher finds - The Verge https://t.co/AnbfNRa8xx",
        "user.screen_name": "widebase"
    },
    {
        "created_at": "Mon Feb 12 01:38:08 +0000 2018",
        "id": 962863357345910784,
        "text": "Facial recognition software is biased towards white men, researcher finds - The Verge https://t.co/fZTmKjlCGV",
        "user.screen_name": "Chaiwattr"
    },
    {
        "created_at": "Mon Feb 12 01:38:05 +0000 2018",
        "id": 962863344402255872,
        "text": "Corporate Transformation - \"the optimal playbook for transformation should involve... reorienting strategy for the\u2026 https://t.co/TMbnH9n7rC",
        "user.screen_name": "NXXTCO"
    },
    {
        "created_at": "Mon Feb 12 01:37:38 +0000 2018",
        "id": 962863232527536128,
        "text": "@redpillarchive @Atheist_Geek48 @andyguy @Unity_Coach @SweetSourJesus @BabbleStamper @matty_lawrence\u2026 https://t.co/60O7045lYB",
        "user.screen_name": "ProbingOmega"
    },
    {
        "created_at": "Mon Feb 12 01:37:07 +0000 2018",
        "id": 962863100893413377,
        "text": "No com mit ted$, deseAsed. Nothing they, did tool$. bA it ed.$.",
        "user.screen_name": "JusticeNASA"
    },
    {
        "created_at": "Mon Feb 12 01:36:33 +0000 2018",
        "id": 962862959352598528,
        "text": "Hey @mit people! A very cool startup here needs your help to make survivors of domestic violence who own pets don\u2019t\u2026 https://t.co/VoPbAOJtrA",
        "user.screen_name": "clarkforamerica"
    },
    {
        "created_at": "Mon Feb 12 01:36:11 +0000 2018",
        "id": 962862866205261824,
        "text": "RT @skocharlakota: Happening now - @msisodia taking questions from MIT students. https://t.co/bArfCC0SFu",
        "user.screen_name": "SreenivasaBilla"
    },
    {
        "created_at": "Mon Feb 12 01:36:07 +0000 2018",
        "id": 962862851932278785,
        "text": "RT @DrHughHarvey: Didn\u2019t study deep learning at MIT?\n\nDon\u2019t worry - here\u2019s the entire course \n\nhttps://t.co/HTONtKKWWz https://t.co/bmbxY5u\u2026",
        "user.screen_name": "Bialogics"
    },
    {
        "created_at": "Mon Feb 12 01:35:59 +0000 2018",
        "id": 962862818226786304,
        "text": "@paulkrugman Well, you sorta heard it here first, even though Bitcoin was $2000 higher. Wonkishy, at least the MIT\u2026 https://t.co/amdaQys3Gj",
        "user.screen_name": "JigsawCapital"
    },
    {
        "created_at": "Mon Feb 12 01:35:30 +0000 2018",
        "id": 962862696923189248,
        "text": "No com mit ted$, deseAsed$. Nothing they, did drool$.",
        "user.screen_name": "JusticeNASA"
    },
    {
        "created_at": "Mon Feb 12 01:35:19 +0000 2018",
        "id": 962862649242353664,
        "text": "Started in 2008 by a Yale &amp; MIT grad who became an entrepreneur at age 10, 40Billion is... https://t.co/FbDlz2GsPW",
        "user.screen_name": "40Billion_com"
    },
    {
        "created_at": "Mon Feb 12 01:35:08 +0000 2018",
        "id": 962862602928971776,
        "text": "meine 3 leiblings lineups (mit mir)\n1: GiratinaXII, LuqiaXII, _qu und AjexoXII -- Xenium\n2:Nawlyy,Hynami,Scqrlxrd u\u2026 https://t.co/dYmQWQIbmK",
        "user.screen_name": "GiratinaXII"
    },
    {
        "created_at": "Mon Feb 12 01:34:46 +0000 2018",
        "id": 962862512315293697,
        "text": "RT @freedevo_: I remember one burned you alive and the other one gave you electric shocks https://t.co/Aj88I9n7ND",
        "user.screen_name": "Taylor_Mit"
    },
    {
        "created_at": "Mon Feb 12 01:33:56 +0000 2018",
        "id": 962862302360940544,
        "text": "RT @DHUNTtweets: @JdeMontreal @mtlgazette @LP_LaPresse @LeDevoir @CBCNews @McGillU @Concordia @Harvard @UniofOxford @Stanford @MIT\n\nA Unive\u2026",
        "user.screen_name": "PHIAtweets"
    },
    {
        "created_at": "Mon Feb 12 01:32:19 +0000 2018",
        "id": 962861894087344130,
        "text": "RT @MaldenHS_Sports: Breaking News...Kevin Ochoa's time in the 200 Freestyle today at the Division 1 North Sectionals at MIT is a New MHS S\u2026",
        "user.screen_name": "m_farias9"
    },
    {
        "created_at": "Mon Feb 12 01:32:15 +0000 2018",
        "id": 962861880002916352,
        "text": "Snapchat, twitter, 22mds\nEt les technologies de pointes ?\nI look high technology's of specialists of data machining\u2026 https://t.co/kdN3LzhRbL",
        "user.screen_name": "AbtMichel"
    },
    {
        "created_at": "Mon Feb 12 01:32:00 +0000 2018",
        "id": 962861813917417472,
        "text": "Using Analytics To Improve Customer Engagement via @mitsmr https://t.co/jsuNLiXr1H #business #analytics",
        "user.screen_name": "dataelixir"
    },
    {
        "created_at": "Mon Feb 12 01:31:16 +0000 2018",
        "id": 962861630483828736,
        "text": "Biggest Lies Told About Entrepreneurs https://t.co/njFdWAJbnN #entrepreneurs #BigData #startups #GrowthHacking",
        "user.screen_name": "thekindleader"
    },
    {
        "created_at": "Mon Feb 12 01:31:11 +0000 2018",
        "id": 962861607834484736,
        "text": "teenns lesbien porno live mit swans shaved sex video https://t.co/YG5mO0vOU3",
        "user.screen_name": "mvzavicola"
    },
    {
        "created_at": "Mon Feb 12 01:30:17 +0000 2018",
        "id": 962861384345292800,
        "text": "Next Sunday! Join Riz Virk, renowned entrepreneur and MIT grad, for a presentation on using synchronicity, dreams,\u2026 https://t.co/pgGJE9xTeA",
        "user.screen_name": "BanyenBooks"
    },
    {
        "created_at": "Mon Feb 12 01:29:18 +0000 2018",
        "id": 962861135383887874,
        "text": "#Dildos #und anal mit #einem #hei\u00dfen #br\u00fcnette https://t.co/xGUtSE2E3A",
        "user.screen_name": "dominguez8342"
    },
    {
        "created_at": "Mon Feb 12 01:29:09 +0000 2018",
        "id": 962861097148706821,
        "text": "RT @MaldenHS_Sports: Breaking News...Kevin Ochoa's time in the 200 Freestyle today at the Division 1 North Sectionals at MIT is a New MHS S\u2026",
        "user.screen_name": "o_forestier"
    },
    {
        "created_at": "Mon Feb 12 01:29:08 +0000 2018",
        "id": 962861095135432704,
        "text": "RT @garoukike: Mattis admits there was no evidence Assad used gas.\n\nWell, the last year, Theodore Postol, MIT Professor &amp; leading CW expert\u2026",
        "user.screen_name": "energizamx"
    },
    {
        "created_at": "Mon Feb 12 01:28:21 +0000 2018",
        "id": 962860897516642304,
        "text": "RT @garoukike: Mattis admits there was no evidence Assad used gas.\n\nWell, the last year, Theodore Postol, MIT Professor &amp; leading CW expert\u2026",
        "user.screen_name": "KingLeoHawk"
    },
    {
        "created_at": "Mon Feb 12 01:28:17 +0000 2018",
        "id": 962860878663225349,
        "text": "Please RT if you like!! #architecture #design #architects #interiordesign MIT Media Lab's Kino &amp;quot;living.\u2026 https://t.co/CAcItmrIfb",
        "user.screen_name": "architectsdays"
    },
    {
        "created_at": "Mon Feb 12 01:28:01 +0000 2018",
        "id": 962860813710168065,
        "text": "Higher ed news: Lawrence Bacow chosen to be 29th president of Harvard University, effective July 1. Ex-chancellor M\u2026 https://t.co/faIUwrwtzC",
        "user.screen_name": "jostonjustice"
    },
    {
        "created_at": "Mon Feb 12 01:27:59 +0000 2018",
        "id": 962860802586894337,
        "text": "RT @StanM3: Germany- Afghan(19) stabbed his ex-girlfriend(23) in the shoulder and fled. The police had been called because of domestic viol\u2026",
        "user.screen_name": "Okay2BWhite"
    },
    {
        "created_at": "Mon Feb 12 01:27:54 +0000 2018",
        "id": 962860782101958656,
        "text": "Please RT if you like!! #architecture #design #architects #interiordesign MIT Media Lab's Kino &amp;quot;living.\u2026 https://t.co/hI8FOv3cSW",
        "user.screen_name": "DecoDays"
    },
    {
        "created_at": "Mon Feb 12 01:27:40 +0000 2018",
        "id": 962860724195295232,
        "text": "Please RT if you like!! #architecture #design #architects #interiordesign MIT Media Lab's Kino &amp;quot;living.\u2026 https://t.co/jrfHTniKoS",
        "user.screen_name": "Interiors__home"
    },
    {
        "created_at": "Mon Feb 12 01:27:34 +0000 2018",
        "id": 962860698165563393,
        "text": "Congrats AnnaLisa! \nWomen's Track &amp; Field's DeBari Improves 60 Hurdles National Mark at MIT's Gordon Kelly Invitati\u2026 https://t.co/27atNc5xMw",
        "user.screen_name": "MHSRedRaiders"
    },
    {
        "created_at": "Mon Feb 12 01:27:05 +0000 2018",
        "id": 962860576337743874,
        "text": "Please RT if you like!! #architecture #design #architects #interiordesign MIT Media Lab's Kino...\u2026 https://t.co/vCz0X9fG1r",
        "user.screen_name": "BestIntDesingn"
    },
    {
        "created_at": "Mon Feb 12 01:26:54 +0000 2018",
        "id": 962860531240468480,
        "text": "Facial recognition software is biased towards white men, useless research finds  #AIisRACIST #tech \n\n https://t.co/NK4FCaSPh4",
        "user.screen_name": "BasedAlcatraz"
    },
    {
        "created_at": "Mon Feb 12 01:26:53 +0000 2018",
        "id": 962860525553180672,
        "text": "@foxy_scientist @CareenIngle Oh. Thought it was cuz I\u2019ve been seeing a lot of warrior cats projects on scratch (\u2026 https://t.co/M6VzVDBHbn",
        "user.screen_name": "JeffyStreet"
    },
    {
        "created_at": "Mon Feb 12 01:26:44 +0000 2018",
        "id": 962860490308321280,
        "text": "RT @mitsmr: \u201cJournalists often check a CEO\u2019s Twitter account before covering the CEO or the company.\u201d https://t.co/er59CY71Vg",
        "user.screen_name": "pepetapia44"
    },
    {
        "created_at": "Mon Feb 12 01:26:33 +0000 2018",
        "id": 962860441788497921,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/fQ1IKfcpVW\u2026",
        "user.screen_name": "MetiJoshi"
    },
    {
        "created_at": "Mon Feb 12 01:26:28 +0000 2018",
        "id": 962860422821855233,
        "text": "RT @TraDove_ICO: Breakfast with our team, board member Gordon Kaufman, and Professor Emeritus from the MIT Sloan School of Management. Big\u2026",
        "user.screen_name": "yunipoerdjo"
    },
    {
        "created_at": "Mon Feb 12 01:25:57 +0000 2018",
        "id": 962860293004058624,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/fQ1IKfcpVW\u2026",
        "user.screen_name": "JamesFl3tcher"
    },
    {
        "created_at": "Mon Feb 12 01:25:30 +0000 2018",
        "id": 962860178948403201,
        "text": "\u201cFacebook\u2019s app for kids should freak parents out\u201d by MIT Technology Review https://t.co/CL8DoXnia4 @Soteryx",
        "user.screen_name": "ProfChris"
    },
    {
        "created_at": "Mon Feb 12 01:25:27 +0000 2018",
        "id": 962860165983756288,
        "text": "Underground News Inc.: MIT expert claims latest chemical weapons attack i... https://t.co/0lKRWCN2bF",
        "user.screen_name": "GeneralStrikeUS"
    },
    {
        "created_at": "Mon Feb 12 01:25:03 +0000 2018",
        "id": 962860067933519874,
        "text": "#goingplaces !  #reisemagazin TV #classic #Video : Tracing the tracs of our parents in a #vintage car. Kaiser-Reich\u2026 https://t.co/5luSkTGHza",
        "user.screen_name": "tv_imweb"
    },
    {
        "created_at": "Mon Feb 12 01:24:49 +0000 2018",
        "id": 962860007535525888,
        "text": "RT @petercoffee: \u201cAll of those businesses evolve from looking forward, reasoning back, figuring out what to do; making some big bets; build\u2026",
        "user.screen_name": "Ron_Lehman"
    },
    {
        "created_at": "Mon Feb 12 01:24:39 +0000 2018",
        "id": 962859965508710400,
        "text": "RT @mitsmr: \u201cJournalists often check a CEO\u2019s Twitter account before covering the CEO or the company.\u201d https://t.co/er59CY71Vg",
        "user.screen_name": "arvmalhotra"
    },
    {
        "created_at": "Mon Feb 12 01:24:36 +0000 2018",
        "id": 962859953269690369,
        "text": "RT @mattreaney_: MIT IQ Initiative Is Taking A Different Approach To AI Research https://t.co/dar0RVeBXf\n#ArtificialIntelligence #AI #DeepL\u2026",
        "user.screen_name": "Calcaware"
    },
    {
        "created_at": "Mon Feb 12 01:24:33 +0000 2018",
        "id": 962859940368076803,
        "text": "\"Keine Profite mit der Miete\" WHAT'S THEIR OBSESSION WITH GERMAN QUOTES I'M SHOOK",
        "user.screen_name": "piedpiperhes"
    },
    {
        "created_at": "Mon Feb 12 01:24:02 +0000 2018",
        "id": 962859810730455040,
        "text": "RT @mattreaney_: MIT IQ Initiative Is Taking A Different Approach To AI Research https://t.co/dar0RVeBXf\n#ArtificialIntelligence #AI #DeepL\u2026",
        "user.screen_name": "Revelnotion"
    },
    {
        "created_at": "Mon Feb 12 01:23:37 +0000 2018",
        "id": 962859705357004800,
        "text": "Get ready to leave and they try to short me a taco salad. Incredible! @yumbrands yes I know it's not MIT grads but\u2026 https://t.co/V7u454zJBO",
        "user.screen_name": "Czar6127"
    },
    {
        "created_at": "Mon Feb 12 01:23:15 +0000 2018",
        "id": 962859613962956801,
        "text": "RT @ansontm: 60. This dog was litt https://t.co/vW1yOGW4Tt",
        "user.screen_name": "_mit_mit"
    },
    {
        "created_at": "Mon Feb 12 01:22:49 +0000 2018",
        "id": 962859504588083200,
        "text": "RT @AndyGrewal: Blue checkmarks are mocking the Pences for looking unhappy while visiting a concentration camp\ud83e\udd26\u200d\u2642\ufe0f https://t.co/vGySnhraZF",
        "user.screen_name": "mit_baggs"
    },
    {
        "created_at": "Mon Feb 12 01:22:46 +0000 2018",
        "id": 962859493506895873,
        "text": "RT @ThirdStreamRes: \"The greater concern is not about the number of jobs but whether those jobs will pay decent wages and people will have\u2026",
        "user.screen_name": "_jockr"
    },
    {
        "created_at": "Mon Feb 12 01:22:44 +0000 2018",
        "id": 962859484807925760,
        "text": "Mattis admits there was no evidence Assad used gas.\n\nWell, the last year, Theodore Postol, MIT Professor &amp; leading\u2026 https://t.co/srrbRFor8c",
        "user.screen_name": "garoukike"
    },
    {
        "created_at": "Mon Feb 12 01:21:51 +0000 2018",
        "id": 962859261666701312,
        "text": "She found a great, basic tribute game done by an MIT student. Now, she's heard me say a million times that MIT is a\u2026 https://t.co/0sSgGgMeNJ",
        "user.screen_name": "majorboredom"
    },
    {
        "created_at": "Mon Feb 12 01:20:57 +0000 2018",
        "id": 962859034109009921,
        "text": "kostenlose pornos mit rachel luttrell rachael taylor naked https://t.co/1xL3ttBwUR",
        "user.screen_name": "lucasgasmaio"
    },
    {
        "created_at": "Mon Feb 12 01:20:16 +0000 2018",
        "id": 962858861676900352,
        "text": "@FedupWithSwamp @mit_baggs Better hurry up and get them hanging gallo's built.",
        "user.screen_name": "GnatJarman"
    },
    {
        "created_at": "Mon Feb 12 01:19:43 +0000 2018",
        "id": 962858725664083968,
        "text": "RT @moooooog35: My son wants to attend MIT. He'll get in unless the entrance exam requires him to not get food on his shirt.",
        "user.screen_name": "pippijoyahoo"
    },
    {
        "created_at": "Mon Feb 12 01:19:00 +0000 2018",
        "id": 962858542003773440,
        "text": "RT @mitsmr: \"Great strategists are like great chess players or great game theorists: They need to think several steps ahead towards the end\u2026",
        "user.screen_name": "kdahlinpdx"
    },
    {
        "created_at": "Mon Feb 12 01:18:53 +0000 2018",
        "id": 962858513985953792,
        "text": "RT @MaldenHS_Sports: Breaking News...Kevin Ochoa's time in the 200 Freestyle today at the Division 1 North Sectionals at MIT is a New MHS S\u2026",
        "user.screen_name": "NewsMaldenMA"
    },
    {
        "created_at": "Mon Feb 12 01:18:46 +0000 2018",
        "id": 962858483782569984,
        "text": "RT @Chet_Cannon: Imagine being so far left and anti-Trump that you praise a child-torturing, teen-raping, murderous dictatorship just to sp\u2026",
        "user.screen_name": "mit_baggs"
    },
    {
        "created_at": "Mon Feb 12 01:18:25 +0000 2018",
        "id": 962858397610708992,
        "text": "Felicity smoak, mit class of 09 \u2014 Nyssa Al Ghul, air to the demon. https://t.co/MR0dS5HMdF",
        "user.screen_name": "clarysmoak"
    },
    {
        "created_at": "Mon Feb 12 01:18:18 +0000 2018",
        "id": 962858367780868096,
        "text": "RT @patdiaz: @mfbenitez I highly recommend @stewartbrand \"Pace layering\" in the recent @MIT_JoDS where he brilliantly describes the role fo\u2026",
        "user.screen_name": "KrishnRamesh"
    },
    {
        "created_at": "Mon Feb 12 01:18:17 +0000 2018",
        "id": 962858364840456192,
        "text": "RT @canuckMBT1512: Another link to Hillary is dead? How many is that? Hire a MIT guy to calculate the odds. https://t.co/0A52hiiLFE",
        "user.screen_name": "HRClintonPrison"
    },
    {
        "created_at": "Mon Feb 12 01:18:05 +0000 2018",
        "id": 962858312772530176,
        "text": "Breaking News...Kevin Ochoa's time in the 200 Freestyle today at the Division 1 North Sectionals at MIT is a New MH\u2026 https://t.co/sT64Iks2Pn",
        "user.screen_name": "MaldenHS_Sports"
    },
    {
        "created_at": "Mon Feb 12 01:17:13 +0000 2018",
        "id": 962858094098374656,
        "text": "BLOW THE BALLOON TO POP CHALLENGE Vol.3||mit Dani||FollyOlly: https://t.co/C3sDRGWh5k via @YouTube",
        "user.screen_name": "Folly_Olly"
    },
    {
        "created_at": "Mon Feb 12 01:16:52 +0000 2018",
        "id": 962858006705668096,
        "text": "Thx @MIT: #AI will replace whole systems but it will reshape business models in the short term. This means all\u2026 https://t.co/6QBafDSath",
        "user.screen_name": "galipeau"
    },
    {
        "created_at": "Mon Feb 12 01:16:42 +0000 2018",
        "id": 962857964594958336,
        "text": "RT @BrightCellars: 2 MIT grads built an algorithm to pair you with wine. Take the quiz to reveal the best wine matches for your taste!  htt\u2026",
        "user.screen_name": "lovedarlingsix"
    },
    {
        "created_at": "Mon Feb 12 01:16:27 +0000 2018",
        "id": 962857902921977856,
        "text": "MERSD HS Represents at MIT Boys Swimming Sectionals! Congrats from one swim fam to another!\nSee you at States \ud83d\ude00 https://t.co/HiYQirvnSW",
        "user.screen_name": "CitMersd"
    },
    {
        "created_at": "Mon Feb 12 01:16:19 +0000 2018",
        "id": 962857870352986113,
        "text": "RT @DrHughHarvey: Didn\u2019t study deep learning at MIT?\n\nDon\u2019t worry - here\u2019s the entire course \n\nhttps://t.co/HTONtKKWWz https://t.co/bmbxY5u\u2026",
        "user.screen_name": "holly_rehu"
    },
    {
        "created_at": "Mon Feb 12 01:15:44 +0000 2018",
        "id": 962857719781822464,
        "text": "Yo, @EvelynHammonds is my idol. She has degrees in engineering, physics AND computer programming. As a professor at\u2026 https://t.co/HNpaHNwY5v",
        "user.screen_name": "TheDoctaZ"
    },
    {
        "created_at": "Mon Feb 12 01:15:35 +0000 2018",
        "id": 962857682712510464,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/fQ1IKfcpVW\u2026",
        "user.screen_name": "ThancmarFeldt"
    },
    {
        "created_at": "Mon Feb 12 01:15:28 +0000 2018",
        "id": 962857653427879936,
        "text": "@thresholds_mit your domain name appears to have expired...",
        "user.screen_name": "tyler_kvochick"
    },
    {
        "created_at": "Mon Feb 12 01:15:14 +0000 2018",
        "id": 962857595626176512,
        "text": "SUPERDRY Angebote Superdry Vintage Logo T-Shirt mit Paillettenbesatz: Category: Damen / T-Shirts / T-Shirt mit Prin\u2026 https://t.co/1zN2MX3Irw",
        "user.screen_name": "SparVolltreffer"
    },
    {
        "created_at": "Mon Feb 12 01:15:02 +0000 2018",
        "id": 962857543318958080,
        "text": "Alumni urge MIT to champion AI for the public good #proudtobeMIT #AIethics https://t.co/53nRcML6uu",
        "user.screen_name": "thecroissants"
    },
    {
        "created_at": "Mon Feb 12 01:14:55 +0000 2018",
        "id": 962857515678621696,
        "text": "RT @MITSloan: 6 competitive advantages that come from turning data into insights. (via @mitsmr) https://t.co/O73x7bVxUS",
        "user.screen_name": "saint_nine_"
    },
    {
        "created_at": "Mon Feb 12 01:14:28 +0000 2018",
        "id": 962857401924898816,
        "text": "RT @MITSloan: The idea of a universal basic income is not new, but the theory has never been thoroughly tested. A massive new study is abou\u2026",
        "user.screen_name": "jose_greg"
    },
    {
        "created_at": "Mon Feb 12 01:14:19 +0000 2018",
        "id": 962857363177918467,
        "text": "RT @mitsmr: \u201cJournalists often check a CEO\u2019s Twitter account before covering the CEO or the company.\u201d https://t.co/er59CY71Vg",
        "user.screen_name": "nancyrubin"
    },
    {
        "created_at": "Mon Feb 12 01:14:06 +0000 2018",
        "id": 962857309323104256,
        "text": "IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/Ar5VhufLkD #DataScience #DataScientist\u2026 https://t.co/psmgiOgJmC",
        "user.screen_name": "eSURETY"
    },
    {
        "created_at": "Mon Feb 12 01:13:59 +0000 2018",
        "id": 962857280130699264,
        "text": "RT @ClimateX_MIT: How can sustainability be incorporated into athletics? ClimateX interviews MLB player and co-founder of Players for the P\u2026",
        "user.screen_name": "globathletes"
    },
    {
        "created_at": "Mon Feb 12 01:13:27 +0000 2018",
        "id": 962857147099906049,
        "text": "RT @MITSloan: 6 competitive advantages that come from turning data into insights. (via @mitsmr) https://t.co/O73x7bVxUS",
        "user.screen_name": "bwilcoxwrites"
    },
    {
        "created_at": "Mon Feb 12 01:13:05 +0000 2018",
        "id": 962857052656685056,
        "text": "Suits Outlets Delivery Code!: Promotion at Suits Outlets: Free Shipping for All Orders. Delivery Code! A Suits Outl\u2026 https://t.co/gmHxoSPAhP",
        "user.screen_name": "coupons_u_need"
    },
    {
        "created_at": "Mon Feb 12 01:13:04 +0000 2018",
        "id": 962857050601484288,
        "text": "QP Jewellers Coupon Code 120 GBP!: Promotion at QP Jewellers: Spend 1000 GBP and get 120 GBP Off Order Total. Coupo\u2026 https://t.co/N4dy3dkDWf",
        "user.screen_name": "coupons_u_need"
    },
    {
        "created_at": "Mon Feb 12 01:12:37 +0000 2018",
        "id": 962856935249907712,
        "text": "RT @mitsmr: \u201cJournalists often check a CEO\u2019s Twitter account before covering the CEO or the company.\u201d https://t.co/er59CY71Vg",
        "user.screen_name": "claudiaKM"
    },
    {
        "created_at": "Mon Feb 12 01:12:25 +0000 2018",
        "id": 962856887162167296,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee https://t.co/Pcgk5wojHs",
        "user.screen_name": "HackerGoodNews"
    },
    {
        "created_at": "Mon Feb 12 01:12:20 +0000 2018",
        "id": 962856865167065088,
        "text": "RT @FedupWithSwamp: GITMO is at MAX CAPACITY!!! They have to prep a second prison!!! https://t.co/PVCmqZr4Rj",
        "user.screen_name": "mit_baggs"
    },
    {
        "created_at": "Mon Feb 12 01:12:07 +0000 2018",
        "id": 962856813124206593,
        "text": "Ex-Alphabet Chairman Joins MIT As Visiting Innovation Fellow https://t.co/B8duEiRPmV #MachineLearning https://t.co/lpG6l7WtY6",
        "user.screen_name": "dj_shaily"
    },
    {
        "created_at": "Mon Feb 12 01:11:43 +0000 2018",
        "id": 962856712750469120,
        "text": "Another link to Hillary is dead? How many is that? Hire a MIT guy to calculate the odds. https://t.co/0A52hiiLFE",
        "user.screen_name": "canuckMBT1512"
    },
    {
        "created_at": "Mon Feb 12 01:11:15 +0000 2018",
        "id": 962856594974240768,
        "text": "Harvard University names 29th president, Dr. Lawrence S. Bacow, @MIT S.B. '72, @Harvard J.D. '76, M.P.P. '76, Ph.D.\u2026 https://t.co/cJg3iriDsA",
        "user.screen_name": "YoonD"
    },
    {
        "created_at": "Mon Feb 12 01:10:55 +0000 2018",
        "id": 962856508798226432,
        "text": "Thawed Hf Flo tree Wii Tim MIT ear sex saw ash dry us all if cliff yrs stars see ah bloc commit us at arc sew ah co\u2026 https://t.co/8GKHfGZoXy",
        "user.screen_name": "SaharaJohnson77"
    },
    {
        "created_at": "Mon Feb 12 01:10:49 +0000 2018",
        "id": 962856482814377984,
        "text": "RT @MPBorman: Using #Analytics to Improve #CustomerEngagement https://t.co/QudJPaK8eD @mitsmr @SASsoftware #corpgov #CEO #CFO #CIO #CMO #Bo\u2026",
        "user.screen_name": "EicherDaryl"
    },
    {
        "created_at": "Mon Feb 12 01:09:34 +0000 2018",
        "id": 962856171039272960,
        "text": "RT @conangray: some pals of mine, shot by david aragon https://t.co/sUHe6isNsV",
        "user.screen_name": "mit_ouo"
    },
    {
        "created_at": "Mon Feb 12 01:08:38 +0000 2018",
        "id": 962855936283963392,
        "text": "RT @TraDove_ICO: Breakfast with our team, board member Gordon Kaufman, and Professor Emeritus from the MIT Sloan School of Management. Big\u2026",
        "user.screen_name": "GihanKanishkaF"
    },
    {
        "created_at": "Mon Feb 12 01:08:36 +0000 2018",
        "id": 962855926305902593,
        "text": "Please RT if you like!! #architecture #design #architects #interiordesign MIT Media Lab's Kino...\u2026 https://t.co/QHiub6FLng",
        "user.screen_name": "ModernnArch"
    },
    {
        "created_at": "Mon Feb 12 01:08:13 +0000 2018",
        "id": 962855828251381760,
        "text": "RT @lotzrickards: felicity: felicity smoak, MIT class of 09\noliver: https://t.co/DRpcvdeCK4",
        "user.screen_name": "dakheughan"
    },
    {
        "created_at": "Mon Feb 12 01:07:39 +0000 2018",
        "id": 962855687926833152,
        "text": "Facial recognition software is biased towards white men, researcher finds https://t.co/HOp6qow39E\n\nNew research out\u2026 https://t.co/kCXMqfAmTX",
        "user.screen_name": "thetechwarf"
    },
    {
        "created_at": "Mon Feb 12 01:06:52 +0000 2018",
        "id": 962855490941341696,
        "text": "Implementation Barriers for Emotion-Sending Technologies https://t.co/sSFWCPAywW Eoin541 danmcduff robgleasure\u2026\u2026 https://t.co/RurpLNbJbQ",
        "user.screen_name": "savia_digital"
    },
    {
        "created_at": "Mon Feb 12 01:06:23 +0000 2018",
        "id": 962855368899596288,
        "text": "This feels odd. He was already president of Tufts and chancellor at MIT. https://t.co/tnb6oV3JrQ",
        "user.screen_name": "NeoconMaudit"
    },
    {
        "created_at": "Mon Feb 12 01:06:03 +0000 2018",
        "id": 962855284040286208,
        "text": "RT @MSFTImagine: Imagine a world with faster, cheaper #AI! @MIT researchers say we're closer to #computers that work like our brains: https\u2026",
        "user.screen_name": "IamPablo"
    },
    {
        "created_at": "Mon Feb 12 01:05:31 +0000 2018",
        "id": 962855148849516544,
        "text": "Is tech dividing America?\n\"We should take a lesson from how the discovery of crude remade Saudi Arabia and Norway.\"\u2026 https://t.co/2xaVuuOx9F",
        "user.screen_name": "StrategicLbries"
    },
    {
        "created_at": "Mon Feb 12 01:05:11 +0000 2018",
        "id": 962855067450773504,
        "text": "RT @MITSloan: The idea of a universal basic income is not new, but the theory has never been thoroughly tested. A massive new study is abou\u2026",
        "user.screen_name": "danpallotta"
    },
    {
        "created_at": "Mon Feb 12 01:05:09 +0000 2018",
        "id": 962855059884306432,
        "text": "RT @MITSloan: Design thinking can be applied to any problem in any industry. Here's how. https://t.co/tE8Q21t1Cs https://t.co/wBYILC483w",
        "user.screen_name": "Shwetango"
    },
    {
        "created_at": "Mon Feb 12 01:05:07 +0000 2018",
        "id": 962855050870689793,
        "text": "RT @MITSloan: 6 competitive advantages that come from turning data into insights. (via @mitsmr) https://t.co/O73x7bVxUS",
        "user.screen_name": "gogos"
    },
    {
        "created_at": "Mon Feb 12 01:05:04 +0000 2018",
        "id": 962855036169719809,
        "text": "\u201cJournalists often check a CEO\u2019s Twitter account before covering the CEO or the company.\u201d https://t.co/er59CY71Vg",
        "user.screen_name": "mitsmr"
    },
    {
        "created_at": "Mon Feb 12 01:04:40 +0000 2018",
        "id": 962854936735289344,
        "text": "Need ur kind sponsorship @ProfOsinbajo  2 represent Nigeria @ d upcoming MIT Innovation and entrepreneurship Bootca\u2026 https://t.co/MyFmIwJJl2",
        "user.screen_name": "Zeeman_AY"
    },
    {
        "created_at": "Mon Feb 12 01:04:38 +0000 2018",
        "id": 962854928669605888,
        "text": "RT @officialjaden: Don't Drink Soda",
        "user.screen_name": "mit_eto"
    },
    {
        "created_at": "Mon Feb 12 01:04:37 +0000 2018",
        "id": 962854922638299141,
        "text": "RT @FraHofm: \"MIT biological engineers have created a programming language that allows them to rapidly design complex, DNA-encoded circuits\u2026",
        "user.screen_name": "Seanredwolf"
    },
    {
        "created_at": "Mon Feb 12 01:04:29 +0000 2018",
        "id": 962854891373957120,
        "text": "RT @MITSloan: 6 competitive advantages that come from turning data into insights. (via @mitsmr) https://t.co/O73x7bVxUS",
        "user.screen_name": "erictetuan"
    },
    {
        "created_at": "Mon Feb 12 01:03:16 +0000 2018",
        "id": 962854583931494401,
        "text": "67 \u2013 Solid aims to radically change the way web applications work https://t.co/CzHCQGxfid",
        "user.screen_name": "betterhn50"
    },
    {
        "created_at": "Mon Feb 12 01:03:09 +0000 2018",
        "id": 962854554453794816,
        "text": "RT @gal_deplorable: I'd have to agree Q...\n\n#qanon https://t.co/0dIpTTcKCz",
        "user.screen_name": "mit_baggs"
    },
    {
        "created_at": "Mon Feb 12 01:03:03 +0000 2018",
        "id": 962854527580991488,
        "text": "February 24 at 8pm: Join us for a recital by @MIT_MTA Institute Professor Marcus Thompson, joined by fellow MIT Mus\u2026 https://t.co/EaVGTsG4rP",
        "user.screen_name": "MIT_SHASS"
    },
    {
        "created_at": "Mon Feb 12 01:02:54 +0000 2018",
        "id": 962854490230542336,
        "text": "RT @random_forests: MIT has shared an Intro to Deep Learning course, see: https://t.co/ULJddTvwvZ. Labs include @TensorFlow code (haven't h\u2026",
        "user.screen_name": "shinya1900012"
    },
    {
        "created_at": "Mon Feb 12 01:02:22 +0000 2018",
        "id": 962854355874471936,
        "text": "RT @ItsAngryBob: Things could get crazy in the next few weeks. Which side are you on? If these things go down prepare yourself to help expl\u2026",
        "user.screen_name": "mit_baggs"
    },
    {
        "created_at": "Mon Feb 12 01:01:54 +0000 2018",
        "id": 962854238555697153,
        "text": "RT @MITSloan: 6 competitive advantages that come from turning data into insights. (via @mitsmr) https://t.co/O73x7bVxUS",
        "user.screen_name": "jonnymateus"
    },
    {
        "created_at": "Mon Feb 12 01:01:38 +0000 2018",
        "id": 962854171077525504,
        "text": "@Mindcite_US @Google @CarnegieMellon @Cambridge_Uni @MIT @UniofOxford @Caltech @TechnionLive @Princeton @Yale\u2026 https://t.co/DJtyLt8KSQ",
        "user.screen_name": "4GodsWillBeDone"
    },
    {
        "created_at": "Mon Feb 12 01:01:26 +0000 2018",
        "id": 962854123912794112,
        "text": "RT @JuliaBrotherton: @Beverly_High MIT Model UN Security Council members Colby Snook and Marvin Wernsing. Topic:  nuclear threat on the Kor\u2026",
        "user.screen_name": "DebSchnabel"
    },
    {
        "created_at": "Mon Feb 12 01:01:25 +0000 2018",
        "id": 962854119798132736,
        "text": "RT @lotzrickards: felicity: felicity smoak, MIT class of 09\noliver: https://t.co/DRpcvdeCK4",
        "user.screen_name": "Dirrtygal"
    },
    {
        "created_at": "Mon Feb 12 01:01:22 +0000 2018",
        "id": 962854105671598080,
        "text": "RT @gal_deplorable: Just a thought...\n\nQ keeps saying mirror \n\n[14] live backwards is evil [41]\n\nIs Bush Sr targeted?\n\n#QAnon https://t.co/\u2026",
        "user.screen_name": "mit_baggs"
    },
    {
        "created_at": "Mon Feb 12 01:01:20 +0000 2018",
        "id": 962854099195752448,
        "text": "A grizzled MIT physicist can return from the edge of the knife alien.",
        "user.screen_name": "cherubikz"
    },
    {
        "created_at": "Mon Feb 12 01:01:19 +0000 2018",
        "id": 962854092170293248,
        "text": "RT @JuliaBrotherton: @Beverly_High               MIT Model UN delegates discussing trade and climate change. https://t.co/kyNrxAjC49",
        "user.screen_name": "DebSchnabel"
    },
    {
        "created_at": "Mon Feb 12 01:01:09 +0000 2018",
        "id": 962854052760502272,
        "text": "RT @ItsAngryBob: Latest Brenden Dilley INTEL drop...12 military panels running right now... POTUS will use Emergency Broadcast System more\u2026",
        "user.screen_name": "mit_baggs"
    },
    {
        "created_at": "Mon Feb 12 01:00:42 +0000 2018",
        "id": 962853936607703041,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "ArkangelScrap"
    },
    {
        "created_at": "Mon Feb 12 01:00:39 +0000 2018",
        "id": 962853925220122624,
        "text": "RT @tom_peters: This is priceless, as good as it gets. Take your time!! \"Is tech dividing America? via @POLITICO for iPad\" https://t.co/nwv\u2026",
        "user.screen_name": "leadershipstool"
    },
    {
        "created_at": "Mon Feb 12 01:00:37 +0000 2018",
        "id": 962853916760334341,
        "text": "Solid aims to radically change the way web applications work https://t.co/TSXz4b3skY",
        "user.screen_name": "hackernewsrobot"
    },
    {
        "created_at": "Mon Feb 12 01:00:17 +0000 2018",
        "id": 962853835298496512,
        "text": "Solid aims to radically change the way web applications work https://t.co/NpidiTW5dS",
        "user.screen_name": "alfonsowebdev"
    },
    {
        "created_at": "Mon Feb 12 01:00:01 +0000 2018",
        "id": 962853766142812161,
        "text": "Our website is full of free resources, perfect for helping #teachers to inspire their students about #invention. Ta\u2026 https://t.co/hln3AxWdam",
        "user.screen_name": "LemelsonMIT"
    },
    {
        "created_at": "Mon Feb 12 01:00:00 +0000 2018",
        "id": 962853761596182529,
        "text": "Solid aims to radically change the way web applications work (posted by doener) #1 on HN: https://t.co/ZSrGuxa4Ni",
        "user.screen_name": "usepanda"
    },
    {
        "created_at": "Mon Feb 12 00:59:31 +0000 2018",
        "id": 962853641085423616,
        "text": "RT @IWMF: Audrey Jiajia Li (@SaySayjiajia) is the 13th annual Elizabeth Neuffer Fellow. Watch this video to learn about her recent work as\u2026",
        "user.screen_name": "pcdnetwork"
    },
    {
        "created_at": "Mon Feb 12 00:59:15 +0000 2018",
        "id": 962853572147843073,
        "text": "RT @MITSloan: 6 competitive advantages that come from turning data into insights. (via @mitsmr) https://t.co/O73x7bVxUS",
        "user.screen_name": "gogos"
    },
    {
        "created_at": "Mon Feb 12 00:58:15 +0000 2018",
        "id": 962853321231994881,
        "text": "RT @MITSloan: 1. Measure productivity in results, not hours. https://t.co/6boIw93jQb",
        "user.screen_name": "gogos"
    },
    {
        "created_at": "Mon Feb 12 00:57:21 +0000 2018",
        "id": 962853095586721793,
        "text": "@JacobBiamonte In @MIT class with Ike Chuang he called |\u2022&gt;&lt;\u2022| \"Los Alamos notation\" and credited it to Zurek. In co\u2026 https://t.co/OFUeDRod7z",
        "user.screen_name": "airwoz"
    },
    {
        "created_at": "Mon Feb 12 00:56:28 +0000 2018",
        "id": 962852874962198528,
        "text": "From your lips, to God\u2019s ears!\n\nI believe President Trump means to never let us down.\n\n#PatiencePatriots\n\nDoing som\u2026 https://t.co/zsyEW8ERmy",
        "user.screen_name": "mit_baggs"
    },
    {
        "created_at": "Mon Feb 12 00:56:26 +0000 2018",
        "id": 962852865126682625,
        "text": "RT @mitsmr: Keep this chart handy when you're Identifying potential #leaders in your company.  https://t.co/WHj7CM39AJ #management https://\u2026",
        "user.screen_name": "careyjimzz"
    },
    {
        "created_at": "Mon Feb 12 00:56:17 +0000 2018",
        "id": 962852828283842561,
        "text": "Wilde analsex #mit Kathy #Anderson https://t.co/mYWABIJCwn",
        "user.screen_name": "e5J3B8uxGn02P9e"
    },
    {
        "created_at": "Mon Feb 12 00:55:39 +0000 2018",
        "id": 962852665892929536,
        "text": "RT @DrHughHarvey: Didn\u2019t study deep learning at MIT?\n\nDon\u2019t worry - here\u2019s the entire course \n\nhttps://t.co/HTONtKKWWz https://t.co/bmbxY5u\u2026",
        "user.screen_name": "manaranjanp"
    },
    {
        "created_at": "Mon Feb 12 00:55:00 +0000 2018",
        "id": 962852504974307329,
        "text": "6 competitive advantages that come from turning data into insights. (via @mitsmr) https://t.co/O73x7bVxUS",
        "user.screen_name": "MITSloan"
    },
    {
        "created_at": "Mon Feb 12 00:54:47 +0000 2018",
        "id": 962852451354333184,
        "text": "RT @franceintheus: Today is International #WomenScienceDay ! \nEsther Duflo is a Professor of Poverty Alleviation &amp; Dev\u2019t Economics at @MIT\u2026",
        "user.screen_name": "frelandv"
    },
    {
        "created_at": "Mon Feb 12 00:54:01 +0000 2018",
        "id": 962852255581069314,
        "text": "@bridgitmendler Just joined to say hello to you. - I'm little bit confused. Are you working at MIT or studying ?",
        "user.screen_name": "Ike_Wexter"
    },
    {
        "created_at": "Mon Feb 12 00:53:55 +0000 2018",
        "id": 962852229651693568,
        "text": "RT @TraDove_ICO: Breakfast with our team, board member Gordon Kaufman, and Professor Emeritus from the MIT Sloan School of Management. Big\u2026",
        "user.screen_name": "john_leo25"
    },
    {
        "created_at": "Mon Feb 12 00:53:33 +0000 2018",
        "id": 962852138476023808,
        "text": "Hot new story Facial recognition software is biased towards white men, researcher finds https://t.co/6ArydpydWz\u2026 https://t.co/PyrwObULrb",
        "user.screen_name": "EmpireDynamic"
    },
    {
        "created_at": "Mon Feb 12 00:53:03 +0000 2018",
        "id": 962852011065724928,
        "text": "Solid aims to radically change the way web applications work\nLink: https://t.co/fqp49EZ0PW\nCmts: https://t.co/JBuxkkuCtO",
        "user.screen_name": "HackerNewsPosts"
    },
    {
        "created_at": "Mon Feb 12 00:52:32 +0000 2018",
        "id": 962851884695351296,
        "text": "RT @TurkHeritage: On International #WomenInScience Day, listen to Turkish MIT @medialab faculty member Dr. Canan Dagdeviren talk at the UN\u2026",
        "user.screen_name": "22C0in"
    },
    {
        "created_at": "Mon Feb 12 00:52:24 +0000 2018",
        "id": 962851850579009536,
        "text": "RT @NeilKBrand: As my score for #Hitchcock's #Blackmail is being played live tonight by the #N\u00fcrnberg Symphony Orchestra tonight (https://t\u2026",
        "user.screen_name": "Minghowriter"
    },
    {
        "created_at": "Mon Feb 12 00:52:09 +0000 2018",
        "id": 962851785634402304,
        "text": "RT @LemelsonMIT: David Sengeh\u2019s interest in designing prostheses stems from his childhood. He grew up in Sierra Leone during the civil war,\u2026",
        "user.screen_name": "stansburyj"
    },
    {
        "created_at": "Mon Feb 12 00:51:50 +0000 2018",
        "id": 962851708148895745,
        "text": "RT @hildabast: Day 2 #BlackHistoryMonth: Physicist, Carolyn Beatrice Parker - a remarkable woman, whose long-lost story shows how much work\u2026",
        "user.screen_name": "NMGasparini"
    },
    {
        "created_at": "Mon Feb 12 00:51:49 +0000 2018",
        "id": 962851704763973632,
        "text": "RT @BrightCellars: 2 MIT grads built an algorithm to match you with wine. Take the quiz to see your matches https://t.co/6bOuliqukx https:/\u2026",
        "user.screen_name": "22C0in"
    },
    {
        "created_at": "Mon Feb 12 00:51:47 +0000 2018",
        "id": 962851693363941377,
        "text": "RT @gbaucom: Meet the biologist who got MIT to examine its treatment of women researchers - via @techreview https://t.co/c6JqibvhkQ //I rec\u2026",
        "user.screen_name": "m_gitz"
    },
    {
        "created_at": "Mon Feb 12 00:51:25 +0000 2018",
        "id": 962851603429711877,
        "text": "RT @TheNolanK: @seangares @launders @stunna @jamesbardolph @Fifflaren @n0thing \"When someone accidentally buys full version of WinRar\" http\u2026",
        "user.screen_name": "Kebap_mit_Alles"
    },
    {
        "created_at": "Mon Feb 12 00:51:17 +0000 2018",
        "id": 962851569510305792,
        "text": "Also looking for any MIT students with access to this https://t.co/5pIn86hNfK",
        "user.screen_name": "therealtblake"
    },
    {
        "created_at": "Mon Feb 12 00:50:58 +0000 2018",
        "id": 962851488266637314,
        "text": "Solid aims to radically change the way web applications work https://t.co/Pk8XjL7SIO (https://t.co/UBcBddSLyz)",
        "user.screen_name": "newsyc50"
    },
    {
        "created_at": "Mon Feb 12 00:49:55 +0000 2018",
        "id": 962851225506107392,
        "text": "Mit means with in German, I think ... unless you are talking about ice in Coca-Cola.  Then it means the same as ohne.  #cocacola",
        "user.screen_name": "DrewArrowood"
    },
    {
        "created_at": "Mon Feb 12 00:49:25 +0000 2018",
        "id": 962851098808803331,
        "text": "@SMITEGame @PlayHotG When will Hog come to ps4 ?? I mean fully (mit with early acesess",
        "user.screen_name": "xHawkeye3"
    },
    {
        "created_at": "Mon Feb 12 00:48:04 +0000 2018",
        "id": 962850757442789376,
        "text": "@Sergeant_Meow Don't forget Scratch. \ud83d\ude01\ud83d\udc31\ud83d\ude09  https://t.co/vJFQFv2BOZ",
        "user.screen_name": "JewelNtheLotus"
    },
    {
        "created_at": "Mon Feb 12 00:46:55 +0000 2018",
        "id": 962850471374475264,
        "text": "RT @skocharlakota: Happening now - @msisodia taking questions from MIT students. https://t.co/bArfCC0SFu",
        "user.screen_name": "jayeshmahajan"
    },
    {
        "created_at": "Mon Feb 12 00:46:35 +0000 2018",
        "id": 962850383709265925,
        "text": "Solid aims to radically change the way web applications work https://t.co/s2Tyz2Bkpj",
        "user.screen_name": "myikegami_bot"
    },
    {
        "created_at": "Mon Feb 12 00:46:31 +0000 2018",
        "id": 962850370287554560,
        "text": "RT @Teri_Lowe_: who chooses a starter over hot chocolate fudge cake n ice cream?!?not me xoxo https://t.co/mxaRubqWZ5",
        "user.screen_name": "harry_mit"
    },
    {
        "created_at": "Mon Feb 12 00:46:13 +0000 2018",
        "id": 962850292424261633,
        "text": "Facial recognition software is biased towards white men, researcher finds https://t.co/y0Z2PZzaUj",
        "user.screen_name": "sunkissedAus"
    },
    {
        "created_at": "Mon Feb 12 00:46:09 +0000 2018",
        "id": 962850274997166080,
        "text": "This is amazing.  Good for you, @JohnCUrschel - wow!  Nice to see Ravens support his move too. https://t.co/Xvd2yd3UIz",
        "user.screen_name": "dannotdaniel"
    },
    {
        "created_at": "Mon Feb 12 00:45:19 +0000 2018",
        "id": 962850067123195909,
        "text": "@Dame_mit_muff @WeDoNotLearn73 Not sure where you are going with this one. I feel I have answered. Sorry if it\u2019s not enough. \ud83d\ude0a",
        "user.screen_name": "keithfraser2017"
    },
    {
        "created_at": "Mon Feb 12 00:45:02 +0000 2018",
        "id": 962849995991822336,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/lg2RZ9eUnd\u2026",
        "user.screen_name": "JoonErdogan"
    },
    {
        "created_at": "Mon Feb 12 00:44:52 +0000 2018",
        "id": 962849953759612929,
        "text": "RT @ItzWolfGives: First Retweet \nOrigin\n\nBei 6 likes geht\u2018s mit First Retweet\u2018s weiter",
        "user.screen_name": "Melonenkekse4"
    },
    {
        "created_at": "Mon Feb 12 00:44:34 +0000 2018",
        "id": 962849878153056256,
        "text": "RT @ItzWolfGives: First Retweet \nOrigin\n\nBei 6 likes geht\u2018s mit First Retweet\u2018s weiter",
        "user.screen_name": "die_guten_123"
    },
    {
        "created_at": "Mon Feb 12 00:44:32 +0000 2018",
        "id": 962849870607503365,
        "text": "RT @ItzWolfGives: First Retweet \nOrigin\n\nBei 6 likes geht\u2018s mit First Retweet\u2018s weiter",
        "user.screen_name": "zJxnCoresBW"
    },
    {
        "created_at": "Mon Feb 12 00:44:30 +0000 2018",
        "id": 962849859396165632,
        "text": "RT @ItzWolfGives: First Retweet \nOrigin\n\nBei 6 likes geht\u2018s mit First Retweet\u2018s weiter",
        "user.screen_name": "KiquJr"
    },
    {
        "created_at": "Mon Feb 12 00:44:27 +0000 2018",
        "id": 962849849707302913,
        "text": "RT @ItzWolfGives: First Retweet \nOrigin\n\nBei 6 likes geht\u2018s mit First Retweet\u2018s weiter",
        "user.screen_name": "_Mxmo"
    },
    {
        "created_at": "Mon Feb 12 00:44:22 +0000 2018",
        "id": 962849827112570881,
        "text": "First Retweet \nOrigin\n\nBei 6 likes geht\u2018s mit First Retweet\u2018s weiter",
        "user.screen_name": "ItzWolfGives"
    },
    {
        "created_at": "Mon Feb 12 00:44:22 +0000 2018",
        "id": 962849826449784832,
        "text": "@winsiah MIT Placement Day ROCKS\ud83e\udd2a\ud83e\udd2a\ud83e\udd2a",
        "user.screen_name": "wimitmom"
    },
    {
        "created_at": "Mon Feb 12 00:44:03 +0000 2018",
        "id": 962849748456787968,
        "text": "RT @mitsmr: RT @joannecanderson: How to achieve \"extreme #productivity\" from @mitsmr  : \"Hours are a traditional way of tracking employee p\u2026",
        "user.screen_name": "gogos"
    },
    {
        "created_at": "Mon Feb 12 00:43:32 +0000 2018",
        "id": 962849617992994816,
        "text": "ICE7 aka GES/MIT \nHistoric Facts \nhttps://t.co/EdIrrtvwx7\n\nICE4 complicated 1994 not going to explain context \nICE7\u2026 https://t.co/pBA6s6cxjB",
        "user.screen_name": "Phillip_Dabney"
    },
    {
        "created_at": "Mon Feb 12 00:43:13 +0000 2018",
        "id": 962849539861434368,
        "text": "Fortnite \u25ba Mit Gaming24, Jacky Rainbow I #RoadTo50Abbos I Livestream I German I CraftCent: https://t.co/P2bf44H8SF via @YouTube",
        "user.screen_name": "CraftCent_"
    },
    {
        "created_at": "Mon Feb 12 00:42:17 +0000 2018",
        "id": 962849304489742336,
        "text": "Love being a MIT for SAI \ud83c\udfbc\u2764\ufe0f",
        "user.screen_name": "AlmaBradley"
    },
    {
        "created_at": "Mon Feb 12 00:42:12 +0000 2018",
        "id": 962849282096328704,
        "text": "I like the fact that this new President of Harvard has spent a lot of time in the Boston area (Harvard, Tufts, MIT)\u2026 https://t.co/xUGWUVAucz",
        "user.screen_name": "tuke"
    },
    {
        "created_at": "Mon Feb 12 00:42:08 +0000 2018",
        "id": 962849264706650112,
        "text": "RT @skocharlakota: Happening now - @msisodia taking questions from MIT students. https://t.co/bArfCC0SFu",
        "user.screen_name": "Georgekurian4K"
    },
    {
        "created_at": "Mon Feb 12 00:42:05 +0000 2018",
        "id": 962849251624538112,
        "text": "RT @MITSloan: The idea of a universal basic income is not new, but the theory has never been thoroughly tested. A massive new study is abou\u2026",
        "user.screen_name": "MarlonCreative"
    },
    {
        "created_at": "Mon Feb 12 00:41:55 +0000 2018",
        "id": 962849212118560768,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "AnnMoyle"
    },
    {
        "created_at": "Mon Feb 12 00:41:05 +0000 2018",
        "id": 962849001656672256,
        "text": "Steep Discount Mart Coupon Code 10%!: Promotion at Steep Discount Mart: 10% OFF YOUR ENTIRE ORDER. Coupon Code 10%!\u2026 https://t.co/3rOWCx0yiM",
        "user.screen_name": "coupons_u_need"
    },
    {
        "created_at": "Mon Feb 12 00:41:04 +0000 2018",
        "id": 962848997558820865,
        "text": "Steep Discount Mart Discount Code 70%!: Promotion at Steep Discount Mart: 70% OFF Pendant Necklace Crystal Drop. Di\u2026 https://t.co/94gKIMs6ye",
        "user.screen_name": "coupons_u_need"
    },
    {
        "created_at": "Mon Feb 12 00:40:47 +0000 2018",
        "id": 962848927971266560,
        "text": "@bridgitmendler btw I\u2018m really interested in your current research at MIT media lab\ud83d\ude2d",
        "user.screen_name": "momomomoilok"
    },
    {
        "created_at": "Mon Feb 12 00:40:45 +0000 2018",
        "id": 962848916659109888,
        "text": "RT @MITdusp: We are proud and delighted  -- DUSP Emeritus Professor Larry Bacow  https://t.co/N7uThsFNfx is the next President of Harvard U\u2026",
        "user.screen_name": "joemcgonegal"
    },
    {
        "created_at": "Mon Feb 12 00:40:22 +0000 2018",
        "id": 962848819951099905,
        "text": "I am starting Artificial Intelligence course with MIT https://t.co/0PimX7wsvy #ai #ml #dl",
        "user.screen_name": "AINewsFeed"
    },
    {
        "created_at": "Mon Feb 12 00:39:46 +0000 2018",
        "id": 962848669006315520,
        "text": "Path Dependency is one of the hindrance for Digital Transformative Capabilities (DTC)\n#digitaltransformation #iiot  https://t.co/JPXxMU6BHR",
        "user.screen_name": "swapan_ghosh"
    },
    {
        "created_at": "Mon Feb 12 00:39:28 +0000 2018",
        "id": 962848593429311488,
        "text": "MIT Engineers Have Designed a Chip That Behaves Just Like Brain Cell Connections https://t.co/qQyoitLQ0E",
        "user.screen_name": "zananeichan"
    },
    {
        "created_at": "Mon Feb 12 00:37:51 +0000 2018",
        "id": 962848186401546246,
        "text": "Thomas just turned my oven mit into a puppet. I don\u2019t know whether to be concerned or more in love with this goof.",
        "user.screen_name": "Lucy_96115"
    },
    {
        "created_at": "Mon Feb 12 00:36:53 +0000 2018",
        "id": 962847942884327424,
        "text": "RT @hrnext: ....never knew DJT is nephew of a top tier MIT Physicist https://t.co/EGrtFelzIk",
        "user.screen_name": "Georgekurian4K"
    },
    {
        "created_at": "Mon Feb 12 00:36:33 +0000 2018",
        "id": 962847859287699456,
        "text": "It might be time to take up coding again: https://t.co/WcQDsvoXdd",
        "user.screen_name": "jcuene"
    },
    {
        "created_at": "Mon Feb 12 00:36:24 +0000 2018",
        "id": 962847824713887745,
        "text": "@himebadweather Yum! That would be really good right now. I saw some fresh trai mit when I was in qld. I guess it\u2019s\u2026 https://t.co/mTHJLUMcl4",
        "user.screen_name": "itsmelanie_t"
    },
    {
        "created_at": "Mon Feb 12 00:36:13 +0000 2018",
        "id": 962847778807451648,
        "text": "RT @hildabast: Day 2 #BlackHistoryMonth: Physicist, Carolyn Beatrice Parker - a remarkable woman, whose long-lost story shows how much work\u2026",
        "user.screen_name": "labour_zone"
    },
    {
        "created_at": "Mon Feb 12 00:36:13 +0000 2018",
        "id": 962847778773880832,
        "text": "RT @hildabast: Day 2 #BlackHistoryMonth: Physicist, Carolyn Beatrice Parker - a remarkable woman, whose long-lost story shows how much work\u2026",
        "user.screen_name": "Labour_North"
    },
    {
        "created_at": "Mon Feb 12 00:36:13 +0000 2018",
        "id": 962847777326804992,
        "text": "RT @hildabast: Day 2 #BlackHistoryMonth: Physicist, Carolyn Beatrice Parker - a remarkable woman, whose long-lost story shows how much work\u2026",
        "user.screen_name": "ChiOnwurah"
    },
    {
        "created_at": "Mon Feb 12 00:35:51 +0000 2018",
        "id": 962847682917171200,
        "text": "RT @gfernandoamb: On October 12, 2017, the MIT Inclusive Innovation Challenge awarded over $1 million in prizes to global entrepreneurs usi\u2026",
        "user.screen_name": "erikbryn"
    },
    {
        "created_at": "Mon Feb 12 00:35:31 +0000 2018",
        "id": 962847601799417860,
        "text": "Bachata Sensual Advanced Workshop mit Ruben aus\u00a0Cadiz https://t.co/yn6cPF999S",
        "user.screen_name": "salsastisch_de"
    },
    {
        "created_at": "Mon Feb 12 00:35:28 +0000 2018",
        "id": 962847586708262916,
        "text": "Kizomba Hearts Night mit Kiz Classes Improver und\u00a0Advanced https://t.co/siZfzd2Nz8",
        "user.screen_name": "salsastisch_de"
    },
    {
        "created_at": "Mon Feb 12 00:35:24 +0000 2018",
        "id": 962847571453599750,
        "text": "RT @MITSloan: Integrating analytics is crucial. Start with these 8 articles. https://t.co/3hxWVgHY9q",
        "user.screen_name": "pirtlj"
    },
    {
        "created_at": "Mon Feb 12 00:35:07 +0000 2018",
        "id": 962847498942468096,
        "text": "MIT&amp;F: Relay Team Sets Record At UW-Platteville Invitational https://t.co/jjwnWVuHF8 #d3track",
        "user.screen_name": "WLCSports"
    },
    {
        "created_at": "Mon Feb 12 00:35:00 +0000 2018",
        "id": 962847472656592897,
        "text": "RT @StanM3: Germany- Afghan(19) stabbed his ex-girlfriend(23) in the shoulder and fled. The police had been called because of domestic viol\u2026",
        "user.screen_name": "erotao"
    },
    {
        "created_at": "Mon Feb 12 00:34:49 +0000 2018",
        "id": 962847424581644288,
        "text": "Ich mag das @YouTube-Video: https://t.co/LBOsMTaOxb West-Ost Roadtrip! mit Maik - THE CREW Part 37 | Lets Play The Crew",
        "user.screen_name": "Killerdaby"
    },
    {
        "created_at": "Mon Feb 12 00:34:42 +0000 2018",
        "id": 962847396689596417,
        "text": "MY MIT YOOO",
        "user.screen_name": "essaxpizza"
    },
    {
        "created_at": "Mon Feb 12 00:34:34 +0000 2018",
        "id": 962847363135045632,
        "text": "RT @lenadroid: It is so sunny in Seattle this morning (I know, weird), but no reason to go outside when I have entire MIT Introduction to D\u2026",
        "user.screen_name": "pdausman"
    },
    {
        "created_at": "Mon Feb 12 00:34:17 +0000 2018",
        "id": 962847288933707781,
        "text": "Late Night Stream | KYOAN | Mit Pipo und Andi: https://t.co/nnH6IUhI8b via @YouTube",
        "user.screen_name": "KyoanYT"
    },
    {
        "created_at": "Mon Feb 12 00:34:13 +0000 2018",
        "id": 962847272001093632,
        "text": "RT @ClintFalin: Day 5: They\u2019ve broken past the barrier. I\u2019m out of food and water. If you\u2019re reading this, I https://t.co/YXk5OTvOia",
        "user.screen_name": "Mit_ch_ell"
    },
    {
        "created_at": "Mon Feb 12 00:34:03 +0000 2018",
        "id": 962847232079745024,
        "text": "@itsmelanie_t yeah it is too hard T_T sigh this is making me miss vietnam, trai mit with muoi tieu chanh T______T",
        "user.screen_name": "himebadweather"
    },
    {
        "created_at": "Mon Feb 12 00:33:56 +0000 2018",
        "id": 962847202686025728,
        "text": "MIT report warns U.S. electrical grid vulnerable | Homeland Security News Wire https://t.co/km6jmHKWP5",
        "user.screen_name": "WaterWavy"
    },
    {
        "created_at": "Mon Feb 12 00:33:52 +0000 2018",
        "id": 962847187322499072,
        "text": "RT @TamaraMcCleary: Mastering the Digital #Innovation Challenge https://t.co/4jbLqULxfg #leadership #digitaltransformation MT @jglass8 via\u2026",
        "user.screen_name": "dleetweet"
    },
    {
        "created_at": "Mon Feb 12 00:32:58 +0000 2018",
        "id": 962846960704204800,
        "text": "#MIT 15.361 Executing Strategy for Results (MIT) - This course provides business students an alternative to the mec\u2026 https://t.co/YdCsPxMUZl",
        "user.screen_name": "MOOCdirectory"
    },
    {
        "created_at": "Mon Feb 12 00:32:52 +0000 2018",
        "id": 962846933890068480,
        "text": "We\u2019d like to give a very warm welcome to our two MIT\u2019s who pledged this evening! Congratulations ladies! \u2764\ufe0f\ud83c\udf39 https://t.co/bvkJbT1coC",
        "user.screen_name": "saimudelta"
    },
    {
        "created_at": "Mon Feb 12 00:32:31 +0000 2018",
        "id": 962846845255987202,
        "text": "RT @JensRoehrich: Interesting article: The Unique Challenges of Cross-Boundary #Collaboration https://t.co/EXelhBmrId You may also find my\u2026",
        "user.screen_name": "clindsaystrath"
    },
    {
        "created_at": "Mon Feb 12 00:32:22 +0000 2018",
        "id": 962846809587666949,
        "text": "Future cities built with volcanic ash? - Image via MIT. By Jennifer Chu/MIT MIT engineers working with scientists i\u2026 https://t.co/TBYqDTFm2a",
        "user.screen_name": "Jeff_Rebitzke"
    },
    {
        "created_at": "Mon Feb 12 00:32:07 +0000 2018",
        "id": 962846743997100032,
        "text": "RT @LemelsonMIT: David Sengeh\u2019s interest in designing prostheses stems from his childhood. He grew up in Sierra Leone during the civil war,\u2026",
        "user.screen_name": "tonyperry"
    },
    {
        "created_at": "Mon Feb 12 00:32:01 +0000 2018",
        "id": 962846720160948225,
        "text": ".@MIT research sprouts two startups competing on new AI-focused chips https://t.co/mA2iWvGIuC",
        "user.screen_name": "BosBizJournal"
    },
    {
        "created_at": "Mon Feb 12 00:31:33 +0000 2018",
        "id": 962846603915689984,
        "text": "Live Fortnite mit Facecam live at https://t.co/XKurIvFHev",
        "user.screen_name": "OnFireBoss"
    },
    {
        "created_at": "Mon Feb 12 00:31:28 +0000 2018",
        "id": 962846583250329601,
        "text": "RT @HarvardDivinity: \u201cSince meeting and befriending Larry Bacow over 25 years ago at MIT, I have had the privilege of working with one of t\u2026",
        "user.screen_name": "MAKEinANDHRA"
    },
    {
        "created_at": "Mon Feb 12 00:31:28 +0000 2018",
        "id": 962846580985430016,
        "text": "RT @hildabast: Day 2 #BlackHistoryMonth: Physicist, Carolyn Beatrice Parker - a remarkable woman, whose long-lost story shows how much work\u2026",
        "user.screen_name": "stevendengue"
    },
    {
        "created_at": "Mon Feb 12 00:31:25 +0000 2018",
        "id": 962846567244984320,
        "text": "RT @EdTech_HigherEd: .@MIT research finds #Wikipedia to be a useful research tool. https://t.co/s8tNYSJlRG",
        "user.screen_name": "mmkrill"
    },
    {
        "created_at": "Mon Feb 12 00:31:15 +0000 2018",
        "id": 962846526367256576,
        "text": "RT @newsyc20: Solid aims to radically change the way web applications work https://t.co/pJ2G4pQ57y (https://t.co/1tZgYZ1TbR)",
        "user.screen_name": "SelenasWays"
    },
    {
        "created_at": "Mon Feb 12 00:30:59 +0000 2018",
        "id": 962846461296828418,
        "text": ".@MIT research finds #Wikipedia to be a useful research tool. https://t.co/s8tNYSJlRG",
        "user.screen_name": "EdTech_HigherEd"
    },
    {
        "created_at": "Mon Feb 12 00:30:49 +0000 2018",
        "id": 962846416828805120,
        "text": "Facial recognition software is biased towards white men, researcher finds. https://t.co/KDJ02Kx9RT",
        "user.screen_name": "PoliGramR"
    },
    {
        "created_at": "Mon Feb 12 00:30:26 +0000 2018",
        "id": 962846323325243394,
        "text": "Facial Recognition Software Is Biased Towards White Men, Researcher Finds https://t.co/EvcxrRbCOL https://t.co/7nSIOaSZji",
        "user.screen_name": "TechShape"
    },
    {
        "created_at": "Mon Feb 12 00:30:07 +0000 2018",
        "id": 962846242287095808,
        "text": "MIT IQ Initiative Is Taking A Different Approach To AI Research\u00a0 | Deep_In_Depth: Deep Learning, ML &amp; DS https://t.co/raDuSaZWX3",
        "user.screen_name": "Deep_In_Depth"
    },
    {
        "created_at": "Mon Feb 12 00:29:59 +0000 2018",
        "id": 962846207830786048,
        "text": "Solid aims to radically change the way web applications work https://t.co/pJ2G4pQ57y (https://t.co/1tZgYZ1TbR)",
        "user.screen_name": "newsyc20"
    },
    {
        "created_at": "Mon Feb 12 00:29:45 +0000 2018",
        "id": 962846151224512512,
        "text": "\u270c @Reading \"Podcast, Nick Seaver: \u201cWhat Do People Do All Day?\u201d\" https://t.co/ZeuHBeYJEg",
        "user.screen_name": "rogreisreading"
    },
    {
        "created_at": "Mon Feb 12 00:29:41 +0000 2018",
        "id": 962846131330875393,
        "text": "RT @leathershirts: i hope vine 2 is better than cars 2",
        "user.screen_name": "Zoey_mit"
    },
    {
        "created_at": "Mon Feb 12 00:29:18 +0000 2018",
        "id": 962846038141804544,
        "text": "Deer Island Waste Water Treatment Plant : MIT Libraries https://t.co/0BewMlq8N1",
        "user.screen_name": "Energy_Needs"
    },
    {
        "created_at": "Mon Feb 12 00:29:09 +0000 2018",
        "id": 962845997239095298,
        "text": "RT @MPBorman: Using #Analytics to Improve #CustomerEngagement https://t.co/QudJPaK8eD @mitsmr @SASsoftware #corpgov #CEO #CFO #CIO #CMO #Bo\u2026",
        "user.screen_name": "gogos"
    },
    {
        "created_at": "Mon Feb 12 00:29:01 +0000 2018",
        "id": 962845965156868097,
        "text": "RT @JensRoehrich: Interesting article: The Unique Challenges of Cross-Boundary #Collaboration https://t.co/EXelhBmrId You may also find my\u2026",
        "user.screen_name": "JensRoehrich"
    },
    {
        "created_at": "Mon Feb 12 00:28:37 +0000 2018",
        "id": 962845866183876610,
        "text": "RT @mitsmr: Be a futurist. Check out this cool six-step forecasting methodology created by @amywebb.  https://t.co/dGU8wKsCaH https://t.co/\u2026",
        "user.screen_name": "NewsNeus"
    },
    {
        "created_at": "Mon Feb 12 00:28:19 +0000 2018",
        "id": 962845789373448193,
        "text": "Solid aims to radically change the way web applications work (31 points on Hacker News): https://t.co/mAi3KjgLmO",
        "user.screen_name": "topnotifier"
    },
    {
        "created_at": "Mon Feb 12 00:27:59 +0000 2018",
        "id": 962845706364030976,
        "text": "RT @MITSloan: New ideas aren\u2019t in short supply, but they have gotten more expensive. More in @mitsmr. https://t.co/IqpxBs8uhs",
        "user.screen_name": "gogos"
    },
    {
        "created_at": "Mon Feb 12 00:26:33 +0000 2018",
        "id": 962845343921725440,
        "text": "RT @hildabast: Day 2 #BlackHistoryMonth: Physicist, Carolyn Beatrice Parker - a remarkable woman, whose long-lost story shows how much work\u2026",
        "user.screen_name": "tkingdot"
    },
    {
        "created_at": "Mon Feb 12 00:25:57 +0000 2018",
        "id": 962845193077604352,
        "text": "RT @FunctorFact: Functional differential geometry https://t.co/Xq4vPRD2AB",
        "user.screen_name": "reeds_michael"
    },
    {
        "created_at": "Mon Feb 12 00:25:45 +0000 2018",
        "id": 962845142515404800,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "mmc955"
    },
    {
        "created_at": "Mon Feb 12 00:25:09 +0000 2018",
        "id": 962844993735020546,
        "text": "RT @scratch: Scratch Day is a global network of events that celebrates Scratch. This year's Scratch Day is on May 12, 2018. Visit https://t\u2026",
        "user.screen_name": "gigabytemag"
    },
    {
        "created_at": "Mon Feb 12 00:25:00 +0000 2018",
        "id": 962844952303689729,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "gigabytemag"
    },
    {
        "created_at": "Mon Feb 12 00:24:56 +0000 2018",
        "id": 962844938865205250,
        "text": "RT @mitmeche: The latest issue of MechE Connects is now online! Hear from our faculty members, students, and alumni about how they are appl\u2026",
        "user.screen_name": "gigabytemag"
    },
    {
        "created_at": "Mon Feb 12 00:24:52 +0000 2018",
        "id": 962844920791883776,
        "text": "RT @MIT: MIT engineers make microfluidics modular using the popular interlocking blocks. https://t.co/DDcxeTCVvC https://t.co/8vH5DxYZow",
        "user.screen_name": "gigabytemag"
    },
    {
        "created_at": "Mon Feb 12 00:24:49 +0000 2018",
        "id": 962844907080740864,
        "text": "One of the first things I would like to see Dr. Polio do is institute a challenge much like Boston Public Schools d\u2026 https://t.co/1NiHLloPyI",
        "user.screen_name": "kycoffeeguy"
    },
    {
        "created_at": "Mon Feb 12 00:24:46 +0000 2018",
        "id": 962844893688279040,
        "text": "RT @mitenergy: MIT's Translational Fellows Program, founded by @RLEatMIT Director Yoel Fink, helps #postdocs bring their innovations out of\u2026",
        "user.screen_name": "gigabytemag"
    },
    {
        "created_at": "Mon Feb 12 00:24:43 +0000 2018",
        "id": 962844884154675200,
        "text": "RT @WE_BAP_US: Dr. #ShirleyJackson the first African-American woman to have earned a doctorate at the MIT.\n\n#BlackAndProud #BlackWomen #Bla\u2026",
        "user.screen_name": "DavisKimbrely"
    },
    {
        "created_at": "Mon Feb 12 00:24:40 +0000 2018",
        "id": 962844868371472384,
        "text": "RT @MIT: Be sure to root for MIT alumni competing in the 2018 Winter Olympics! \ud83e\udd47\ud83e\udd48\ud83e\udd49  The opening ceremony is tonight at 8 ET https://t.co/9l\u2026",
        "user.screen_name": "gigabytemag"
    },
    {
        "created_at": "Mon Feb 12 00:24:39 +0000 2018",
        "id": 962844863967518721,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "scratch"
    },
    {
        "created_at": "Mon Feb 12 00:24:23 +0000 2018",
        "id": 962844800230809600,
        "text": "\"Find Your Own Way...\" #LeonardNimoy\n\nvia @10MillionMiler #quote #leadership #entrepreneur #startups RT @MIT\u2026 https://t.co/9JyLDLAIwu",
        "user.screen_name": "elaine_perry"
    },
    {
        "created_at": "Mon Feb 12 00:24:22 +0000 2018",
        "id": 962844794631348224,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/lg2RZ9eUnd\u2026",
        "user.screen_name": "RobynPope83"
    },
    {
        "created_at": "Mon Feb 12 00:24:16 +0000 2018",
        "id": 962844769079541760,
        "text": "RT @mitsmr: Keep this chart handy when you're Identifying potential #leaders in your company.  https://t.co/WHj7CM39AJ #management https://\u2026",
        "user.screen_name": "meadowsalestech"
    },
    {
        "created_at": "Mon Feb 12 00:24:11 +0000 2018",
        "id": 962844748716355584,
        "text": "@DieElbmerle go pls und bring hustenstiller mit ^^",
        "user.screen_name": "Drachenkatze"
    },
    {
        "created_at": "Mon Feb 12 00:24:07 +0000 2018",
        "id": 962844732748648449,
        "text": "In 1945, Vannevar Bush described the semantic web in his article \"As We May Think\". Thanks @MIT for publishing a pd\u2026 https://t.co/hoSrU4S3rb",
        "user.screen_name": "UXDiane"
    },
    {
        "created_at": "Mon Feb 12 00:23:27 +0000 2018",
        "id": 962844564896624645,
        "text": "RT @skocharlakota: Happening now - @msisodia taking questions from MIT students. https://t.co/bArfCC0SFu",
        "user.screen_name": "AAP4ODISHA"
    },
    {
        "created_at": "Mon Feb 12 00:23:03 +0000 2018",
        "id": 962844464703332358,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee https://t.co/ZIOC87yb1Z (https://t.co/LOoxwQ6lBP)",
        "user.screen_name": "hn_bot_top1"
    },
    {
        "created_at": "Mon Feb 12 00:22:51 +0000 2018",
        "id": 962844412194836482,
        "text": "Bald ABO ZOCKEN ! Fortnite Live mit Facecam!: https://t.co/b40edjdkhA via @YouTube",
        "user.screen_name": "RobsTV_"
    },
    {
        "created_at": "Mon Feb 12 00:22:42 +0000 2018",
        "id": 962844373384916992,
        "text": "Ex-Alphabet Chairman Joins MIT As Visiting Innovation Fellow - Former Executive Chairman of G https://t.co/buZIOTB8nq #machine-learning",
        "user.screen_name": "homeAIinfo"
    },
    {
        "created_at": "Mon Feb 12 00:22:29 +0000 2018",
        "id": 962844318774960128,
        "text": "RT @mitsmr: 3 new types of AI-driven  jobs \n1. Trainers teach AI systems how to perform\n2. Explainers clarify the inner workings of complex\u2026",
        "user.screen_name": "8sanjay"
    },
    {
        "created_at": "Mon Feb 12 00:22:08 +0000 2018",
        "id": 962844233190334464,
        "text": "JUNGE WAS SOLL ICH MIT DENEN FUCK 3RD ANNIVERSAFY https://t.co/pNDSOFGZXq",
        "user.screen_name": "AntiLPaz"
    },
    {
        "created_at": "Mon Feb 12 00:21:46 +0000 2018",
        "id": 962844139166420992,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee https://t.co/MQNSxpDl0m",
        "user.screen_name": "angsuman"
    },
    {
        "created_at": "Mon Feb 12 00:21:44 +0000 2018",
        "id": 962844131876917248,
        "text": "RT @lotzrickards: felicity: felicity smoak, MIT class of 09\noliver: https://t.co/DRpcvdeCK4",
        "user.screen_name": "killyamax"
    },
    {
        "created_at": "Mon Feb 12 00:21:14 +0000 2018",
        "id": 962844004227444736,
        "text": "@dialogic01 bring die uke mit",
        "user.screen_name": "TheGurkenkaiser"
    },
    {
        "created_at": "Mon Feb 12 00:20:55 +0000 2018",
        "id": 962843925483409413,
        "text": "RT @FraHofm: \"MIT biological engineers have created a programming language that allows them to rapidly design complex, DNA-encoded circuits\u2026",
        "user.screen_name": "FlyingTigerComx"
    },
    {
        "created_at": "Mon Feb 12 00:20:06 +0000 2018",
        "id": 962843721007030272,
        "text": "HNews: Solid is an exciting new project led by Prof. Tim Berners-Lee https://t.co/NBuMhRNWws",
        "user.screen_name": "tek_news"
    },
    {
        "created_at": "Mon Feb 12 00:20:02 +0000 2018",
        "id": 962843702803795968,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee: https://t.co/3Ta8UKQhzx Comments: https://t.co/j4YWR4hrHf",
        "user.screen_name": "HNTweets"
    },
    {
        "created_at": "Mon Feb 12 00:19:43 +0000 2018",
        "id": 962843624533831680,
        "text": "I liked a @YouTube video https://t.co/NF786iY9Wy KS Mafia - La fiesta (Ich fick dich mit dem Satansschuh)",
        "user.screen_name": "lilskyxo"
    },
    {
        "created_at": "Mon Feb 12 00:19:31 +0000 2018",
        "id": 962843572360839171,
        "text": "@ladygagarmx wird recreated mit debby",
        "user.screen_name": "dasgrizzlylied"
    },
    {
        "created_at": "Mon Feb 12 00:18:56 +0000 2018",
        "id": 962843427481141253,
        "text": "Facial recognition software is biased towards white men, researcher finds https://t.co/XKQuIhltyB via @Verge",
        "user.screen_name": "LaurenGoode"
    },
    {
        "created_at": "Mon Feb 12 00:18:49 +0000 2018",
        "id": 962843399857504256,
        "text": "RT @cashjim: Which function is better at generating primes: f(n) = 1 + 6n  or  f(m) = 5 + 6m? @MatthewOldridge @dtangred @lisaannefloyd @mr\u2026",
        "user.screen_name": "lisaannefloyd"
    },
    {
        "created_at": "Mon Feb 12 00:18:34 +0000 2018",
        "id": 962843335240093696,
        "text": "RT @mitsmr: People who are \u201cdifferent\u201d \u2014whether behaviorally or neurologically\u2014 don\u2019t always fit into standard job categories. But if you c\u2026",
        "user.screen_name": "ritamakai"
    },
    {
        "created_at": "Mon Feb 12 00:18:29 +0000 2018",
        "id": 962843314948108289,
        "text": "RT @cashjim: Which function is better at generating primes: f(n) = 1 + 6n  or  f(m) = 5 + 6m? @MatthewOldridge @dtangred @lisaannefloyd @mr\u2026",
        "user.screen_name": "dtangred"
    },
    {
        "created_at": "Mon Feb 12 00:18:22 +0000 2018",
        "id": 962843284392509440,
        "text": "felicity: felicity smoak, MIT class of 09\noliver: https://t.co/DRpcvdeCK4",
        "user.screen_name": "lotzrickards"
    },
    {
        "created_at": "Mon Feb 12 00:18:20 +0000 2018",
        "id": 962843277765603328,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee https://t.co/1jQSpNoyqu",
        "user.screen_name": "neuropuff"
    },
    {
        "created_at": "Mon Feb 12 00:18:17 +0000 2018",
        "id": 962843263362244608,
        "text": "RT @catherinealonz0: Navigating how to manage your virtual team? These practices can help your #organization succeed at its remote policy:\u2026",
        "user.screen_name": "ChiefData2"
    },
    {
        "created_at": "Mon Feb 12 00:18:04 +0000 2018",
        "id": 962843207217262593,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/lg2RZ9eUnd\u2026",
        "user.screen_name": "michavinogrado1"
    },
    {
        "created_at": "Mon Feb 12 00:17:38 +0000 2018",
        "id": 962843101919432704,
        "text": "RT @MITengineers: MIT men's volleyball improved to 8-1 this season with a thrilling five set win over St. John Fisher this afternoon!  http\u2026",
        "user.screen_name": "NoontimeSports"
    },
    {
        "created_at": "Mon Feb 12 00:17:11 +0000 2018",
        "id": 962842987150548993,
        "text": "SUPERDRY Angebote Superdry Warriors Biker T-Shirt: Category: Herren / T-Shirts / T-Shirt mit Print Item number: 104\u2026 https://t.co/MxYmrna5sW",
        "user.screen_name": "SparVolltreffer"
    },
    {
        "created_at": "Mon Feb 12 00:16:58 +0000 2018",
        "id": 962842933966843904,
        "text": "ameteur sex pics ask sexi kostenlos sex mit tire https://t.co/jmjRGseXmO",
        "user.screen_name": "hmoddi1_hmoddi"
    },
    {
        "created_at": "Mon Feb 12 00:16:14 +0000 2018",
        "id": 962842747798523904,
        "text": "RT @mitsmr: When it comes to digital transformation, #digital isn't the answer. Transformation is. https://t.co/wKK3hp1lgZ @gwesterman @mit\u2026",
        "user.screen_name": "Carlos079"
    },
    {
        "created_at": "Mon Feb 12 00:15:42 +0000 2018",
        "id": 962842614625169409,
        "text": "RT @YouBrandInc: Facial recognition software is biased towards white men, researcher finds - New research out of MIT\u2019s Media Lab... https:/\u2026",
        "user.screen_name": "Luiscoutio06"
    },
    {
        "created_at": "Mon Feb 12 00:15:06 +0000 2018",
        "id": 962842461147049984,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee \n(Discussion on HN - https://t.co/k4FjTUNhNJ) https://t.co/55gQOKiwYh",
        "user.screen_name": "hnbot"
    },
    {
        "created_at": "Mon Feb 12 00:15:01 +0000 2018",
        "id": 962842442851602432,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee : https://t.co/vKgJ70lseW Comments: https://t.co/EbejLVSo75",
        "user.screen_name": "hacker_news_hir"
    },
    {
        "created_at": "Mon Feb 12 00:14:22 +0000 2018",
        "id": 962842278015287297,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/fQ1IKfcpVW\u2026",
        "user.screen_name": "RobynPope83"
    },
    {
        "created_at": "Mon Feb 12 00:14:01 +0000 2018",
        "id": 962842190652129280,
        "text": "Cmon @ferrarifoster don't be the next Aldon Smith for us \ud83e\udd26\u200d\u2642\ufe0f",
        "user.screen_name": "Mit_ch_ell"
    },
    {
        "created_at": "Mon Feb 12 00:13:32 +0000 2018",
        "id": 962842069172719616,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee https://t.co/TIWM40kZDQ (cmts https://t.co/ZRQBtKXyE4)",
        "user.screen_name": "newsycbot"
    },
    {
        "created_at": "Mon Feb 12 00:13:23 +0000 2018",
        "id": 962842032359333888,
        "text": "RT @SteveCase: Is tech dividing America? https://t.co/sMTVRWErsX \u201cThere are 2 schools of thought:  One is \u2018sky is falling &amp; robots are comi\u2026",
        "user.screen_name": "AshekulHuq"
    },
    {
        "created_at": "Mon Feb 12 00:13:06 +0000 2018",
        "id": 962841957306421248,
        "text": "RT @gbaucom: Meet the biologist who got MIT to examine its treatment of women researchers - via @techreview https://t.co/c6JqibvhkQ //I rec\u2026",
        "user.screen_name": "RixeyMegan"
    },
    {
        "created_at": "Mon Feb 12 00:12:58 +0000 2018",
        "id": 962841925639225344,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/fQ1IKfcpVW\u2026",
        "user.screen_name": "ParisMahavira"
    },
    {
        "created_at": "Mon Feb 12 00:12:04 +0000 2018",
        "id": 962841699159457792,
        "text": "RT @neha: First cryptocurrency class with @tdryja! https://t.co/6ERcuhvGBZ #MITDCI https://t.co/5EG8yvjlyZ",
        "user.screen_name": "patmillertime"
    },
    {
        "created_at": "Mon Feb 12 00:11:25 +0000 2018",
        "id": 962841536542265344,
        "text": "SPIELEN  #Casino - 300% up to euro1200 on first 3 deposits mit #Timesquare - https://t.co/7LPT6ZLm1h https://t.co/G9NOTv3v9G",
        "user.screen_name": "bestbetforyou"
    },
    {
        "created_at": "Mon Feb 12 00:11:24 +0000 2018",
        "id": 962841532180107265,
        "text": "SPIELEN  #Casino - 300% up to euro1200 on first 3 deposits mit #Timesquare - https://t.co/kxRpC4IB5R https://t.co/lbwI4Ksg9K",
        "user.screen_name": "atticagambling"
    },
    {
        "created_at": "Mon Feb 12 00:10:52 +0000 2018",
        "id": 962841395802370049,
        "text": "What to watch besides the athletes at Winter Olympics https://t.co/balAivNHQ3 via @mitsloan",
        "user.screen_name": "BarbaraCoward"
    },
    {
        "created_at": "Mon Feb 12 00:10:33 +0000 2018",
        "id": 962841316618104832,
        "text": "RT @HamillHimself: Today is the perfect day for letting @MarilouHamill know how grateful I am for having her in my life. She makes the ordi\u2026",
        "user.screen_name": "mit_chell03"
    },
    {
        "created_at": "Mon Feb 12 00:10:31 +0000 2018",
        "id": 962841309420638208,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee  https://t.co/9XHMMmnSJz",
        "user.screen_name": "zonadigitalPT"
    },
    {
        "created_at": "Mon Feb 12 00:10:23 +0000 2018",
        "id": 962841276851937280,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee https://t.co/IdkmFmmpcb (cmts https://t.co/AchdqjIseZ)",
        "user.screen_name": "FrontPageHN"
    },
    {
        "created_at": "Mon Feb 12 00:10:02 +0000 2018",
        "id": 962841185948614656,
        "text": "\u23ec watch \u23ec\n\nhttps://t.co/WJfPsX8pLd\n\nfacesitting porn whipping femdom mistress slave bdsm domina xxx sex nsfw",
        "user.screen_name": "shim1985sheila"
    },
    {
        "created_at": "Mon Feb 12 00:09:56 +0000 2018",
        "id": 962841160724176896,
        "text": "RT @HarvardDivinity: \u201cSince meeting and befriending Larry Bacow over 25 years ago at MIT, I have had the privilege of working with one of t\u2026",
        "user.screen_name": "hr072"
    },
    {
        "created_at": "Mon Feb 12 00:09:25 +0000 2018",
        "id": 962841033041051648,
        "text": "RT @MITSloan: The idea of a universal basic income is not new, but the theory has never been thoroughly tested. A massive new study is abou\u2026",
        "user.screen_name": "thedroneboy"
    },
    {
        "created_at": "Mon Feb 12 00:09:24 +0000 2018",
        "id": 962841027466924038,
        "text": "SPIELEN  #Casino - UP to GBP200 bonus  18+,Ts&amp;Cs apply mit #Karamba - https://t.co/7SE0mNsTdz https://t.co/jz3QM9wCEn",
        "user.screen_name": "bestbetforyou"
    },
    {
        "created_at": "Mon Feb 12 00:09:23 +0000 2018",
        "id": 962841022979100673,
        "text": "SPIELEN  #Casino - UP to GBP200 bonus  18+,Ts&amp;Cs apply mit #Karamba - https://t.co/TGFW5TK5TQ https://t.co/E7TNcRe6De",
        "user.screen_name": "atticagambling"
    },
    {
        "created_at": "Mon Feb 12 00:09:02 +0000 2018",
        "id": 962840937473892352,
        "text": "RT @mitsmr: Keep this chart handy when you're Identifying potential #leaders in your company.  https://t.co/WHj7CM39AJ #management https://\u2026",
        "user.screen_name": "nancyrubin"
    },
    {
        "created_at": "Mon Feb 12 00:09:01 +0000 2018",
        "id": 962840932432449538,
        "text": "Solid is an exciting new project led by Prof. Tim Berners-Lee\nL: https://t.co/aZqVHJ2niu\nC: https://t.co/12fvh74TV1",
        "user.screen_name": "hn_frontpage"
    },
    {
        "created_at": "Mon Feb 12 00:09:00 +0000 2018",
        "id": 962840927625605120,
        "text": "RT @joshgerstein: New Harvard president &amp; MIT frat brother on policy punishing membership in single-sex organizations: 'It's the right one\u2026",
        "user.screen_name": "EggRetweet"
    },
    {
        "created_at": "Mon Feb 12 00:08:43 +0000 2018",
        "id": 962840854338486272,
        "text": "RT @MITSloan: Still don't understand blockchain? You're not alone. https://t.co/fInM4OoA2E",
        "user.screen_name": "farrasharahap"
    },
    {
        "created_at": "Mon Feb 12 00:08:27 +0000 2018",
        "id": 962840787435343872,
        "text": "RT @mathematicsprof: I hope every math student knows about MIT's Mathlets that gives animations of many math concepts.  https://t.co/3Jtc1b\u2026",
        "user.screen_name": "amaatouq"
    },
    {
        "created_at": "Mon Feb 12 00:08:15 +0000 2018",
        "id": 962840736868728833,
        "text": "#Doppel penetration #mit #Andy Anderson #jvswzizy https://t.co/Ea2o7zMdqL",
        "user.screen_name": "rDdECJ5u6BAogvs"
    },
    {
        "created_at": "Mon Feb 12 00:08:05 +0000 2018",
        "id": 962840696175542273,
        "text": "Sparkles Make It Special Coupon Code 10 USD!: Promotion at Sparkles Make It Special: 10 USD off 50 USD with code. C\u2026 https://t.co/uaDVNGW47y",
        "user.screen_name": "coupons_u_need"
    },
    {
        "created_at": "Mon Feb 12 00:08:04 +0000 2018",
        "id": 962840694644621314,
        "text": "Sparkles Make It Special Discount Code 5 USD!: Promotion at Sparkles Make It Special: 5 USD off 25 USD on all Organ\u2026 https://t.co/XR8iPTgNGK",
        "user.screen_name": "coupons_u_need"
    },
    {
        "created_at": "Mon Feb 12 00:07:26 +0000 2018",
        "id": 962840532178427905,
        "text": "RT @SJPSwimCoach: A man of few words: Senior Max Scalley tells us the best part about diving at the 2018 MIAA North Sectionals at MIT.  Go\u2026",
        "user.screen_name": "leavitt_dylan5"
    },
    {
        "created_at": "Mon Feb 12 00:07:22 +0000 2018",
        "id": 962840518211309568,
        "text": "SPIELEN  #Casino - Up to GBP1000 Welcome bonus  18+,Ts&amp;Cs apply mit #Affpower - https://t.co/AkIJ6dBq69 https://t.co/Wf3d18VQlV",
        "user.screen_name": "bestbetforyou"
    },
    {
        "created_at": "Mon Feb 12 00:07:21 +0000 2018",
        "id": 962840514025357312,
        "text": "RT @TurkHeritage: On International #WomenInScience Day, listen to Turkish MIT @medialab faculty member Dr. Canan Dagdeviren talk at the UN\u2026",
        "user.screen_name": "TrendNe_"
    },
    {
        "created_at": "Mon Feb 12 00:07:21 +0000 2018",
        "id": 962840513941524482,
        "text": "SPIELEN  #Casino - Up to GBP1000 Welcome bonus  18+,Ts&amp;Cs apply mit #Affpower - https://t.co/nY4UwB6IAC https://t.co/5T6r4TjWfS",
        "user.screen_name": "atticagambling"
    },
    {
        "created_at": "Mon Feb 12 00:07:20 +0000 2018",
        "id": 962840507146756097,
        "text": "#Neu\n\nHeavy Metal TV 2018 M\u00e4rz\n\nmit:\nBilly Idol\n\nDazed and Confused\n\nWoodstock 15.08.1969\n\nEasy Rider Movie\n\nIan... https://t.co/YmWDfXYAZJ",
        "user.screen_name": "HansHeavyMetal"
    },
    {
        "created_at": "Mon Feb 12 00:07:01 +0000 2018",
        "id": 962840426603597825,
        "text": "RT @girlposts: Someone brought their bear to the mall. https://t.co/JMIyG51auS",
        "user.screen_name": "Mit_540"
    },
    {
        "created_at": "Mon Feb 12 00:06:25 +0000 2018",
        "id": 962840275772149760,
        "text": "RT @ansontm: 2. Dopest family in America https://t.co/t6tRR9qGCF",
        "user.screen_name": "Mit_540"
    },
    {
        "created_at": "Mon Feb 12 00:05:21 +0000 2018",
        "id": 962840009475788801,
        "text": "SPIELEN  #Casino - Get up to GBP2000 Welcome bonus  18+,Ts&amp;Cs apply mit #Affpower - https://t.co/BCTDq1ieuw https://t.co/qYo9GMD5jp",
        "user.screen_name": "bestbetforyou"
    },
    {
        "created_at": "Mon Feb 12 00:05:20 +0000 2018",
        "id": 962840003343765504,
        "text": "SPIELEN  #Casino - Get up to GBP2000 Welcome bonus  18+,Ts&amp;Cs apply mit #Affpower - https://t.co/n6JE8kkvuv https://t.co/b3AXNk0lKC",
        "user.screen_name": "atticagambling"
    },
    {
        "created_at": "Mon Feb 12 00:05:05 +0000 2018",
        "id": 962839943633625088,
        "text": "Keep this chart handy when you're Identifying potential #leaders in your company.  https://t.co/WHj7CM39AJ\u2026 https://t.co/XXUDkPJjqk",
        "user.screen_name": "mitsmr"
    },
    {
        "created_at": "Mon Feb 12 00:04:44 +0000 2018",
        "id": 962839853762260992,
        "text": "RT @FlLMGRAIN: when crew love starts https://t.co/oqahYlnjwC",
        "user.screen_name": "Mit_540"
    },
    {
        "created_at": "Mon Feb 12 00:04:37 +0000 2018",
        "id": 962839824356069376,
        "text": "RT @BAP_US: Dr. #ShirleyJackson the first African-American woman to have earned a doctorate at the MIT.\n\n#BlackAndProud #BlackWomen #BlackE\u2026",
        "user.screen_name": "ChxJenn"
    },
    {
        "created_at": "Mon Feb 12 00:03:52 +0000 2018",
        "id": 962839635868217344,
        "text": "RT @finah: What Rihanna sounds like in Needed Me slowed down \ud83d\ude33 https://t.co/0jEsxjlqr3",
        "user.screen_name": "Mit_540"
    },
    {
        "created_at": "Mon Feb 12 00:03:39 +0000 2018",
        "id": 962839580159500288,
        "text": "RT @MichaelTripper: Page preparing readers for the next one:\nhttps://t.co/esmsdW8EZ3\nThe Hook, the actual #wtf for a #scientist, mass #medi\u2026",
        "user.screen_name": "everburningfire"
    },
    {
        "created_at": "Mon Feb 12 00:03:39 +0000 2018",
        "id": 962839579266027520,
        "text": "RT @lithiumforum: New independent study of #ICCT shows: #EV much better for climate than ICE. No surprise, but some lobbyists still distrib\u2026",
        "user.screen_name": "01moreland10"
    },
    {
        "created_at": "Mon Feb 12 00:03:38 +0000 2018",
        "id": 962839576149725184,
        "text": "RT @Syzdem: ADHS mit @Imprezziv\n\nhttps://t.co/R40zOKoH0r https://t.co/ZUTIAIEl32",
        "user.screen_name": "Syzdem"
    },
    {
        "created_at": "Mon Feb 12 00:03:25 +0000 2018",
        "id": 962839522982719488,
        "text": "#hot #redhead amateur #blowjob mit #cumshot https://t.co/6213Wegj0u",
        "user.screen_name": "WnURm8yiEjCdO5w"
    },
    {
        "created_at": "Mon Feb 12 00:03:21 +0000 2018",
        "id": 962839504234172417,
        "text": "RT @akwyz: Surviving a Day Without Smartphones https://t.co/iQXbYrRbKz",
        "user.screen_name": "Lord_Sirjs"
    },
    {
        "created_at": "Mon Feb 12 00:03:12 +0000 2018",
        "id": 962839467995336704,
        "text": "@BleacherReport This is the 3rd time in the last month I've seen him toss the ball towards someone with some sort o\u2026 https://t.co/l68DjluWwo",
        "user.screen_name": "ffulC_miT"
    },
    {
        "created_at": "Mon Feb 12 00:03:10 +0000 2018",
        "id": 962839458415566848,
        "text": "RT @Syzdem: ADHS 2.0 mit @Imprezziv\n\nhttps://t.co/R40zOKoH0r https://t.co/Dhgp5qdVyV",
        "user.screen_name": "Syzdem"
    },
    {
        "created_at": "Mon Feb 12 00:02:43 +0000 2018",
        "id": 962839344187879425,
        "text": "Surviving a Day Without Smartphones https://t.co/iQXbYrRbKz",
        "user.screen_name": "akwyz"
    },
    {
        "created_at": "Mon Feb 12 00:02:05 +0000 2018",
        "id": 962839187723554821,
        "text": "Ficken #mit #meiner #Freundin in Yogahosen https://t.co/LWhSbejZh8",
        "user.screen_name": "huber_eldridge"
    },
    {
        "created_at": "Mon Feb 12 00:01:54 +0000 2018",
        "id": 962839139136823296,
        "text": "RT @kweintraub: Harvard names Larry Bacow its next president. Son of immigrants, former head of Tufts, and Professor of Environmental Studi\u2026",
        "user.screen_name": "AliciaBlatchfor"
    },
    {
        "created_at": "Mon Feb 12 00:01:37 +0000 2018",
        "id": 962839068475314177,
        "text": "RT @StanM3: Germany- Afghan(19) stabbed his ex-girlfriend(23) in the shoulder and fled. The police had been called because of domestic viol\u2026",
        "user.screen_name": "Halo5_"
    },
    {
        "created_at": "Mon Feb 12 00:01:31 +0000 2018",
        "id": 962839042571358208,
        "text": "RT @MITSloan: The idea of a universal basic income is not new, but the theory has never been thoroughly tested. A massive new study is abou\u2026",
        "user.screen_name": "AshishHosalkar"
    },
    {
        "created_at": "Mon Feb 12 00:00:56 +0000 2018",
        "id": 962838895481278464,
        "text": "RT @mitsmr: Take a few minutes to read this classic: The Nine Elements of Digital Transformation: https://t.co/FBFlzQbwQF  #digitaltransfor\u2026",
        "user.screen_name": "Juanbg"
    },
    {
        "created_at": "Mon Feb 12 00:00:45 +0000 2018",
        "id": 962838853227876352,
        "text": "RT @joshgerstein: New Harvard president &amp; MIT frat brother on policy punishing membership in single-sex organizations: 'It's the right one\u2026",
        "user.screen_name": "lvbgal"
    },
    {
        "created_at": "Mon Feb 12 00:00:39 +0000 2018",
        "id": 962838826547892225,
        "text": "#Update\n\nHeavy Metal TV 2018 Februar\n\nmit:\nSteven Tyler (Aerosmith) \n\nGene Simmons (KISS) \n\nWolveSpirit... https://t.co/O66eS2suMa",
        "user.screen_name": "HansHeavyMetal"
    },
    {
        "created_at": "Mon Feb 12 00:00:19 +0000 2018",
        "id": 962838743873826816,
        "text": "MIT created the smart home app of the future https://t.co/9jbJI5lM4m",
        "user.screen_name": "KlinikuNet"
    },
    {
        "created_at": "Mon Feb 12 00:00:19 +0000 2018",
        "id": 962838741026033664,
        "text": "Live mit CoD WW2 https://t.co/knqiDSYTBq  #CoD #MWR #twitch",
        "user.screen_name": "cr4sher619Fritz"
    },
    {
        "created_at": "Mon Feb 12 00:00:02 +0000 2018",
        "id": 962838669257314304,
        "text": "RT @MITSloan: The idea of a universal basic income is not new, but the theory has never been thoroughly tested. A massive new study is abou\u2026",
        "user.screen_name": "Rod_Pardo"
    },
    {
        "created_at": "Sun Feb 11 23:59:21 +0000 2018",
        "id": 962838499333255168,
        "text": "RT @MITSloan: \u201cThe Olympic host city loses money on the venture.\u201d https://t.co/JoFh4VZF8x https://t.co/sioocepgZj",
        "user.screen_name": "megumitakata"
    },
    {
        "created_at": "Sun Feb 11 23:59:12 +0000 2018",
        "id": 962838463086190592,
        "text": "@haydentiff @pl_mothergoose please don\u2019t without reading this first. many have tried to bash $IOTA. they all failed\u2026 https://t.co/xGXXcoVXFw",
        "user.screen_name": "c4chaos"
    },
    {
        "created_at": "Sun Feb 11 23:59:04 +0000 2018",
        "id": 962838428717957120,
        "text": "Page preparing readers for the next one:\nhttps://t.co/esmsdW8EZ3\nThe Hook, the actual #wtf for a #scientist, mass\u2026 https://t.co/VKj6IIXfuv",
        "user.screen_name": "MichaelTripper"
    },
    {
        "created_at": "Sun Feb 11 23:58:36 +0000 2018",
        "id": 962838311948742656,
        "text": "@NetflixMulhouse @MsEmmaPeele @CRUSADER0fTRUTH @louann_rolph @hereticornot @CentaurSteed @deadheadsticker\u2026 https://t.co/7Dvq1CuJgl",
        "user.screen_name": "MarionF74"
    },
    {
        "created_at": "Sun Feb 11 23:58:17 +0000 2018",
        "id": 962838230600007680,
        "text": "@beauty_b_me @karawalker_art @ngadc https://t.co/fZTGtnPITS https://t.co/eoyWYUCu7R I recommend emailing the\u2026 https://t.co/QgR9G27UH5",
        "user.screen_name": "PeripateticMe"
    },
    {
        "created_at": "Sun Feb 11 23:57:30 +0000 2018",
        "id": 962838032956121088,
        "text": "RT @ThomasWictor: (10) Turkey did exactly the same thing when reporters revealed that the \nNational Intelligence Organization (MIT) was fun\u2026",
        "user.screen_name": "DavyJonesPizza"
    },
    {
        "created_at": "Sun Feb 11 23:57:11 +0000 2018",
        "id": 962837954702991362,
        "text": "RT @joshgerstein: New Harvard president &amp; MIT frat brother on policy punishing membership in single-sex organizations: 'It's the right one\u2026",
        "user.screen_name": "jeanee5TAM"
    },
    {
        "created_at": "Sun Feb 11 23:57:06 +0000 2018",
        "id": 962837932049555456,
        "text": "MIT 6.S191: Introduction to Deep Learning(19):https://t.co/5PyyZi6tps",
        "user.screen_name": "kogatake"
    },
    {
        "created_at": "Sun Feb 11 23:56:36 +0000 2018",
        "id": 962837805054513157,
        "text": "RT @dark_shark: How Rocket Science And Early Computer Music Converged At Bell Labs by #MaxMathews #IBM #MIT @geetadayal https://t.co/msjR9E\u2026",
        "user.screen_name": "TurneReeves"
    },
    {
        "created_at": "Sun Feb 11 23:56:34 +0000 2018",
        "id": 962837796653289473,
        "text": "RT @mitsmr: If your company has rigid timelines about promotions and salary raises, you will lose valuable talent https://t.co/GAJNArfr0B",
        "user.screen_name": "DaphneHalkias"
    },
    {
        "created_at": "Sun Feb 11 23:55:57 +0000 2018",
        "id": 962837642143346688,
        "text": "@BioRender 1. My sister @kaymtye whose lab studies how emotional &amp; motivational states influence behavior at MIT. \ud83d\ude0d\u2026 https://t.co/O4hFreGOGS",
        "user.screen_name": "lynnetye"
    },
    {
        "created_at": "Sun Feb 11 23:55:44 +0000 2018",
        "id": 962837588737445894,
        "text": "I just released a #frontend for Nu #Html #Checker written with HTML5 / CSS3 / Javascript. You can do bulk validatio\u2026 https://t.co/yWEXxGTXdB",
        "user.screen_name": "BeFiveINFO"
    },
    {
        "created_at": "Sun Feb 11 23:55:32 +0000 2018",
        "id": 962837540129689600,
        "text": "40 kWh and #V2G ready: Very good!\n#nissan #range #cube\nhttps://t.co/tm7D45aA7b",
        "user.screen_name": "PeterLoeck"
    },
    {
        "created_at": "Sun Feb 11 23:55:19 +0000 2018",
        "id": 962837485544931328,
        "text": "mit Knibbol! https://t.co/FHKfueK8MQ",
        "user.screen_name": "Hack_Dedrul"
    },
    {
        "created_at": "Sun Feb 11 23:53:46 +0000 2018",
        "id": 962837095562715137,
        "text": "Asggee https://t.co/H6PCOqtfTZ",
        "user.screen_name": "LarryTasse"
    },
    {
        "created_at": "Sun Feb 11 23:53:36 +0000 2018",
        "id": 962837051937665025,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/lg2RZ9eUnd\u2026",
        "user.screen_name": "BuanaFrank3"
    },
    {
        "created_at": "Sun Feb 11 23:53:11 +0000 2018",
        "id": 962836947084435457,
        "text": "RT @MITSloan: The idea of a universal basic income is not new, but the theory has never been thoroughly tested. A massive new study is abou\u2026",
        "user.screen_name": "2be_here"
    },
    {
        "created_at": "Sun Feb 11 23:53:01 +0000 2018",
        "id": 962836904428359681,
        "text": "@DieBatsuDie *yoda dabs*",
        "user.screen_name": "mit_ouo"
    },
    {
        "created_at": "Sun Feb 11 23:52:29 +0000 2018",
        "id": 962836770705506305,
        "text": "RT @MITSloan: The idea of a universal basic income is not new, but the theory has never been thoroughly tested. A massive new study is abou\u2026",
        "user.screen_name": "diaviv"
    },
    {
        "created_at": "Sun Feb 11 23:52:26 +0000 2018",
        "id": 962836759116595200,
        "text": "RT @mitsmr: People who are \u201cdifferent\u201d \u2014whether behaviorally or neurologically\u2014 don\u2019t always fit into standard job categories. But if you c\u2026",
        "user.screen_name": "meadowsalestech"
    },
    {
        "created_at": "Sun Feb 11 23:52:03 +0000 2018",
        "id": 962836662744158208,
        "text": "@lad1121 @dqjul @BrianKempGA @FultonGOP @MIT Go back to Chicago you snowflake",
        "user.screen_name": "RobertJonesJr12"
    },
    {
        "created_at": "Sun Feb 11 23:51:43 +0000 2018",
        "id": 962836578858143746,
        "text": "RT @MITSloan: The idea of a universal basic income is not new, but the theory has never been thoroughly tested. A massive new study is abou\u2026",
        "user.screen_name": "TammyBo35924315"
    },
    {
        "created_at": "Sun Feb 11 23:51:07 +0000 2018",
        "id": 962836425266868226,
        "text": "RT @CCollinsPhD: TRAILBLAZERS: Nuclear physicist and engineer, Dr. Shirley A. Jackson, was the 1st African-American woman to earn a Ph.D. @\u2026",
        "user.screen_name": "DrEFleming7"
    },
    {
        "created_at": "Sun Feb 11 23:51:02 +0000 2018",
        "id": 962836406522515456,
        "text": "RT @dandyliving: Fasching mit @namenlos4 \ud83d\ude0d https://t.co/2hRAjHhXUS",
        "user.screen_name": "VCrncec"
    },
    {
        "created_at": "Sun Feb 11 23:51:00 +0000 2018",
        "id": 962836398842744832,
        "text": "The idea of a universal basic income is not new, but the theory has never been thoroughly tested. A massive new stu\u2026 https://t.co/NY8zOBOEVt",
        "user.screen_name": "MITSloan"
    },
    {
        "created_at": "Sun Feb 11 23:50:10 +0000 2018",
        "id": 962836188385107968,
        "text": "RT @kendricklamar: Black Panther \n\nRespect to all the artist/producers that allowed me to execute a sound for the soundtrack.\n\nThe concept\u2026",
        "user.screen_name": "Mit_ch_ell"
    },
    {
        "created_at": "Sun Feb 11 23:49:48 +0000 2018",
        "id": 962836093954478080,
        "text": "RT @mitsmr: \u201cThe \u2018blame\u2019 culture that permeates most organizations paralyzes decision makers so much that they don\u2019t take chances and they\u2026",
        "user.screen_name": "Duckydoodle18"
    },
    {
        "created_at": "Sun Feb 11 23:49:31 +0000 2018",
        "id": 962836025566531584,
        "text": "RT @ProfBuehlerMIT: Registration now open for the Materials By Design short course @MIT this summer: Learn how multiscale simulation is use\u2026",
        "user.screen_name": "CSHub_MIT"
    },
    {
        "created_at": "Sun Feb 11 23:49:23 +0000 2018",
        "id": 962835991714246657,
        "text": "RT @MIT: Shirley Ann Jackson '68 PhD '73 was the first black woman to earn a doctorate from MIT. Jackson helped to bring about more diversi\u2026",
        "user.screen_name": "SusanaPablo"
    },
    {
        "created_at": "Sun Feb 11 23:49:02 +0000 2018",
        "id": 962835902425980929,
        "text": "Facial recognition software is biased towards white men, researcher finds https://t.co/KLeYD34Kdp",
        "user.screen_name": "drinkncode"
    },
    {
        "created_at": "Sun Feb 11 23:48:29 +0000 2018",
        "id": 962835764445925376,
        "text": "#HarvardUniversity Names Former .@TuftsUniversity President Lawrence S. Bacow To Lead University, spent 24 years at\u2026 https://t.co/w5hdjJqboL",
        "user.screen_name": "finneyeric"
    },
    {
        "created_at": "Sun Feb 11 23:48:22 +0000 2018",
        "id": 962835736155377664,
        "text": "Facial recognition software is biased towards white men, researcher finds https://t.co/E7mta8U40g via @Verge",
        "user.screen_name": "AntoninPribetic"
    },
    {
        "created_at": "Sun Feb 11 23:47:49 +0000 2018",
        "id": 962835598657585152,
        "text": "lowkey thinking about putting subs in the maro \ud83d\ude43",
        "user.screen_name": "Taylor_Mit"
    },
    {
        "created_at": "Sun Feb 11 23:47:09 +0000 2018",
        "id": 962835428956131328,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "kellyandkids3"
    },
    {
        "created_at": "Sun Feb 11 23:47:09 +0000 2018",
        "id": 962835428876410887,
        "text": "RT @MITengineers: MIT men's volleyball improved to 8-1 this season with a thrilling five set win over St. John Fisher this afternoon!  http\u2026",
        "user.screen_name": "TheUVC"
    },
    {
        "created_at": "Sun Feb 11 23:47:09 +0000 2018",
        "id": 962835427446071296,
        "text": "RT @DrMattFinch: @alamw gently &amp; lovingly sassing MIT reminds me of this project we did in Aussie - the one thing you can\u2019t hack in the USA\u2026",
        "user.screen_name": "ebeh"
    },
    {
        "created_at": "Sun Feb 11 23:47:07 +0000 2018",
        "id": 962835422320758784,
        "text": "RT @The_EmmaxD: I liked a @YouTube video https://t.co/a4pQcGKlZ6 Minecraft KLARO | Ententanz mit Unterhose | 02",
        "user.screen_name": "IRTMC"
    },
    {
        "created_at": "Sun Feb 11 23:47:01 +0000 2018",
        "id": 962835396831870976,
        "text": "RT @JuliaBrotherton: @Beverly_High  Congrats to award winners Jennie Krigbaum, Laina Meagher, and Ibrahima Diagne, AND to the entire BHS de\u2026",
        "user.screen_name": "APDestefano"
    },
    {
        "created_at": "Sun Feb 11 23:46:54 +0000 2018",
        "id": 962835366532194304,
        "text": "RT @deeplearning4j: Pace Layering: How Complex Systems Learn and Keep Learning https://t.co/XysTbEoVZG",
        "user.screen_name": "pranjaltandon2"
    },
    {
        "created_at": "Sun Feb 11 23:46:52 +0000 2018",
        "id": 962835356642152448,
        "text": "RT @FisherAthletics: Men's Volleyball Outlasted By MIT In Five Set UVC Matchup  https://t.co/ChyxbIlxuh",
        "user.screen_name": "TheUVC"
    },
    {
        "created_at": "Sun Feb 11 23:46:49 +0000 2018",
        "id": 962835343140585473,
        "text": "I liked a @YouTube video https://t.co/a4pQcGKlZ6 Minecraft KLARO | Ententanz mit Unterhose | 02",
        "user.screen_name": "The_EmmaxD"
    },
    {
        "created_at": "Sun Feb 11 23:46:40 +0000 2018",
        "id": 962835307405217792,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "shyduroff"
    },
    {
        "created_at": "Sun Feb 11 23:46:37 +0000 2018",
        "id": 962835294839083009,
        "text": "#RonWhite https://t.co/9cgaaDF5Re This bioengineering technique removes/replace the genetic code for passing on cer\u2026 https://t.co/7FLNc5BObl",
        "user.screen_name": "lazymanltd"
    },
    {
        "created_at": "Sun Feb 11 23:46:28 +0000 2018",
        "id": 962835254905069568,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "drgregjones"
    },
    {
        "created_at": "Sun Feb 11 23:46:23 +0000 2018",
        "id": 962835236043177984,
        "text": "RT @LeadershipPros2: RT @mitsmr \"\u201cThe \u2018blame\u2019 culture that permeates most organizations paralyzes decision makers so much that they don\u2019t t\u2026",
        "user.screen_name": "Duckydoodle18"
    },
    {
        "created_at": "Sun Feb 11 23:46:23 +0000 2018",
        "id": 962835233874890752,
        "text": "New post: Rudolf Kingslake Medal awarded by SPIE for paper on space-based imaging Researchers at MIT have won th https://t.co/ArNLfccWc6",
        "user.screen_name": "grp_net"
    },
    {
        "created_at": "Sun Feb 11 23:46:17 +0000 2018",
        "id": 962835211070291968,
        "text": "@alamw gently &amp; lovingly sassing MIT reminds me of this project we did in Aussie - the one thing you can\u2019t hack in\u2026 https://t.co/qhBXKe4zeQ",
        "user.screen_name": "DrMattFinch"
    },
    {
        "created_at": "Sun Feb 11 23:46:15 +0000 2018",
        "id": 962835204183293952,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "allisongrrl"
    },
    {
        "created_at": "Sun Feb 11 23:46:05 +0000 2018",
        "id": 962835159618797568,
        "text": "Electric Circuits | MIT OpenCourseWare | Free Online Course Materials https://t.co/Kg0vz02Oe5",
        "user.screen_name": "Wire_Queen"
    },
    {
        "created_at": "Sun Feb 11 23:45:59 +0000 2018",
        "id": 962835133727498240,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "stevegagne99"
    },
    {
        "created_at": "Sun Feb 11 23:45:58 +0000 2018",
        "id": 962835131185672193,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Nissan__Xterra"
    },
    {
        "created_at": "Sun Feb 11 23:45:57 +0000 2018",
        "id": 962835128383926272,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "RimboltBlack"
    },
    {
        "created_at": "Sun Feb 11 23:45:56 +0000 2018",
        "id": 962835120809037824,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Toyota_Venza"
    },
    {
        "created_at": "Sun Feb 11 23:45:46 +0000 2018",
        "id": 962835082011652096,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "StewartJaxson"
    },
    {
        "created_at": "Sun Feb 11 23:45:43 +0000 2018",
        "id": 962835069944713216,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "HeavenGianna"
    },
    {
        "created_at": "Sun Feb 11 23:45:42 +0000 2018",
        "id": 962835062311006211,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "AsiliaZinsha"
    },
    {
        "created_at": "Sun Feb 11 23:45:41 +0000 2018",
        "id": 962835058368401408,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "PaulRees45"
    },
    {
        "created_at": "Sun Feb 11 23:45:39 +0000 2018",
        "id": 962835052731256833,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "AudreyPullman5"
    },
    {
        "created_at": "Sun Feb 11 23:45:35 +0000 2018",
        "id": 962835035995951105,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "BloggerLeeWhite"
    },
    {
        "created_at": "Sun Feb 11 23:45:32 +0000 2018",
        "id": 962835023656378368,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "StevenDavidso3"
    },
    {
        "created_at": "Sun Feb 11 23:45:32 +0000 2018",
        "id": 962835023232716800,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "VictorSmith67"
    },
    {
        "created_at": "Sun Feb 11 23:45:31 +0000 2018",
        "id": 962835019214540801,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "KathyEnzerink"
    },
    {
        "created_at": "Sun Feb 11 23:45:29 +0000 2018",
        "id": 962835007445323781,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Raphaelle_Smith"
    },
    {
        "created_at": "Sun Feb 11 23:45:26 +0000 2018",
        "id": 962834996439416832,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "DavidHardacre7"
    },
    {
        "created_at": "Sun Feb 11 23:45:25 +0000 2018",
        "id": 962834994652737536,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "HarmonyEmilie"
    },
    {
        "created_at": "Sun Feb 11 23:45:25 +0000 2018",
        "id": 962834993130196992,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "JenniferAlsop7"
    },
    {
        "created_at": "Sun Feb 11 23:45:25 +0000 2018",
        "id": 962834991460900865,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "SamKelly63"
    },
    {
        "created_at": "Sun Feb 11 23:45:16 +0000 2018",
        "id": 962834956308434945,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "AlomoraSimslens"
    },
    {
        "created_at": "Sun Feb 11 23:45:12 +0000 2018",
        "id": 962834939342401537,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "BellaRoberts181"
    },
    {
        "created_at": "Sun Feb 11 23:45:09 +0000 2018",
        "id": 962834926839238656,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "JacobGrant31"
    },
    {
        "created_at": "Sun Feb 11 23:45:05 +0000 2018",
        "id": 962834908392632320,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "MarkWhite1983"
    },
    {
        "created_at": "Sun Feb 11 23:44:58 +0000 2018",
        "id": 962834881104482304,
        "text": "RT @StanM3: Germany- Afghan(19) stabbed his ex-girlfriend(23) in the shoulder and fled. The police had been called because of domestic viol\u2026",
        "user.screen_name": "andreasguenth22"
    },
    {
        "created_at": "Sun Feb 11 23:44:55 +0000 2018",
        "id": 962834865757462528,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "AkanshaDigital"
    },
    {
        "created_at": "Sun Feb 11 23:44:49 +0000 2018",
        "id": 962834843091402752,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "DollyRay1987"
    },
    {
        "created_at": "Sun Feb 11 23:44:42 +0000 2018",
        "id": 962834813517414400,
        "text": "RT @Ehh_Le_Nah: When u peep ur boo like another girls pic on the tl https://t.co/IFx42pLtUc",
        "user.screen_name": "_mit_mit"
    },
    {
        "created_at": "Sun Feb 11 23:44:39 +0000 2018",
        "id": 962834799378489344,
        "text": "@Humbug0505 mit wem",
        "user.screen_name": "Reppinum"
    },
    {
        "created_at": "Sun Feb 11 23:44:37 +0000 2018",
        "id": 962834792436953093,
        "text": "Schrimps \ud83c\udf64 mit Broccoli \ud83e\udd66 Karotten \ud83e\udd55 und Bohnen \ud83d\udc4c\ud83c\udffd shrimp with broccoli carrots &amp; beans\u2026 https://t.co/ahImvIePpS",
        "user.screen_name": "MamaKukiTweets"
    },
    {
        "created_at": "Sun Feb 11 23:44:36 +0000 2018",
        "id": 962834788049563648,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/fQ1IKfcpVW\u2026",
        "user.screen_name": "Jozef_Moffat_AI"
    },
    {
        "created_at": "Sun Feb 11 23:44:33 +0000 2018",
        "id": 962834773667233792,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Michael_Jacobe"
    },
    {
        "created_at": "Sun Feb 11 23:44:31 +0000 2018",
        "id": 962834765836505089,
        "text": "RT @DrHughHarvey: Didn\u2019t study deep learning at MIT?\n\nDon\u2019t worry - here\u2019s the entire course \n\nhttps://t.co/HTONtKKWWz https://t.co/bmbxY5u\u2026",
        "user.screen_name": "dangrsmind"
    },
    {
        "created_at": "Sun Feb 11 23:44:26 +0000 2018",
        "id": 962834743820632064,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "DollyRayDigital"
    },
    {
        "created_at": "Sun Feb 11 23:44:12 +0000 2018",
        "id": 962834686614560768,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "SocialMedia_ist"
    },
    {
        "created_at": "Sun Feb 11 23:44:08 +0000 2018",
        "id": 962834670520971265,
        "text": "RT @mitsmr: RT @MITSloan: There actually are enough hours in the day. Get more out of them with these 7 productivity tips from @Pozen. http\u2026",
        "user.screen_name": "micki59806"
    },
    {
        "created_at": "Sun Feb 11 23:43:58 +0000 2018",
        "id": 962834628640784384,
        "text": "\"It's really hard to relate to MIT\" https://t.co/VSBJ2rDsOc",
        "user.screen_name": "The_Informaiden"
    },
    {
        "created_at": "Sun Feb 11 23:43:55 +0000 2018",
        "id": 962834613893701632,
        "text": "@klmccook \u201cIt\u2019s hard to relate to MIT.\u201d #alamw18",
        "user.screen_name": "ebeh"
    },
    {
        "created_at": "Sun Feb 11 23:43:51 +0000 2018",
        "id": 962834596600492032,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "SMDominator"
    },
    {
        "created_at": "Sun Feb 11 23:43:46 +0000 2018",
        "id": 962834575838924801,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "itknowingness"
    },
    {
        "created_at": "Sun Feb 11 23:43:45 +0000 2018",
        "id": 962834573733257216,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "SunnyRayDigital"
    },
    {
        "created_at": "Sun Feb 11 23:43:35 +0000 2018",
        "id": 962834531907751936,
        "text": "\"it's really hard to relate to MIT\" ooooouch, that was a good burn #alamw18",
        "user.screen_name": "aamcnamara"
    },
    {
        "created_at": "Sun Feb 11 23:42:33 +0000 2018",
        "id": 962834272984993792,
        "text": "RT @tom_peters: This is priceless, as good as it gets. Take your time!! \"Is tech dividing America? via @POLITICO for iPad\" https://t.co/nwv\u2026",
        "user.screen_name": "OwenMasonOMC"
    },
    {
        "created_at": "Sun Feb 11 23:42:12 +0000 2018",
        "id": 962834183470002176,
        "text": "@aashdizzleeeeee Must be nice\ud83d\ude43",
        "user.screen_name": "_mit_mit"
    },
    {
        "created_at": "Sun Feb 11 23:41:41 +0000 2018",
        "id": 962834053245427714,
        "text": "RT @juliagalef: I'm excited MIT is trying this: A master's in development economics that doesn't require a degree, GRE, or letters of recom\u2026",
        "user.screen_name": "realABSHOKOYA"
    },
    {
        "created_at": "Sun Feb 11 23:41:31 +0000 2018",
        "id": 962834011356848128,
        "text": "RT @judah47: \"Records are meant to be broken\" new all time record set in poleward #heat transport into the #polar stratosphere.Increasing t\u2026",
        "user.screen_name": "solhog"
    },
    {
        "created_at": "Sun Feb 11 23:41:03 +0000 2018",
        "id": 962833893970890752,
        "text": "New research from MIT suggests that beta brainwaves act to control working memory, while gamma brainwaves are assoc\u2026 https://t.co/egD1ATo8w2",
        "user.screen_name": "R_RedRaider"
    },
    {
        "created_at": "Sun Feb 11 23:39:33 +0000 2018",
        "id": 962833517594935296,
        "text": "RT @mitsmr: 4 steps to sharing positive stories\n1. Work with consumers to generate compelling stories\n2. Convert stories into high-quality\u2026",
        "user.screen_name": "MMinevich"
    },
    {
        "created_at": "Sun Feb 11 23:39:29 +0000 2018",
        "id": 962833500494880770,
        "text": "RT @StanM3: Germany- Afghan(19) stabbed his ex-girlfriend(23) in the shoulder and fled. The police had been called because of domestic viol\u2026",
        "user.screen_name": "ElTheochari"
    },
    {
        "created_at": "Sun Feb 11 23:39:23 +0000 2018",
        "id": 962833472850145280,
        "text": "RT @mitsmr: Free webinar: Turning Data Into Customer Engagement Thursday, February 15, 2018 * 11 EST / 8 PST If you\u2019re unable to attend liv\u2026",
        "user.screen_name": "katie350501"
    },
    {
        "created_at": "Sun Feb 11 23:39:08 +0000 2018",
        "id": 962833410614898690,
        "text": "Facial recognition software is biased towards white men, researcher finds https://t.co/I0Yy48YqZI https://t.co/pLJZ4WLuCx",
        "user.screen_name": "SynetecUK"
    },
    {
        "created_at": "Sun Feb 11 23:38:56 +0000 2018",
        "id": 962833359373242369,
        "text": "@tomkraftwerk https://t.co/UjygbnEdJX\n\nPudding mit Haut!",
        "user.screen_name": "Klingelpfote"
    },
    {
        "created_at": "Sun Feb 11 23:38:50 +0000 2018",
        "id": 962833337470652416,
        "text": "RT @hildabast: Day 2 #BlackHistoryMonth: Physicist, Carolyn Beatrice Parker - a remarkable woman, whose long-lost story shows how much work\u2026",
        "user.screen_name": "OpheliaBottom"
    },
    {
        "created_at": "Sun Feb 11 23:38:29 +0000 2018",
        "id": 962833249830690817,
        "text": "RT @BPoD_mrc: Preventing #memories from sticking and retrieving lost ones. Research by @MIT_Picower in PNAS @PNASNews. Read more on https:/\u2026",
        "user.screen_name": "artcollisions"
    },
    {
        "created_at": "Sun Feb 11 23:37:53 +0000 2018",
        "id": 962833097246085120,
        "text": "RT @JuliaBrotherton: @Beverly_High  Congrats to award winners Jennie Krigbaum, Laina Meagher, and Ibrahima Diagne, AND to the entire BHS de\u2026",
        "user.screen_name": "DebSchnabel"
    },
    {
        "created_at": "Sun Feb 11 23:37:51 +0000 2018",
        "id": 962833089150857216,
        "text": "@CNBC @coinics @MIT And people will debate over its actual colour they really see. Is it black or purple?",
        "user.screen_name": "tokioessence"
    },
    {
        "created_at": "Sun Feb 11 23:37:45 +0000 2018",
        "id": 962833064027217921,
        "text": "@ultsongnieI klaudia mit k but you will know who i mean the second she comes on",
        "user.screen_name": "thssmslkfn"
    },
    {
        "created_at": "Sun Feb 11 23:37:44 +0000 2018",
        "id": 962833059669299201,
        "text": "@keithfraser2017 @WeDoNotLearn73 Ok, so why do policemen have 'pay and conditions' which allow them to retire at le\u2026 https://t.co/EOpsmM8rIr",
        "user.screen_name": "Dame_mit_muff"
    },
    {
        "created_at": "Sun Feb 11 23:37:35 +0000 2018",
        "id": 962833019626192897,
        "text": "The Power of Consumer Stories in Digital Marketing https://t.co/haNc6q5d6u via @mitsmr #Digital #Marketing",
        "user.screen_name": "simonhodgkins"
    },
    {
        "created_at": "Sun Feb 11 23:37:33 +0000 2018",
        "id": 962833014827995136,
        "text": "At the bar I chatted with a man whose daughter is studying aerospace engineering at MIT. #womeninscience",
        "user.screen_name": "justmaryse"
    },
    {
        "created_at": "Sun Feb 11 23:37:11 +0000 2018",
        "id": 962832920212922370,
        "text": "RT @FraHofm: \"MIT biological engineers have created a programming language that allows them to rapidly design complex, DNA-encoded circuits\u2026",
        "user.screen_name": "skyjones55"
    },
    {
        "created_at": "Sun Feb 11 23:36:43 +0000 2018",
        "id": 962832804982779904,
        "text": "@TaylorLorenz @ChrisCaesar same https://t.co/7ncPbUCjcv",
        "user.screen_name": "peteyreplies"
    },
    {
        "created_at": "Sun Feb 11 23:36:35 +0000 2018",
        "id": 962832770996224000,
        "text": "RT @PhilosophyMttrs: Applying philosophy for a better democracy ... https://t.co/vToYau9O2Q",
        "user.screen_name": "ojcius"
    },
    {
        "created_at": "Sun Feb 11 23:36:17 +0000 2018",
        "id": 962832695951798272,
        "text": "RT @mitsmr: RT @MITSloan: There actually are enough hours in the day. Get more out of them with these 7 productivity tips from @Pozen. http\u2026",
        "user.screen_name": "RayBordogna"
    },
    {
        "created_at": "Sun Feb 11 23:35:54 +0000 2018",
        "id": 962832599394725889,
        "text": "RT @random_forests: MIT has shared an Intro to Deep Learning course, see: https://t.co/ULJddTvwvZ. Labs include @TensorFlow code (haven't h\u2026",
        "user.screen_name": "dev_kaique"
    },
    {
        "created_at": "Sun Feb 11 23:35:36 +0000 2018",
        "id": 962832523645435904,
        "text": "RT @MITSloan: Integrating analytics is crucial. Start with these 8 articles. https://t.co/3hxWVgHY9q",
        "user.screen_name": "StephanieSFOSIS"
    },
    {
        "created_at": "Sun Feb 11 23:35:26 +0000 2018",
        "id": 962832479861297154,
        "text": "RT @StanM3: Germany- Afghan(19) stabbed his ex-girlfriend(23) in the shoulder and fled. The police had been called because of domestic viol\u2026",
        "user.screen_name": "Wizzy9883"
    },
    {
        "created_at": "Sun Feb 11 23:35:22 +0000 2018",
        "id": 962832463339847680,
        "text": "Chips mit Dip https://t.co/xjEGpZZlFZ",
        "user.screen_name": "Te_Meerkats"
    },
    {
        "created_at": "Sun Feb 11 23:35:21 +0000 2018",
        "id": 962832461087551489,
        "text": "RT @mitsmr: Take a few minutes to read this classic: The Nine Elements of Digital Transformation: https://t.co/FBFlzQbwQF  #digitaltransfor\u2026",
        "user.screen_name": "RayBordogna"
    },
    {
        "created_at": "Sun Feb 11 23:35:20 +0000 2018",
        "id": 962832453957275649,
        "text": "RT @CoyleAthletics: Good luck to Julie Mason today at the swimming sectionals at MIT! #gowarriors",
        "user.screen_name": "fdeepsportstalk"
    },
    {
        "created_at": "Sun Feb 11 23:34:52 +0000 2018",
        "id": 962832338798501888,
        "text": "RT @mcsantacaterina: 2 MIT grads built an algorithm to match you with wine. Take the quiz to see your matches. https://t.co/ynQQomEIak",
        "user.screen_name": "detroitdre1974"
    },
    {
        "created_at": "Sun Feb 11 23:34:51 +0000 2018",
        "id": 962832332997750784,
        "text": "RT @mitsmr: 4 steps to sharing positive stories\n1. Work with consumers to generate compelling stories\n2. Convert stories into high-quality\u2026",
        "user.screen_name": "CurationSuite"
    },
    {
        "created_at": "Sun Feb 11 23:34:36 +0000 2018",
        "id": 962832270695567360,
        "text": "RT @ToniPirosa: 2 SONGS in 1 mit DANERGY!!!\n\nLink: https://t.co/bA57YWP3w1 https://t.co/YcMSotQQxY",
        "user.screen_name": "AndreaPutzgrub1"
    },
    {
        "created_at": "Sun Feb 11 23:34:26 +0000 2018",
        "id": 962832226932043776,
        "text": "RT @BAP_US: Dr. #ShirleyJackson the first African-American woman to have earned a doctorate at the MIT.\n\n#BlackAndProud #BlackWomen #BlackE\u2026",
        "user.screen_name": "melaniepknight"
    },
    {
        "created_at": "Sun Feb 11 23:34:03 +0000 2018",
        "id": 962832131029381122,
        "text": "@USRealityCheck Congratulations to Professor Bacow who was my teacher and advisor at MIT.",
        "user.screen_name": "mucketymucks"
    },
    {
        "created_at": "Sun Feb 11 23:33:57 +0000 2018",
        "id": 962832107100807168,
        "text": "Defining a problem is the most underrated skill in management.  It requires \u2018soft\u2019 skills (critical thinking, abili\u2026 https://t.co/6UiI997ijO",
        "user.screen_name": "knowablekate"
    },
    {
        "created_at": "Sun Feb 11 23:33:46 +0000 2018",
        "id": 962832062410559488,
        "text": "RT @GarthGreenwell: I talked to Der Spiegel about #WhatBelongstoYou. The best bits are the photographs they included by Marc Martin, a Fren\u2026",
        "user.screen_name": "vvxzz26"
    },
    {
        "created_at": "Sun Feb 11 23:33:02 +0000 2018",
        "id": 962831877848608768,
        "text": "RT @econromesh: Empirical, tightly focused studies of trade &amp; development - overview of research by David Atkin @MITEcon, #WhatEconomistsRe\u2026",
        "user.screen_name": "Motoconomist"
    },
    {
        "created_at": "Sun Feb 11 23:32:45 +0000 2018",
        "id": 962831804507000832,
        "text": "RT @mitsmr: Take a few minutes to read this classic: The Nine Elements of Digital Transformation: https://t.co/FBFlzQbwQF  #digitaltransfor\u2026",
        "user.screen_name": "Sufiy"
    },
    {
        "created_at": "Sun Feb 11 23:32:45 +0000 2018",
        "id": 962831803206787072,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "WandererMegan"
    },
    {
        "created_at": "Sun Feb 11 23:32:43 +0000 2018",
        "id": 962831795933929473,
        "text": "RT @mitsmr: The 20 Most Popular @MITSMR  Articles of 2017. Spoiler alert: The impact of artificial intelligence on the #FutureofWork and or\u2026",
        "user.screen_name": "Sufiy"
    },
    {
        "created_at": "Sun Feb 11 23:32:33 +0000 2018",
        "id": 962831753403564032,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "JamesYoung1986"
    },
    {
        "created_at": "Sun Feb 11 23:32:31 +0000 2018",
        "id": 962831744528453632,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "mustardmary7"
    },
    {
        "created_at": "Sun Feb 11 23:32:25 +0000 2018",
        "id": 962831719794728961,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "JimRHenson"
    },
    {
        "created_at": "Sun Feb 11 23:32:16 +0000 2018",
        "id": 962831682620608512,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Hyundai__Equus"
    },
    {
        "created_at": "Sun Feb 11 23:32:15 +0000 2018",
        "id": 962831677922988037,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "BenNatureAddict"
    },
    {
        "created_at": "Sun Feb 11 23:32:10 +0000 2018",
        "id": 962831657181917184,
        "text": "RT @MITSloanAdcom: How do you map the future of a rapidly growing city? MIT and @Tsinghua_Uni in #Beijing teamed up to develop leading-edge\u2026",
        "user.screen_name": "HunanofChina"
    },
    {
        "created_at": "Sun Feb 11 23:32:07 +0000 2018",
        "id": 962831644314005504,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "AntonioRelenn"
    },
    {
        "created_at": "Sun Feb 11 23:32:05 +0000 2018",
        "id": 962831638999846912,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Honda_Ridgeline"
    },
    {
        "created_at": "Sun Feb 11 23:31:58 +0000 2018",
        "id": 962831607517401088,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Alexia_Lavoie"
    },
    {
        "created_at": "Sun Feb 11 23:31:54 +0000 2018",
        "id": 962831590224289792,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "GeekJimiLee"
    },
    {
        "created_at": "Sun Feb 11 23:31:53 +0000 2018",
        "id": 962831587158183937,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Toyota__Yaris"
    },
    {
        "created_at": "Sun Feb 11 23:31:52 +0000 2018",
        "id": 962831581034381312,
        "text": "RT @deeplearning4j: Pace Layering: How Complex Systems Learn and Keep Learning https://t.co/XysTbEoVZG",
        "user.screen_name": "aneesha"
    },
    {
        "created_at": "Sun Feb 11 23:31:38 +0000 2018",
        "id": 962831525195780096,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Lamborghini__US"
    },
    {
        "created_at": "Sun Feb 11 23:31:34 +0000 2018",
        "id": 962831508187828229,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "smithylife"
    },
    {
        "created_at": "Sun Feb 11 23:31:31 +0000 2018",
        "id": 962831494975836160,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Mark_Lewis_NYC"
    },
    {
        "created_at": "Sun Feb 11 23:31:29 +0000 2018",
        "id": 962831487216136193,
        "text": "MIT Bootcampers from 39 countries hearing from @BillAulet at @QUT @MITBootcamps #entrepreneurship #MITbootcamp https://t.co/Ji14TD0jWl",
        "user.screen_name": "karenfoelz"
    },
    {
        "created_at": "Sun Feb 11 23:31:29 +0000 2018",
        "id": 962831485043605505,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "DorothyPCarter"
    },
    {
        "created_at": "Sun Feb 11 23:31:25 +0000 2018",
        "id": 962831468342009857,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "DeryaGaby"
    },
    {
        "created_at": "Sun Feb 11 23:31:24 +0000 2018",
        "id": 962831464005021696,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "suzieqnelson"
    },
    {
        "created_at": "Sun Feb 11 23:31:23 +0000 2018",
        "id": 962831460813111301,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "SMM_Lisa"
    },
    {
        "created_at": "Sun Feb 11 23:31:23 +0000 2018",
        "id": 962831460095942656,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "SofiaMiller0"
    },
    {
        "created_at": "Sun Feb 11 23:31:19 +0000 2018",
        "id": 962831443188748289,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "KirkwoodTalon"
    },
    {
        "created_at": "Sun Feb 11 23:31:16 +0000 2018",
        "id": 962831429787729921,
        "text": "Well this looks exciting...  \n\nhttps://t.co/bGvxubEVHY\n\n@timberners_lee @MIT can't wait to try this out!",
        "user.screen_name": "_alexray"
    },
    {
        "created_at": "Sun Feb 11 23:31:15 +0000 2018",
        "id": 962831425924890624,
        "text": "Il a mit une photo PWAAAAA",
        "user.screen_name": "FannySalimat"
    },
    {
        "created_at": "Sun Feb 11 23:31:13 +0000 2018",
        "id": 962831418069016581,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "AndersonJohn74"
    },
    {
        "created_at": "Sun Feb 11 23:31:13 +0000 2018",
        "id": 962831417855102977,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "YoginiMaureen"
    },
    {
        "created_at": "Sun Feb 11 23:31:13 +0000 2018",
        "id": 962831416978542594,
        "text": "RT @cmualumnihouse: The 2nd round of @CarnegieMellon #Crowdfunding campaigns are off &amp; running! From Art Therapy and the Social Good Expo,\u2026",
        "user.screen_name": "jluisaguirre"
    },
    {
        "created_at": "Sun Feb 11 23:31:11 +0000 2018",
        "id": 962831410099900416,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "honecks85"
    },
    {
        "created_at": "Sun Feb 11 23:31:11 +0000 2018",
        "id": 962831409940455424,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "sharonocarter"
    },
    {
        "created_at": "Sun Feb 11 23:31:07 +0000 2018",
        "id": 962831392794202112,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Nissan__Juke"
    },
    {
        "created_at": "Sun Feb 11 23:31:04 +0000 2018",
        "id": 962831379494047745,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Theresa21Young"
    },
    {
        "created_at": "Sun Feb 11 23:31:03 +0000 2018",
        "id": 962831376109264896,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "jesspatrick86"
    },
    {
        "created_at": "Sun Feb 11 23:31:02 +0000 2018",
        "id": 962831372191698945,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "PurvisRobinson"
    },
    {
        "created_at": "Sun Feb 11 23:30:57 +0000 2018",
        "id": 962831350649819136,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "elizabethlswai"
    },
    {
        "created_at": "Sun Feb 11 23:30:55 +0000 2018",
        "id": 962831342374457344,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "fernandocuenca"
    },
    {
        "created_at": "Sun Feb 11 23:30:50 +0000 2018",
        "id": 962831321566412800,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "docdavis77"
    },
    {
        "created_at": "Sun Feb 11 23:30:49 +0000 2018",
        "id": 962831318684856320,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "akdm_bot"
    },
    {
        "created_at": "Sun Feb 11 23:30:49 +0000 2018",
        "id": 962831317061730305,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "jayjohannes24"
    },
    {
        "created_at": "Sun Feb 11 23:30:44 +0000 2018",
        "id": 962831298099376129,
        "text": "RT @VARcrypt: The latest The Virtual and Augmented Reality Daily! https://t.co/dWEgocjwYf Thanks to @virtrealitytime @hashVR @mit_cmsw #vr\u2026",
        "user.screen_name": "VirginiaKettle1"
    },
    {
        "created_at": "Sun Feb 11 23:30:43 +0000 2018",
        "id": 962831293355405312,
        "text": "RT @mitsmr: People who are \u201cdifferent\u201d \u2014whether behaviorally or neurologically\u2014 don\u2019t always fit into standard job categories. But if you c\u2026",
        "user.screen_name": "Duckydoodle18"
    },
    {
        "created_at": "Sun Feb 11 23:30:43 +0000 2018",
        "id": 962831292646780931,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "fabrica23"
    },
    {
        "created_at": "Sun Feb 11 23:30:43 +0000 2018",
        "id": 962831292151803904,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "carterjamss"
    },
    {
        "created_at": "Sun Feb 11 23:30:41 +0000 2018",
        "id": 962831286305017856,
        "text": "RT @SachinLulla: IoT Voices with WIRED  MIT Director, MIT IBM Watson AI Lab https://t.co/yV0wAuFSmH #DataScience #DataScientist #BigData #I\u2026",
        "user.screen_name": "Berardinelli3"
    },
    {
        "created_at": "Sun Feb 11 23:30:39 +0000 2018",
        "id": 962831276129603594,
        "text": "Facial recognition software is biased towards white men, researcher finds https://t.co/YhDiIsNBIC",
        "user.screen_name": "NGRColosimo"
    },
    {
        "created_at": "Sun Feb 11 23:30:37 +0000 2018",
        "id": 962831266822303744,
        "text": "RT @StanM3: Germany- Afghan(19) stabbed his ex-girlfriend(23) in the shoulder and fled. The police had been called because of domestic viol\u2026",
        "user.screen_name": "beatlesjad"
    },
    {
        "created_at": "Sun Feb 11 23:30:20 +0000 2018",
        "id": 962831195200516096,
        "text": "RT @mitsmr: 4 steps to sharing positive stories\n1. Work with consumers to generate compelling stories\n2. Convert stories into high-quality\u2026",
        "user.screen_name": "LibertadCompart"
    },
    {
        "created_at": "Sun Feb 11 23:30:13 +0000 2018",
        "id": 962831169413726208,
        "text": "@SteveKornacki You really need a time travel device. Possibly MIT could work on that for you. After all, you are a native.",
        "user.screen_name": "ruralfabulous"
    },
    {
        "created_at": "Sun Feb 11 23:30:02 +0000 2018",
        "id": 962831122181869568,
        "text": "#nowplaying: DJ Rewerb pr. Houseschuh - Houseschuh, HSP134 Freak Like Osterhase mit Lee Walker, Basti Grub &amp; Natch! und Luca Bisori Teil2",
        "user.screen_name": "radiohouseschuh"
    },
    {
        "created_at": "Sun Feb 11 23:29:41 +0000 2018",
        "id": 962831035246567425,
        "text": "RT @mitsmr: \"Even with rapid advances,\" says @erikbryn, \"AI won\u2019t be able to replace most jobs anytime soon. But in almost every industry,\u2026",
        "user.screen_name": "AlanHollandCork"
    },
    {
        "created_at": "Sun Feb 11 23:29:38 +0000 2018",
        "id": 962831022214864897,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "Joan_Artes"
    },
    {
        "created_at": "Sun Feb 11 23:29:36 +0000 2018",
        "id": 962831011909373952,
        "text": "RT DWV13: RT mitsmr: \"Great strategists are like great chess players or great game theorists: They need to think se\u2026 https://t.co/kQSD2Ncfmk",
        "user.screen_name": "DWV13"
    },
    {
        "created_at": "Sun Feb 11 23:29:25 +0000 2018",
        "id": 962830967596462081,
        "text": "RT @franceintheus: Today is International #WomenScienceDay ! \nEsther Duflo is a Professor of Poverty Alleviation &amp; Dev\u2019t Economics at @MIT\u2026",
        "user.screen_name": "BigSkyFlyer"
    },
    {
        "created_at": "Sun Feb 11 23:29:22 +0000 2018",
        "id": 962830954711658496,
        "text": "@Trace_Of_Jesus @RevSteLilimborn @WoopsWoah @Ah_Science So \"Gott mit Uns\" means atheism? Joseph Stalin wasn't an Or\u2026 https://t.co/jSWcxGfLZd",
        "user.screen_name": "FredMacManus"
    },
    {
        "created_at": "Sun Feb 11 23:29:18 +0000 2018",
        "id": 962830937112399872,
        "text": "MIT alumnus Ryan Robinson will talk about \"Breaking the #Blockchain: The Quantum Computing Effect\" this Tuesday (13\u2026 https://t.co/njukFx14EE",
        "user.screen_name": "MITBitcoinClub"
    },
    {
        "created_at": "Sun Feb 11 23:29:07 +0000 2018",
        "id": 962830890903752705,
        "text": "RT @judah47: \"Records are meant to be broken\" new all time record set in poleward #heat transport into the #polar stratosphere.Increasing t\u2026",
        "user.screen_name": "Ana_von_blis"
    },
    {
        "created_at": "Sun Feb 11 23:29:05 +0000 2018",
        "id": 962830881458216960,
        "text": "MIT AGI: Building machines that see, learn, and think like people (Josh Tenenbaum) https://t.co/FSxG5opAp8",
        "user.screen_name": "tbsmartens"
    },
    {
        "created_at": "Sun Feb 11 23:28:59 +0000 2018",
        "id": 962830856799817728,
        "text": "RT @kaysevenkenya: Some  Djs Tweeting #StopArrestingDjs Are Either hypocrites or they Don't Use Twitter Often \u263a \n\nWhen #KOT  Shouted #PayMo\u2026",
        "user.screen_name": "billboardlatest"
    },
    {
        "created_at": "Sun Feb 11 23:28:42 +0000 2018",
        "id": 962830785207263232,
        "text": "Facial recognition software is biased towards white men, researcher finds https://t.co/I0hzRdp8gN via @Verge",
        "user.screen_name": "SusiDarwin"
    },
    {
        "created_at": "Sun Feb 11 23:28:21 +0000 2018",
        "id": 962830697860878336,
        "text": "I liked a @YouTube video https://t.co/KO251BRBZA Fortnite Battle Royale Gameplay German - Gewinnen mit Slurp Hammer",
        "user.screen_name": "G12RG1"
    },
    {
        "created_at": "Sun Feb 11 23:27:57 +0000 2018",
        "id": 962830598158127104,
        "text": "RT @journal_edit: #MIT neuroscientists study how the brain manages habit formation - truly incredible! #cognitivescience #neurology #brain\u2026",
        "user.screen_name": "CathSalisbury"
    },
    {
        "created_at": "Sun Feb 11 23:27:29 +0000 2018",
        "id": 962830481581633536,
        "text": "RT @ToniPirosa: 2 SONGS in 1 mit DANERGY!!!\n\nLink: https://t.co/bA57YWP3w1 https://t.co/YcMSotQQxY",
        "user.screen_name": "ChristophBahner"
    },
    {
        "created_at": "Sun Feb 11 23:27:15 +0000 2018",
        "id": 962830420680282112,
        "text": "Here is coverage from #CNN on the new #HarvardUniversity President -- #LawrenceBacow  who brings his experience at\u2026 https://t.co/QJlEDRXaLX",
        "user.screen_name": "Shamstress"
    },
    {
        "created_at": "Sun Feb 11 23:27:12 +0000 2018",
        "id": 962830408932052993,
        "text": "RT @Fuchsmariechen: @citoyen_lauris \nPassend: \u2018All I know is the content of my own mind.\u2019 That\u2019s paving the path to authoritarianism.\nhttps\u2026",
        "user.screen_name": "citoyen_lauris"
    },
    {
        "created_at": "Sun Feb 11 23:27:10 +0000 2018",
        "id": 962830398555410437,
        "text": "RT @DeSantisMarcelo: Design thinking, explained https://t.co/rb8dJU2Pmi",
        "user.screen_name": "D_ThoughtLeader"
    },
    {
        "created_at": "Sun Feb 11 23:26:50 +0000 2018",
        "id": 962830316841963521,
        "text": "Instead of doing the same thing you always do, read this a piece Humanyze CEO and co-founder and MIT Media Lab visi\u2026 https://t.co/fpf4gd28mV",
        "user.screen_name": "NetworkingPhx"
    },
    {
        "created_at": "Sun Feb 11 23:26:01 +0000 2018",
        "id": 962830108745719809,
        "text": "Design thinking, explained https://t.co/rb8dJU2Pmi",
        "user.screen_name": "DeSantisMarcelo"
    },
    {
        "created_at": "Sun Feb 11 23:26:00 +0000 2018",
        "id": 962830107797835776,
        "text": "RT @deeplearning4j: Pace Layering: How Complex Systems Learn and Keep Learning https://t.co/XysTbEoVZG",
        "user.screen_name": "homeAIinfo"
    },
    {
        "created_at": "Sun Feb 11 23:26:00 +0000 2018",
        "id": 962830106908643330,
        "text": "RT @MITSloan: Integrating analytics is crucial. Start with these 8 articles. https://t.co/3hxWVgHY9q",
        "user.screen_name": "MrLuckyClover"
    },
    {
        "created_at": "Sun Feb 11 23:25:38 +0000 2018",
        "id": 962830012691857408,
        "text": "#science #technology #News &gt;&gt;  href=\"https://t.co/R1sDHyBZPq\"&gt;MIT Initiative on the Digital ... For More LIKE &amp; FOLLOW @JPPMsolutions",
        "user.screen_name": "JPPMsolutions"
    },
    {
        "created_at": "Sun Feb 11 23:25:37 +0000 2018",
        "id": 962830011282739200,
        "text": "RT @skymindio: Pace Layering: How Complex Systems Learn and Keep Learning https://t.co/BneRsa2frY",
        "user.screen_name": "AdaptToReality"
    },
    {
        "created_at": "Sun Feb 11 23:25:31 +0000 2018",
        "id": 962829983390380032,
        "text": "@QuixotesHorse @MartinLarner @ni_treasa @ClintWarren6 @mapon888 @Genghis_McCann @RenieriArts @VanessaBeeley\u2026 https://t.co/TDgtujmPYb",
        "user.screen_name": "taigstaigs"
    },
    {
        "created_at": "Sun Feb 11 23:25:09 +0000 2018",
        "id": 962829892076187649,
        "text": "RT @JackedYoTweets: How the club owner must look at the birthday girl who is there celebrating her 21st but has been a regular at the club\u2026",
        "user.screen_name": "Mit_ch_ell"
    },
    {
        "created_at": "Sun Feb 11 23:25:06 +0000 2018",
        "id": 962829880554475520,
        "text": "Pace Layering: How Complex Systems Learn and Keep Learning \n(Discussion on HN - https://t.co/GLTyLa8VgB) https://t.co/xpV0Omaq0n",
        "user.screen_name": "hnbot"
    },
    {
        "created_at": "Sun Feb 11 23:25:05 +0000 2018",
        "id": 962829875634671616,
        "text": "Ein #sehr sexy Casting mit Stacey #fhmzmjkt https://t.co/5IeueYkDmE",
        "user.screen_name": "allen_allen9116"
    },
    {
        "created_at": "Sun Feb 11 23:25:04 +0000 2018",
        "id": 962829870723190784,
        "text": "RT @judah47: \"Records are meant to be broken\" new all time record set in poleward #heat transport into the #polar stratosphere.Increasing t\u2026",
        "user.screen_name": "MindOfAn_Empath"
    },
    {
        "created_at": "Sun Feb 11 23:24:58 +0000 2018",
        "id": 962829844957618176,
        "text": "Men's Volleyball Outlasted By MIT In Five Set UVC Matchup  https://t.co/ChyxbIlxuh",
        "user.screen_name": "FisherAthletics"
    },
    {
        "created_at": "Sun Feb 11 23:24:21 +0000 2018",
        "id": 962829690015834113,
        "text": "POLICY INNOVATION GAI/BASIC INCOME @AndrewYangVFA @kevinroose @erikbryn @MIT_IDE https://t.co/nY9i0QPAt7 on the iss\u2026 https://t.co/v7EY29Kqjr",
        "user.screen_name": "jimdewilde"
    },
    {
        "created_at": "Sun Feb 11 23:24:14 +0000 2018",
        "id": 962829660248793088,
        "text": "#Sexualtherapie mit #der #Psychologe Shanda #Fay #mwpkhnic https://t.co/3aduqyi3q8",
        "user.screen_name": "christy31633198"
    },
    {
        "created_at": "Sun Feb 11 23:23:13 +0000 2018",
        "id": 962829406933667840,
        "text": "\"Facial recognition technology is subject to biases based on the data sets provided and the conditions in which alg\u2026 https://t.co/guq26mzW5a",
        "user.screen_name": "doublejrecords"
    },
    {
        "created_at": "Sun Feb 11 23:22:56 +0000 2018",
        "id": 962829335928459264,
        "text": "Should I go to MIT now? \ud83d\ude02",
        "user.screen_name": "Applezap42"
    },
    {
        "created_at": "Sun Feb 11 23:22:34 +0000 2018",
        "id": 962829241145585664,
        "text": "RT @StanM3: Germany- Afghan(19) stabbed his ex-girlfriend(23) in the shoulder and fled. The police had been called because of domestic viol\u2026",
        "user.screen_name": "aaaadam75"
    },
    {
        "created_at": "Sun Feb 11 23:22:22 +0000 2018",
        "id": 962829193703841792,
        "text": "@ashleylynne4 Cause that's annoying \ud83d\ude02\ud83d\ude02 get out my damn mit",
        "user.screen_name": "amayaaa_j"
    },
    {
        "created_at": "Sun Feb 11 23:21:44 +0000 2018",
        "id": 962829031954673664,
        "text": "Pace Layering: How Complex Systems Learn and Keep Learning https://t.co/XysTbEoVZG",
        "user.screen_name": "deeplearning4j"
    },
    {
        "created_at": "Sun Feb 11 23:21:44 +0000 2018",
        "id": 962829031728123905,
        "text": "Pace Layering: How Complex Systems Learn and Keep Learning https://t.co/BneRsa2frY",
        "user.screen_name": "skymindio"
    },
    {
        "created_at": "Sun Feb 11 23:21:37 +0000 2018",
        "id": 962829004167401472,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "suprmrkt"
    },
    {
        "created_at": "Sun Feb 11 23:21:37 +0000 2018",
        "id": 962829001105358848,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/fQ1IKfcpVW\u2026",
        "user.screen_name": "KristiAlvarad0"
    },
    {
        "created_at": "Sun Feb 11 23:21:20 +0000 2018",
        "id": 962828929928118272,
        "text": "SUPERDRY Angebote Superdry Premium Goods Tri-Fade T-Shirt: Category: Damen / T-Shirts / T-Shirt mit Print Item numb\u2026 https://t.co/ICljsrnlOm",
        "user.screen_name": "SparVolltreffer"
    },
    {
        "created_at": "Sun Feb 11 23:21:18 +0000 2018",
        "id": 962828924303659014,
        "text": "RT @LaughOutNOW: \"RU or UR FUNNY FRIEND HBO WORTHY?\" (Gift idea) https://t.co/h2QGPHTOFs #minneapolis #kuwtk #teenmom2 #lifeofkyle #califor\u2026",
        "user.screen_name": "MilwaukeeHotBuy"
    },
    {
        "created_at": "Sun Feb 11 23:21:05 +0000 2018",
        "id": 962828868397789184,
        "text": "Facial recognition software is biased towards white men, researcher finds - New research out of MIT\u2019s Media Lab... https://t.co/D5YgJdKECq",
        "user.screen_name": "YouBrandInc"
    },
    {
        "created_at": "Sun Feb 11 23:20:59 +0000 2018",
        "id": 962828841789132800,
        "text": "\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\"Ed Sheeran\"\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\n\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0dmit\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\ud83d\ude0d\u2026 https://t.co/82dLGaetjC",
        "user.screen_name": "_ronny_14"
    },
    {
        "created_at": "Sun Feb 11 23:20:51 +0000 2018",
        "id": 962828809056673793,
        "text": "RT @DLoesch: \u201cFlashing smiles outflanking,\u201d \u201ccaptivates people,\u201d \u201cstealing the show,\u201d North Korea didn\u2019t have to hire PR to rehabilitate it\u2026",
        "user.screen_name": "mit_baggs"
    },
    {
        "created_at": "Sun Feb 11 23:20:46 +0000 2018",
        "id": 962828790199144448,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "afromusing"
    },
    {
        "created_at": "Sun Feb 11 23:19:17 +0000 2018",
        "id": 962828417304596487,
        "text": "wow god bless mit open courseware for having compsci courses because I really need to brush up on everything before\u2026 https://t.co/TUyR0B7lW5",
        "user.screen_name": "_hannabal_"
    },
    {
        "created_at": "Sun Feb 11 23:18:58 +0000 2018",
        "id": 962828334680936449,
        "text": "RT @scratch: Scratch Days can be large or small, for beginners and for more experienced Scratchers. Find a Scratch Day in your community, o\u2026",
        "user.screen_name": "johnmaeda"
    },
    {
        "created_at": "Sun Feb 11 23:18:48 +0000 2018",
        "id": 962828294524669952,
        "text": "RT @medical_xpress: Study identifies neurons that fire at the beginning and end of a #behavior as it becomes a #habit @MIT @currentbiology\u2026",
        "user.screen_name": "GuiltFreeTips"
    },
    {
        "created_at": "Sun Feb 11 23:18:43 +0000 2018",
        "id": 962828273460961281,
        "text": "RT @Carlos_E_Goico: How an analytics-based predictive model can improve kidney transplant survival rates https://t.co/1lnNPohQa8",
        "user.screen_name": "Red_IDi"
    },
    {
        "created_at": "Sun Feb 11 23:18:34 +0000 2018",
        "id": 962828234583879680,
        "text": "RT @BAP_US: Dr. #ShirleyJackson the first African-American woman to have earned a doctorate at the MIT.\n\n#BlackAndProud #BlackWomen #BlackE\u2026",
        "user.screen_name": "xzppaddy"
    },
    {
        "created_at": "Sun Feb 11 23:18:25 +0000 2018",
        "id": 962828196180910080,
        "text": "RT @mitsmr: RT @MITSloan: There actually are enough hours in the day. Get more out of them with these 7 productivity tips from @Pozen. http\u2026",
        "user.screen_name": "katie350501"
    },
    {
        "created_at": "Sun Feb 11 23:18:08 +0000 2018",
        "id": 962828124504428545,
        "text": "RT @BenjaminTseng: The remarkable career of Shirley Ann Jackson: first African-American woman to earn a PhD from MIT, chair of US NRC under\u2026",
        "user.screen_name": "RMilesMD"
    },
    {
        "created_at": "Sun Feb 11 23:17:51 +0000 2018",
        "id": 962828056497938436,
        "text": "How an analytics-based predictive model can improve kidney transplant survival rates https://t.co/1lnNPohQa8",
        "user.screen_name": "Carlos_E_Goico"
    },
    {
        "created_at": "Sun Feb 11 23:17:28 +0000 2018",
        "id": 962827960309993472,
        "text": "@DPolGBerlin leckere Curry mit Darm ;)\n\nStay safe!",
        "user.screen_name": "GPRealomon"
    },
    {
        "created_at": "Sun Feb 11 23:17:26 +0000 2018",
        "id": 962827950008696834,
        "text": "RT @econromesh: Empirical, tightly focused studies of trade &amp; development - overview of research by David Atkin @MITEcon, #WhatEconomistsRe\u2026",
        "user.screen_name": "arthurbraganca7"
    },
    {
        "created_at": "Sun Feb 11 23:17:07 +0000 2018",
        "id": 962827868966330368,
        "text": "RT @takis_metaxas: Can\u2019t wait to read Artificial Unintelligence by @merbroussard. We need to think about her perspective. https://t.co/H0Wh\u2026",
        "user.screen_name": "LUtang_Secret"
    },
    {
        "created_at": "Sun Feb 11 23:17:02 +0000 2018",
        "id": 962827848494010368,
        "text": "RT @mitsmr: RT @joannecanderson: How to achieve \"extreme #productivity\" from @mitsmr  : \"Hours are a traditional way of tracking employee p\u2026",
        "user.screen_name": "CountryStar72"
    },
    {
        "created_at": "Sun Feb 11 23:16:59 +0000 2018",
        "id": 962827835466567681,
        "text": "Facial recognition software is biased towards white men, researcher finds. https://t.co/JeztqmKOSG",
        "user.screen_name": "LivesInThought"
    },
    {
        "created_at": "Sun Feb 11 23:16:51 +0000 2018",
        "id": 962827802675326976,
        "text": "RT @IainLJBrown: Facial recognition software is biased towards white men, researcher finds https://t.co/T61FBRudfs https://t.co/fQ1IKfcpVW\u2026",
        "user.screen_name": "CarrieH3nry"
    },
    {
        "created_at": "Sun Feb 11 23:16:51 +0000 2018",
        "id": 962827802469945345,
        "text": "RT @FiveRights: Laura Ingraham on Fox: Why did George W. Bush refuse to criticize Obama even when O screwed up badly but he often criticize\u2026",
        "user.screen_name": "AutumndiPace1"
    },
    {
        "created_at": "Sun Feb 11 23:16:50 +0000 2018",
        "id": 962827800171499522,
        "text": "RT @GrrrGraphics: \"In the Head of Hillary\" #BenGarrison #cartoon \nSomeone asked me why I draw so many #Obama &amp; #Hillary cartoons. \nread mor\u2026",
        "user.screen_name": "JStiverson13"
    },
    {
        "created_at": "Sun Feb 11 23:16:50 +0000 2018",
        "id": 962827799927996417,
        "text": "RT @captcapt1234: The Great Experiment                   \u2018Narional Review\u2019                             https://t.co/zxEmpmWWTZ",
        "user.screen_name": "LindaKight64"
    },
    {
        "created_at": "Sun Feb 11 23:16:50 +0000 2018",
        "id": 962827798888009728,
        "text": "RT @JessieJaneDuff: DHS official &amp; former Obama ambassador James Nealon resigned, upset recommendations to extend \u201ctemporary protected stat\u2026",
        "user.screen_name": "JaniceTXBlessed"
    },
    {
        "created_at": "Sun Feb 11 23:16:50 +0000 2018",
        "id": 962827797566812166,
        "text": "@rejialex7 Let them stay in tbe UK, sorry obama your wish 4 the invasion of AMERICA is on hold",
        "user.screen_name": "kochtb606"
    },
    {
        "created_at": "Sun Feb 11 23:16:49 +0000 2018",
        "id": 962827796233023489,
        "text": "@BonneauGenie NAW YOU ENJOY, I DEPEND ON ME\nNOT DEMOCRATS.\nAND YO MOUTH BIG \nSO QUICK TO THINK I'M GULLIBLE, YOU'RE\u2026 https://t.co/J7vf2hIqjS",
        "user.screen_name": "Fleetwoodmack3"
    },
    {
        "created_at": "Sun Feb 11 23:16:49 +0000 2018",
        "id": 962827795213594624,
        "text": "Solve For \"X\": A comparison of X under Obama and Trump during the same period in their presidencies shows better pe\u2026 https://t.co/Grt8a5C4el",
        "user.screen_name": "PaulHRosenberg"
    },
    {
        "created_at": "Sun Feb 11 23:16:49 +0000 2018",
        "id": 962827793926107137,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "RustyMayeux"
    },
    {
        "created_at": "Sun Feb 11 23:16:49 +0000 2018",
        "id": 962827793850494977,
        "text": "@adamcbest @PaulStewartII The GOP will blame the left and/or Hillary, Obama, etc. for all of their faults and f*kup\u2026 https://t.co/j8hDVaKtkC",
        "user.screen_name": "QuancyClayborne"
    },
    {
        "created_at": "Sun Feb 11 23:16:49 +0000 2018",
        "id": 962827793108107264,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "hwfranzjr"
    },
    {
        "created_at": "Sun Feb 11 23:16:48 +0000 2018",
        "id": 962827792382681090,
        "text": "RT @GRYKING: WHAAAAAAAT?!!?! Obama grew a beard? https://t.co/V1mzrDcrYy",
        "user.screen_name": "jps521"
    },
    {
        "created_at": "Sun Feb 11 23:16:48 +0000 2018",
        "id": 962827791854170112,
        "text": "RT @clivebushjd: Take a look what Democrats, Neocons &amp; RINOs have done to America\n\nWe must #DeportDreamers #EndChainMigration &amp; #BuildTheWa\u2026",
        "user.screen_name": "jeangalvanonly"
    },
    {
        "created_at": "Sun Feb 11 23:16:48 +0000 2018",
        "id": 962827791111684098,
        "text": "@JBitterly @mikebloodworth @realDonaldTrump Says who? One pollster that consistently leans R by a significant amoun\u2026 https://t.co/0SUGxaRNjl",
        "user.screen_name": "JustAPerson83"
    },
    {
        "created_at": "Sun Feb 11 23:16:48 +0000 2018",
        "id": 962827791019446274,
        "text": "RT @robjh1: For all the doubters Obama gave us this picture after an imaginary line in the sand was trounced by Syria. Naturally, to a larg\u2026",
        "user.screen_name": "LoriJac47135906"
    },
    {
        "created_at": "Sun Feb 11 23:16:48 +0000 2018",
        "id": 962827789866061825,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "lucas_glenn"
    },
    {
        "created_at": "Sun Feb 11 23:16:48 +0000 2018",
        "id": 962827789656363013,
        "text": "RT @RealJack: It\u2019s not looking good for the Democrats.\n\nPOLL: Majority of Americans Believe Obama SPIED on Trump Campaign https://t.co/dC30\u2026",
        "user.screen_name": "mcowgerFL"
    },
    {
        "created_at": "Sun Feb 11 23:16:47 +0000 2018",
        "id": 962827788435841025,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "Kimmy2858"
    },
    {
        "created_at": "Sun Feb 11 23:16:47 +0000 2018",
        "id": 962827788314034176,
        "text": "@FoxNews @McDonalds This started happening when Barack Obama was elected president. He said he would fundamentally\u2026 https://t.co/bzY3thWKEw",
        "user.screen_name": "crash99502"
    },
    {
        "created_at": "Sun Feb 11 23:16:47 +0000 2018",
        "id": 962827785843638277,
        "text": "RT @DorothyYonker: I don't think the President can unseal Obama's records but if Obama is charged with a crime, A/G Sessions could.  I may\u2026",
        "user.screen_name": "BrockXerox"
    },
    {
        "created_at": "Sun Feb 11 23:16:47 +0000 2018",
        "id": 962827784728072192,
        "text": "This is the ultra bizarre that is right wing Fox. no matter how nonsensical if they can put Obama's name (or Clinto\u2026 https://t.co/JCQNSrRAFQ",
        "user.screen_name": "leejcaroll"
    },
    {
        "created_at": "Sun Feb 11 23:16:46 +0000 2018",
        "id": 962827784178618369,
        "text": "RT @Imperator_Rex3: Important thread focussing on how the criminals used a foreign intelligence service (GCHQ) to inject the dodgy dossier\u2026",
        "user.screen_name": "DaisyClover4"
    },
    {
        "created_at": "Sun Feb 11 23:16:46 +0000 2018",
        "id": 962827782853185536,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "c_millerhorton"
    },
    {
        "created_at": "Sun Feb 11 23:16:46 +0000 2018",
        "id": 962827782848991232,
        "text": "RT @FiveRights: For 5 years Obama couldn't stop ISIS, couldn't even contain them.\nTrump, w same military, wiped out ISIS in 9 mos.\nO wasn't\u2026",
        "user.screen_name": "IBumbybee"
    },
    {
        "created_at": "Sun Feb 11 23:16:46 +0000 2018",
        "id": 962827781771091968,
        "text": "RT @Hoosiers1986: #FakeRelationshipFacts\n\nDEM voters are gullible fools!\n\nThey revere idiots like Obama, Schumer &amp; Pelosi who COULD have pr\u2026",
        "user.screen_name": "Riff_Raff45"
    },
    {
        "created_at": "Sun Feb 11 23:16:46 +0000 2018",
        "id": 962827781661962240,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "lety_xo"
    },
    {
        "created_at": "Sun Feb 11 23:16:46 +0000 2018",
        "id": 962827781326430208,
        "text": "RT @fubaglady: How Obama\u2019s Hillary Clinton cover-ups destroyed DOJ and FBI https://t.co/26KPBHmpyz",
        "user.screen_name": "Pando18483"
    },
    {
        "created_at": "Sun Feb 11 23:16:45 +0000 2018",
        "id": 962827779992576000,
        "text": "@jfreewright @JudgeJeanine WTF?? so it's Obama's fault that Porter abused his wife???\ud83d\ude44\n\nWhen I wake up each day &amp; s\u2026 https://t.co/VBfU2M2Rgp",
        "user.screen_name": "bunnyhuggr"
    },
    {
        "created_at": "Sun Feb 11 23:16:45 +0000 2018",
        "id": 962827779803824128,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "Mskifast"
    },
    {
        "created_at": "Sun Feb 11 23:16:45 +0000 2018",
        "id": 962827776595320833,
        "text": "RT @ErrBodyLuvsCris: Honorable mentions:\n\u2022 Mo\u2019Nique\n\u2022 Drinking Water \n\u2022 Black Panther \n\u2022 Why black owned businesses fail \n\u2022 Obama\n\u2022 False a\u2026",
        "user.screen_name": "hanifipuffs06"
    },
    {
        "created_at": "Sun Feb 11 23:16:44 +0000 2018",
        "id": 962827775227957248,
        "text": "@DWCDroneGuy @4everNeverTrump @GothamKnight05 Obama couldn't have competed with Melania anyway!! https://t.co/FcCNODEwmB",
        "user.screen_name": "rlbmcb14"
    },
    {
        "created_at": "Sun Feb 11 23:16:44 +0000 2018",
        "id": 962827774359691264,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "erconger"
    },
    {
        "created_at": "Sun Feb 11 23:16:44 +0000 2018",
        "id": 962827773810237440,
        "text": "RT @KarenThomasson1: @Johnpdca More so than Obama's college records and birth certificate, I'd like to see all of his acts of treason revea\u2026",
        "user.screen_name": "BJCollins131"
    },
    {
        "created_at": "Sun Feb 11 23:16:44 +0000 2018",
        "id": 962827773126602753,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "diciembre_tres_"
    },
    {
        "created_at": "Sun Feb 11 23:16:44 +0000 2018",
        "id": 962827773030125568,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "vickiha08202081"
    },
    {
        "created_at": "Sun Feb 11 23:16:44 +0000 2018",
        "id": 962827772879101953,
        "text": "@DonaldJTrumpJr The guy really shocked is Obama ...that we found out.",
        "user.screen_name": "AlexPeresviet"
    },
    {
        "created_at": "Sun Feb 11 23:16:44 +0000 2018",
        "id": 962827772774187008,
        "text": "My new waffle maker arrived today. Went out and got some waffle mix and chocolate chips. When I got home the electr\u2026 https://t.co/JNUifSSQLC",
        "user.screen_name": "Gregg25Gelzinis"
    },
    {
        "created_at": "Sun Feb 11 23:16:43 +0000 2018",
        "id": 962827771973120000,
        "text": "RT @MJoemal19: @ObozoLies  2011: Why Iran's capture of US drone will shake CIA https://t.co/3PVqMWjGKZ #CIA #Obama #NationalSecurity",
        "user.screen_name": "ObozoLies"
    },
    {
        "created_at": "Sun Feb 11 23:16:43 +0000 2018",
        "id": 962827770291281920,
        "text": "RT @Pink_About_it: The real question about fake dossier is not IF #Fisa warrant is now a widely known retroactive cover up, but rather, wha\u2026",
        "user.screen_name": "DecosterGina"
    },
    {
        "created_at": "Sun Feb 11 23:16:43 +0000 2018",
        "id": 962827769611739136,
        "text": "@DonaldJTrumpJr Obama got caught paying the Terrorist on his payroll. Now what?",
        "user.screen_name": "mjtullo64"
    },
    {
        "created_at": "Sun Feb 11 23:16:43 +0000 2018",
        "id": 962827769355763712,
        "text": "RT @KrisParonto: We also didn\u2019t use the @FBI @CIA and @NSAGov to spy on @realDonaldTrump either.......isn\u2019t that what you said to Chris Wal\u2026",
        "user.screen_name": "hwfranzjr"
    },
    {
        "created_at": "Sun Feb 11 23:16:43 +0000 2018",
        "id": 962827769318064128,
        "text": "@A_BettyD What facts have you stated? I cannot find any. I understand your predicament. You hate Trump, but he is m\u2026 https://t.co/b6GjElMmMt",
        "user.screen_name": "Patr4915"
    },
    {
        "created_at": "Sun Feb 11 23:16:42 +0000 2018",
        "id": 962827767200010241,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "blacklabapril23"
    },
    {
        "created_at": "Sun Feb 11 23:16:42 +0000 2018",
        "id": 962827766117883904,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "StephMcMurphy"
    },
    {
        "created_at": "Sun Feb 11 23:16:41 +0000 2018",
        "id": 962827763286728704,
        "text": "RT @theinquisitr: New Poll Finds Many Americans Think Obama Administration \u2018Improperly\u2019 Spied On Trump Campaign. Many survey respondents ar\u2026",
        "user.screen_name": "letsplay2of3"
    },
    {
        "created_at": "Sun Feb 11 23:16:41 +0000 2018",
        "id": 962827761944530944,
        "text": "RT @Education4Libs: Obama\u2019s election was the worst thing to ever happen to this country. \n\nTrump\u2019s election was the best.\n\nWe now have a gr\u2026",
        "user.screen_name": "nitesky56"
    },
    {
        "created_at": "Sun Feb 11 23:16:41 +0000 2018",
        "id": 962827761747419136,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "sdmack"
    },
    {
        "created_at": "Sun Feb 11 23:16:41 +0000 2018",
        "id": 962827761185378304,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "billybong79"
    },
    {
        "created_at": "Sun Feb 11 23:16:40 +0000 2018",
        "id": 962827759037960192,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "MariaMexs"
    },
    {
        "created_at": "Sun Feb 11 23:16:40 +0000 2018",
        "id": 962827758924529664,
        "text": "RT @clivebushjd: Take a look what Democrats, Neocons &amp; RINOs have done to America\n\nWe must #DeportDreamers #EndChainMigration &amp; #BuildTheWa\u2026",
        "user.screen_name": "ElisAmerica1"
    },
    {
        "created_at": "Sun Feb 11 23:16:40 +0000 2018",
        "id": 962827758723313665,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "_strate"
    },
    {
        "created_at": "Sun Feb 11 23:16:40 +0000 2018",
        "id": 962827757737558016,
        "text": "RT @MplsMe: Wall can't stop MS-13 because it started in Los Angeles, and is well-established in US. Many US citizens are members. Wall won'\u2026",
        "user.screen_name": "sherry_bath"
    },
    {
        "created_at": "Sun Feb 11 23:16:40 +0000 2018",
        "id": 962827757628608513,
        "text": "RT @Patbagley: Let's keep in mind Obama had scandals early on in his administration https://t.co/qjp2XQDU2s",
        "user.screen_name": "cy_yenke"
    },
    {
        "created_at": "Sun Feb 11 23:16:40 +0000 2018",
        "id": 962827756768653312,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "TotalBroadcast"
    },
    {
        "created_at": "Sun Feb 11 23:16:39 +0000 2018",
        "id": 962827755149705216,
        "text": "RT @AZjbc: They are Alinskey Tactics!!  Chicago's Finest Barack Obama! Student of Marxist Agenda...Hard 2 Believe Half of the Country Just\u2026",
        "user.screen_name": "Anak72297161"
    },
    {
        "created_at": "Sun Feb 11 23:16:39 +0000 2018",
        "id": 962827754076033024,
        "text": "RT @EntheosShines: Source: Obama Fears #MuslimBrotherhood &amp; CAIR Link to Downing of Russian Airliner @MattJAnder @CathyTo47590555 https://t\u2026",
        "user.screen_name": "JamesGoodall17"
    },
    {
        "created_at": "Sun Feb 11 23:16:39 +0000 2018",
        "id": 962827752566087681,
        "text": "RT @KrisParonto: We also didn\u2019t use the @FBI @CIA and @NSAGov to spy on @realDonaldTrump either.......isn\u2019t that what you said to Chris Wal\u2026",
        "user.screen_name": "bkgroh"
    },
    {
        "created_at": "Sun Feb 11 23:16:39 +0000 2018",
        "id": 962827751668568065,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "Zenaphobe"
    },
    {
        "created_at": "Sun Feb 11 23:16:39 +0000 2018",
        "id": 962827751400058885,
        "text": "RT @EdKrassen: @IRdotnet @realDonaldTrump You have been falsely accusing the Democrats, Hillary, Obama, and just anyone else who doesn't ag\u2026",
        "user.screen_name": "Sandy24689844"
    },
    {
        "created_at": "Sun Feb 11 23:16:38 +0000 2018",
        "id": 962827750921981952,
        "text": "RT @MRSSMH2: No, sweetie. No one sat on twitter defending Obama 24 hours a day the way Trump morons do. Look at yourselves. You\u2019re still at\u2026",
        "user.screen_name": "Barkforlove1"
    },
    {
        "created_at": "Sun Feb 11 23:16:38 +0000 2018",
        "id": 962827749936324608,
        "text": "@MRSSMH2 @TomiLahren Then you are totally blind and you slept through the Obama presidency! The left along with the\u2026 https://t.co/zOu30GfEsE",
        "user.screen_name": "RickBrown3440"
    },
    {
        "created_at": "Sun Feb 11 23:16:38 +0000 2018",
        "id": 962827749164486656,
        "text": "@Amy_Siskind This is actually hilarious, considering the Pres. Obama targeted journalists, spied on American citize\u2026 https://t.co/XjhJmQKUaB",
        "user.screen_name": "account_redact"
    },
    {
        "created_at": "Sun Feb 11 23:16:38 +0000 2018",
        "id": 962827747943829505,
        "text": "RT @Bakari_Sellers: Fox News viewers believe its Obama\u2019s fault Rob Porter beat his wives. https://t.co/5y8wPzWLOu",
        "user.screen_name": "seraphimmoon13"
    },
    {
        "created_at": "Sun Feb 11 23:16:38 +0000 2018",
        "id": 962827747491016705,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "moonbeam_0416"
    },
    {
        "created_at": "Sun Feb 11 23:16:38 +0000 2018",
        "id": 962827747209990144,
        "text": "RT @JudicialWatch: As part of our effort to hold Mueller's investigation accountable, JW uncovered docs showing top DOJ officials including\u2026",
        "user.screen_name": "rosdel128"
    },
    {
        "created_at": "Sun Feb 11 23:16:37 +0000 2018",
        "id": 962827745553088513,
        "text": "RT @bellaace52: @realDonaldTrump Not Obama!!!! His rein had no problems at all.  Obama was a shinning light in a world of darkness.  Here\u2019s\u2026",
        "user.screen_name": "AxelrodLorin"
    },
    {
        "created_at": "Sun Feb 11 23:16:36 +0000 2018",
        "id": 962827742625632257,
        "text": "@dan11thhour Obama and his handlers pulled off a world-wide coup.  Not just the U.S. and Canada.  S. America is seeing this also.",
        "user.screen_name": "gttbotl"
    },
    {
        "created_at": "Sun Feb 11 23:16:36 +0000 2018",
        "id": 962827741820280832,
        "text": "RT @joncoopertweets: Sure, @realDonaldTrump is a lying, corrupt, racist, traitorous imbecile who defends white supremacists, Nazis, wife be\u2026",
        "user.screen_name": "future_md23"
    },
    {
        "created_at": "Sun Feb 11 23:16:36 +0000 2018",
        "id": 962827740901715968,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "flip_flopps"
    },
    {
        "created_at": "Sun Feb 11 23:16:36 +0000 2018",
        "id": 962827740129869824,
        "text": "Obama Official: I Passed Clinton Lies to Steele That Were Used Against Trump.A top State Department official who se\u2026 https://t.co/uwW0qV10zy",
        "user.screen_name": "Lanchr4"
    },
    {
        "created_at": "Sun Feb 11 23:16:36 +0000 2018",
        "id": 962827738682978305,
        "text": "RT @TeaPainUSA: FUN FACTS:  DACA was established by the Obama Administration in June 2012 and RESCINDED by the Trump Administration in Sept\u2026",
        "user.screen_name": "KimEbeth"
    },
    {
        "created_at": "Sun Feb 11 23:16:35 +0000 2018",
        "id": 962827735138750465,
        "text": "RT @Owens4996: @MichelleObama You are awesome, many of us miss you and President Obama everyday! \u2764\ufe0f\u2764\ufe0f\u2764\ufe0f",
        "user.screen_name": "TimminsRealtor"
    },
    {
        "created_at": "Sun Feb 11 23:16:35 +0000 2018",
        "id": 962827734979289088,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "xoaleenah"
    },
    {
        "created_at": "Sun Feb 11 23:16:34 +0000 2018",
        "id": 962827733276545024,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "lakemichigangal"
    },
    {
        "created_at": "Sun Feb 11 23:16:34 +0000 2018",
        "id": 962827732932485120,
        "text": "RT @NevadaJack2: American Public Opinion Finally Turns on Obama Administration... \"Overwhelmingly\" https://t.co/i7LRoJ5lZc",
        "user.screen_name": "BillWes76233793"
    },
    {
        "created_at": "Sun Feb 11 23:16:34 +0000 2018",
        "id": 962827731753877504,
        "text": "RT @Chicago1Ray: \" You, me... we own this Country. Politicians are employees of ours. And when somebody doesn't do the Job, We gotta let 'e\u2026",
        "user.screen_name": "TheRose50302638"
    },
    {
        "created_at": "Sun Feb 11 23:16:33 +0000 2018",
        "id": 962827727861637120,
        "text": "@TheStarsFan @realDonaldTrump QE happened under Obama. Fed moves were dictated by his policy so I don't see how tha\u2026 https://t.co/l6Rpd95c1a",
        "user.screen_name": "nickrock23"
    },
    {
        "created_at": "Sun Feb 11 23:16:33 +0000 2018",
        "id": 962827726267789312,
        "text": "RT @SusanStormXO: @hatedtruthpig77 @Ann_B_Barber @wolfgangfaustX Burns me Up \ud83d\udd25\ud83d\udd25\nHow do we have people in America that are condoning this !\u2026",
        "user.screen_name": "DagnyRed"
    },
    {
        "created_at": "Sun Feb 11 23:16:32 +0000 2018",
        "id": 962827725189894144,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "sixthgentexan"
    },
    {
        "created_at": "Sun Feb 11 23:16:31 +0000 2018",
        "id": 962827720542605314,
        "text": "RT @TuckerCarlson: Here's what is clear right now, the bottom line on what we've learned this week and the one thing worth remembering: The\u2026",
        "user.screen_name": "MorgannaMorales"
    },
    {
        "created_at": "Sun Feb 11 23:16:31 +0000 2018",
        "id": 962827720009900032,
        "text": "@thehill Watergate reporter: We've never had a president who lies like @realDonaldTrump and Americans never will be\u2026 https://t.co/4CbbGPaZdo",
        "user.screen_name": "MikeAE35"
    },
    {
        "created_at": "Sun Feb 11 23:16:30 +0000 2018",
        "id": 962827717413568515,
        "text": "@realDonaldTrump Thank you Mr. President for standing up for American values and beliefs!!  I am proud to support y\u2026 https://t.co/OX41abJ2Mk",
        "user.screen_name": "striperbassman"
    },
    {
        "created_at": "Sun Feb 11 23:16:30 +0000 2018",
        "id": 962827716780331009,
        "text": "RT @FiveRights: For 5 years Obama couldn't stop ISIS, couldn't even contain them.\nTrump, w same military, wiped out ISIS in 9 mos.\nO wasn't\u2026",
        "user.screen_name": "marinebrothers1"
    },
    {
        "created_at": "Sun Feb 11 23:16:30 +0000 2018",
        "id": 962827716323041280,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "CyndieHarris"
    },
    {
        "created_at": "Sun Feb 11 23:16:30 +0000 2018",
        "id": 962827714066571264,
        "text": "RT @Brasilmagic: Jeanine Pirro needs a straight-jacket  https://t.co/G4wzGBUJ0b",
        "user.screen_name": "eugeniad26"
    },
    {
        "created_at": "Sun Feb 11 23:16:29 +0000 2018",
        "id": 962827712825036803,
        "text": "RT @EdwardTHardy: Donald Trump spent years spreading the false allegation that Barack Obama was not born in the US https://t.co/d0XiP8l2yI",
        "user.screen_name": "LatonaDawn"
    },
    {
        "created_at": "Sun Feb 11 23:16:29 +0000 2018",
        "id": 962827711939936257,
        "text": "RT @DineshDSouza: There is more proof to date that Obama\u2014not Trump\u2014tried to rig the 2016 election. Let the truth come out &amp; hold the guilty\u2026",
        "user.screen_name": "AshleyEdam"
    },
    {
        "created_at": "Sun Feb 11 23:16:29 +0000 2018",
        "id": 962827711214272512,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "Rayr63"
    },
    {
        "created_at": "Sun Feb 11 23:16:29 +0000 2018",
        "id": 962827709272526849,
        "text": "RT @MplsMe: Wall can't stop MS-13 because it started in Los Angeles, and is well-established in US. Many US citizens are members. Wall won'\u2026",
        "user.screen_name": "mdfazende"
    },
    {
        "created_at": "Sun Feb 11 23:16:28 +0000 2018",
        "id": 962827708794396672,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "GourleyEwing"
    },
    {
        "created_at": "Sun Feb 11 23:16:28 +0000 2018",
        "id": 962827707921944576,
        "text": "@RCdeWinter them the White House with the help of Putin and friends. Now, tRUMP has the whole lot of the GOP over a\u2026 https://t.co/O5wePkKKzD",
        "user.screen_name": "giantdave1"
    },
    {
        "created_at": "Sun Feb 11 23:16:28 +0000 2018",
        "id": 962827707020140544,
        "text": "RT @Bakari_Sellers: Fox News viewers believe its Obama\u2019s fault Rob Porter beat his wives. https://t.co/5y8wPzWLOu",
        "user.screen_name": "BitterSaltiness"
    },
    {
        "created_at": "Sun Feb 11 23:16:28 +0000 2018",
        "id": 962827706810413056,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "rightyfrommont"
    },
    {
        "created_at": "Sun Feb 11 23:16:28 +0000 2018",
        "id": 962827705610842112,
        "text": "RT @DonnaWR8: In addition to removing ALL pagan and demonic items from the Obama and Clinton years at the White House, Pastor Paul Begley s\u2026",
        "user.screen_name": "Sherry_Bass"
    },
    {
        "created_at": "Sun Feb 11 23:16:27 +0000 2018",
        "id": 962827704562274304,
        "text": "RT @GeorgiaDirtRoad: Eric Holder is thinking of running  for president... He was Obama\u2019s lap dog &amp; now wants to be the next clown to run fo\u2026",
        "user.screen_name": "Esthersaved12"
    },
    {
        "created_at": "Sun Feb 11 23:16:27 +0000 2018",
        "id": 962827703098454017,
        "text": "RT @MEMLiberal: .@JudgeJeanine Pirro brilliantly pins the blame for the #RobPorter fiasco where it belongs. On Barack Obama.\n\nIn other news\u2026",
        "user.screen_name": "hoover913"
    },
    {
        "created_at": "Sun Feb 11 23:16:27 +0000 2018",
        "id": 962827701114621952,
        "text": "RT @FoxNews: .@TomFitton: \"[@realDonaldTrump] has been victimized by the Obama Administration.\" https://t.co/z3Vn9KY1M3",
        "user.screen_name": "leapingknown"
    },
    {
        "created_at": "Sun Feb 11 23:16:26 +0000 2018",
        "id": 962827699411607552,
        "text": "RT @JessieJaneDuff: DHS official &amp; former Obama ambassador James Nealon resigned, upset recommendations to extend \u201ctemporary protected stat\u2026",
        "user.screen_name": "cathie_lagrange"
    },
    {
        "created_at": "Sun Feb 11 23:16:26 +0000 2018",
        "id": 962827697901789186,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "Triscuitttt"
    },
    {
        "created_at": "Sun Feb 11 23:16:26 +0000 2018",
        "id": 962827697708703744,
        "text": "RT @joncoopertweets: Sure, @realDonaldTrump is a lying, corrupt, racist, traitorous imbecile who defends white supremacists, Nazis, wife be\u2026",
        "user.screen_name": "JTDENVERDUBS"
    },
    {
        "created_at": "Sun Feb 11 23:16:26 +0000 2018",
        "id": 962827697314394113,
        "text": "RT @yoly4Trump: Tom Del Beccaro: All Corrupt DOJ and FBI Roads Lead to Obama https://t.co/JxPNVW1yWp via @BreitbartNews",
        "user.screen_name": "yoly4Trump"
    },
    {
        "created_at": "Sun Feb 11 23:16:26 +0000 2018",
        "id": 962827697092288512,
        "text": "@GOP You don\u2019t want to give Obama credit because you don\u2019t want to give Bush credit either.     What kind of chesse\u2026 https://t.co/cdgxkI5FAD",
        "user.screen_name": "Michael51114020"
    },
    {
        "created_at": "Sun Feb 11 23:16:26 +0000 2018",
        "id": 962827696937070592,
        "text": "RT @fubaglady: How Obama\u2019s Hillary Clinton cover-ups destroyed DOJ and FBI https://t.co/26KPBHmpyz",
        "user.screen_name": "RedBaronUSA1"
    },
    {
        "created_at": "Sun Feb 11 23:16:25 +0000 2018",
        "id": 962827696060289024,
        "text": "Obama and Democrats never solved this man's problem. https://t.co/gbciZ04pCP",
        "user.screen_name": "Hardhat_Patriot"
    },
    {
        "created_at": "Sun Feb 11 23:16:25 +0000 2018",
        "id": 962827695297097728,
        "text": "RT @Go_DeeJay21: Barack Obama https://t.co/0T4ZCvOzGL",
        "user.screen_name": "Harbsyy"
    },
    {
        "created_at": "Sun Feb 11 23:16:25 +0000 2018",
        "id": 962827694558728192,
        "text": "RT @ElderLansing: I will never respect the Ex Resident Coward Obama! He was a horrible leader and had numerous scandals overlooked because\u2026",
        "user.screen_name": "Lynny222"
    },
    {
        "created_at": "Sun Feb 11 23:16:25 +0000 2018",
        "id": 962827693648527360,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "realtime1954"
    },
    {
        "created_at": "Sun Feb 11 23:16:25 +0000 2018",
        "id": 962827693115899905,
        "text": "RT @HrrEerrer: Does @realDonaldTrump hafta spend money where congress says?Obama didn\u2019t!Almost NO stimulus went2shovel ready jobs https://t\u2026",
        "user.screen_name": "BillWes76233793"
    },
    {
        "created_at": "Sun Feb 11 23:16:24 +0000 2018",
        "id": 962827692268810240,
        "text": "RT @joncoopertweets: Sure, @realDonaldTrump is a lying, corrupt, racist, traitorous imbecile who defends white supremacists, Nazis, wife be\u2026",
        "user.screen_name": "UsEmpowered"
    },
    {
        "created_at": "Sun Feb 11 23:16:24 +0000 2018",
        "id": 962827691350200320,
        "text": "RT @GeorgiaDirtRoad: Eric Holder is thinking of running  for president... He was Obama\u2019s lap dog &amp; now wants to be the next clown to run fo\u2026",
        "user.screen_name": "pepper10001"
    },
    {
        "created_at": "Sun Feb 11 23:16:24 +0000 2018",
        "id": 962827689710120961,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "BettinaVLA"
    },
    {
        "created_at": "Sun Feb 11 23:16:24 +0000 2018",
        "id": 962827689399787520,
        "text": "RT @mattmfm: Barack Obama was in the same room as Louis Farrakhan once and it caused a decades-long controversy. \n\nDonald Trump gave a shou\u2026",
        "user.screen_name": "JosephOsaka"
    },
    {
        "created_at": "Sun Feb 11 23:16:24 +0000 2018",
        "id": 962827688980332544,
        "text": "How ironic that only the wealthy elite can hear Michelle Obama speak. Heck, I can not even afford parking in the area let alone $$$ tix.",
        "user.screen_name": "feschukphoto"
    },
    {
        "created_at": "Sun Feb 11 23:16:23 +0000 2018",
        "id": 962827684794351617,
        "text": "RT @JessieJaneDuff: DHS official &amp; former Obama ambassador James Nealon resigned, upset recommendations to extend \u201ctemporary protected stat\u2026",
        "user.screen_name": "Harper04138060"
    },
    {
        "created_at": "Sun Feb 11 23:16:23 +0000 2018",
        "id": 962827684639322113,
        "text": "RT @miamijj48: Our fast-growing national debt is a toxic legacy for my generation \n\n$1 Trillion in debt is unacceptable-We need to continue\u2026",
        "user.screen_name": "SouthurnMama"
    },
    {
        "created_at": "Sun Feb 11 23:16:22 +0000 2018",
        "id": 962827683016134656,
        "text": "RT @qz: Hip-hop painter Kehinde Wiley\u2019s portrait of Barack Obama will be unveiled tomorrow https://t.co/8wCPxkTX78",
        "user.screen_name": "fisachi3x"
    },
    {
        "created_at": "Sun Feb 11 23:16:22 +0000 2018",
        "id": 962827682344992768,
        "text": "RT @bfraser747: Is anyone actually surprised that Obama wanted to \u201cknow everything\u201d?\n\nOf course he interfered with the Hillary investigatio\u2026",
        "user.screen_name": "TruthsbyRalph"
    },
    {
        "created_at": "Sun Feb 11 23:16:22 +0000 2018",
        "id": 962827681665568771,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "972_834"
    },
    {
        "created_at": "Sun Feb 11 23:16:22 +0000 2018",
        "id": 962827681619496960,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "RichardVerMeul1"
    },
    {
        "created_at": "Sun Feb 11 23:16:22 +0000 2018",
        "id": 962827681577558016,
        "text": "RT @MsMcMullan: Am I the only one who knows with complete certainty that the GOP never would have let the Democrats steal their Supreme Cou\u2026",
        "user.screen_name": "IPM_Tweets"
    },
    {
        "created_at": "Sun Feb 11 23:16:21 +0000 2018",
        "id": 962827679694123008,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "Brew_sir54"
    },
    {
        "created_at": "Sun Feb 11 23:16:21 +0000 2018",
        "id": 962827679119667200,
        "text": "RT @Go_DeeJay21: Barack Obama https://t.co/0T4ZCvOzGL",
        "user.screen_name": "Drake_4"
    },
    {
        "created_at": "Sun Feb 11 23:16:21 +0000 2018",
        "id": 962827679027220480,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "bretpdx"
    },
    {
        "created_at": "Sun Feb 11 23:16:21 +0000 2018",
        "id": 962827676519223296,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "Sbeks72986"
    },
    {
        "created_at": "Sun Feb 11 23:16:20 +0000 2018",
        "id": 962827675374161921,
        "text": "RT @SebGorka: Just REMEMBER:\n\n@JohnBrennan was proud to have voted for Gus Hall the Communist candidate for American President. \n\nTHEN OBAM\u2026",
        "user.screen_name": "Ed19642Ed"
    },
    {
        "created_at": "Sun Feb 11 23:16:20 +0000 2018",
        "id": 962827674610782213,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "StevBlacker"
    },
    {
        "created_at": "Sun Feb 11 23:16:20 +0000 2018",
        "id": 962827673318969345,
        "text": "RT @ARmastrangelo: We all know Obama loves weaponizing government agencies. Remember the IRS?\n\nWe all know Hillary loves to cheat. Remember\u2026",
        "user.screen_name": "BlgaethGaeth"
    },
    {
        "created_at": "Sun Feb 11 23:16:19 +0000 2018",
        "id": 962827668675731456,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "Verona83"
    },
    {
        "created_at": "Sun Feb 11 23:16:18 +0000 2018",
        "id": 962827666196967424,
        "text": "@mikebloodworth @JBitterly @realDonaldTrump Trump is still talk about Obama &amp; Hillary so his supporters will do the\u2026 https://t.co/iM5134O4z0",
        "user.screen_name": "pam_pannarai"
    },
    {
        "created_at": "Sun Feb 11 23:16:18 +0000 2018",
        "id": 962827665744031746,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "jennyfields79"
    },
    {
        "created_at": "Sun Feb 11 23:16:18 +0000 2018",
        "id": 962827665542664192,
        "text": "RT @abiantes: @amandanaude @IamMarkStephens @bellaace52 @realDonaldTrump You do know that America's current economic situation came about u\u2026",
        "user.screen_name": "FuelMan55"
    },
    {
        "created_at": "Sun Feb 11 23:16:18 +0000 2018",
        "id": 962827663579762688,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "terryjgosh"
    },
    {
        "created_at": "Sun Feb 11 23:16:18 +0000 2018",
        "id": 962827663122472960,
        "text": "RT @MOVEFORWARDHUGE: THE OBAMA ADMINISTRATION HOUSE OF CARDS\n\nIS ABOUT TO MEET GITMO BARS!\n\nWHEN THE MILITARY TRIBUNALS ARE DONE,\n\nAMERICA\u2026",
        "user.screen_name": "MOVEFORWARDHUGE"
    },
    {
        "created_at": "Sun Feb 11 23:16:17 +0000 2018",
        "id": 962827661583310850,
        "text": "@conserv_tribune It is incredible and awesome obama was the worst president ever and it erasing the stain he left behind is necessary",
        "user.screen_name": "m_mmilling"
    },
    {
        "created_at": "Sun Feb 11 23:16:17 +0000 2018",
        "id": 962827659804733440,
        "text": "RT @tangJINjaemx: @vlissful @BTS_twt OBAMA SUPPORTS THIS! \ud83d\udc4f\ud83d\udc4f\ud83d\udc4f\ud83d\udc4f LEGEEEEENDS!!\n\n#BTS #BestBoyBand #iHeartAwards @BTS_twt https://t.co/hvqe2sI\u2026",
        "user.screen_name": "becauseofKTH"
    },
    {
        "created_at": "Sun Feb 11 23:16:16 +0000 2018",
        "id": 962827658449928192,
        "text": "RT @StevenTDennis: DACA exists because Obama acted after a Senate minority filibustered the DREAM Act in 2010; John Boehner and Paul Ryan h\u2026",
        "user.screen_name": "dazilmz"
    },
    {
        "created_at": "Sun Feb 11 23:16:16 +0000 2018",
        "id": 962827657422491648,
        "text": "@___aniT___ @Obama_FOS @Tiffany1985B We\u2019re a thing now so don\u2019t push me away when I\u2019m all up in your business. \ud83d\ude09\ud83d\ude02",
        "user.screen_name": "jennyleesac30"
    },
    {
        "created_at": "Sun Feb 11 23:16:16 +0000 2018",
        "id": 962827657384812544,
        "text": "RT @a4_adorable: Barack Obama https://t.co/a1EuLpeoT9",
        "user.screen_name": "CharlayaTyler"
    },
    {
        "created_at": "Sun Feb 11 23:16:16 +0000 2018",
        "id": 962827656868892672,
        "text": "RT @realDonaldTrump: \u201cMy view is that not only has Trump been vindicated in the last several weeks about the mishandling of the Dossier and\u2026",
        "user.screen_name": "babafemi9"
    },
    {
        "created_at": "Sun Feb 11 23:16:16 +0000 2018",
        "id": 962827655765725184,
        "text": "RT @JohnJHarwood: Obama and Democratic Congress constructed their central domestic initiative, the ACA, with sufficient tax revenue so that\u2026",
        "user.screen_name": "wonz"
    },
    {
        "created_at": "Sun Feb 11 23:16:16 +0000 2018",
        "id": 962827655211925504,
        "text": "RT @cbouzy: \ud83d\udd25\ud83d\udd25\ud83d\udd25OMG!!! Jeanine Pirro blames Barack Obama for Rob Porter wife-beating scandal. Fox News is a fake news network endorsed by th\u2026",
        "user.screen_name": "michellred"
    },
    {
        "created_at": "Sun Feb 11 23:16:16 +0000 2018",
        "id": 962827654876549121,
        "text": "mr obama pwease hewp.",
        "user.screen_name": "younghocsp"
    },
    {
        "created_at": "Sun Feb 11 23:16:15 +0000 2018",
        "id": 962827651827355648,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "RichardVerMeul1"
    },
    {
        "created_at": "Sun Feb 11 23:16:14 +0000 2018",
        "id": 962827649759444997,
        "text": "RT @KrisParonto: We also didn\u2019t use the @FBI @CIA and @NSAGov to spy on @realDonaldTrump either.......isn\u2019t that what you said to Chris Wal\u2026",
        "user.screen_name": "Baltazar_Bolado"
    },
    {
        "created_at": "Sun Feb 11 23:16:14 +0000 2018",
        "id": 962827649750990850,
        "text": "RT @GOP: Democrats are trying to take credit for our thriving economy. \ud83d\ude02\nhttps://t.co/gKTke2wqO3",
        "user.screen_name": "BettinaVLA"
    },
    {
        "created_at": "Sun Feb 11 23:16:14 +0000 2018",
        "id": 962827647452463104,
        "text": "RT @OliverMcGee: Wow. Throwback to when Senator Barack Obama agreed with @realDonaldTrump on immigration! RT this so your friends see this!\u2026",
        "user.screen_name": "SandraM02169645"
    },
    {
        "created_at": "Sun Feb 11 23:16:13 +0000 2018",
        "id": 962827645279981568,
        "text": "RT @TrumpNewsz: \"Instant Justice: After G W Bush &amp; Obama Teamed Up to Attack Trump, Fox Host Leaked Their Worst Nightmare\" https://t.co/KbE\u2026",
        "user.screen_name": "ceci8775"
    },
    {
        "created_at": "Sun Feb 11 23:16:13 +0000 2018",
        "id": 962827644113997825,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "BrookhartKim"
    },
    {
        "created_at": "Sun Feb 11 23:16:13 +0000 2018",
        "id": 962827643149221888,
        "text": "Obama by Kevin Bozeman is #NowPlaying on https://t.co/IBx3JZxB9Y https://t.co/94jE4ONxEt",
        "user.screen_name": "CCS_Radio"
    },
    {
        "created_at": "Sun Feb 11 23:16:13 +0000 2018",
        "id": 962827642339774465,
        "text": "RT @phil200269: Reminder: \n\nThe Obama Appointees Who Covered Up Hillary and Obama's Uranium Sale To Russia Are Still In Charge of the Trump\u2026",
        "user.screen_name": "page_kimiko"
    },
    {
        "created_at": "Sun Feb 11 23:16:12 +0000 2018",
        "id": 962827641639391233,
        "text": "@DonnaWR8 @POTUS Obama and crew got away with everything.",
        "user.screen_name": "SaraBuc44740477"
    },
    {
        "created_at": "Sun Feb 11 23:16:12 +0000 2018",
        "id": 962827640980860928,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "gbetree"
    },
    {
        "created_at": "Sun Feb 11 23:16:12 +0000 2018",
        "id": 962827640624250880,
        "text": "RT @AMErikaNGIRLBOT: Watch:Leaked footage of Trump firing Comey\ud83d\udca5\u201dYou\u2019re Fired!\u201d \nThe Obama admin turned America into a sitcom where every d\u2026",
        "user.screen_name": "bsgirl2u"
    },
    {
        "created_at": "Sun Feb 11 23:16:12 +0000 2018",
        "id": 962827640343285761,
        "text": "RT @MaxBlumenthal: This excellent move would almost make up for giving the prize to Obama https://t.co/pJV5GoPJp9",
        "user.screen_name": "DianeDobrski"
    },
    {
        "created_at": "Sun Feb 11 23:16:12 +0000 2018",
        "id": 962827640255270913,
        "text": "Newt Hammer Clinton And The Deep State  https://t.co/VKMy2s67WD",
        "user.screen_name": "starrick1"
    },
    {
        "created_at": "Sun Feb 11 23:16:12 +0000 2018",
        "id": 962827639672074240,
        "text": "RT @AriFleischer: It\u2019s easy to be a thug dealing with liberal media. The MSM forgets prison camps, forced hunger, brutality, nuclear threat\u2026",
        "user.screen_name": "Verona83"
    },
    {
        "created_at": "Sun Feb 11 23:16:11 +0000 2018",
        "id": 962827637638029314,
        "text": "@DineshDSouza @Debber66 @realDonaldTrump #DrainTheSorosCesspool\n#ObamaKnew\n#CorruptFBI\nObama's FBI and DOJ tricked\u2026 https://t.co/yqiv6aRsUL",
        "user.screen_name": "j_c_k17jck"
    },
    {
        "created_at": "Sun Feb 11 23:16:11 +0000 2018",
        "id": 962827637562466304,
        "text": "BOMBSHELL: FBI Informant In Uranium One Scandal Testifies Against Obama. Here's What He Said.  https://t.co/AwCYRiLoug",
        "user.screen_name": "MrLeeHanna"
    },
    {
        "created_at": "Sun Feb 11 23:16:11 +0000 2018",
        "id": 962827637524754432,
        "text": "RT @Sunrise51052: DACA was created on 6/15/12 because polling showed Obama would need more Hispanic votes to win 2012. \n\n#MAGA #AmericaFirs\u2026",
        "user.screen_name": "denverkb"
    },
    {
        "created_at": "Sun Feb 11 23:16:11 +0000 2018",
        "id": 962827636132196352,
        "text": "RT @FiveRights: Laura Ingraham on Fox: Why did George W. Bush refuse to criticize Obama even when O screwed up badly but he often criticize\u2026",
        "user.screen_name": "DianeMDeath"
    },
    {
        "created_at": "Sun Feb 11 23:16:11 +0000 2018",
        "id": 962827634064244736,
        "text": "RT @JessieJaneDuff: DHS official &amp; former Obama ambassador James Nealon resigned, upset recommendations to extend \u201ctemporary protected stat\u2026",
        "user.screen_name": "queensword"
    },
    {
        "created_at": "Sun Feb 11 23:16:10 +0000 2018",
        "id": 962827633410105344,
        "text": "RT @RealMAGASteve: This bombshell report from the Senate Homeland Security Comm. IMPLICATES OBAMA in the #Obamagate scandal &amp; Clinton email\u2026",
        "user.screen_name": "willieluv2016"
    },
    {
        "created_at": "Sun Feb 11 23:16:10 +0000 2018",
        "id": 962827633234006017,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "TreetopMcPhers2"
    },
    {
        "created_at": "Sun Feb 11 23:16:10 +0000 2018",
        "id": 962827632705449984,
        "text": "RT @TommyAl40344973: @JanC182 @DerkaCards @ChaMamasHouse @realDonaldTrump Obama was worst pres ever. He ruined the economy &amp; started a raci\u2026",
        "user.screen_name": "dbaug57942"
    },
    {
        "created_at": "Sun Feb 11 23:16:10 +0000 2018",
        "id": 962827630570438656,
        "text": "RT @JalenSkutt: Barack Obama https://t.co/Z91o7bG2EH",
        "user.screen_name": "danyyy26"
    },
    {
        "created_at": "Sun Feb 11 23:16:10 +0000 2018",
        "id": 962827630457352192,
        "text": "RT @Logic_Triumphs: \u2b50\u2b50\u2b50\u2b50\u2b50\nBarack Obama has 99.7 million followers.\nIt would kill Donald Trump if Obama hit 100 million. Whatever you do do\u2026",
        "user.screen_name": "gjackson963"
    },
    {
        "created_at": "Sun Feb 11 23:16:09 +0000 2018",
        "id": 962827628037197829,
        "text": "RT @TomFitton: The American people should be able to see for themselves the FISA court docs on how Obama admin used Clinton document to mis\u2026",
        "user.screen_name": "nuzombie4"
    },
    {
        "created_at": "Sun Feb 11 23:16:09 +0000 2018",
        "id": 962827627991060481,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "gatorKayla2"
    },
    {
        "created_at": "Sun Feb 11 23:16:09 +0000 2018",
        "id": 962827627324207104,
        "text": "RT @omriceren: Obama Dec 2011, after Iran seized American UAV: \"We've asked for it back. We'll see how the Iranians respond\" https://t.co/y\u2026",
        "user.screen_name": "awkwardfuzzball"
    },
    {
        "created_at": "Sun Feb 11 23:16:08 +0000 2018",
        "id": 962827624434323456,
        "text": "RT @AZWS: This meme is aging very well. It\u2019s still amazing the Mainstream Media would have you believe Obama\u2019s presidency was scandal free.\u2026",
        "user.screen_name": "maxislv"
    },
    {
        "created_at": "Sun Feb 11 23:16:07 +0000 2018",
        "id": 962827619640033281,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "pcphx90"
    },
    {
        "created_at": "Sun Feb 11 23:16:07 +0000 2018",
        "id": 962827619023687681,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "MLGoley"
    },
    {
        "created_at": "Sun Feb 11 23:16:06 +0000 2018",
        "id": 962827616125415424,
        "text": "RT @Imperator_Rex3: Important thread focussing on how the criminals used a foreign intelligence service (GCHQ) to inject the dodgy dossier\u2026",
        "user.screen_name": "Teresa13218380"
    },
    {
        "created_at": "Sun Feb 11 23:16:06 +0000 2018",
        "id": 962827615160684545,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "oqven"
    },
    {
        "created_at": "Sun Feb 11 23:16:06 +0000 2018",
        "id": 962827614934175744,
        "text": "RT @goodoldcatchy: Jesus wasn\u2019t white. Trump isn\u2019t a Christian. Trickle-down economics doesn\u2019t work. A border wall isn\u2019t feasible. Climate\u2026",
        "user.screen_name": "chels2saucy"
    },
    {
        "created_at": "Sun Feb 11 23:16:06 +0000 2018",
        "id": 962827613948530688,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "WoodCarma"
    },
    {
        "created_at": "Sun Feb 11 23:16:06 +0000 2018",
        "id": 962827612992299009,
        "text": "RT @yogagenie: Poll: Americans 'Overwhelmingly' Believe Obama 'Improperly Surveilled' Trump Campaign - Breitbart https://t.co/6vZcuiaf2b",
        "user.screen_name": "M08D26"
    },
    {
        "created_at": "Sun Feb 11 23:16:06 +0000 2018",
        "id": 962827612811751424,
        "text": "RT @USArmy333: Wait #Obama \n\nYou mean you destroyed cars that were FINE! While #Homeless #Veterans need a car?  https://t.co/RKQvQdDdQD",
        "user.screen_name": "BRADALL76027393"
    },
    {
        "created_at": "Sun Feb 11 23:16:06 +0000 2018",
        "id": 962827612736315392,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "ttcriddell"
    },
    {
        "created_at": "Sun Feb 11 23:16:04 +0000 2018",
        "id": 962827608508588039,
        "text": "RT @BenjaminNorton: US Ambassador Confirms Billions Spent On Regime Change in Syria, Debunking 'Obama Did Nothing' Myth https://t.co/nWGvwI\u2026",
        "user.screen_name": "ymahfooz"
    },
    {
        "created_at": "Sun Feb 11 23:16:04 +0000 2018",
        "id": 962827608021856257,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "cathie_lagrange"
    },
    {
        "created_at": "Sun Feb 11 23:16:04 +0000 2018",
        "id": 962827607724253184,
        "text": "RT @NewtTrump: Newt Gingrich: \"Let me just point out how sick the elite media is \u2014 they report all that as though it\u2019s something bad about\u2026",
        "user.screen_name": "kfwinter15"
    },
    {
        "created_at": "Sun Feb 11 23:16:04 +0000 2018",
        "id": 962827605601914880,
        "text": "If President Obama wasn\u2019t President Obama he\u2019d be James Bond , Idris Elba , The Dos Equis man , John Shaft , Jason\u2026 https://t.co/wt0Y950nPn",
        "user.screen_name": "bergamp64"
    },
    {
        "created_at": "Sun Feb 11 23:16:03 +0000 2018",
        "id": 962827603903094784,
        "text": "@dorianp626 You\u2019ve got Trump confused with War Instigator Champ, Obama.",
        "user.screen_name": "donaldpirl"
    },
    {
        "created_at": "Sun Feb 11 23:16:03 +0000 2018",
        "id": 962827602535833600,
        "text": "RT @JudicialWatch: Reminder: JW found evidence showing Obama State Dept under John Kerry sent its own \"dossier\" of classified info on Russi\u2026",
        "user.screen_name": "donrh65"
    },
    {
        "created_at": "Sun Feb 11 23:16:03 +0000 2018",
        "id": 962827601768337409,
        "text": "@RealCandaceO Black Nationalism under Obama https://t.co/dVNWiTLMeX",
        "user.screen_name": "JTCMD"
    },
    {
        "created_at": "Sun Feb 11 23:16:02 +0000 2018",
        "id": 962827599880781824,
        "text": "RT @JudicialWatch: Reminder: JW found evidence showing Obama State Dept under John Kerry sent its own \"dossier\" of classified info on Russi\u2026",
        "user.screen_name": "danecloud1"
    },
    {
        "created_at": "Sun Feb 11 23:16:02 +0000 2018",
        "id": 962827599708938240,
        "text": "RT @GrrrGraphics: \"In the Head of Hillary\" #BenGarrison #cartoon \nSomeone asked me why I draw so many #Obama &amp; #Hillary cartoons. \nread mor\u2026",
        "user.screen_name": "velvet_chainsaw"
    },
    {
        "created_at": "Sun Feb 11 23:16:02 +0000 2018",
        "id": 962827599377448960,
        "text": "RT @brianklaas: Man who called to execute Central Park 5 &amp; insisted they were guilty after DNA evidence proved their innocence; spread birt\u2026",
        "user.screen_name": "LegendOfSandy"
    },
    {
        "created_at": "Sun Feb 11 23:16:02 +0000 2018",
        "id": 962827598723211264,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "HavicanWatson"
    },
    {
        "created_at": "Sun Feb 11 23:16:02 +0000 2018",
        "id": 962827598589022208,
        "text": "RT @winstonmeiiis: Dems are still denying the facts that Obama/Clinton admin knowingly used fake Trump dossier to obtain FISA warrants.\nDo\u2026",
        "user.screen_name": "donnamaxwell861"
    },
    {
        "created_at": "Sun Feb 11 23:16:02 +0000 2018",
        "id": 962827597087309824,
        "text": "RT @MOVEFORWARDHUGE: THE OBAMA ADMINISTRATION HOUSE OF CARDS\n\nIS ABOUT TO MEET GITMO BARS!\n\nWHEN THE MILITARY TRIBUNALS ARE DONE,\n\nAMERICA\u2026",
        "user.screen_name": "michaelroller"
    },
    {
        "created_at": "Sun Feb 11 23:16:01 +0000 2018",
        "id": 962827593547501568,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "BobaFenwick"
    },
    {
        "created_at": "Sun Feb 11 23:16:01 +0000 2018",
        "id": 962827593316818946,
        "text": "@gal_deplorable @tamaraleighllc It's become a valid certification that gained prominence under obama.  Prior to 200\u2026 https://t.co/tyXxGpwMUh",
        "user.screen_name": "JaiceHarmon"
    },
    {
        "created_at": "Sun Feb 11 23:16:01 +0000 2018",
        "id": 962827593161625601,
        "text": "RT @justinamash: This morning, every Republican in Congress who blasted government growth under Pres. Obama gets to answer the following qu\u2026",
        "user.screen_name": "clarkeswa"
    },
    {
        "created_at": "Sun Feb 11 23:16:01 +0000 2018",
        "id": 962827592871981056,
        "text": "RT @1776Stonewall: @JudiMichels I'll never forget when he went at Obama and the empty chair at the RNC convention/ The left, of course, att\u2026",
        "user.screen_name": "edwardjrcomcas1"
    },
    {
        "created_at": "Sun Feb 11 23:16:01 +0000 2018",
        "id": 962827592805027842,
        "text": "RT @rocketsales44: You must have been asleep for the Obama years #MAGA #LiberalismIsAMentalDisorder https://t.co/m8hVmN0q2g",
        "user.screen_name": "sg07840_mayra"
    },
    {
        "created_at": "Sun Feb 11 23:16:00 +0000 2018",
        "id": 962827590133202944,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "Darlem303"
    },
    {
        "created_at": "Sun Feb 11 23:16:00 +0000 2018",
        "id": 962827589835546624,
        "text": "Israel Strikes Iran in Syria and Loses a Jet via @NYTimes. Obama\u2019s other legacy? https://t.co/R7bEaEn2CM",
        "user.screen_name": "JoelPFeldman"
    },
    {
        "created_at": "Sun Feb 11 23:16:00 +0000 2018",
        "id": 962827589009231873,
        "text": "RT @labuda_robert: Define Russian Collusion.:\n\nWhy did Barack Obama\n\n1) Work With Iran?\n\n2) Use the Intel Community to Monitor/Attack Benja\u2026",
        "user.screen_name": "SthrnMomNGram"
    },
    {
        "created_at": "Sun Feb 11 23:16:00 +0000 2018",
        "id": 962827587813888000,
        "text": "RT @DineshDSouza: There is more proof to date that Obama\u2014not Trump\u2014tried to rig the 2016 election. Let the truth come out &amp; hold the guilty\u2026",
        "user.screen_name": "NMLifestyles"
    },
    {
        "created_at": "Sun Feb 11 23:15:59 +0000 2018",
        "id": 962827584827359232,
        "text": "@MohamedMOSalih Harriet Tubman, Frederick Douglass, MLK, Nichelle Nichols. Barack &amp; Michelle Obama. U.S. Rep John Lewis. Just to name a few.",
        "user.screen_name": "LisaBlycker"
    },
    {
        "created_at": "Sun Feb 11 23:15:59 +0000 2018",
        "id": 962827584005287936,
        "text": "RT @RyanAFournier: Do you believe the Obama Administration improperly and illegally surveilled the Trump Campaign? #SHARE",
        "user.screen_name": "crookedchair69"
    },
    {
        "created_at": "Sun Feb 11 23:15:58 +0000 2018",
        "id": 962827582461894657,
        "text": "RT @rmasher2: Funny. I don't recall President Obama being called to testify before a Special Counsel/Grand Jury looking into possible crimi\u2026",
        "user.screen_name": "MayIrmamay14"
    },
    {
        "created_at": "Sun Feb 11 23:15:58 +0000 2018",
        "id": 962827581434183680,
        "text": "RT @BenjaminNorton: US Ambassador Confirms Billions Spent On Regime Change in Syria, Debunking 'Obama Did Nothing' Myth https://t.co/nWGvwI\u2026",
        "user.screen_name": "Pepperpear"
    },
    {
        "created_at": "Sun Feb 11 23:15:58 +0000 2018",
        "id": 962827580968759296,
        "text": "@keithellison @ErikaAndiola DACA is unconstitutional Obama stated that fact 25xs! Democrat majority could of passed\u2026 https://t.co/UtC7GYPkBj",
        "user.screen_name": "KellyCurran20"
    },
    {
        "created_at": "Sun Feb 11 23:15:58 +0000 2018",
        "id": 962827580901679109,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "deb_sadie"
    },
    {
        "created_at": "Sun Feb 11 23:15:58 +0000 2018",
        "id": 962827580863758336,
        "text": "@shirleyann32 @HouseGOP Did you see any of that 2500 Obama promise you, or did you healthcare go down or are you on the free line??",
        "user.screen_name": "GregoryMaul"
    },
    {
        "created_at": "Sun Feb 11 23:15:58 +0000 2018",
        "id": 962827580348030977,
        "text": "RT @RyanAFournier: Do you believe the Obama Administration improperly and illegally surveilled the Trump Campaign? #SHARE",
        "user.screen_name": "I_am_KevinW"
    },
    {
        "created_at": "Sun Feb 11 23:15:58 +0000 2018",
        "id": 962827579286843397,
        "text": "RT @BettyBowers: TRUMP LIE: Democrats didn't fix #DACA from 2008-2011. \n\nINCONVENIENT FACT: DACA didn't exist until 2012.\n\nTRUMP LIE: Repub\u2026",
        "user.screen_name": "kingT"
    },
    {
        "created_at": "Sun Feb 11 23:15:57 +0000 2018",
        "id": 962827577864966144,
        "text": "@RadioFreeTom Many of those voters were possessed of the same magical thinking as Obama voters.",
        "user.screen_name": "TomNeven1"
    },
    {
        "created_at": "Sun Feb 11 23:15:57 +0000 2018",
        "id": 962827577760145408,
        "text": "RT @Jali_Cat: Two days after Obama sent Iran the ransom cash, USA government wired 13 individual payments for $99,999,999.99 , each w/ an i\u2026",
        "user.screen_name": "dalvis0921"
    },
    {
        "created_at": "Sun Feb 11 23:15:57 +0000 2018",
        "id": 962827576510242817,
        "text": "RT @RealMAGASteve: This bombshell report from the Senate Homeland Security Comm. IMPLICATES OBAMA in the #Obamagate scandal &amp; Clinton email\u2026",
        "user.screen_name": "DianneSteiner"
    },
    {
        "created_at": "Sun Feb 11 23:15:56 +0000 2018",
        "id": 962827574215819265,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "ccary67"
    },
    {
        "created_at": "Sun Feb 11 23:15:56 +0000 2018",
        "id": 962827573351866368,
        "text": "RT @sportsfan_james: @dbongino He knew it from the start he has been a trained liar. He lied about the ILLEGAL spying to Congress and AMERI\u2026",
        "user.screen_name": "cooch28"
    },
    {
        "created_at": "Sun Feb 11 23:15:56 +0000 2018",
        "id": 962827573133750272,
        "text": "RT @Brasilmagic: Jeanine Pirro needs a straight-jacket  https://t.co/G4wzGBUJ0b",
        "user.screen_name": "ResistTilDeath"
    },
    {
        "created_at": "Sun Feb 11 23:15:56 +0000 2018",
        "id": 962827571611275270,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "meg_moreno"
    },
    {
        "created_at": "Sun Feb 11 23:15:55 +0000 2018",
        "id": 962827570050891778,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "facingeast52"
    },
    {
        "created_at": "Sun Feb 11 23:15:55 +0000 2018",
        "id": 962827567727247360,
        "text": "RT @KaniJJackson: This is just your daily reminder that Barack Obama did not have 1 scandal or allegation against him during his time in th\u2026",
        "user.screen_name": "DredPirateJames"
    },
    {
        "created_at": "Sun Feb 11 23:15:55 +0000 2018",
        "id": 962827567320391680,
        "text": "RT @Education4Libs: Obama\u2019s election was the worst thing to ever happen to this country. \n\nTrump\u2019s election was the best.\n\nWe now have a gr\u2026",
        "user.screen_name": "Rayr63"
    },
    {
        "created_at": "Sun Feb 11 23:15:55 +0000 2018",
        "id": 962827567203012614,
        "text": "RT @BettyBowers: TRUMP LIE: Democrats didn't fix #DACA from 2008-2011. \n\nINCONVENIENT FACT: DACA didn't exist until 2012.\n\nTRUMP LIE: Repub\u2026",
        "user.screen_name": "BenKallaway"
    },
    {
        "created_at": "Sun Feb 11 23:15:55 +0000 2018",
        "id": 962827567198818304,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "lkw72258"
    },
    {
        "created_at": "Sun Feb 11 23:15:54 +0000 2018",
        "id": 962827566083133441,
        "text": "@DineshDSouza @JessieJaneDuff Like the IRS acted as Obama's SS on conservative NFP's",
        "user.screen_name": "Publius7"
    },
    {
        "created_at": "Sun Feb 11 23:15:54 +0000 2018",
        "id": 962827565957287937,
        "text": "RT @JudicialWatch: As part of our effort to hold Mueller's investigation accountable, JW uncovered docs showing top DOJ officials including\u2026",
        "user.screen_name": "PatriotMarie"
    },
    {
        "created_at": "Sun Feb 11 23:15:54 +0000 2018",
        "id": 962827565751730178,
        "text": "RT @TomFitton: The American people should be able to see for themselves the FISA court docs on how Obama admin used Clinton document to mis\u2026",
        "user.screen_name": "gwoodle"
    },
    {
        "created_at": "Sun Feb 11 23:15:54 +0000 2018",
        "id": 962827564665405440,
        "text": "RT @MEL2AUSA: If anyone is looking for #Obama he\u2019s in his safe space.\nIt\u2019s in the ladies restroom. #ObamaKnew #ObamaGate https://t.co/TKakg\u2026",
        "user.screen_name": "Mtweetie4848gm2"
    },
    {
        "created_at": "Sun Feb 11 23:15:54 +0000 2018",
        "id": 962827564153745408,
        "text": "RT @Psychoman1976: Marie Harf on #Outnumbered having a coronary about #Obama involvement with email and dossier scandals Bwahahaha!!!!!! ht\u2026",
        "user.screen_name": "MikeJorgensen5"
    },
    {
        "created_at": "Sun Feb 11 23:15:54 +0000 2018",
        "id": 962827563910475776,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "RichardVerMeul1"
    },
    {
        "created_at": "Sun Feb 11 23:15:53 +0000 2018",
        "id": 962827562052411392,
        "text": "I hope @tedlieu @RepSwalwell get to the bottom of whether Hope Hicks pegs Trump\u2019s bottom with the Obama dildo, as h\u2026 https://t.co/2xmVkVnFZo",
        "user.screen_name": "BeurreyBlanco"
    },
    {
        "created_at": "Sun Feb 11 23:15:53 +0000 2018",
        "id": 962827558273208320,
        "text": "@CNN And Bullets paid for by Obama\u2019s Nuclear Deal.",
        "user.screen_name": "TASWhatever"
    },
    {
        "created_at": "Sun Feb 11 23:15:52 +0000 2018",
        "id": 962827555551240192,
        "text": "RT @JessieJaneDuff: DHS official &amp; former Obama ambassador James Nealon resigned, upset recommendations to extend \u201ctemporary protected stat\u2026",
        "user.screen_name": "hockeymom9598"
    },
    {
        "created_at": "Sun Feb 11 23:15:52 +0000 2018",
        "id": 962827554842439680,
        "text": "RT @Khanoisseur: This is arguably the most important speech Obama has given\n\nListen to it carefully and share with friends https://t.co/Heq\u2026",
        "user.screen_name": "tabfreeweir"
    },
    {
        "created_at": "Sun Feb 11 23:15:52 +0000 2018",
        "id": 962827554745970689,
        "text": "RT @RyanAFournier: Do you believe the Obama Administration improperly and illegally surveilled the Trump Campaign? #SHARE",
        "user.screen_name": "bwcawilderness"
    },
    {
        "created_at": "Sun Feb 11 23:15:51 +0000 2018",
        "id": 962827553424773121,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "PLFord52"
    },
    {
        "created_at": "Sun Feb 11 23:15:51 +0000 2018",
        "id": 962827553215012864,
        "text": "RT @jackshafer: \"Obama &amp; Hillary Ordered FBI to Spy on Trump!\" https://t.co/l007E3XT81",
        "user.screen_name": "SeanOCasey1"
    },
    {
        "created_at": "Sun Feb 11 23:15:51 +0000 2018",
        "id": 962827553038888960,
        "text": "RT @mattmfm: Barack Obama was in the same room as Louis Farrakhan once and it caused a decades-long controversy. \n\nDonald Trump gave a shou\u2026",
        "user.screen_name": "barbjean"
    },
    {
        "created_at": "Sun Feb 11 23:15:51 +0000 2018",
        "id": 962827552279719936,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "VeronicaSam13"
    },
    {
        "created_at": "Sun Feb 11 23:15:51 +0000 2018",
        "id": 962827550715031552,
        "text": "RT @JudicialWatch: As part of our effort to hold Mueller's investigation accountable, JW uncovered docs showing top DOJ officials including\u2026",
        "user.screen_name": "BreeColorado"
    },
    {
        "created_at": "Sun Feb 11 23:15:50 +0000 2018",
        "id": 962827547481427969,
        "text": "RT @tonyposnanski: Trump believes in due process except for...\n\n- Kenyan born Obama\n- Crooked Hillary\n- FBI\n- Anyone in the media who doesn\u2026",
        "user.screen_name": "TwymanPaige"
    },
    {
        "created_at": "Sun Feb 11 23:15:50 +0000 2018",
        "id": 962827546697064449,
        "text": "RT @RealMAGASteve: This bombshell report from the Senate Homeland Security Comm. IMPLICATES OBAMA in the #Obamagate scandal &amp; Clinton email\u2026",
        "user.screen_name": "broker1ajs"
    },
    {
        "created_at": "Sun Feb 11 23:15:50 +0000 2018",
        "id": 962827546390876160,
        "text": "RT @BluePillSheep: New FBI Text Messages Show Obama \u2018Wants To Know Everything We\u2019re Doing\u2019\n\nREAD OUR STORY HERE https://t.co/TRrmxBavZj\n\n#S\u2026",
        "user.screen_name": "OnlyJeanSeixasM"
    },
    {
        "created_at": "Sun Feb 11 23:15:49 +0000 2018",
        "id": 962827545572933633,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "EarlSimpsonII"
    },
    {
        "created_at": "Sun Feb 11 23:15:49 +0000 2018",
        "id": 962827543513411584,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "SATwerdnerd"
    },
    {
        "created_at": "Sun Feb 11 23:15:49 +0000 2018",
        "id": 962827543261806592,
        "text": "RT @brianklaas: Man who called to execute Central Park 5 &amp; insisted they were guilty after DNA evidence proved their innocence; spread birt\u2026",
        "user.screen_name": "ametola"
    },
    {
        "created_at": "Sun Feb 11 23:15:48 +0000 2018",
        "id": 962827541374435329,
        "text": "RT @realDonaldTrump: \u201cMy view is that not only has Trump been vindicated in the last several weeks about the mishandling of the Dossier and\u2026",
        "user.screen_name": "fidman_143"
    },
    {
        "created_at": "Sun Feb 11 23:15:48 +0000 2018",
        "id": 962827540791521280,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "CureOurCountry"
    },
    {
        "created_at": "Sun Feb 11 23:15:48 +0000 2018",
        "id": 962827540426567680,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "lynn_laj"
    },
    {
        "created_at": "Sun Feb 11 23:15:48 +0000 2018",
        "id": 962827539428380673,
        "text": "RT @TuckerCarlson: Here's what is clear right now, the bottom line on what we've learned this week and the one thing worth remembering: The\u2026",
        "user.screen_name": "bulladave"
    },
    {
        "created_at": "Sun Feb 11 23:15:48 +0000 2018",
        "id": 962827538895695872,
        "text": "@Shaithis1404 She hasn\u2019t done nothing? You\u2019re an idiot, is it normal to bleach and destroy your computer hard drive\u2026 https://t.co/FJvrd3NZMP",
        "user.screen_name": "JPK051315"
    },
    {
        "created_at": "Sun Feb 11 23:15:48 +0000 2018",
        "id": 962827538438406144,
        "text": "RT @Go_DeeJay21: Barack Obama https://t.co/0T4ZCvOzGL",
        "user.screen_name": "CagedElefunt_"
    },
    {
        "created_at": "Sun Feb 11 23:15:47 +0000 2018",
        "id": 962827536341364736,
        "text": "@LorraineButch10 @patfo49 @Renshaw1921 @MrConsrvative @darkbeautiful77 @DeannaSands1 @blkftid @TenaciousTwitt\u2026 https://t.co/WOK6gW3Fg8",
        "user.screen_name": "Chazmaspaz"
    },
    {
        "created_at": "Sun Feb 11 23:15:47 +0000 2018",
        "id": 962827534298628096,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "Vammen2"
    },
    {
        "created_at": "Sun Feb 11 23:15:47 +0000 2018",
        "id": 962827534198067200,
        "text": "RT @Fuctupmind: Pretty much everyone knew about the Steele Dossier.\n\nThe entire Obama admin.\nSid Blumenthal.\nHillary Clinton.\nLoretta Lynch\u2026",
        "user.screen_name": "Dimplenut"
    },
    {
        "created_at": "Sun Feb 11 23:15:47 +0000 2018",
        "id": 962827533791014912,
        "text": "RT @SoCoolUSA: It seems Holder and OBama and Kerry thinking aiding terrorists and enemies of the US is okay.   I call it treason. https://t\u2026",
        "user.screen_name": "TinaWest123321"
    },
    {
        "created_at": "Sun Feb 11 23:15:47 +0000 2018",
        "id": 962827533371797504,
        "text": "RT @KaniJJackson: This is just your daily reminder that Barack Obama did not have 1 scandal or allegation against him during his time in th\u2026",
        "user.screen_name": "diaz_suzanneX"
    },
    {
        "created_at": "Sun Feb 11 23:15:46 +0000 2018",
        "id": 962827532897841154,
        "text": "RT @NewtTrump: Newt Gingrich: \"Let me just point out how sick the elite media is \u2014 they report all that as though it\u2019s something bad about\u2026",
        "user.screen_name": "circumspectus"
    },
    {
        "created_at": "Sun Feb 11 23:15:46 +0000 2018",
        "id": 962827532109262848,
        "text": "@Education4Libs Don't forget Obama meeting a chick that eats cereal out of the bathtub.",
        "user.screen_name": "LOLatSJWs"
    },
    {
        "created_at": "Sun Feb 11 23:15:46 +0000 2018",
        "id": 962827531903815681,
        "text": "\"Instant Justice: After G W Bush &amp; Obama Teamed Up to Attack Trump, Fox Host Leaked Their Worst Nightmare\" https://t.co/KbExiSstJD",
        "user.screen_name": "TrumpNewsz"
    },
    {
        "created_at": "Sun Feb 11 23:15:46 +0000 2018",
        "id": 962827530846769155,
        "text": "RT @Bakari_Sellers: Fox News viewers believe its Obama\u2019s fault Rob Porter beat his wives. https://t.co/5y8wPzWLOu",
        "user.screen_name": "JeffMisterWhite"
    },
    {
        "created_at": "Sun Feb 11 23:15:46 +0000 2018",
        "id": 962827530834186242,
        "text": "RT @qz: Hip-hop painter Kehinde Wiley\u2019s portrait of Barack Obama will be unveiled tomorrow https://t.co/8wCPxkTX78",
        "user.screen_name": "zakouts84"
    },
    {
        "created_at": "Sun Feb 11 23:15:45 +0000 2018",
        "id": 962827528095219713,
        "text": "RT @YugeCrowd: Trump speaking about Putin:\n\n\"I do have a relationship with him\"\n\n\"He's done a brilliant job\"\n\nOn Putin's leadership:\n\n\"Some\u2026",
        "user.screen_name": "TheMadWhitaker"
    },
    {
        "created_at": "Sun Feb 11 23:15:45 +0000 2018",
        "id": 962827528066002946,
        "text": "#Comey's court declaration may lead to #Obama &amp; #ObamaGate\nComey must clear himself - and everyone - of suspicion t\u2026 https://t.co/0ANp5FOp42",
        "user.screen_name": "LanceSilver1"
    },
    {
        "created_at": "Sun Feb 11 23:15:45 +0000 2018",
        "id": 962827526816108547,
        "text": "RT @sdc0911: \ud83d\udd25Clinton and Obama\ud83d\udd25Two people\u2019s \ud83d\ude21NAMES\ud83d\ude21 that are ENOUGH\u274c\u274cTO PISS YOU OFF\u203c\ufe0f\ud83d\ude21#LockThemUp\ud83d\udca5#ClintonCrimeFamily \ud83d\udca5#ObamaGateExposed\u2026",
        "user.screen_name": "tkearney922"
    },
    {
        "created_at": "Sun Feb 11 23:15:45 +0000 2018",
        "id": 962827526170128386,
        "text": "RT @renato_mariotti: President Obama created DACA because Republicans blocked the Dream Act. Trump ended DACA on his own\u2014don\u2019t let him get\u2026",
        "user.screen_name": "8ayonetta"
    },
    {
        "created_at": "Sun Feb 11 23:15:45 +0000 2018",
        "id": 962827525226340353,
        "text": "@realDonaldTrump when are you going to Fix education? The system is corrupted with Obama era liberal &amp; self entitle\u2026 https://t.co/IEF5Rpehjm",
        "user.screen_name": "voltagerisk"
    },
    {
        "created_at": "Sun Feb 11 23:15:45 +0000 2018",
        "id": 962827525146759168,
        "text": "RT @hectormorenco: Obama\u2019s Iran Deal was such a ridiculous and amateur attempt at foreign policy. He gave billions in cash and nuclear weap\u2026",
        "user.screen_name": "pepper10001"
    },
    {
        "created_at": "Sun Feb 11 23:15:44 +0000 2018",
        "id": 962827524630827014,
        "text": "RT @treasonstickers: Multiple people have taken plea deals in Mueller\u2019s investigation\n\n\ud83d\udc47\n\nMueller would only approve a plea deal for a witn\u2026",
        "user.screen_name": "b_l_edwards"
    },
    {
        "created_at": "Sun Feb 11 23:15:44 +0000 2018",
        "id": 962827523775221760,
        "text": "RT @JimKuther: JUST IN: Police Searching for Obama DREAMer Accused of Brutal Murder https://t.co/FAmqybSgBn via @truthfeednews",
        "user.screen_name": "carlislecockato"
    },
    {
        "created_at": "Sun Feb 11 23:15:44 +0000 2018",
        "id": 962827522751811585,
        "text": "RT @Chicago1Ray: \" You, me... we own this Country. Politicians are employees of ours. And when somebody doesn't do the Job, We gotta let 'e\u2026",
        "user.screen_name": "acom5sm"
    },
    {
        "created_at": "Sun Feb 11 23:15:44 +0000 2018",
        "id": 962827521346756608,
        "text": "\u201cTrue democracy is a project that\u2019s much bigger than any one of us. It\u2019s bigger than any one person, any one presid\u2026 https://t.co/35NzyKVx0I",
        "user.screen_name": "PattiLaRue"
    },
    {
        "created_at": "Sun Feb 11 23:15:44 +0000 2018",
        "id": 962827520797265926,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "kOCarter2016"
    },
    {
        "created_at": "Sun Feb 11 23:15:43 +0000 2018",
        "id": 962827520214093824,
        "text": "Tom Del Beccaro: All Corrupt DOJ and FBI Roads Lead to Obama https://t.co/JxPNVW1yWp via @BreitbartNews",
        "user.screen_name": "yoly4Trump"
    },
    {
        "created_at": "Sun Feb 11 23:15:43 +0000 2018",
        "id": 962827518955831296,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "ryannsinclaire"
    },
    {
        "created_at": "Sun Feb 11 23:15:43 +0000 2018",
        "id": 962827518322663424,
        "text": "RT @RobertIobbi: @CharlieDaniels Assets were spinning up within minutes. Obama gave the stand down order They were protecting their gun smu\u2026",
        "user.screen_name": "HellyerE"
    },
    {
        "created_at": "Sun Feb 11 23:15:43 +0000 2018",
        "id": 962827517353656321,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "DennisKulpa"
    },
    {
        "created_at": "Sun Feb 11 23:15:43 +0000 2018",
        "id": 962827516439416833,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "YaReelDaddy"
    },
    {
        "created_at": "Sun Feb 11 23:15:42 +0000 2018",
        "id": 962827514694586373,
        "text": "RT @Hoosiers1986: #FakeRelationshipFacts\n\nDEM voters are gullible fools!\n\nThey revere idiots like Obama, Schumer &amp; Pelosi who COULD have pr\u2026",
        "user.screen_name": "sissylou1"
    },
    {
        "created_at": "Sun Feb 11 23:15:42 +0000 2018",
        "id": 962827514539380736,
        "text": "RT @RyanAFournier: Do you believe the Obama Administration improperly and illegally surveilled the Trump Campaign? #SHARE",
        "user.screen_name": "decadentbehavi1"
    },
    {
        "created_at": "Sun Feb 11 23:15:42 +0000 2018",
        "id": 962827513499090949,
        "text": "RT @Bakari_Sellers: Fox News viewers believe its Obama\u2019s fault Rob Porter beat his wives. https://t.co/5y8wPzWLOu",
        "user.screen_name": "javierroman3711"
    },
    {
        "created_at": "Sun Feb 11 23:15:41 +0000 2018",
        "id": 962827510462537728,
        "text": "RT @mike_Zollo: Obama's former Press Secretary @JayCarney, as well as the #FakeNews Media say Obama NEVER spoke about the #StockMarket when\u2026",
        "user.screen_name": "DianneSteiner"
    },
    {
        "created_at": "Sun Feb 11 23:15:41 +0000 2018",
        "id": 962827509170520064,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "Arise_Israel"
    },
    {
        "created_at": "Sun Feb 11 23:15:41 +0000 2018",
        "id": 962827508969299969,
        "text": "RT @tonyposnanski: Trump believes in due process except for...\n\n- Kenyan born Obama\n- Crooked Hillary\n- FBI\n- Anyone in the media who doesn\u2026",
        "user.screen_name": "miightymiighty"
    },
    {
        "created_at": "Sun Feb 11 23:15:40 +0000 2018",
        "id": 962827505781665797,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "lindamarlow4"
    },
    {
        "created_at": "Sun Feb 11 23:15:40 +0000 2018",
        "id": 962827505588736000,
        "text": "RT @rmasher2: Funny. I don't recall President Obama being called to testify before a Special Counsel/Grand Jury looking into possible crimi\u2026",
        "user.screen_name": "AugustLady241"
    },
    {
        "created_at": "Sun Feb 11 23:15:40 +0000 2018",
        "id": 962827503885848576,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "VetforP"
    },
    {
        "created_at": "Sun Feb 11 23:15:39 +0000 2018",
        "id": 962827502640132098,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "jaded5643"
    },
    {
        "created_at": "Sun Feb 11 23:15:39 +0000 2018",
        "id": 962827502543515648,
        "text": "Poll: Most Americans believe former President Barack Obama wiretapped the Trump administration &amp; want a special pro\u2026 https://t.co/cyFWAfA7lf",
        "user.screen_name": "d_notices"
    },
    {
        "created_at": "Sun Feb 11 23:15:39 +0000 2018",
        "id": 962827501599936514,
        "text": "RT @DeborahDiltz: @MarthaG45242469 @MonumentsForUSA @realDonaldTrump @SecretaryZinke  Obama named 33 huge areas of US National Monuments. N\u2026",
        "user.screen_name": "DebRourke4"
    },
    {
        "created_at": "Sun Feb 11 23:15:39 +0000 2018",
        "id": 962827500123500544,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "Cass_I_Nova"
    },
    {
        "created_at": "Sun Feb 11 23:15:38 +0000 2018",
        "id": 962827498773012480,
        "text": "@wi11iedigital @JudgeJudyPovich @kylegriffin1 Yes and my grandpa use to wear red boxers, and we had a moonlight 3 d\u2026 https://t.co/Tpwc23iHcT",
        "user.screen_name": "needimpeachment"
    },
    {
        "created_at": "Sun Feb 11 23:15:38 +0000 2018",
        "id": 962827497598541826,
        "text": "RT @johncusack: You wanna play ?  Answer-  look up Obama\u2019s war on constitution - interview I did - check out @FreedomofPress  I\u2019m on the bo\u2026",
        "user.screen_name": "butterflyann"
    },
    {
        "created_at": "Sun Feb 11 23:15:38 +0000 2018",
        "id": 962827496495374336,
        "text": "RT @11S_L_2016_Cat: What deluded Upside Down world do you live in? You sent him a memo YOU knew could not be released. The louder you prote\u2026",
        "user.screen_name": "ElisAmerica1"
    },
    {
        "created_at": "Sun Feb 11 23:15:38 +0000 2018",
        "id": 962827496361267200,
        "text": "@chelseahandler Yes Obama\u2019s supports the left. Weinstein\u2019s actions are ok by you guys",
        "user.screen_name": "10th_03blacksvt"
    },
    {
        "created_at": "Sun Feb 11 23:15:38 +0000 2018",
        "id": 962827496319344641,
        "text": "RT @edgecrusher23: DEA Agent Notices $200,000,000 in Cars Being Shipped into South Africa by Obama Admin. as Drug Money flows to American B\u2026",
        "user.screen_name": "JonnybeHood"
    },
    {
        "created_at": "Sun Feb 11 23:15:38 +0000 2018",
        "id": 962827495438475265,
        "text": "RT @DropTha_Mic25: @PoliticalShort It even began before Crowdstrike was hanging out with John Carlin, Hillary henchmen, Obama wingmen &amp; GCH\u2026",
        "user.screen_name": "see_jl"
    },
    {
        "created_at": "Sun Feb 11 23:15:37 +0000 2018",
        "id": 962827495203659776,
        "text": "RT @JessieJaneDuff: DHS official &amp; former Obama ambassador James Nealon resigned, upset recommendations to extend \u201ctemporary protected stat\u2026",
        "user.screen_name": "JNG1925"
    },
    {
        "created_at": "Sun Feb 11 23:15:37 +0000 2018",
        "id": 962827494931030023,
        "text": "@dlreddy14051 @honeysiota @Scaramucci Hussein turned the federal government into a corrupt, Chicago-style machine,\u2026 https://t.co/ovLV8yelHL",
        "user.screen_name": "SandyWocs"
    },
    {
        "created_at": "Sun Feb 11 23:15:37 +0000 2018",
        "id": 962827492892360704,
        "text": "RT @eschaz12: @rich752913078 @lehimesa 2 years ago all my protests were tagged 2 Obama &amp; his horse killer Secretary of the Interior #KenSal\u2026",
        "user.screen_name": "lehimesa"
    },
    {
        "created_at": "Sun Feb 11 23:15:37 +0000 2018",
        "id": 962827492280164353,
        "text": "RT @TheNYevening: Sylvester Stallone: \u2018Pathetic\u2019 Obama Is \u2018Closet Homosexual Living A Lie\u2019 https://t.co/FbeFN3Fu3N https://t.co/FJDWQ0HS8X",
        "user.screen_name": "Imlacerci"
    },
    {
        "created_at": "Sun Feb 11 23:15:37 +0000 2018",
        "id": 962827491500089344,
        "text": "RT @TomFitton: The American people should be able to see for themselves the FISA court docs on how Obama admin used Clinton document to mis\u2026",
        "user.screen_name": "Najum13"
    },
    {
        "created_at": "Sun Feb 11 23:15:36 +0000 2018",
        "id": 962827488899473408,
        "text": "RT @NinoCutraro: She say do you love me, I tell her only partly, I only love my bed and Obama, I'm sorry. https://t.co/6Pc1fsg8jn",
        "user.screen_name": "Cinnamon_daddy"
    },
    {
        "created_at": "Sun Feb 11 23:15:36 +0000 2018",
        "id": 962827486986895362,
        "text": "RT @LBCINDAHOUSE: @HandofGOD7 George Soros is a financial terrorist, and a forked tongue lizard who said: \"the culmination of my life's wor\u2026",
        "user.screen_name": "spurs4eva1965"
    },
    {
        "created_at": "Sun Feb 11 23:15:35 +0000 2018",
        "id": 962827484898131968,
        "text": "RT @GStuedler: Budget-busting deal shows that Barack Obama was much better at business than Trump https://t.co/DaC4HutnHh",
        "user.screen_name": "LeAnnLawson15"
    },
    {
        "created_at": "Sun Feb 11 23:15:35 +0000 2018",
        "id": 962827484118077440,
        "text": "RT @UnitedWeStandDT: @AMErikaNGIRLBOT @realDonaldTrump @DonaldJTrumpJr The only time I have ever agreed with @BarackObama\u2026",
        "user.screen_name": "juliegw613"
    },
    {
        "created_at": "Sun Feb 11 23:15:35 +0000 2018",
        "id": 962827483807735808,
        "text": "RT @JudicialWatch: As part of our effort to hold Mueller's investigation accountable, JW uncovered docs showing top DOJ officials including\u2026",
        "user.screen_name": "Beck38094740"
    },
    {
        "created_at": "Sun Feb 11 23:15:34 +0000 2018",
        "id": 962827479265128448,
        "text": "@AynRandPaulRyan Just can't stop blaming every Trump screw up on Obama or Hillary. Come take ownership when your gu\u2026 https://t.co/SeBEpg8hDj",
        "user.screen_name": "Leafsbh"
    },
    {
        "created_at": "Sun Feb 11 23:15:33 +0000 2018",
        "id": 962827478313132032,
        "text": "RT @JessieJaneDuff: DHS official &amp; former Obama ambassador James Nealon resigned, upset recommendations to extend \u201ctemporary protected stat\u2026",
        "user.screen_name": "LibertysCall45"
    },
    {
        "created_at": "Sun Feb 11 23:15:33 +0000 2018",
        "id": 962827477822394369,
        "text": "RT @WilDonnelly: Rajesh De, who served as top lawyer at the NSA, and also in Porter's job in Obama WH, says he was exposed to much more sen\u2026",
        "user.screen_name": "mvanderKist"
    },
    {
        "created_at": "Sun Feb 11 23:15:33 +0000 2018",
        "id": 962827476677341184,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "RainerMcDermott"
    },
    {
        "created_at": "Sun Feb 11 23:15:33 +0000 2018",
        "id": 962827476497059843,
        "text": "RT @TheTrumpLady: BREAKING: FBI Informant Just Flipped on Obama in Uranium One Testimony. Obama's House of Cards Is Starting To Tumble In T\u2026",
        "user.screen_name": "koaga7"
    },
    {
        "created_at": "Sun Feb 11 23:15:33 +0000 2018",
        "id": 962827475729375232,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "mrmatt408"
    },
    {
        "created_at": "Sun Feb 11 23:15:32 +0000 2018",
        "id": 962827473409880064,
        "text": "RT @jtwigg52: @sam_doucette @kelly4NC Just curious. Do you feel that Trumps executive orders are just as illegal as President Obama's were,\u2026",
        "user.screen_name": "pookietooth"
    },
    {
        "created_at": "Sun Feb 11 23:15:32 +0000 2018",
        "id": 962827472160088065,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "Warhead85Ben"
    },
    {
        "created_at": "Sun Feb 11 23:15:32 +0000 2018",
        "id": 962827470603997184,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "JohnRealSmith"
    },
    {
        "created_at": "Sun Feb 11 23:15:31 +0000 2018",
        "id": 962827469781807104,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "Alpha_Lady1"
    },
    {
        "created_at": "Sun Feb 11 23:15:31 +0000 2018",
        "id": 962827469345636352,
        "text": "Obama Official: I Passed Clinton Lies to Steele That Were Used Against Trump https://t.co/JZWF387sNz",
        "user.screen_name": "Lanchr4"
    },
    {
        "created_at": "Sun Feb 11 23:15:31 +0000 2018",
        "id": 962827467575578624,
        "text": "Next week she'll blame Obama for beating Porter's wife and framing Porter. https://t.co/AR1X66TgDJ",
        "user.screen_name": "FakeArtCritic"
    },
    {
        "created_at": "Sun Feb 11 23:15:30 +0000 2018",
        "id": 962827465541419008,
        "text": "@MikaelaSkyeSays @Shoq His recent tweets are about him trying to get MAGA people to admit even one thing they disag\u2026 https://t.co/jGg7fNJSMK",
        "user.screen_name": "KubeJ9"
    },
    {
        "created_at": "Sun Feb 11 23:15:30 +0000 2018",
        "id": 962827465512058882,
        "text": "RT @PimpingPolitics: @JerylBier AND wherever you find @LouisFarrakhan, you're gonna find #Muslims &amp; @BarackObama engaging with @scientology\u2026",
        "user.screen_name": "PimpingPolitics"
    },
    {
        "created_at": "Sun Feb 11 23:15:29 +0000 2018",
        "id": 962827461430882305,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "tree165r"
    },
    {
        "created_at": "Sun Feb 11 23:15:29 +0000 2018",
        "id": 962827460197875712,
        "text": "RT @BillPeriman: @TomAdams9999 @MyReaume @jcdwms @sholzbee @USAlivestrong @Peggyha85570471 @blove65 @mommydean74 @Tierrah46 @yjon97 @thetoy\u2026",
        "user.screen_name": "MclaneScott"
    },
    {
        "created_at": "Sun Feb 11 23:15:29 +0000 2018",
        "id": 962827459879194624,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "sgenie"
    },
    {
        "created_at": "Sun Feb 11 23:15:29 +0000 2018",
        "id": 962827458126012417,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "JamesJo76415286"
    },
    {
        "created_at": "Sun Feb 11 23:15:29 +0000 2018",
        "id": 962827458029420549,
        "text": "RT @BennytheKite: @brandona5811 @ObozoLies Thank you for following me.\n\nWhat a shame that #WheresBarack is sill missing.  A photo of him wi\u2026",
        "user.screen_name": "ObozoLies"
    },
    {
        "created_at": "Sun Feb 11 23:15:29 +0000 2018",
        "id": 962827457647673344,
        "text": "RT @aligiarc: Real criminality by BHO is lying in PLAIN SIGHT. Epic corruption purposely ignored by self-proclaimed arbiters of truth in MS\u2026",
        "user.screen_name": "yoly4Trump"
    },
    {
        "created_at": "Sun Feb 11 23:15:28 +0000 2018",
        "id": 962827456888569857,
        "text": "RT @JudicialWatch: Reminder: JW found evidence showing Obama State Dept under John Kerry sent its own \"dossier\" of classified info on Russi\u2026",
        "user.screen_name": "cyndi_obrion"
    },
    {
        "created_at": "Sun Feb 11 23:15:28 +0000 2018",
        "id": 962827455403786245,
        "text": "RT @WilDonnelly: Rajesh De, who served as top lawyer at the NSA, and also in Porter's job in Obama WH, says he was exposed to much more sen\u2026",
        "user.screen_name": "cecilia45301471"
    },
    {
        "created_at": "Sun Feb 11 23:15:28 +0000 2018",
        "id": 962827455076716545,
        "text": "RT @cathibrgnr58: @LoriJac47135906 @SandraTXAS @ClintonM614 @LVNancy @JVER1 @Hoosiers1986 @GrizzleMeister @GaetaSusan @baalter @On_The_Hook\u2026",
        "user.screen_name": "Chriskl70208387"
    },
    {
        "created_at": "Sun Feb 11 23:15:28 +0000 2018",
        "id": 962827454904766464,
        "text": "@TomFitton @JudicialWatch @realDonaldTrump obama's 3000 days of repugnant jihadist tyranny, we haven't seen this le\u2026 https://t.co/L5cskkj8tp",
        "user.screen_name": "americanpro1"
    },
    {
        "created_at": "Sun Feb 11 23:15:28 +0000 2018",
        "id": 962827453822586887,
        "text": "@MaudlinTown Truer words were never spoken. I have always been apprehensive about President Trump\u2019s manner and word\u2026 https://t.co/uSlvTT9tF6",
        "user.screen_name": "tediph"
    },
    {
        "created_at": "Sun Feb 11 23:15:27 +0000 2018",
        "id": 962827451595288576,
        "text": "RT @_David_Edward: The worst part about this outrage bait is the fact that literally nobody is ignoring North Korea. Well, except maybe Oba\u2026",
        "user.screen_name": "mooshakins"
    },
    {
        "created_at": "Sun Feb 11 23:15:27 +0000 2018",
        "id": 962827450462879744,
        "text": "@islandmama0105 @WayneDupreeShow @GOP I'm neither lib or conservative I'm about the truth. Yes Obama took a pic wit\u2026 https://t.co/7z7J4nQ8Hn",
        "user.screen_name": "Bdwal359"
    },
    {
        "created_at": "Sun Feb 11 23:15:27 +0000 2018",
        "id": 962827450123104257,
        "text": "RT @MrFutbol: A Day at Svasvar with the Trumps https://t.co/xy0f8MZkHv",
        "user.screen_name": "MrFutbol"
    },
    {
        "created_at": "Sun Feb 11 23:15:27 +0000 2018",
        "id": 962827449946972160,
        "text": "RT @JessieJaneDuff: DHS official &amp; former Obama ambassador James Nealon resigned, upset recommendations to extend \u201ctemporary protected stat\u2026",
        "user.screen_name": "PeggySizemore1"
    },
    {
        "created_at": "Sun Feb 11 23:15:26 +0000 2018",
        "id": 962827448890089473,
        "text": "RT @TomFitton: The American people should be able to see for themselves the FISA court docs on how Obama admin used Clinton document to mis\u2026",
        "user.screen_name": "LoriHasso"
    },
    {
        "created_at": "Sun Feb 11 23:15:26 +0000 2018",
        "id": 962827448642621440,
        "text": "RT @chuckwoolery: CONFIRMED: Cash from Obama\u2019s $1.7 Billion Ransom Payment to Iran Traced to Terrorist Groups (VIDEO) https://t.co/iXgrFQyw\u2026",
        "user.screen_name": "AlliSheKnows"
    },
    {
        "created_at": "Sun Feb 11 23:15:26 +0000 2018",
        "id": 962827446989946880,
        "text": "RT @renato_mariotti: President Obama created DACA because Republicans blocked the Dream Act. Trump ended DACA on his own\u2014don\u2019t let him get\u2026",
        "user.screen_name": "iandjardine"
    },
    {
        "created_at": "Sun Feb 11 23:15:26 +0000 2018",
        "id": 962827445693906945,
        "text": "RT @FiveRights: Obama State Dept Official Jonathan Winer:\nI took opposition research from Hillary's best friend, Sid Blumenthal, and fed it\u2026",
        "user.screen_name": "177618122016USA"
    },
    {
        "created_at": "Sun Feb 11 23:15:26 +0000 2018",
        "id": 962827445685702656,
        "text": "RT @Chicago1Ray: \" You, me... we own this Country. Politicians are employees of ours. And when somebody doesn't do the Job, We gotta let 'e\u2026",
        "user.screen_name": "Marla68983234"
    },
    {
        "created_at": "Sun Feb 11 23:15:25 +0000 2018",
        "id": 962827444905480192,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "TNbabyboomer"
    },
    {
        "created_at": "Sun Feb 11 23:15:25 +0000 2018",
        "id": 962827443143766017,
        "text": "RT @GaitaudCons: Another 1st ! Barack Obama has been eerily silent, now exposed that this is not just a federal offense, but also it can le\u2026",
        "user.screen_name": "schmuckal51"
    },
    {
        "created_at": "Sun Feb 11 23:15:24 +0000 2018",
        "id": 962827439704629248,
        "text": "RT @JudicialWatch: Reminder: JW found evidence showing Obama State Dept under John Kerry sent its own \"dossier\" of classified info on Russi\u2026",
        "user.screen_name": "joeycanoli62"
    },
    {
        "created_at": "Sun Feb 11 23:15:24 +0000 2018",
        "id": 962827438232297472,
        "text": "RT @wraithwrites: @hotfunkytown @DineshDSouza Obama failed at everything he did. Why should this be any different? Corrupt FBI &amp; DOJ agents\u2026",
        "user.screen_name": "SiewTng"
    },
    {
        "created_at": "Sun Feb 11 23:15:23 +0000 2018",
        "id": 962827436126765057,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "Aledajane"
    },
    {
        "created_at": "Sun Feb 11 23:15:23 +0000 2018",
        "id": 962827435560570880,
        "text": "RT @JudicialWatch: Reminder: JW found evidence showing Obama State Dept under John Kerry sent its own \"dossier\" of classified info on Russi\u2026",
        "user.screen_name": "brendakae42"
    },
    {
        "created_at": "Sun Feb 11 23:15:23 +0000 2018",
        "id": 962827434658758657,
        "text": "RT @brianklaas: Man who called to execute Central Park 5 &amp; insisted they were guilty after DNA evidence proved their innocence; spread birt\u2026",
        "user.screen_name": "siegel_nancy"
    },
    {
        "created_at": "Sun Feb 11 23:15:23 +0000 2018",
        "id": 962827433371164673,
        "text": "@JerylBier AND wherever you find @LouisFarrakhan, you're gonna find #Muslims &amp; @BarackObama engaging with\u2026 https://t.co/xynpCUGrhs",
        "user.screen_name": "PimpingPolitics"
    },
    {
        "created_at": "Sun Feb 11 23:15:22 +0000 2018",
        "id": 962827430972084225,
        "text": "RT @joncoopertweets: Sure, @realDonaldTrump is a lying, corrupt, racist, traitorous imbecile who defends white supremacists, Nazis, wife be\u2026",
        "user.screen_name": "Yates4Prez"
    },
    {
        "created_at": "Sun Feb 11 23:15:22 +0000 2018",
        "id": 962827429210411008,
        "text": "RT @Logic_Triumphs: \u2b50\u2b50\u2b50\u2b50\u2b50\nBarack Obama has 99.7 million followers.\nIt would kill Donald Trump if Obama hit 100 million. Whatever you do do\u2026",
        "user.screen_name": "lamadness123"
    },
    {
        "created_at": "Sun Feb 11 23:15:22 +0000 2018",
        "id": 962827428899979264,
        "text": "RT @KaniJJackson: This is just your daily reminder that Barack Obama did not have 1 scandal or allegation against him during his time in th\u2026",
        "user.screen_name": "Bill_Canter"
    },
    {
        "created_at": "Sun Feb 11 23:15:21 +0000 2018",
        "id": 962827427880738817,
        "text": "Why Sasha Obama Why Expose Yourself #Why2Me",
        "user.screen_name": "Gwiz24"
    },
    {
        "created_at": "Sun Feb 11 23:15:21 +0000 2018",
        "id": 962827426928750592,
        "text": "@Indyria57Maria @SusResister @POTUS44 That picture and thinking of what it said to me, made me cry tears of joy thi\u2026 https://t.co/SfZ3wX7Pvv",
        "user.screen_name": "mydogsmom315"
    },
    {
        "created_at": "Sun Feb 11 23:15:21 +0000 2018",
        "id": 962827425259446272,
        "text": "@Abnsojer1970 @FoxNews @foxandfriends @Franklin_Graham @realDonaldTrump Give some examples of Clinton and Obama sco\u2026 https://t.co/ur420flAOo",
        "user.screen_name": "Reini25"
    },
    {
        "created_at": "Sun Feb 11 23:15:21 +0000 2018",
        "id": 962827424051417088,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "Yvyraiju"
    },
    {
        "created_at": "Sun Feb 11 23:15:20 +0000 2018",
        "id": 962827423866814465,
        "text": "Most Think Obama White House Spied On Trump Campaign, Want Special Counsel: IBD/TIPP Poll https://t.co/5jq53vtMS3 -\n @IBDeditorials",
        "user.screen_name": "SMcK17"
    },
    {
        "created_at": "Sun Feb 11 23:15:20 +0000 2018",
        "id": 962827422855933952,
        "text": "RT @EdKrassen: If Jeanine Pirro can blame Barack Obama for Rob Porter beating his wives, then I blame Jeanine Pirro for Donald Trump assaul\u2026",
        "user.screen_name": "CatMamacat324"
    },
    {
        "created_at": "Sun Feb 11 23:15:20 +0000 2018",
        "id": 962827421518106624,
        "text": "Another trusted scourge Jonathan Winer comes clean!TRUTH shows Obama, HRC, Dems House/Senate, FBI Director Comey, D\u2026 https://t.co/DmWKFyGXk9",
        "user.screen_name": "JonReynolds6"
    },
    {
        "created_at": "Sun Feb 11 23:15:20 +0000 2018",
        "id": 962827421018984448,
        "text": "RT @ElderLansing: I've taken on the Ex Resident Coward Obama, Jay Z , Oprah, Steph Curry, LeBron James, Poverty Pump Maxine Waters and the\u2026",
        "user.screen_name": "SternsMarilyn"
    },
    {
        "created_at": "Sun Feb 11 23:15:20 +0000 2018",
        "id": 962827420280619008,
        "text": "Obama State Dept. Official Admits Free-Flowing Exchange of Reports with Trump Dossier Author https://t.co/G4X08ifm3L.",
        "user.screen_name": "S10MD3141592ne"
    },
    {
        "created_at": "Sun Feb 11 23:15:19 +0000 2018",
        "id": 962827417126612994,
        "text": "@ontarioisproud same reason Obama weakened US military. Trudeau is 'the last hope for international liberal order'",
        "user.screen_name": "ThreadgoodIdgy"
    },
    {
        "created_at": "Sun Feb 11 23:15:19 +0000 2018",
        "id": 962827416430243841,
        "text": "RT @DearAuntCrabby: Trump promotes argument that he's been 'victimized' by Obama administration https://t.co/NY5a0e77YZ \n\nOh brother, what\u2026",
        "user.screen_name": "Jorin_AZ_"
    },
    {
        "created_at": "Sun Feb 11 23:15:19 +0000 2018",
        "id": 962827415910277120,
        "text": "RT @danwlin: TRUMP: False allegations are dangerous\n\nALSO TRUMP: Obama is a foreigner. Central Park Five are guilty. Rafael Cruz killed JFK\u2026",
        "user.screen_name": "old_new_dad"
    },
    {
        "created_at": "Sun Feb 11 23:15:18 +0000 2018",
        "id": 962827414547107841,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "Kaos_Vs_Control"
    },
    {
        "created_at": "Sun Feb 11 23:15:18 +0000 2018",
        "id": 962827412668022784,
        "text": "If Edwin Jackson were Malia Obama, borders would be closed https://t.co/jdF0rJHtSQ",
        "user.screen_name": "res416"
    },
    {
        "created_at": "Sun Feb 11 23:15:18 +0000 2018",
        "id": 962827412135432192,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "Janettegallag15"
    },
    {
        "created_at": "Sun Feb 11 23:15:17 +0000 2018",
        "id": 962827409723572224,
        "text": "RT @FoxNews: .@TomFitton: \"[@realDonaldTrump] has been victimized by the Obama Administration.\" https://t.co/z3Vn9KY1M3",
        "user.screen_name": "sweetpeach77"
    },
    {
        "created_at": "Sun Feb 11 23:15:17 +0000 2018",
        "id": 962827408905732098,
        "text": "@realDonaldTrump The Obama Admin has indeed victimized our great President!  Can't wait to see justice done!",
        "user.screen_name": "LivingSmallNews"
    },
    {
        "created_at": "Sun Feb 11 23:15:17 +0000 2018",
        "id": 962827407773364224,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "P0TUSTrump2020"
    },
    {
        "created_at": "Sun Feb 11 23:15:17 +0000 2018",
        "id": 962827407659970560,
        "text": "RT @MRSSMH2: No, sweetie. No one sat on twitter defending Obama 24 hours a day the way Trump morons do. Look at yourselves. You\u2019re still at\u2026",
        "user.screen_name": "SylviaDonoghue3"
    },
    {
        "created_at": "Sun Feb 11 23:15:17 +0000 2018",
        "id": 962827407253106688,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "jpatton05"
    },
    {
        "created_at": "Sun Feb 11 23:15:16 +0000 2018",
        "id": 962827405915287552,
        "text": "RT @ObozoLies: This treasonous bastard Obama should be arrested for Sedition and Espionage for allowing Iran to obtain America's most advan\u2026",
        "user.screen_name": "ObozoLies"
    },
    {
        "created_at": "Sun Feb 11 23:15:16 +0000 2018",
        "id": 962827405802004481,
        "text": "RT @KaniJJackson: This is just your daily reminder that Barack Obama did not have 1 scandal or allegation against him during his time in th\u2026",
        "user.screen_name": "SpeckTara"
    },
    {
        "created_at": "Sun Feb 11 23:15:16 +0000 2018",
        "id": 962827405311266817,
        "text": "RT @Thomas1774Paine: ICYMI + DNC Letter May Have Uncovered Obama Scheme to Have FBI Frame-Up Trump https://t.co/NFmEyprw8C",
        "user.screen_name": "JUSTSHEKEL"
    },
    {
        "created_at": "Sun Feb 11 23:15:16 +0000 2018",
        "id": 962827403406884864,
        "text": "Truth\nhttps://t.co/FwJXbaqutT",
        "user.screen_name": "Dozingstocks"
    },
    {
        "created_at": "Sun Feb 11 23:15:15 +0000 2018",
        "id": 962827402694021120,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "UzjetotuF"
    },
    {
        "created_at": "Sun Feb 11 23:15:15 +0000 2018",
        "id": 962827400617889792,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "siesienna"
    },
    {
        "created_at": "Sun Feb 11 23:15:15 +0000 2018",
        "id": 962827400336871426,
        "text": "RT @tonyposnanski: Trump believes in due process except for...\n\n- Kenyan born Obama\n- Crooked Hillary\n- FBI\n- Anyone in the media who doesn\u2026",
        "user.screen_name": "mrboneheaddave"
    },
    {
        "created_at": "Sun Feb 11 23:15:15 +0000 2018",
        "id": 962827399464337408,
        "text": "RT @KrisParonto: We also didn\u2019t use the @FBI @CIA and @NSAGov to spy on @realDonaldTrump either.......isn\u2019t that what you said to Chris Wal\u2026",
        "user.screen_name": "sportschef"
    },
    {
        "created_at": "Sun Feb 11 23:15:15 +0000 2018",
        "id": 962827399359533062,
        "text": "@JasonJdphillips @Clark408 @realDonaldTrump Thanks Obama for setting that up.",
        "user.screen_name": "loum102"
    },
    {
        "created_at": "Sun Feb 11 23:15:15 +0000 2018",
        "id": 962827398919188480,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "VetforP"
    },
    {
        "created_at": "Sun Feb 11 23:15:14 +0000 2018",
        "id": 962827398310973443,
        "text": "RT @Hoosiers1986: #FakeRelationshipFacts\n\nDEM voters are gullible fools!\n\nThey revere idiots like Obama, Schumer &amp; Pelosi who COULD have pr\u2026",
        "user.screen_name": "DianeMDeath"
    },
    {
        "created_at": "Sun Feb 11 23:15:14 +0000 2018",
        "id": 962827397753061377,
        "text": "This Week in Media Bias History: Journalist Excited Over Obama Sex Dreams...  https://t.co/xnNTEUjfCF #NightmareFromHell #Nobama",
        "user.screen_name": "DragonForce_One"
    },
    {
        "created_at": "Sun Feb 11 23:15:14 +0000 2018",
        "id": 962827395043540992,
        "text": "RT @Imperator_Rex3: @DonaldJTrumpJr @KevinBooker212 I'm not. \n\nObama wanted to make Iran and Hezbollah stronger.\n\nThat's why Obama delivere\u2026",
        "user.screen_name": "tonibfoster"
    },
    {
        "created_at": "Sun Feb 11 23:15:13 +0000 2018",
        "id": 962827394464845832,
        "text": "@KaniJJackson @radiochick841 \ud83d\ude22 miss the Obama's",
        "user.screen_name": "SpeckTara"
    },
    {
        "created_at": "Sun Feb 11 23:15:13 +0000 2018",
        "id": 962827391537221632,
        "text": "@thesmed1 @Nativemanley @corinnemcdevitt @SarahPalinUSA Obama is not in office..we are dealing with a serial liar n\u2026 https://t.co/LpTQghNP7b",
        "user.screen_name": "andyscandy10"
    },
    {
        "created_at": "Sun Feb 11 23:15:13 +0000 2018",
        "id": 962827390522220545,
        "text": "RT @clivebushjd: Take a look what Democrats, Neocons &amp; RINOs have done to America\n\nWe must #DeportDreamers #EndChainMigration &amp; #BuildTheWa\u2026",
        "user.screen_name": "Pug2016"
    },
    {
        "created_at": "Sun Feb 11 23:15:12 +0000 2018",
        "id": 962827390106984450,
        "text": "RT @linda_lindylou: @NorthTXBlue @ChrisKosowski1 @DemWrite GO MOMS!! WE NEED EVERY ONE ON BOARD!! Be an ACTIVIST whever wnd however you can\u2026",
        "user.screen_name": "ChrisKosowski1"
    },
    {
        "created_at": "Sun Feb 11 23:15:12 +0000 2018",
        "id": 962827389498789889,
        "text": "RT @FiveRights: .@CNN\nTwo huge stories broke this wk:\n1. Strzok &amp; Page texts show Obama knew abt FBI's illegal spying on Trump &amp; did nothin\u2026",
        "user.screen_name": "bjdunniw001"
    },
    {
        "created_at": "Sun Feb 11 23:15:12 +0000 2018",
        "id": 962827388764721158,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "DanaZim92427381"
    },
    {
        "created_at": "Sun Feb 11 23:15:12 +0000 2018",
        "id": 962827388496293888,
        "text": "RT @ScottyBrain: \"One day we will realize that the Barack Obama Presidency was the biggest fraud ever perpetrated on the American people.\"\u2026",
        "user.screen_name": "CaseyPGAPro"
    },
    {
        "created_at": "Sun Feb 11 23:15:12 +0000 2018",
        "id": 962827387963658241,
        "text": "RT @HrrEerrer: Maybe Kelly didn\u2019t know because it didn\u2019t happen. How many times did obama say he found out when a scandal hit the press? Be\u2026",
        "user.screen_name": "TheRea1Hazelnut"
    },
    {
        "created_at": "Sun Feb 11 23:15:11 +0000 2018",
        "id": 962827386122272768,
        "text": "@DevinSavageOfcl @realDonaldTrump @DonaldJTrumpJr @JudgeJeanine @GovMikeHuckabee @seanhannity @SebGorka\u2026 https://t.co/0sf2Y5qT3P",
        "user.screen_name": "zackmantx"
    },
    {
        "created_at": "Sun Feb 11 23:15:11 +0000 2018",
        "id": 962827383739994112,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "jillfahmyyahoo1"
    },
    {
        "created_at": "Sun Feb 11 23:15:11 +0000 2018",
        "id": 962827383479861248,
        "text": "RT @RyanAFournier: Do you believe the Obama Administration improperly and illegally surveilled the Trump Campaign? #SHARE",
        "user.screen_name": "dalvis0921"
    },
    {
        "created_at": "Sun Feb 11 23:15:11 +0000 2018",
        "id": 962827383135809537,
        "text": "RT @adamcbest: The Fox News playbook in a nutshell: When there\u2019s absolutely, positively no way you can blame Hillary, some crackpot theory\u2026",
        "user.screen_name": "PaulStewartII"
    },
    {
        "created_at": "Sun Feb 11 23:15:11 +0000 2018",
        "id": 962827382297001984,
        "text": "RT @Joseph_B_James: @hotfunkytown @davidrodneyarch Obama is the epitome of fail.",
        "user.screen_name": "SiewTng"
    },
    {
        "created_at": "Sun Feb 11 23:15:10 +0000 2018",
        "id": 962827380204228609,
        "text": "'Democrats should be absolutely not confident in our ability to beat Donald Trump.' https://t.co/dBPx2xejdW",
        "user.screen_name": "PoliticsIsDirty"
    },
    {
        "created_at": "Sun Feb 11 23:15:10 +0000 2018",
        "id": 962827379914788864,
        "text": "RT @RealMAGASteve: This bombshell report from the Senate Homeland Security Comm. IMPLICATES OBAMA in the #Obamagate scandal &amp; Clinton email\u2026",
        "user.screen_name": "yogagenie"
    },
    {
        "created_at": "Sun Feb 11 23:15:10 +0000 2018",
        "id": 962827379197562880,
        "text": "Just watchin @MeetThePress...what a waste of an interview. Every time this adm brings up President Obama they shoul\u2026 https://t.co/VD0oiS95dt",
        "user.screen_name": "mommadigs"
    },
    {
        "created_at": "Sun Feb 11 23:15:10 +0000 2018",
        "id": 962827378534899717,
        "text": "RT @omriceren: Obama Dec 2011, after Iran seized American UAV: \"We've asked for it back. We'll see how the Iranians respond\" https://t.co/y\u2026",
        "user.screen_name": "boomdudecom"
    },
    {
        "created_at": "Sun Feb 11 23:15:09 +0000 2018",
        "id": 962827376865419264,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "BiancaaAlyssaa"
    },
    {
        "created_at": "Sun Feb 11 23:15:09 +0000 2018",
        "id": 962827374604816384,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "mhand4159"
    },
    {
        "created_at": "Sun Feb 11 23:15:09 +0000 2018",
        "id": 962827374587912192,
        "text": "RT @MRSSMH2: No, sweetie. No one sat on twitter defending Obama 24 hours a day the way Trump morons do. Look at yourselves. You\u2019re still at\u2026",
        "user.screen_name": "shaker0309"
    },
    {
        "created_at": "Sun Feb 11 23:15:09 +0000 2018",
        "id": 962827374306963456,
        "text": "RT @Hoosiers1986: #FakeRelationshipFacts\n\nDEM voters are gullible fools!\n\nThey revere idiots like Obama, Schumer &amp; Pelosi who COULD have pr\u2026",
        "user.screen_name": "carlislecockato"
    },
    {
        "created_at": "Sun Feb 11 23:15:08 +0000 2018",
        "id": 962827372830576641,
        "text": "@realDonaldTrump @JohnKasich @WestervillePD So Sad. Black guy guns down 2 officers. Where is black lives matter. Oh\u2026 https://t.co/g1AzJeFYw9",
        "user.screen_name": "HDSG2013"
    },
    {
        "created_at": "Sun Feb 11 23:15:08 +0000 2018",
        "id": 962827370565656576,
        "text": "@RepAdamSchiff You are such an idiot.  No more Obama and Hillary and you just can\u2019t help yourself. You haven\u2019t prov\u2026 https://t.co/CjL7vn47qe",
        "user.screen_name": "KarenGlasgow3"
    },
    {
        "created_at": "Sun Feb 11 23:15:08 +0000 2018",
        "id": 962827370502803456,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "PattyxB"
    },
    {
        "created_at": "Sun Feb 11 23:15:07 +0000 2018",
        "id": 962827366559985665,
        "text": "RT @TrumpBrat: ASTOUNDING 96% believe you, Bush41, are THE SWAMP\u203c\ufe0f in bed with Obama &amp; terrorists\u203c\ufe0f\n\nYOU LOSE! America is winning again w/P\u2026",
        "user.screen_name": "Mykalbq"
    },
    {
        "created_at": "Sun Feb 11 23:15:07 +0000 2018",
        "id": 962827366073622529,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "NancyCatalano6"
    },
    {
        "created_at": "Sun Feb 11 23:15:07 +0000 2018",
        "id": 962827365511446529,
        "text": "RT @LouDobbs: Surveillance Abuse- @EdRollins: The Obama administration did not play by the rules. They thought Clinton would be the next pr\u2026",
        "user.screen_name": "GateOfDemocracy"
    },
    {
        "created_at": "Sun Feb 11 23:15:06 +0000 2018",
        "id": 962827362911096832,
        "text": "The left will likely attempt to commandeer this success as a leftover effect of the Obama presidency, but there... https://t.co/85JWVd02O7",
        "user.screen_name": "visiontoamerica"
    },
    {
        "created_at": "Sun Feb 11 23:15:06 +0000 2018",
        "id": 962827362781024264,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "StaceyMaLaine"
    },
    {
        "created_at": "Sun Feb 11 23:15:05 +0000 2018",
        "id": 962827359647883264,
        "text": "RT @peterjhasson: Obama was at that 2005 meeting and took a smiling picture with Farrakhan...Which the the caucus suppressed for 13 years t\u2026",
        "user.screen_name": "txlady706"
    },
    {
        "created_at": "Sun Feb 11 23:15:05 +0000 2018",
        "id": 962827359437996032,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "1jeffwest"
    },
    {
        "created_at": "Sun Feb 11 23:15:05 +0000 2018",
        "id": 962827359052234752,
        "text": "RT @TheRISEofROD: The Day of Reckoning is coming for Dirty Dossier Dems/RINOs.\n\nIG Horowitz Report w/ over 1M pages of evidence to convict\u2026",
        "user.screen_name": "unkSWestside"
    },
    {
        "created_at": "Sun Feb 11 23:15:05 +0000 2018",
        "id": 962827358989443077,
        "text": "@WatchChad Hear Ye!! Hear Ye! As usual #celebrity  #liberals admiring now the #NorthKoreans a country who\u2019s leaders\u2026 https://t.co/wPmub41GE0",
        "user.screen_name": "soniajanet27"
    },
    {
        "created_at": "Sun Feb 11 23:15:05 +0000 2018",
        "id": 962827357286379520,
        "text": "RT @GartrellLinda: Flashback: Obama Felt 'Patriotic Resentment' Towards Mexican Flag-Waving Illegal Supporters\nWhy is it a punishment to be\u2026",
        "user.screen_name": "Arise_Israel"
    },
    {
        "created_at": "Sun Feb 11 23:15:05 +0000 2018",
        "id": 962827357093580800,
        "text": "RT @OliverMcGee: Jumping the Aisle: How I became a Black Republican in the Age of Obama. Retweet to share with your friends https://t.co/XE\u2026",
        "user.screen_name": "MaddoxMags"
    },
    {
        "created_at": "Sun Feb 11 23:15:04 +0000 2018",
        "id": 962827355650777090,
        "text": "RT @Bakari_Sellers: Fox News viewers believe its Obama\u2019s fault Rob Porter beat his wives. https://t.co/5y8wPzWLOu",
        "user.screen_name": "dnabarbera"
    },
    {
        "created_at": "Sun Feb 11 23:15:04 +0000 2018",
        "id": 962827355570999298,
        "text": "RT @bbusa617: JUST IN: GEORGE W. BUSH In Abu Dhabi\u2026TRASHES Trump, Embraces Illegals\u2026Pushes Russian Meddling In 2016 US Elections https://t.\u2026",
        "user.screen_name": "steadman_fl"
    },
    {
        "created_at": "Sun Feb 11 23:15:04 +0000 2018",
        "id": 962827354773995520,
        "text": "RT @twpettyVeteran: Another \u201chit job\u201d on President Trump. Had their beloved messiah, Obama, been treated in such a manner, the MSM would ha\u2026",
        "user.screen_name": "ImmoralReport"
    },
    {
        "created_at": "Sun Feb 11 23:15:04 +0000 2018",
        "id": 962827353343762432,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "Ryan_Chriss"
    },
    {
        "created_at": "Sun Feb 11 23:15:03 +0000 2018",
        "id": 962827352630800384,
        "text": "High level intelligence also continued as Crimea and sanctions were still recent events under Obama and, in 2017, t\u2026 https://t.co/QIafgU71Tb",
        "user.screen_name": "SRASorg"
    },
    {
        "created_at": "Sun Feb 11 23:15:03 +0000 2018",
        "id": 962827351062171648,
        "text": "@chuckwoolery THEY ARE ALL STILL WORKING FOR OBAMA'S 'I HAVE DREAM' MOMENT BY TRYING TO STEAL THE UNITED STATES IN\u2026 https://t.co/DfMhjSACnL",
        "user.screen_name": "uptheante99"
    },
    {
        "created_at": "Sun Feb 11 23:15:03 +0000 2018",
        "id": 962827350864887808,
        "text": "RT @PamelaGeller: Obama provided Iran with stealth drone that penetrated Israel\u2019s border https://t.co/pQqaiwDeSN https://t.co/rJuFUggwZl",
        "user.screen_name": "cali_dreamer12"
    },
    {
        "created_at": "Sun Feb 11 23:15:03 +0000 2018",
        "id": 962827350781112321,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "JimP3737"
    },
    {
        "created_at": "Sun Feb 11 23:15:03 +0000 2018",
        "id": 962827350449811456,
        "text": "RT @GartrellLinda: Obama Official Johnathan Winer: I Passed Clinton Lies to Steele That Were Used Against Trump Now the #ObamaGate scandal\u2026",
        "user.screen_name": "franginter"
    },
    {
        "created_at": "Sun Feb 11 23:15:03 +0000 2018",
        "id": 962827349933854727,
        "text": "RT @Brasilmagic: Jeanine Pirro needs a straight-jacket  https://t.co/G4wzGBUJ0b",
        "user.screen_name": "lamadness123"
    },
    {
        "created_at": "Sun Feb 11 23:15:03 +0000 2018",
        "id": 962827349220831233,
        "text": "RT @mikebloodworth: @JBitterly @realDonaldTrump Lol it never fails.  Can\u2019t defend Trump without bringing up Obama or a Clinton.",
        "user.screen_name": "JadeJensen29"
    },
    {
        "created_at": "Sun Feb 11 23:15:03 +0000 2018",
        "id": 962827349095079937,
        "text": "RT @conserv_tribune: It's incredible how fast Obama's \"legacy\" is collapsing. https://t.co/q1fK0zCVsO",
        "user.screen_name": "m_mmilling"
    },
    {
        "created_at": "Sun Feb 11 23:15:03 +0000 2018",
        "id": 962827348788858882,
        "text": "RT @WEEI: Kevin Garnett, Rajon Rondo and Doc Rivers on hand for Paul Pierce's number retirement https://t.co/o7Mra8B1Gz",
        "user.screen_name": "Obama_FOS"
    },
    {
        "created_at": "Sun Feb 11 23:15:03 +0000 2018",
        "id": 962827348709117952,
        "text": "Obama \u201cBureau\u201d Delivers Millions To Supporters, No Oversight, Now Laptops Gone https://t.co/vVQprXv45L via @cdp-something",
        "user.screen_name": "Usnst4"
    },
    {
        "created_at": "Sun Feb 11 23:15:02 +0000 2018",
        "id": 962827347681513477,
        "text": "@Shouty_Dave @Puckberger @LifeZette @trumps_feed @POTUS And BTW, there are a lot more facts supporting Obama/Hillar\u2026 https://t.co/a75n9Sywlw",
        "user.screen_name": "jbowser74"
    },
    {
        "created_at": "Sun Feb 11 23:15:01 +0000 2018",
        "id": 962827343319375877,
        "text": "RT @SassBaller: \u201cYou have the power to show our children that they matter!\u201d \n\nMichelle Obama gave this inspirational speech at the 2018 Sch\u2026",
        "user.screen_name": "olrockcandymtns"
    },
    {
        "created_at": "Sun Feb 11 23:15:01 +0000 2018",
        "id": 962827340685377536,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "alecserovic"
    },
    {
        "created_at": "Sun Feb 11 23:15:00 +0000 2018",
        "id": 962827336260481024,
        "text": "@ChrisCuomo Chris your network is fake.   Obama administration spied on Trump. FACT\n\nYou called Trump a liar for that.  CNN is pathetic.",
        "user.screen_name": "toddkazz"
    },
    {
        "created_at": "Sun Feb 11 23:14:59 +0000 2018",
        "id": 962827332691136512,
        "text": "RT @EdKrassen: If Jeanine Pirro can blame Barack Obama for Rob Porter beating his wives, then I blame Jeanine Pirro for Donald Trump assaul\u2026",
        "user.screen_name": "eeh230"
    },
    {
        "created_at": "Sun Feb 11 23:14:58 +0000 2018",
        "id": 962827331529306112,
        "text": "RT @Imperator_Rex3: @PoliticalShort Steele gave the dossier to Hannigan, who passes it to Brennan, who then passed it to Obama &amp; Comey.\n\nHe\u2026",
        "user.screen_name": "see_jl"
    },
    {
        "created_at": "Sun Feb 11 23:14:58 +0000 2018",
        "id": 962827330082271232,
        "text": "@Legski0301 @HCiavotto @wildbez @DineshDSouza @dbongino @realDonaldTrump U don't know if you'll spend  $500,000 of\u2026 https://t.co/f2yQ5M1JuR",
        "user.screen_name": "DennisLittle19"
    },
    {
        "created_at": "Sun Feb 11 23:14:58 +0000 2018",
        "id": 962827328282943488,
        "text": "RT @nizmycuba: \"Melania Trump Demanded Spiritual Cleansing of Obama &amp; Clinton White House, Removal of Pagan and Demonic Idols.\" That\u2019s a st\u2026",
        "user.screen_name": "Imlacerci"
    },
    {
        "created_at": "Sun Feb 11 23:14:57 +0000 2018",
        "id": 962827326550573056,
        "text": "RT @FiveRights: Laura Ingraham on Fox: Why did George W. Bush refuse to criticize Obama even when O screwed up badly but he often criticize\u2026",
        "user.screen_name": "n1bbles"
    },
    {
        "created_at": "Sun Feb 11 23:14:57 +0000 2018",
        "id": 962827325623566336,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "ckylecarter4"
    },
    {
        "created_at": "Sun Feb 11 23:14:57 +0000 2018",
        "id": 962827325271191553,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "donutsayit"
    },
    {
        "created_at": "Sun Feb 11 23:14:57 +0000 2018",
        "id": 962827323719299073,
        "text": "@blades_brad @MBach63 @Redpainter1 Maybe you missed Obama bringing us back from the brink of a major depression after Bush.",
        "user.screen_name": "AM_McCarthy"
    },
    {
        "created_at": "Sun Feb 11 23:14:56 +0000 2018",
        "id": 962827323111329793,
        "text": "New FBI Text Messages Show Obama \u2018Wants To Know Everything We\u2019re Doing\u2019\n\nREAD OUR STORY HERE\u2026 https://t.co/biwVstHLdw",
        "user.screen_name": "BluePillSheep"
    },
    {
        "created_at": "Sun Feb 11 23:14:56 +0000 2018",
        "id": 962827322268172289,
        "text": "RT @GaitaudCons: Another 1st ! Barack Obama has been eerily silent, now exposed that this is not just a federal offense, but also it can le\u2026",
        "user.screen_name": "elgomes15"
    },
    {
        "created_at": "Sun Feb 11 23:14:56 +0000 2018",
        "id": 962827321404162053,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "_raymondngo"
    },
    {
        "created_at": "Sun Feb 11 23:14:55 +0000 2018",
        "id": 962827315364339714,
        "text": "#UniteBlue, Obama bombed way more countries than Bush and sold twice the weapons to terrorist nations.  Your corpor\u2026 https://t.co/ihvnNsAsBR",
        "user.screen_name": "TravisRuger"
    },
    {
        "created_at": "Sun Feb 11 23:14:55 +0000 2018",
        "id": 962827315234459650,
        "text": "@StopTrump2020 @lann111 @FoxNews I think the Wife Beater was there when Obama was President and both times HE was i\u2026 https://t.co/imODhkSddN",
        "user.screen_name": "Shadowcat22"
    },
    {
        "created_at": "Sun Feb 11 23:14:54 +0000 2018",
        "id": 962827313669902336,
        "text": "@horowitz39 More than we need.   Obama really stuck it to us.   His acolytes are still entrenched, but the veneer is wearing thin.",
        "user.screen_name": "gttbotl"
    },
    {
        "created_at": "Sun Feb 11 23:14:54 +0000 2018",
        "id": 962827313305055232,
        "text": "RT @TheRISEofROD: The Day of Reckoning is coming for Dirty Dossier Dems/RINOs.\n\nIG Horowitz Report w/ over 1M pages of evidence to convict\u2026",
        "user.screen_name": "txGirl4ever_"
    },
    {
        "created_at": "Sun Feb 11 23:14:54 +0000 2018",
        "id": 962827312642363395,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "JPBENAVE"
    },
    {
        "created_at": "Sun Feb 11 23:14:54 +0000 2018",
        "id": 962827312541528065,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "Vammen2"
    },
    {
        "created_at": "Sun Feb 11 23:14:54 +0000 2018",
        "id": 962827310973030401,
        "text": "RT @BreeNewsome: Again, Obama faced such racist backlash that white America elected Trump to undo his presidency because no matter how much\u2026",
        "user.screen_name": "musicalcure"
    },
    {
        "created_at": "Sun Feb 11 23:14:53 +0000 2018",
        "id": 962827309718831104,
        "text": "@kristianlaliber @ArthurSchwartz Do you call out the Iran and N.Korea regime? Or do you try to normalize them? Also\u2026 https://t.co/hrMmkjnoJm",
        "user.screen_name": "Indy4MAGA"
    },
    {
        "created_at": "Sun Feb 11 23:14:53 +0000 2018",
        "id": 962827308980719616,
        "text": "RT @GrrrGraphics: \"In the Head of Hillary\" #BenGarrison #cartoon \nSomeone asked me why I draw so many #Obama &amp; #Hillary cartoons. \nread mor\u2026",
        "user.screen_name": "leewal"
    },
    {
        "created_at": "Sun Feb 11 23:14:53 +0000 2018",
        "id": 962827308947202048,
        "text": "RT @JessieJaneDuff: DHS official &amp; former Obama ambassador James Nealon resigned, upset recommendations to extend \u201ctemporary protected stat\u2026",
        "user.screen_name": "Pal3Z"
    },
    {
        "created_at": "Sun Feb 11 23:14:53 +0000 2018",
        "id": 962827308775149568,
        "text": "RT @JudicialWatch: Reminder: JW found evidence showing Obama State Dept under John Kerry sent its own \"dossier\" of classified info on Russi\u2026",
        "user.screen_name": "chachalaca"
    },
    {
        "created_at": "Sun Feb 11 23:14:53 +0000 2018",
        "id": 962827308749881344,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "KirkNason"
    },
    {
        "created_at": "Sun Feb 11 23:14:53 +0000 2018",
        "id": 962827308527702017,
        "text": "RT @charliebearnix: @RepSwalwell I, for one would like to see that birth certificate again now that it\u2019s a fact Obama is a 1st liar &amp; trait\u2026",
        "user.screen_name": "kachninja"
    },
    {
        "created_at": "Sun Feb 11 23:14:53 +0000 2018",
        "id": 962827307630002176,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "TonyMerwin55"
    },
    {
        "created_at": "Sun Feb 11 23:14:53 +0000 2018",
        "id": 962827307592372224,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "flymum"
    },
    {
        "created_at": "Sun Feb 11 23:14:53 +0000 2018",
        "id": 962827307294523392,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "StaceyMaLaine"
    },
    {
        "created_at": "Sun Feb 11 23:14:52 +0000 2018",
        "id": 962827306451513344,
        "text": "RT @joannperrone15: @RyanAFournier What happens to Obama because of this and all the rest of his cartel, including Hillary and her crew....\u2026",
        "user.screen_name": "fearlessfoe1"
    },
    {
        "created_at": "Sun Feb 11 23:14:52 +0000 2018",
        "id": 962827304547299328,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "Sundncefn"
    },
    {
        "created_at": "Sun Feb 11 23:14:51 +0000 2018",
        "id": 962827298629144576,
        "text": "RT @Chicago1Ray: \" You, me... we own this Country. Politicians are employees of ours. And when somebody doesn't do the Job, We gotta let 'e\u2026",
        "user.screen_name": "RealPowerSlave"
    },
    {
        "created_at": "Sun Feb 11 23:14:50 +0000 2018",
        "id": 962827296972386304,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "Too_Many_Leaks"
    },
    {
        "created_at": "Sun Feb 11 23:14:50 +0000 2018",
        "id": 962827295781150720,
        "text": "@thereallj915 I am digging civilian Obama, tho.",
        "user.screen_name": "ucruben"
    },
    {
        "created_at": "Sun Feb 11 23:14:50 +0000 2018",
        "id": 962827294619312128,
        "text": "@President1Trump @julieaallen1958 @MariaBartiromo @DevinNunes The guilty will not be prosecuted.  Equal justice in\u2026 https://t.co/BaBhzy23Qu",
        "user.screen_name": "ljkoolone"
    },
    {
        "created_at": "Sun Feb 11 23:14:50 +0000 2018",
        "id": 962827294317330432,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "RitaChmielCEO"
    },
    {
        "created_at": "Sun Feb 11 23:14:50 +0000 2018",
        "id": 962827294266937345,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "Harper04138060"
    },
    {
        "created_at": "Sun Feb 11 23:14:49 +0000 2018",
        "id": 962827292543279105,
        "text": "RT @krassenstein: The Trump Administrations has literally had more scandals in the last week than Obama had in his entire 8 years in office\u2026",
        "user.screen_name": "SheralynDuncum"
    },
    {
        "created_at": "Sun Feb 11 23:14:48 +0000 2018",
        "id": 962827289560928256,
        "text": "RT @RyanAFournier: Do you believe the Obama Administration improperly and illegally surveilled the Trump Campaign? #SHARE",
        "user.screen_name": "AshleyEdam"
    },
    {
        "created_at": "Sun Feb 11 23:14:48 +0000 2018",
        "id": 962827286805450752,
        "text": "RT @RedWaveRising: #ObamaGate\n\n#SundayThoughts\n#BarackObama used classified intelligence leaks for political gain - https://t.co/tkba3Y498I\u2026",
        "user.screen_name": "GaryWil59456334"
    },
    {
        "created_at": "Sun Feb 11 23:14:48 +0000 2018",
        "id": 962827286348091392,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "MyPugGrumble"
    },
    {
        "created_at": "Sun Feb 11 23:14:48 +0000 2018",
        "id": 962827286197174283,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "DannyNflfreak"
    },
    {
        "created_at": "Sun Feb 11 23:14:48 +0000 2018",
        "id": 962827285710680065,
        "text": "@thehill Oh give it up.  Obama lied continually.",
        "user.screen_name": "Freebirdwraps"
    },
    {
        "created_at": "Sun Feb 11 23:14:47 +0000 2018",
        "id": 962827284594831360,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "DarekisGo"
    },
    {
        "created_at": "Sun Feb 11 23:14:47 +0000 2018",
        "id": 962827284251054080,
        "text": "RT @JohnFromCranber: After 8 Yrs of Obama, US Teetered on The Abyss. The Damage Was Nearly  Irreversible...But Now Trump, + a Chance to Und\u2026",
        "user.screen_name": "larryqqueen"
    },
    {
        "created_at": "Sun Feb 11 23:14:46 +0000 2018",
        "id": 962827279951908864,
        "text": "RT @JudicialWatch: Reminder: JW found evidence showing Obama State Dept under John Kerry sent its own \"dossier\" of classified info on Russi\u2026",
        "user.screen_name": "JohnstonDennise"
    },
    {
        "created_at": "Sun Feb 11 23:14:46 +0000 2018",
        "id": 962827278265831426,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "daniellep703"
    },
    {
        "created_at": "Sun Feb 11 23:14:45 +0000 2018",
        "id": 962827276713852928,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "nitsch_robert"
    },
    {
        "created_at": "Sun Feb 11 23:14:45 +0000 2018",
        "id": 962827274813890561,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "kattywompas1"
    },
    {
        "created_at": "Sun Feb 11 23:14:45 +0000 2018",
        "id": 962827274075680769,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "MezzoMoon"
    },
    {
        "created_at": "Sun Feb 11 23:14:45 +0000 2018",
        "id": 962827273597603840,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "ctsew377"
    },
    {
        "created_at": "Sun Feb 11 23:14:44 +0000 2018",
        "id": 962827270762258432,
        "text": "RT @claverackjac: \ud83e\udd14@realDonaldTrump \n\nThere is one thing trumpy is great at. In fact he's bigly great at it...\n\nLetting Americans know each\u2026",
        "user.screen_name": "bagglo"
    },
    {
        "created_at": "Sun Feb 11 23:14:44 +0000 2018",
        "id": 962827270703296512,
        "text": "RT @FoxNews: .@TomFitton: \"[@realDonaldTrump] has been victimized by the Obama Administration.\" https://t.co/z3Vn9KY1M3",
        "user.screen_name": "Novella1_JJ"
    },
    {
        "created_at": "Sun Feb 11 23:14:44 +0000 2018",
        "id": 962827269185077248,
        "text": "RT @TranslateRealDT: In the \u201cold days,\u201d when it was still Obama's final fiscal year, the Stock Market would go up. Today, now that my tax p\u2026",
        "user.screen_name": "Harlis_8"
    },
    {
        "created_at": "Sun Feb 11 23:14:43 +0000 2018",
        "id": 962827267989786624,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "mjktinkell"
    },
    {
        "created_at": "Sun Feb 11 23:14:43 +0000 2018",
        "id": 962827267469651968,
        "text": "RT @bfraser747: Is anyone actually surprised that Obama wanted to \u201cknow everything\u201d?\n\nOf course he interfered with the Hillary investigatio\u2026",
        "user.screen_name": "BrandonJLandry"
    },
    {
        "created_at": "Sun Feb 11 23:14:43 +0000 2018",
        "id": 962827265175359489,
        "text": "Btw, Obama made health insurance mandatory &amp; more expensive. Since when do we need the Govt to Determine our money\u2026 https://t.co/hqVpsrWGK0",
        "user.screen_name": "MMeomi4r"
    },
    {
        "created_at": "Sun Feb 11 23:14:42 +0000 2018",
        "id": 962827263040544769,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "n1bbles"
    },
    {
        "created_at": "Sun Feb 11 23:14:42 +0000 2018",
        "id": 962827262981758977,
        "text": "RT @Hoosiers1986: #FakeRelationshipFacts\n\nDEM voters are gullible fools!\n\nThey revere idiots like Obama, Schumer &amp; Pelosi who COULD have pr\u2026",
        "user.screen_name": "WI4Palin"
    },
    {
        "created_at": "Sun Feb 11 23:14:41 +0000 2018",
        "id": 962827259433373696,
        "text": "RT @paulbhb: \"By my count, there are now at least 4 Obama/Clinton \"get Trump\" dossiers.\" https://t.co/8nRSog9KlZ",
        "user.screen_name": "Pearl33502007"
    },
    {
        "created_at": "Sun Feb 11 23:14:41 +0000 2018",
        "id": 962827258921709568,
        "text": "@cl822 @DavidCornDC My opinion? Combination of 9 years of glowing stories about him (\u201coh, he paints now!\u201d) and Obam\u2026 https://t.co/3HQ5Vzj6pJ",
        "user.screen_name": "jasonbgray"
    },
    {
        "created_at": "Sun Feb 11 23:14:41 +0000 2018",
        "id": 962827258678382597,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "MarioB80"
    },
    {
        "created_at": "Sun Feb 11 23:14:41 +0000 2018",
        "id": 962827257239785472,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "Rollergirltx"
    },
    {
        "created_at": "Sun Feb 11 23:14:41 +0000 2018",
        "id": 962827256732246016,
        "text": "RT @ConservaMomUSA: it\u2019s #BlackHistoryMonth\u00a0-so it\u2019s only fitting 2point out that America\u2019s 1st black president #Obama has been implicated\u2026",
        "user.screen_name": "usaconcretetom"
    },
    {
        "created_at": "Sun Feb 11 23:14:40 +0000 2018",
        "id": 962827255960387584,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "hankandmya12"
    },
    {
        "created_at": "Sun Feb 11 23:14:40 +0000 2018",
        "id": 962827255327199233,
        "text": "RT @KatrinaPierson: BREAKING: It goes to the Top! Newly revealed text message between anti-Trump lovers Peter Strzok and Lisa Page appear t\u2026",
        "user.screen_name": "Tresidential"
    },
    {
        "created_at": "Sun Feb 11 23:14:40 +0000 2018",
        "id": 962827252978409472,
        "text": "RT @jaybeware: Mike Pence and the Trump regime (like the Obama regime before them) run more, bigger gulags, with a lot more people in them.\u2026",
        "user.screen_name": "aloofwoofwoof"
    },
    {
        "created_at": "Sun Feb 11 23:14:40 +0000 2018",
        "id": 962827252315586560,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "MobileMagnolia"
    },
    {
        "created_at": "Sun Feb 11 23:14:39 +0000 2018",
        "id": 962827251770261505,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "pc325"
    },
    {
        "created_at": "Sun Feb 11 23:14:39 +0000 2018",
        "id": 962827250763739137,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "Zappatista"
    },
    {
        "created_at": "Sun Feb 11 23:14:39 +0000 2018",
        "id": 962827249874587648,
        "text": "RT @FoxNews: .@TomFitton: \"[@realDonaldTrump] has been victimized by the Obama Administration.\" https://t.co/z3Vn9KY1M3",
        "user.screen_name": "DanielNanle"
    },
    {
        "created_at": "Sun Feb 11 23:14:38 +0000 2018",
        "id": 962827246892343296,
        "text": "RT @charliekirk11: Obama assuredly knew the Democrat party paid $160,000 for a fake dossier to get a memo to spy on Trump \n\nHillary paid fo\u2026",
        "user.screen_name": "Terrawales"
    },
    {
        "created_at": "Sun Feb 11 23:14:38 +0000 2018",
        "id": 962827246783275009,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "ronbeckner"
    },
    {
        "created_at": "Sun Feb 11 23:14:38 +0000 2018",
        "id": 962827246145888256,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "lassekoskela"
    },
    {
        "created_at": "Sun Feb 11 23:14:38 +0000 2018",
        "id": 962827246032502784,
        "text": "Republicans really that stupid to be claiming that Michelle Obama is a man? Lmao damn.",
        "user.screen_name": "alexxslappz"
    },
    {
        "created_at": "Sun Feb 11 23:14:38 +0000 2018",
        "id": 962827245906612224,
        "text": "RT @tonyposnanski: Trump believes in due process except for...\n\n- Kenyan born Obama\n- Crooked Hillary\n- FBI\n- Anyone in the media who doesn\u2026",
        "user.screen_name": "RitaMarietwo"
    },
    {
        "created_at": "Sun Feb 11 23:14:38 +0000 2018",
        "id": 962827245038514178,
        "text": "RT @RedWaveRising: #ObamaGate\n\n#SundayThoughts\n#BarackObama used classified intelligence leaks for political gain - https://t.co/tkba3Y498I\u2026",
        "user.screen_name": "Mannaleemer"
    },
    {
        "created_at": "Sun Feb 11 23:14:37 +0000 2018",
        "id": 962827243549372417,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "GateOfDemocracy"
    },
    {
        "created_at": "Sun Feb 11 23:14:37 +0000 2018",
        "id": 962827241770987520,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "Icebox74"
    },
    {
        "created_at": "Sun Feb 11 23:14:37 +0000 2018",
        "id": 962827240466731008,
        "text": "RT @RyanAFournier: Do you believe the Obama Administration improperly and illegally surveilled the Trump Campaign? #SHARE",
        "user.screen_name": "The__Claud"
    },
    {
        "created_at": "Sun Feb 11 23:14:37 +0000 2018",
        "id": 962827240131018752,
        "text": "RT @dave1234_david: @hotfunkytown @KNP2BP The only thing Obama has been consistent at is failure. #ObamaGate #MAGA",
        "user.screen_name": "SiewTng"
    },
    {
        "created_at": "Sun Feb 11 23:14:36 +0000 2018",
        "id": 962827237639811078,
        "text": "RT @joncoopertweets: Sure, @realDonaldTrump is a lying, corrupt, racist, traitorous imbecile who defends white supremacists, Nazis, wife be\u2026",
        "user.screen_name": "CelesteT333"
    },
    {
        "created_at": "Sun Feb 11 23:14:36 +0000 2018",
        "id": 962827237098774528,
        "text": "RT @tjbpdb: How AWESOME Would it be, if when all said &amp; done the proof is shown that Saint Obama, was in on the hole thing. J.Carter &amp; R.Ni\u2026",
        "user.screen_name": "beansforme2"
    },
    {
        "created_at": "Sun Feb 11 23:14:36 +0000 2018",
        "id": 962827235307769857,
        "text": "Trump Sends Feds To Arrest Obama Appointed Judge - https://t.co/HBqVfa8YPG",
        "user.screen_name": "SUCCESSFULGGIRL"
    },
    {
        "created_at": "Sun Feb 11 23:14:35 +0000 2018",
        "id": 962827235068661761,
        "text": "RT @RealMAGASteve: This bombshell report from the Senate Homeland Security Comm. IMPLICATES OBAMA in the #Obamagate scandal &amp; Clinton email\u2026",
        "user.screen_name": "jluke121"
    },
    {
        "created_at": "Sun Feb 11 23:14:35 +0000 2018",
        "id": 962827233483161603,
        "text": "Barack Obama - https://t.co/2sNp15OF0K https://t.co/ccnrAg36sx",
        "user.screen_name": "treasurestore5"
    },
    {
        "created_at": "Sun Feb 11 23:14:35 +0000 2018",
        "id": 962827232090587136,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "MagnumJedi"
    },
    {
        "created_at": "Sun Feb 11 23:14:35 +0000 2018",
        "id": 962827231650242560,
        "text": "RT @TruthFeedNews: ICYMI: Obama Official Admits Working With Close Clinton Friend to Take Down Trump! https://t.co/OxIn68e2sy #MAGA #TrumpT\u2026",
        "user.screen_name": "cliff_shaw1"
    },
    {
        "created_at": "Sun Feb 11 23:14:35 +0000 2018",
        "id": 962827231591653376,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "JessieJaneDuff"
    },
    {
        "created_at": "Sun Feb 11 23:14:35 +0000 2018",
        "id": 962827231289659394,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "Rick_497"
    },
    {
        "created_at": "Sun Feb 11 23:14:35 +0000 2018",
        "id": 962827231230873600,
        "text": "@MRSSMH2 Because we didn\u2019t have to defend Obama for even ONE hour https://t.co/Ajy6NKPJUD",
        "user.screen_name": "jasoncopeland73"
    },
    {
        "created_at": "Sun Feb 11 23:14:34 +0000 2018",
        "id": 962827231012651008,
        "text": "RT @wesley_jordan: With Mueller closing in &amp; the Russia scandal exploding all around him, one-trick Trump once again blamed everything on O\u2026",
        "user.screen_name": "WaltonDornisch"
    },
    {
        "created_at": "Sun Feb 11 23:14:34 +0000 2018",
        "id": 962827230995996672,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "scody89"
    },
    {
        "created_at": "Sun Feb 11 23:14:34 +0000 2018",
        "id": 962827229443997696,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "iamopressed"
    },
    {
        "created_at": "Sun Feb 11 23:14:34 +0000 2018",
        "id": 962827227686670336,
        "text": "@Squirl00 @laura_stietz @realDonaldTrump Libturds can\u2019t stand to lose!  Enjoy the next 4-8 yrs.  we sure will!  I h\u2026 https://t.co/QlYacUXlBz",
        "user.screen_name": "tootickedoff"
    },
    {
        "created_at": "Sun Feb 11 23:14:34 +0000 2018",
        "id": 962827227225354241,
        "text": "RT @TheRickyDavila: A racist lunatic once again finding a way to blame President Obama for the actions of yet another abuser of women.\n\nA s\u2026",
        "user.screen_name": "1961pattieann"
    },
    {
        "created_at": "Sun Feb 11 23:14:33 +0000 2018",
        "id": 962827226571051008,
        "text": "RT @jefftiedrich: Kellyanne Conway, because when I need facts grounded in reality I turn to a woman who accused Barack Obama of spying on t\u2026",
        "user.screen_name": "paragonhealth21"
    },
    {
        "created_at": "Sun Feb 11 23:14:33 +0000 2018",
        "id": 962827226340384770,
        "text": "@jh45123 We Agree. Obama is a Manchurian Candidate, probably Paid for By Soros.",
        "user.screen_name": "G_Pond47"
    },
    {
        "created_at": "Sun Feb 11 23:14:33 +0000 2018",
        "id": 962827226021486592,
        "text": "RT @Bakari_Sellers: Fox News viewers believe its Obama\u2019s fault Rob Porter beat his wives. https://t.co/5y8wPzWLOu",
        "user.screen_name": "OldSouthernDem"
    },
    {
        "created_at": "Sun Feb 11 23:14:33 +0000 2018",
        "id": 962827222707875840,
        "text": "RT @TuckerCarlson: Here's what is clear right now, the bottom line on what we've learned this week and the one thing worth remembering: The\u2026",
        "user.screen_name": "kimengland9"
    },
    {
        "created_at": "Sun Feb 11 23:14:32 +0000 2018",
        "id": 962827222632419328,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "healthysuzi"
    },
    {
        "created_at": "Sun Feb 11 23:14:32 +0000 2018",
        "id": 962827221810458624,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "jennfox515"
    },
    {
        "created_at": "Sun Feb 11 23:14:32 +0000 2018",
        "id": 962827221399490560,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "TaNee69216947"
    },
    {
        "created_at": "Sun Feb 11 23:14:32 +0000 2018",
        "id": 962827220749230080,
        "text": "RT @HowitzerPatriot: @hotfunkytown I love the SNL skit when Obama refutes Trumps claims as Obama being worst President in history. He does\u2026",
        "user.screen_name": "SiewTng"
    },
    {
        "created_at": "Sun Feb 11 23:14:32 +0000 2018",
        "id": 962827220195700736,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "_Carallena_"
    },
    {
        "created_at": "Sun Feb 11 23:14:32 +0000 2018",
        "id": 962827219155505157,
        "text": "RT @BillKristol: Got home, took a look at Twitter: The media seem to love North Korea; people mock Mike and Karen Pence for appearing unhap\u2026",
        "user.screen_name": "iluvliberals"
    },
    {
        "created_at": "Sun Feb 11 23:14:32 +0000 2018",
        "id": 962827219025481728,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "lring1up"
    },
    {
        "created_at": "Sun Feb 11 23:14:31 +0000 2018",
        "id": 962827218236911617,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "kfwinter15"
    },
    {
        "created_at": "Sun Feb 11 23:14:31 +0000 2018",
        "id": 962827216869609472,
        "text": "RT @KrisParonto: We also didn\u2019t use the @FBI @CIA and @NSAGov to spy on @realDonaldTrump either.......isn\u2019t that what you said to Chris Wal\u2026",
        "user.screen_name": "joannet57"
    },
    {
        "created_at": "Sun Feb 11 23:14:31 +0000 2018",
        "id": 962827215581863936,
        "text": "RT @nutquacker1: Majority of Americans now think President Obama surveilled the Trump campaign. Time to throw him in jail\n\nPoll: Americans\u2026",
        "user.screen_name": "LoriHasso"
    },
    {
        "created_at": "Sun Feb 11 23:14:30 +0000 2018",
        "id": 962827214042681345,
        "text": "RT @HrrEerrer: Maybe Kelly didn\u2019t know because it didn\u2019t happen. How many times did obama say he found out when a scandal hit the press? Be\u2026",
        "user.screen_name": "terriUKfan"
    },
    {
        "created_at": "Sun Feb 11 23:14:30 +0000 2018",
        "id": 962827211509202944,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "charitystartsat"
    },
    {
        "created_at": "Sun Feb 11 23:14:30 +0000 2018",
        "id": 962827211333033984,
        "text": "RT @SebGorka: Just REMEMBER:\n\n@JohnBrennan was proud to have voted for Gus Hall the Communist candidate for American President. \n\nTHEN OBAM\u2026",
        "user.screen_name": "cjlutje21"
    },
    {
        "created_at": "Sun Feb 11 23:14:29 +0000 2018",
        "id": 962827209928073217,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "MobileMagnolia"
    },
    {
        "created_at": "Sun Feb 11 23:14:29 +0000 2018",
        "id": 962827209038733313,
        "text": "RT @joncoopertweets: Setting aside Donald Trump\u2019s minor scandals \u2014 such as Trump\u2019s conspiracy with Russia, obstruction of justice, politica\u2026",
        "user.screen_name": "ShelbyEmerald"
    },
    {
        "created_at": "Sun Feb 11 23:14:29 +0000 2018",
        "id": 962827209022033920,
        "text": "RT @CKnSD619: I\u2019m still very confused as to why it\u2019s Obama\u2019s fault that two men physically abused women. The logic that @FoxNews spreads is\u2026",
        "user.screen_name": "ChandaFinch"
    },
    {
        "created_at": "Sun Feb 11 23:14:29 +0000 2018",
        "id": 962827208820690944,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "KenElevan"
    },
    {
        "created_at": "Sun Feb 11 23:14:29 +0000 2018",
        "id": 962827208359256064,
        "text": "@foxandfriends We are seeing the brainwashing of the mentality of the younger people in the USA.\nThis is being done\u2026 https://t.co/GrLmXVpbXq",
        "user.screen_name": "dottieh1932"
    },
    {
        "created_at": "Sun Feb 11 23:14:29 +0000 2018",
        "id": 962827208099356672,
        "text": "RT @RepStevenSmith: Diane Feinstein thinks the dossier is true because it\u2019s not \u201crefuted.\u201d\n\nShe doesn\u2019t care that it\u2019s COMPLETELY UNVERIFIE\u2026",
        "user.screen_name": "keesie59"
    },
    {
        "created_at": "Sun Feb 11 23:14:28 +0000 2018",
        "id": 962827205481910272,
        "text": "RT @G6throughF5: @JulianAssange Do you have Obama's sealed records? https://t.co/6P2jS8vhrM",
        "user.screen_name": "Unkle_Ken"
    },
    {
        "created_at": "Sun Feb 11 23:14:28 +0000 2018",
        "id": 962827205310115842,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "Doanziegirl"
    },
    {
        "created_at": "Sun Feb 11 23:14:28 +0000 2018",
        "id": 962827202537689089,
        "text": "RT @KaniJJackson: This is just your daily reminder that Barack Obama did not have 1 scandal or allegation against him during his time in th\u2026",
        "user.screen_name": "GuileRita"
    },
    {
        "created_at": "Sun Feb 11 23:14:27 +0000 2018",
        "id": 962827200771870720,
        "text": "RT @Bakari_Sellers: Fox News viewers believe its Obama\u2019s fault Rob Porter beat his wives. https://t.co/5y8wPzWLOu",
        "user.screen_name": "rlsrox"
    },
    {
        "created_at": "Sun Feb 11 23:14:27 +0000 2018",
        "id": 962827200415203328,
        "text": "RT @JudicialWatch: As part of our effort to hold Mueller's investigation accountable, JW uncovered docs showing top DOJ officials including\u2026",
        "user.screen_name": "bbl58"
    },
    {
        "created_at": "Sun Feb 11 23:14:27 +0000 2018",
        "id": 962827200062877697,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "kcSnoWhite"
    },
    {
        "created_at": "Sun Feb 11 23:14:27 +0000 2018",
        "id": 962827199656136704,
        "text": "RT @DrXPsychologist: The House, Senate &amp; Presidency aren't the 3 branches of govt, you dope. DACA didn't exist in 2008-2011, you dope. The\u2026",
        "user.screen_name": "historygirlMA"
    },
    {
        "created_at": "Sun Feb 11 23:14:27 +0000 2018",
        "id": 962827199429529600,
        "text": "Brackin OBama https://t.co/jbpsXClPsf",
        "user.screen_name": "chkwma"
    },
    {
        "created_at": "Sun Feb 11 23:14:27 +0000 2018",
        "id": 962827199089991680,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "UzjetotuF"
    },
    {
        "created_at": "Sun Feb 11 23:14:27 +0000 2018",
        "id": 962827198771224576,
        "text": "RT @MaxDevlin: Here\u2019s what some of the Hollywood Powerhouses have said about this article:\n\nKim Kardashian \u201cI haven\u2019t read it.\u201d\nTom Hanks \u201c\u2026",
        "user.screen_name": "ggma5757"
    },
    {
        "created_at": "Sun Feb 11 23:14:27 +0000 2018",
        "id": 962827198641135617,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "thplett"
    },
    {
        "created_at": "Sun Feb 11 23:14:27 +0000 2018",
        "id": 962827198611652608,
        "text": "RT @NxGenEarthlings: How\u2019s that #ObamaLegacy looking now...\n\nSucking even more now, isn\u2019t it?\n\n#Obama #SaturdayMorning https://t.co/W1ayvRn\u2026",
        "user.screen_name": "Stargazer2020"
    },
    {
        "created_at": "Sun Feb 11 23:14:27 +0000 2018",
        "id": 962827197546295298,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "BicknellShirley"
    },
    {
        "created_at": "Sun Feb 11 23:14:26 +0000 2018",
        "id": 962827197139603459,
        "text": "RT @MichelleObama: There\u2019s Zaniya, who won our #BetterMakeRoom essay contest and got to be on the cover of @Seventeen with me in 2016. Now,\u2026",
        "user.screen_name": "TimminsRealtor"
    },
    {
        "created_at": "Sun Feb 11 23:14:26 +0000 2018",
        "id": 962827196044840960,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "RealityBoost"
    },
    {
        "created_at": "Sun Feb 11 23:14:26 +0000 2018",
        "id": 962827194799214595,
        "text": "@ge2229617 @DonaldJTrumpJr Anyone with COMMON SENSE knew that money was going to their NUCLEAR AMBITIONS &amp; TERRORIS\u2026 https://t.co/Fcuv65KYuo",
        "user.screen_name": "LeeEllmauerJr"
    },
    {
        "created_at": "Sun Feb 11 23:14:26 +0000 2018",
        "id": 962827194119548928,
        "text": "RT @JalenSkutt: Barack Obama https://t.co/Z91o7bG2EH",
        "user.screen_name": "_Veronica_10"
    },
    {
        "created_at": "Sun Feb 11 23:14:26 +0000 2018",
        "id": 962827193998077954,
        "text": "RT @Golfinggary5221: \u201cThe bottom line is that these Trump-hating FBI agents were on an anti-Trump mission and President Obama may be involv\u2026",
        "user.screen_name": "Tresaann70"
    },
    {
        "created_at": "Sun Feb 11 23:14:26 +0000 2018",
        "id": 962827193398198272,
        "text": "RT @sxdoc: CONFIRMED: FRONT PAGE NEWS Cash from Obama's $1.7 Billion Ransom Payment to Iran Traced to Terrorist Groups (VIDEO) SURPRISE SUR\u2026",
        "user.screen_name": "papaschu1"
    },
    {
        "created_at": "Sun Feb 11 23:14:26 +0000 2018",
        "id": 962827193364566016,
        "text": "@dakota295752 @jllgraham @Jerusal53393006 @Diann12stephens @Bruchell1 @realDonaldTrump @PenelopePratts\u2026 https://t.co/G2dwCKvgyn",
        "user.screen_name": "kefkapelazzo"
    },
    {
        "created_at": "Sun Feb 11 23:14:25 +0000 2018",
        "id": 962827193121460226,
        "text": "RT @ChrissyUSA1: #MAGA #Patriot #Qanon #TheStormIsHere #GreatAwakening #AmericaFirst #WeThePeople #CCCTrain #TrumpsTroops \ud83c\uddfa\ud83c\uddf8 FACT; Who paid\u2026",
        "user.screen_name": "zanadu99laura"
    },
    {
        "created_at": "Sun Feb 11 23:14:25 +0000 2018",
        "id": 962827191905112064,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "arsneddon"
    },
    {
        "created_at": "Sun Feb 11 23:14:25 +0000 2018",
        "id": 962827191586295809,
        "text": "DHS official &amp; former Obama ambassador James Nealon resigned, upset recommendations to extend \u201ctemporary protected\u2026 https://t.co/W0Fy1AUSrW",
        "user.screen_name": "JessieJaneDuff"
    },
    {
        "created_at": "Sun Feb 11 23:14:25 +0000 2018",
        "id": 962827191422803970,
        "text": "RT @PoliticalShort: Brennan put the pressure on the FBI and Congress to investigate Trump while hiding behind the scenes not only briefing\u2026",
        "user.screen_name": "RoloT17"
    },
    {
        "created_at": "Sun Feb 11 23:14:25 +0000 2018",
        "id": 962827191015809024,
        "text": "@cshirky Dowd is the writer who repeatedly faulted Obama for not having Paul Newman's blue eyes. Too bad she isn't a special case.",
        "user.screen_name": "alanatpaterra"
    },
    {
        "created_at": "Sun Feb 11 23:14:25 +0000 2018",
        "id": 962827190642626560,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "brian_cadena"
    },
    {
        "created_at": "Sun Feb 11 23:14:25 +0000 2018",
        "id": 962827190458114048,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "marthyjazz"
    },
    {
        "created_at": "Sun Feb 11 23:14:25 +0000 2018",
        "id": 962827189606604805,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "HelenHelenc"
    },
    {
        "created_at": "Sun Feb 11 23:14:25 +0000 2018",
        "id": 962827189384335360,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "superfastbobby"
    },
    {
        "created_at": "Sun Feb 11 23:14:24 +0000 2018",
        "id": 962827188507639808,
        "text": "RT @HrrEerrer: Maybe Kelly didn\u2019t know because it didn\u2019t happen. How many times did obama say he found out when a scandal hit the press? Be\u2026",
        "user.screen_name": "connieSuver"
    },
    {
        "created_at": "Sun Feb 11 23:14:24 +0000 2018",
        "id": 962827188272803840,
        "text": "RT @EdKrassen: If Jeanine Pirro can blame Barack Obama for Rob Porter beating his wives, then I blame Jeanine Pirro for Donald Trump assaul\u2026",
        "user.screen_name": "lamadness123"
    },
    {
        "created_at": "Sun Feb 11 23:14:24 +0000 2018",
        "id": 962827188214140933,
        "text": "RT @AlexMunday_2018: \"There is no limit to what we, as women, can accomplish.\" \u2014Michelle Obama\n\nWe see you, @GOP. Midterms are coming and w\u2026",
        "user.screen_name": "LicorcePony"
    },
    {
        "created_at": "Sun Feb 11 23:14:24 +0000 2018",
        "id": 962827188117626880,
        "text": "$10 Trillion Spent on the Democrat Great Society vote getting gambit and $10 Trillion more added to the national de\u2026 https://t.co/6CMtCxZTs6",
        "user.screen_name": "JC7109"
    },
    {
        "created_at": "Sun Feb 11 23:14:24 +0000 2018",
        "id": 962827186934894592,
        "text": "RT @Hoosiers1986: #FakeRelationshipFacts\n\nDEM voters are gullible fools!\n\nThey revere idiots like Obama, Schumer &amp; Pelosi who COULD have pr\u2026",
        "user.screen_name": "JdhCap"
    },
    {
        "created_at": "Sun Feb 11 23:14:23 +0000 2018",
        "id": 962827184300789762,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "BaRebelmom"
    },
    {
        "created_at": "Sun Feb 11 23:14:23 +0000 2018",
        "id": 962827183977828352,
        "text": "RT @TheZullinator: If Obama wasn't part black the entire country would have turned against him a long time ago. Can we as Americans just lo\u2026",
        "user.screen_name": "M08D26"
    },
    {
        "created_at": "Sun Feb 11 23:14:23 +0000 2018",
        "id": 962827183646425088,
        "text": "RT @charliekirk11: If Bush would have done the same exact things Obama did he would have been impeached",
        "user.screen_name": "Terrawales"
    },
    {
        "created_at": "Sun Feb 11 23:14:23 +0000 2018",
        "id": 962827183034003456,
        "text": "@bbusa617 Let\u2019s hope Clinton\u2019s &amp; Mueller,obama all pay the piper",
        "user.screen_name": "expiditer57"
    },
    {
        "created_at": "Sun Feb 11 23:14:23 +0000 2018",
        "id": 962827182434390016,
        "text": "RT @goodoldcatchy: Trump hounded Obama for his birth certificate because he was black, ran for President because Obama mocked him, was vote\u2026",
        "user.screen_name": "kjoerwin"
    },
    {
        "created_at": "Sun Feb 11 23:14:23 +0000 2018",
        "id": 962827181008224257,
        "text": "The Daily Caller | Only Obama's expansionary fiscal policies can be good.... https://t.co/hxZSwec5Qf https://t.co/SPCyheMLwX",
        "user.screen_name": "obamolizer"
    },
    {
        "created_at": "Sun Feb 11 23:14:22 +0000 2018",
        "id": 962827180383326208,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "bocabelo"
    },
    {
        "created_at": "Sun Feb 11 23:14:22 +0000 2018",
        "id": 962827177879203840,
        "text": "RT @jcpenni7maga: I am dropping my #HBO subscription after hearing about this BS\ud83e\udd2c\ud83e\udd2c\ud83e\udd2cand you should too!\n\nHBO - #HomeBoxOffice is hiring #Oba\u2026",
        "user.screen_name": "RouleLynda"
    },
    {
        "created_at": "Sun Feb 11 23:14:21 +0000 2018",
        "id": 962827175979339777,
        "text": "RT @BreeNewsome: Again, Obama faced such racist backlash that white America elected Trump to undo his presidency because no matter how much\u2026",
        "user.screen_name": "AbortionFaerie"
    },
    {
        "created_at": "Sun Feb 11 23:14:21 +0000 2018",
        "id": 962827174553284608,
        "text": "Turns out Obama\u2019s American \u201chome\u201d is just like his real home in Kenya....a shithole\n\n#QAnon #Trump #ObamaGate \n\n https://t.co/L7a7IPvP57",
        "user.screen_name": "_00111111_"
    },
    {
        "created_at": "Sun Feb 11 23:14:21 +0000 2018",
        "id": 962827173135572993,
        "text": "@CNN Victimized by Obama my ass.  If anyone's been victimized by anytime it's the American people by you, you asshat",
        "user.screen_name": "amc91355"
    },
    {
        "created_at": "Sun Feb 11 23:14:21 +0000 2018",
        "id": 962827172724592640,
        "text": "RT @Fuctupmind: Pretty much everyone knew about the Steele Dossier.\n\nThe entire Obama admin.\nSid Blumenthal.\nHillary Clinton.\nLoretta Lynch\u2026",
        "user.screen_name": "ejmichaels74"
    },
    {
        "created_at": "Sun Feb 11 23:14:20 +0000 2018",
        "id": 962827171508183040,
        "text": "RT @JGreenbergSez: At the time, Dick Cheney called for the Obama Admin to order an attack to destroy our drone and the unit that brought it\u2026",
        "user.screen_name": "csvari"
    },
    {
        "created_at": "Sun Feb 11 23:14:20 +0000 2018",
        "id": 962827168161193984,
        "text": "RT @FoxNews: .@TomFitton: \"[@realDonaldTrump] has been victimized by the Obama Administration.\" https://t.co/z3Vn9KY1M3",
        "user.screen_name": "Ciminolaw"
    },
    {
        "created_at": "Sun Feb 11 23:14:19 +0000 2018",
        "id": 962827165325778945,
        "text": "RT @lawlerchuck1: @sxdoc @realDonaldTrump Proof Obama Supporting Terrorists !\nIsn\u2019t That Treason ?",
        "user.screen_name": "Brendag38323989"
    },
    {
        "created_at": "Sun Feb 11 23:14:19 +0000 2018",
        "id": 962827164335960065,
        "text": "RT @DearAuntCrabby: Trump promotes argument that he's been 'victimized' by Obama administration https://t.co/NY5a0e77YZ \n\nOh brother, what\u2026",
        "user.screen_name": "DeannFields13"
    },
    {
        "created_at": "Sun Feb 11 23:14:18 +0000 2018",
        "id": 962827162008018944,
        "text": "RT @starcrosswolf: Rep Jim Himes, D, took his dumb pills &amp; admitted there is something in the Democratic intelligence memo that shows the F\u2026",
        "user.screen_name": "blondefrog123"
    },
    {
        "created_at": "Sun Feb 11 23:14:18 +0000 2018",
        "id": 962827161857155072,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "Electroman05"
    },
    {
        "created_at": "Sun Feb 11 23:14:18 +0000 2018",
        "id": 962827161194283008,
        "text": "RT @prayingmedic: 48) When you hear that the FBI, DOJ or Obama State Department were involved in something nefarious, keep in mind the fact\u2026",
        "user.screen_name": "mpg25mary"
    },
    {
        "created_at": "Sun Feb 11 23:14:17 +0000 2018",
        "id": 962827159613116421,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "24baseballReed"
    },
    {
        "created_at": "Sun Feb 11 23:14:17 +0000 2018",
        "id": 962827158828863490,
        "text": "RT @Chicago1Ray: \" You, me... we own this Country. Politicians are employees of ours. And when somebody doesn't do the Job, We gotta let 'e\u2026",
        "user.screen_name": "MousseauJim"
    },
    {
        "created_at": "Sun Feb 11 23:14:17 +0000 2018",
        "id": 962827157998374912,
        "text": "RT @SusanStormXO: @hatedtruthpig77 @Ann_B_Barber @wolfgangfaustX Burns me Up \ud83d\udd25\ud83d\udd25\nHow do we have people in America that are condoning this !\u2026",
        "user.screen_name": "MichaelYuchuck"
    },
    {
        "created_at": "Sun Feb 11 23:14:17 +0000 2018",
        "id": 962827157792854016,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "Covfefe445"
    },
    {
        "created_at": "Sun Feb 11 23:14:17 +0000 2018",
        "id": 962827156744261634,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "bill_lindy1959"
    },
    {
        "created_at": "Sun Feb 11 23:14:17 +0000 2018",
        "id": 962827155829940225,
        "text": "RT @realDonaldTrump: \u201cMy view is that not only has Trump been vindicated in the last several weeks about the mishandling of the Dossier and\u2026",
        "user.screen_name": "mylifebox"
    },
    {
        "created_at": "Sun Feb 11 23:14:17 +0000 2018",
        "id": 962827155737542661,
        "text": "RT @TomFitton: The American people should be able to see for themselves the FISA court docs on how Obama admin used Clinton document to mis\u2026",
        "user.screen_name": "JoyceBruns"
    },
    {
        "created_at": "Sun Feb 11 23:14:16 +0000 2018",
        "id": 962827152457633792,
        "text": "George .W  Refused to  criticize obama during his presidency https://t.co/N8eVgSjIfb via @YouTube",
        "user.screen_name": "ukchima61"
    },
    {
        "created_at": "Sun Feb 11 23:14:16 +0000 2018",
        "id": 962827152306724867,
        "text": "RT @FiveRights: Obama State Dept Official Jonathan Winer finally comes clean:\nI fed opposition research from Sid Blumenthal (Hillary's best\u2026",
        "user.screen_name": "chelsea7707"
    },
    {
        "created_at": "Sun Feb 11 23:14:15 +0000 2018",
        "id": 962827150255644672,
        "text": "RT @fubaglady: All Corrupt DOJ and FBI Roads Lead to Obama  https://t.co/mEzuGckwxr",
        "user.screen_name": "Jan26475074"
    },
    {
        "created_at": "Sun Feb 11 23:14:14 +0000 2018",
        "id": 962827143523729410,
        "text": "RT @MOVEFORWARDHUGE: MOTHER EARTH IS CRYING BECAUSE YOU CHILDREN WOULD BELIEVE \n\nOBAMA WAS A GOOD POTUS &amp; HILLARY IS A FEMINIST.  \n\nMY LORD\u2026",
        "user.screen_name": "JimJimbo54"
    },
    {
        "created_at": "Sun Feb 11 23:14:14 +0000 2018",
        "id": 962827143024599041,
        "text": "RT @demsrloosers: Crooked Eric, The Obama Lap Dog, Responsible for the IRS Targeting of Tea Party Conservatives, is thinking of running  fo\u2026",
        "user.screen_name": "SpeculativePig"
    },
    {
        "created_at": "Sun Feb 11 23:14:13 +0000 2018",
        "id": 962827142546579456,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "DanaHogue5"
    },
    {
        "created_at": "Sun Feb 11 23:14:12 +0000 2018",
        "id": 962827137765036032,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "246Cyd"
    },
    {
        "created_at": "Sun Feb 11 23:14:12 +0000 2018",
        "id": 962827137060409344,
        "text": "RT @PoliticalShort: Brennan put the pressure on the FBI and Congress to investigate Trump while hiding behind the scenes not only briefing\u2026",
        "user.screen_name": "see_jl"
    },
    {
        "created_at": "Sun Feb 11 23:14:12 +0000 2018",
        "id": 962827135873302529,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "MousseauJim"
    },
    {
        "created_at": "Sun Feb 11 23:14:12 +0000 2018",
        "id": 962827135718129665,
        "text": "RT @Bakari_Sellers: Fox News viewers believe its Obama\u2019s fault Rob Porter beat his wives. https://t.co/5y8wPzWLOu",
        "user.screen_name": "OgNazeem"
    },
    {
        "created_at": "Sun Feb 11 23:14:12 +0000 2018",
        "id": 962827135613202433,
        "text": "RT @sxdoc: Newt Hammers Hillary, Obama And \u2018#DeepState\u2019 For Destroying The Rule Of Law; Chaos Reigns When Laws Not Enforced #LawAndOrder ht\u2026",
        "user.screen_name": "AshleyEdam"
    },
    {
        "created_at": "Sun Feb 11 23:14:12 +0000 2018",
        "id": 962827135567192064,
        "text": "RT @MEL2AUSA: If anyone is looking for #Obama he\u2019s in his safe space.\nIt\u2019s in the ladies restroom. #ObamaKnew #ObamaGate https://t.co/TKakg\u2026",
        "user.screen_name": "RubyRockstar333"
    },
    {
        "created_at": "Sun Feb 11 23:14:11 +0000 2018",
        "id": 962827133742649347,
        "text": "RT @GartrellLinda: Obama Official Johnathan Winer: I Passed Clinton Lies to Steele That Were Used Against Trump Now the #ObamaGate scandal\u2026",
        "user.screen_name": "RHLIVEFREEORDIE"
    },
    {
        "created_at": "Sun Feb 11 23:14:11 +0000 2018",
        "id": 962827133306388481,
        "text": "RT @GrrrGraphics: #ObamaGate #Obamaspyingscandal #ObamaForPrison #LockThemAllUp \n\nYour #SaturdayMorning #Throwback #BenGarrison #cartoon #O\u2026",
        "user.screen_name": "SKITZOx916"
    },
    {
        "created_at": "Sun Feb 11 23:14:11 +0000 2018",
        "id": 962827133205794821,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "STARFORCEHH"
    },
    {
        "created_at": "Sun Feb 11 23:14:11 +0000 2018",
        "id": 962827132719087616,
        "text": "RT @12foto: All the funds that are traced to terrorists should be seized from Obama\u2019s assets! https://t.co/JWDHLaeVza",
        "user.screen_name": "Stargazer2020"
    },
    {
        "created_at": "Sun Feb 11 23:14:11 +0000 2018",
        "id": 962827131662274566,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "kiowa581997"
    },
    {
        "created_at": "Sun Feb 11 23:14:10 +0000 2018",
        "id": 962827129569280006,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "TonyinNY"
    },
    {
        "created_at": "Sun Feb 11 23:14:10 +0000 2018",
        "id": 962827128751493125,
        "text": "@timriley70 @realDonaldTrump Your just another nose ring liberal missing your Prince Liar Muslim Obama",
        "user.screen_name": "FighterAngel1"
    },
    {
        "created_at": "Sun Feb 11 23:14:10 +0000 2018",
        "id": 962827128747319296,
        "text": "RT @ChristiChat: OBAMA KNEW EVERYTHING\nOn Friday Sept 2, 2016\n67 days before America's\nPresidential Election\nFBI Lawyer Lisa Page\nsent a te\u2026",
        "user.screen_name": "VetforP"
    },
    {
        "created_at": "Sun Feb 11 23:14:10 +0000 2018",
        "id": 962827128231247872,
        "text": "RT @starcrosswolf: Rep Jim Himes, D, took his dumb pills &amp; admitted there is something in the Democratic intelligence memo that shows the F\u2026",
        "user.screen_name": "gbiggieatb"
    },
    {
        "created_at": "Sun Feb 11 23:14:09 +0000 2018",
        "id": 962827124892606465,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "james_kacee"
    },
    {
        "created_at": "Sun Feb 11 23:14:09 +0000 2018",
        "id": 962827124586381312,
        "text": "RT @Brasilmagic: Jeanine Pirro needs a straight-jacket  https://t.co/G4wzGBUJ0b",
        "user.screen_name": "Sybertuts"
    },
    {
        "created_at": "Sun Feb 11 23:14:09 +0000 2018",
        "id": 962827124271804416,
        "text": "RT @TomFitton: The American people should be able to see for themselves the FISA court docs on how Obama admin used Clinton document to mis\u2026",
        "user.screen_name": "TinaWest123321"
    },
    {
        "created_at": "Sun Feb 11 23:14:09 +0000 2018",
        "id": 962827123277881344,
        "text": "RT @PoliticalShort: Grassley-Graham memo tells us that we need not only a full-blown investigation of what possessed the Obama admin to sub\u2026",
        "user.screen_name": "ChrisCandysh"
    },
    {
        "created_at": "Sun Feb 11 23:14:09 +0000 2018",
        "id": 962827122715832322,
        "text": "@GOP Obama is responsible for the great economy\u2014-BECAUSE HE IS NOT POTUS ANYMORE, thank GOD!!",
        "user.screen_name": "Searcher1911"
    },
    {
        "created_at": "Sun Feb 11 23:14:08 +0000 2018",
        "id": 962827121793077248,
        "text": "RT @JalenSkutt: Barack Obama https://t.co/Z91o7bG2EH",
        "user.screen_name": "MarieBacungan"
    },
    {
        "created_at": "Sun Feb 11 23:14:08 +0000 2018",
        "id": 962827120870350850,
        "text": "RT @Thomas1774Paine: New York Times photographer: Trump gives us more access than Obama https://t.co/T6Z1CVtk5O",
        "user.screen_name": "divabusiness"
    },
    {
        "created_at": "Sun Feb 11 23:14:08 +0000 2018",
        "id": 962827120622874625,
        "text": "RT @GartrellLinda: Obama Official Johnathan Winer: I Passed Clinton Lies to Steele That Were Used Against Trump Now the #ObamaGate scandal\u2026",
        "user.screen_name": "teokee"
    },
    {
        "created_at": "Sun Feb 11 23:14:08 +0000 2018",
        "id": 962827119410610176,
        "text": ".American Public Opinion Finally Turns on Obama Admin... Overwhelmingly \nhttps://t.co/8LkWJogy54",
        "user.screen_name": "CharlieRand9"
    },
    {
        "created_at": "Sun Feb 11 23:14:08 +0000 2018",
        "id": 962827118521540608,
        "text": "RT @starcrosswolf: Rep Jim Himes, D, took his dumb pills &amp; admitted there is something in the Democratic intelligence memo that shows the F\u2026",
        "user.screen_name": "laearle"
    },
    {
        "created_at": "Sun Feb 11 23:14:07 +0000 2018",
        "id": 962827115761725440,
        "text": "RT @joncoopertweets: Sure, @realDonaldTrump is a lying, corrupt, racist, traitorous imbecile who defends white supremacists, Nazis, wife be\u2026",
        "user.screen_name": "MosesDidItBest"
    },
    {
        "created_at": "Sun Feb 11 23:14:07 +0000 2018",
        "id": 962827115552038912,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "navigatorclan"
    },
    {
        "created_at": "Sun Feb 11 23:14:07 +0000 2018",
        "id": 962827114377441280,
        "text": "Trump wants to screw his own daughter, cheated on all 3 wives = good. Obama 1 wife 2 kids faithful and faithful = B\u2026 https://t.co/dZQ15IC8da",
        "user.screen_name": "Nativemanley"
    },
    {
        "created_at": "Sun Feb 11 23:14:06 +0000 2018",
        "id": 962827113148674049,
        "text": "@amanda_pompili @FML_Nation @Kimosabe12345 @KurtSchlichter @VadersDeLorean @Judges445 66 million vs 63 million. He\u2026 https://t.co/QxvvfgdetL",
        "user.screen_name": "turningabout"
    },
    {
        "created_at": "Sun Feb 11 23:14:06 +0000 2018",
        "id": 962827109696786432,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "brhardy1"
    },
    {
        "created_at": "Sun Feb 11 23:14:05 +0000 2018",
        "id": 962827108757180416,
        "text": "RT @AynRandPaulRyan: Fox News host Jeanine Pirro, inexplicably and yet somehow predictably, blames Barack Obama for Rob Porter wife-beating\u2026",
        "user.screen_name": "VinLospinuso91"
    },
    {
        "created_at": "Sun Feb 11 23:14:05 +0000 2018",
        "id": 962827107922579456,
        "text": "I liked a @YouTube video https://t.co/eAVEU0BIQA Barack Obama on employers who hire illegal immigrants",
        "user.screen_name": "Renlou14Smasher"
    },
    {
        "created_at": "Sun Feb 11 23:14:05 +0000 2018",
        "id": 962827106660077568,
        "text": "RT @MichelleRMed: Pres Trump &amp; VP Pence love &amp; respect our military. Trump gave Mattis free reign to destroy ISIS which he did in less than\u2026",
        "user.screen_name": "daisylueboo1"
    },
    {
        "created_at": "Sun Feb 11 23:14:05 +0000 2018",
        "id": 962827106504855553,
        "text": "@TrueFactsStated Friendly reminder that Michael Flynn could still be there.\n\nAnd would be if an American Hero hadn'\u2026 https://t.co/PGIatAjh6V",
        "user.screen_name": "nebhusker84"
    },
    {
        "created_at": "Sun Feb 11 23:14:04 +0000 2018",
        "id": 962827104655200256,
        "text": "RT @juniperbreeze07: @RepSwalwell You can point the finger at your buddy Sid Blumenthal and Hillary Clinton\u2019s handler who started the birth\u2026",
        "user.screen_name": "kachninja"
    },
    {
        "created_at": "Sun Feb 11 23:14:04 +0000 2018",
        "id": 962827103761850370,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "Ciminolaw"
    },
    {
        "created_at": "Sun Feb 11 23:14:04 +0000 2018",
        "id": 962827102688079872,
        "text": "RT @CreechJeff: @cazad1966 @LisaASchulz2 @Teddysmom1 @Azonei1 @_etgeeee_ @SenFeinstein The US Constitution will hold. \nObama and Holder (bo\u2026",
        "user.screen_name": "Browser60911"
    },
    {
        "created_at": "Sun Feb 11 23:14:04 +0000 2018",
        "id": 962827101618532353,
        "text": "RT @RealMAGASteve: When more of the truth comes out we will discover Levin is right about the Presidential Daily Briefing.\n\nObama tried to\u2026",
        "user.screen_name": "GloriaProphet"
    },
    {
        "created_at": "Sun Feb 11 23:14:04 +0000 2018",
        "id": 962827101601714183,
        "text": "RT @kelly4NC: Bots out in full force with \u201cUsing Us as Pawns\u201d bullsh*t. Anyone paying attention knows the Trump administration is using DAC\u2026",
        "user.screen_name": "lizmbd2"
    },
    {
        "created_at": "Sun Feb 11 23:14:03 +0000 2018",
        "id": 962827100553179137,
        "text": "RT @BillKristol: Got home, took a look at Twitter: The media seem to love North Korea; people mock Mike and Karen Pence for appearing unhap\u2026",
        "user.screen_name": "JackJLSmith"
    },
    {
        "created_at": "Sun Feb 11 23:14:03 +0000 2018",
        "id": 962827098607046656,
        "text": "RT @EdKrassen: If Jeanine Pirro can blame Barack Obama for Rob Porter beating his wives, then I blame Jeanine Pirro for Donald Trump assaul\u2026",
        "user.screen_name": "VinLospinuso91"
    },
    {
        "created_at": "Sun Feb 11 23:14:01 +0000 2018",
        "id": 962827091451437056,
        "text": "RT @Bossip: President Obama\u2019s Photoshopped Beard Is Pulverizing Panny Drawls Across The Internet https://t.co/8MKoR6RHmq https://t.co/aMSAP\u2026",
        "user.screen_name": "_sabrinadsena"
    },
    {
        "created_at": "Sun Feb 11 23:14:01 +0000 2018",
        "id": 962827091300487174,
        "text": "RT @c19485591: @John3_and_16 What is disheartening.....this is much deeper than obama's presidency...the swamp is still in force and every\u2026",
        "user.screen_name": "JackieMcReath1"
    },
    {
        "created_at": "Sun Feb 11 23:14:01 +0000 2018",
        "id": 962827090751115264,
        "text": "RT @DTrumpPoll: Do you think @realDonaldTrump was vicitmized by the Obama Administration, or were investigations in to ties with Russia jus\u2026",
        "user.screen_name": "herunlikelyname"
    },
    {
        "created_at": "Sun Feb 11 23:14:00 +0000 2018",
        "id": 962827087122907137,
        "text": "RT @jeromegravesbm1: @hotfunkytown All the world leaders knew Obama was a \"girly man\" and this is no surprise from the weak leadership he h\u2026",
        "user.screen_name": "SiewTng"
    },
    {
        "created_at": "Sun Feb 11 23:14:00 +0000 2018",
        "id": 962827085164167168,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "schmuckal51"
    },
    {
        "created_at": "Sun Feb 11 23:14:00 +0000 2018",
        "id": 962827084883099648,
        "text": "RT @MyDaughtersArmy: Fox News - If all else fails, blame Obama. https://t.co/kpZ28fwWtx",
        "user.screen_name": "the_tanner21"
    },
    {
        "created_at": "Sun Feb 11 23:14:00 +0000 2018",
        "id": 962827084467974144,
        "text": "RT @johncusack: You wanna play ?  Answer-  look up Obama\u2019s war on constitution - interview I did - check out @FreedomofPress  I\u2019m on the bo\u2026",
        "user.screen_name": "TJSeraphim"
    },
    {
        "created_at": "Sun Feb 11 23:13:59 +0000 2018",
        "id": 962827084228853760,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "RealityBoost"
    },
    {
        "created_at": "Sun Feb 11 23:13:59 +0000 2018",
        "id": 962827083993972739,
        "text": "@jetking428 @JGreenblattADL The Obama admin is already gone \ud83e\udd14The Democratic bastard slavers will be out by truth &amp;\u2026 https://t.co/xF4IQ1gCdF",
        "user.screen_name": "Virgomae2891"
    },
    {
        "created_at": "Sun Feb 11 23:13:59 +0000 2018",
        "id": 962827083541110789,
        "text": "Obama, Michelle portraits to be unveiled Monday at National Portrait Gallery\n\nhttps://t.co/TJbcc9PqgQ",
        "user.screen_name": "mafoya"
    },
    {
        "created_at": "Sun Feb 11 23:13:59 +0000 2018",
        "id": 962827081410256896,
        "text": "RT @KaniJJackson: This is just your daily reminder that Barack Obama did not have 1 scandal or allegation against him during his time in th\u2026",
        "user.screen_name": "CrimeDefense"
    },
    {
        "created_at": "Sun Feb 11 23:13:59 +0000 2018",
        "id": 962827080827326464,
        "text": "RT @DFBHarvard: Well, that's DACA for you! Thanks Obama for your big fat Legacy! https://t.co/K8wwJ5Np7c",
        "user.screen_name": "katscan27_kim"
    },
    {
        "created_at": "Sun Feb 11 23:13:59 +0000 2018",
        "id": 962827080785453061,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "eva48w4"
    },
    {
        "created_at": "Sun Feb 11 23:13:59 +0000 2018",
        "id": 962827080470876162,
        "text": "RT @HawksGal_: @LevineJonathan #OMAROSA is full of BS..she knows @POTUS is undoing #Obama\u2019s mess\ud83d\ude44#MAGA @peachespulliam @helloross #TruthTel\u2026",
        "user.screen_name": "JesusIsTrueKing"
    },
    {
        "created_at": "Sun Feb 11 23:13:59 +0000 2018",
        "id": 962827080416325633,
        "text": "RT @renato_mariotti: President Obama created DACA because Republicans blocked the Dream Act. Trump ended DACA on his own\u2014don\u2019t let him get\u2026",
        "user.screen_name": "caseysigmundd"
    },
    {
        "created_at": "Sun Feb 11 23:13:58 +0000 2018",
        "id": 962827079124422657,
        "text": "RT @MichelleTrain79: Don't forget Obama sent his cronies to three funerals and never sent one to kate's funeral https://t.co/mnOfzmIFqF",
        "user.screen_name": "kevinmklerks"
    },
    {
        "created_at": "Sun Feb 11 23:13:58 +0000 2018",
        "id": 962827076221972482,
        "text": "Obama also waved instead of saluting while exiting Air Force One . https://t.co/fcoLHNe7Ts",
        "user.screen_name": "slamman140"
    },
    {
        "created_at": "Sun Feb 11 23:13:57 +0000 2018",
        "id": 962827075315838976,
        "text": "RT @TeaPainUSA: Who does Fox News blame for Trump harborin' serial domestic abuser, Rob Porter?  \n\nYou guessed it!  The black guy!\n\nhttps:/\u2026",
        "user.screen_name": "kfseattle"
    },
    {
        "created_at": "Sun Feb 11 23:13:57 +0000 2018",
        "id": 962827073273417729,
        "text": "RT @timmoore1973: @shoot38special @jamacia813 @TNMouth @Nprestn23 @Idclair @DearAuntCrabby @grammyresists @Write_Sense @PiconeKaren @DocSto\u2026",
        "user.screen_name": "shoot38special"
    },
    {
        "created_at": "Sun Feb 11 23:13:57 +0000 2018",
        "id": 962827072623316992,
        "text": "RT @hotfunkytown: This was Obama's military parade. https://t.co/boCUoj7MIW",
        "user.screen_name": "sharonsizelove"
    },
    {
        "created_at": "Sun Feb 11 23:13:57 +0000 2018",
        "id": 962827071968960512,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "Jaxgma3235"
    },
    {
        "created_at": "Sun Feb 11 23:13:56 +0000 2018",
        "id": 962827071214014465,
        "text": "RT @Isa4031AMP: BOMBSHELL: FBI Informant In Uranium One Scandal Testifies Against Obama. Here's What He Said https://t.co/cfs5cyQw14 https:\u2026",
        "user.screen_name": "MikeJudy12"
    },
    {
        "created_at": "Sun Feb 11 23:13:56 +0000 2018",
        "id": 962827070370996224,
        "text": "@Mike562017 @DiogenesLamp0 @Pr0litical @evan_manifesto @amoreimarketing @Aeon__News @Sequencer16 @LisaTomain\u2026 https://t.co/ZL2z4tgBie",
        "user.screen_name": "Raypatrick7734"
    },
    {
        "created_at": "Sun Feb 11 23:13:56 +0000 2018",
        "id": 962827069536092160,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "M5B1tch"
    },
    {
        "created_at": "Sun Feb 11 23:13:56 +0000 2018",
        "id": 962827067481116672,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "snowbirdron"
    },
    {
        "created_at": "Sun Feb 11 23:13:55 +0000 2018",
        "id": 962827067233619969,
        "text": "RT @TeaPainUSA: Who does Fox News blame for Trump harborin' serial domestic abuser, Rob Porter?  \n\nYou guessed it!  The black guy!\n\nhttps:/\u2026",
        "user.screen_name": "MajinNita"
    },
    {
        "created_at": "Sun Feb 11 23:13:55 +0000 2018",
        "id": 962827065971093504,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "gns1013"
    },
    {
        "created_at": "Sun Feb 11 23:13:55 +0000 2018",
        "id": 962827064977043456,
        "text": "RT @Logic_Triumphs: \u2b50\u2b50\u2b50\u2b50\u2b50\nBarack Obama has 99.7 million followers.\nIt would kill Donald Trump if Obama hit 100 million. Whatever you do do\u2026",
        "user.screen_name": "b_l_edwards"
    },
    {
        "created_at": "Sun Feb 11 23:13:55 +0000 2018",
        "id": 962827063299313664,
        "text": "RT @JudicialWatch: Reminder: JW found evidence showing Obama State Dept under John Kerry sent its own \"dossier\" of classified info on Russi\u2026",
        "user.screen_name": "TaNee69216947"
    },
    {
        "created_at": "Sun Feb 11 23:13:54 +0000 2018",
        "id": 962827061063688192,
        "text": "RT @SusanStormXO: @hatedtruthpig77 @Ann_B_Barber @wolfgangfaustX Burns me Up \ud83d\udd25\ud83d\udd25\nHow do we have people in America that are condoning this !\u2026",
        "user.screen_name": "Jaywall13271015"
    },
    {
        "created_at": "Sun Feb 11 23:13:53 +0000 2018",
        "id": 962827058270343175,
        "text": "RT @starcrosswolf: Rep Jim Himes, D, took his dumb pills &amp; admitted there is something in the Democratic intelligence memo that shows the F\u2026",
        "user.screen_name": "MtRushmore2016"
    },
    {
        "created_at": "Sun Feb 11 23:13:53 +0000 2018",
        "id": 962827058098290688,
        "text": "RT @Chicago1Ray: \" You, me... we own this Country. Politicians are employees of ours. And when somebody doesn't do the Job, We gotta let 'e\u2026",
        "user.screen_name": "VickieSpringer"
    },
    {
        "created_at": "Sun Feb 11 23:13:53 +0000 2018",
        "id": 962827057045692416,
        "text": "RT @KaniJJackson: This is just your daily reminder that Barack Obama did not have 1 scandal or allegation against him during his time in th\u2026",
        "user.screen_name": "bluediamond421"
    },
    {
        "created_at": "Sun Feb 11 23:13:53 +0000 2018",
        "id": 962827056458485760,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "JamesRLarkins"
    },
    {
        "created_at": "Sun Feb 11 23:13:53 +0000 2018",
        "id": 962827056382869506,
        "text": "RT @lowereast4derr: Someone needs to tell them Obama, unfortunately, has finished his term, Clinton is a private citizen(despite what bat s\u2026",
        "user.screen_name": "RobynNess1"
    },
    {
        "created_at": "Sun Feb 11 23:13:53 +0000 2018",
        "id": 962827055808294913,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "CarolynTittle"
    },
    {
        "created_at": "Sun Feb 11 23:13:52 +0000 2018",
        "id": 962827054558384129,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "afterthebridge"
    },
    {
        "created_at": "Sun Feb 11 23:13:52 +0000 2018",
        "id": 962827054549909504,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "DrJudyOhmer"
    },
    {
        "created_at": "Sun Feb 11 23:13:52 +0000 2018",
        "id": 962827053958447104,
        "text": "RT @RedWaveRising: #ObamaGate\n\n#SundayThoughts\n#BarackObama used classified intelligence leaks for political gain - https://t.co/tkba3Y498I\u2026",
        "user.screen_name": "ElisAmerica1"
    },
    {
        "created_at": "Sun Feb 11 23:13:52 +0000 2018",
        "id": 962827053010771968,
        "text": "RT @Hoosiers1986: #FakeRelationshipFacts\n\nDEM voters are gullible fools!\n\nThey revere idiots like Obama, Schumer &amp; Pelosi who COULD have pr\u2026",
        "user.screen_name": "Doembon"
    },
    {
        "created_at": "Sun Feb 11 23:13:52 +0000 2018",
        "id": 962827052893302785,
        "text": "RT @stardesert418: @sxdoc @realDonaldTrump OBAMA's $1.7B ransom payment to Iran's Terrorists groups... sell out!",
        "user.screen_name": "Brendag38323989"
    },
    {
        "created_at": "Sun Feb 11 23:13:52 +0000 2018",
        "id": 962827050808676357,
        "text": "RT @FiveRights: For 5 years Obama couldn't stop ISIS, couldn't even contain them.\nTrump, w same military, wiped out ISIS in 9 mos.\nO wasn't\u2026",
        "user.screen_name": "onthesoundshore"
    },
    {
        "created_at": "Sun Feb 11 23:13:51 +0000 2018",
        "id": 962827050640748544,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "SeattleRocko"
    },
    {
        "created_at": "Sun Feb 11 23:13:51 +0000 2018",
        "id": 962827050162810880,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "tommylowens1"
    },
    {
        "created_at": "Sun Feb 11 23:13:51 +0000 2018",
        "id": 962827050083143681,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "stevetwiss"
    },
    {
        "created_at": "Sun Feb 11 23:13:51 +0000 2018",
        "id": 962827048678051840,
        "text": "Make America Informed Again #MAIA: Is Trump even conscious? Barack Obama was sworn in on January 20, 2009. In the 2\u2026 https://t.co/6v1vkxzOVf",
        "user.screen_name": "eagle3300"
    },
    {
        "created_at": "Sun Feb 11 23:13:51 +0000 2018",
        "id": 962827048619249664,
        "text": "RT @JudicialWatch: Reminder: JW found evidence showing Obama State Dept under John Kerry sent its own \"dossier\" of classified info on Russi\u2026",
        "user.screen_name": "TxMsLee"
    },
    {
        "created_at": "Sun Feb 11 23:13:51 +0000 2018",
        "id": 962827047671402496,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "cbferry1860"
    },
    {
        "created_at": "Sun Feb 11 23:13:51 +0000 2018",
        "id": 962827047184642049,
        "text": "RT @Vento921: @hotfunkytown As much as I disliked Obama,  it showed the power of Trump and his supporters, and the indomitable spirit of Am\u2026",
        "user.screen_name": "SiewTng"
    },
    {
        "created_at": "Sun Feb 11 23:13:51 +0000 2018",
        "id": 962827046878679040,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "jfhdvm"
    },
    {
        "created_at": "Sun Feb 11 23:13:50 +0000 2018",
        "id": 962827046278791168,
        "text": "@MikaelaSkyeSays @Shoq He doesn't hate Obama, but he did disagree with some of Obama's foreign policies. He believe\u2026 https://t.co/lAP9l7fBwy",
        "user.screen_name": "KubeJ9"
    },
    {
        "created_at": "Sun Feb 11 23:13:50 +0000 2018",
        "id": 962827044785676289,
        "text": "@BarackObama Obama is from Chicago! Did the murder rate go up or down in his eight years in Washington?",
        "user.screen_name": "jonwoock"
    },
    {
        "created_at": "Sun Feb 11 23:13:50 +0000 2018",
        "id": 962827044642897921,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "BRADALL76027393"
    },
    {
        "created_at": "Sun Feb 11 23:13:50 +0000 2018",
        "id": 962827043648999425,
        "text": "RT @RVAwonk: Guy who falsely accused President Obama of a felony is suddenly concerned about false accusations. https://t.co/VBCuQmKh7N",
        "user.screen_name": "PatPattip860"
    },
    {
        "created_at": "Sun Feb 11 23:13:50 +0000 2018",
        "id": 962827042965409792,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "DevenMotley"
    },
    {
        "created_at": "Sun Feb 11 23:13:50 +0000 2018",
        "id": 962827042872963072,
        "text": "RT @stand4honor: @4USASoldiers @CAoutcast @RoryGilligan1 @CothranVicky @jeeptec420 @Baby___Del @bronson69 @Seeds81Planting @ezrateach @Tabb\u2026",
        "user.screen_name": "ElisAmerica1"
    },
    {
        "created_at": "Sun Feb 11 23:13:49 +0000 2018",
        "id": 962827042256506880,
        "text": "RT @Chicago1Ray: \" You, me... we own this Country. Politicians are employees of ours. And when somebody doesn't do the Job, We gotta let 'e\u2026",
        "user.screen_name": "jeff_jamz"
    },
    {
        "created_at": "Sun Feb 11 23:13:49 +0000 2018",
        "id": 962827039454588928,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "sexy702latina"
    },
    {
        "created_at": "Sun Feb 11 23:13:49 +0000 2018",
        "id": 962827038666051584,
        "text": "@joancichon @USAneedsTRUMP @RedaMor_ @realDonaldTrump @JohnKasich @WestervillePD Did you complain during Obama 10 t\u2026 https://t.co/W0r2mhB205",
        "user.screen_name": "jayracer440"
    },
    {
        "created_at": "Sun Feb 11 23:13:48 +0000 2018",
        "id": 962827037844164608,
        "text": "RT @carrieksada: Poll: Americans 'Overwhelmingly' Believe Obama 'Improperly Surveilled' Trump Campaign \n https://t.co/TVVpOkBUTT\n\n#CouldBea\u2026",
        "user.screen_name": "rightyfrommont"
    },
    {
        "created_at": "Sun Feb 11 23:13:48 +0000 2018",
        "id": 962827037089017856,
        "text": "RT @BJcrazyaunt: There is a reason Obama bought a house in a country that does not extradite. There is a reason Obama just hired 12 lawyers\u2026",
        "user.screen_name": "177618122016USA"
    },
    {
        "created_at": "Sun Feb 11 23:13:48 +0000 2018",
        "id": 962827035251847169,
        "text": "RT @andersonDrLJA: #OBAMA &amp; #HILLARY....2 OF THE GREATEST FRAUDS EVER PERPETRATED ON AMERICA......EVER! https://t.co/eFLCNCdNs1",
        "user.screen_name": "proudnana_3"
    },
    {
        "created_at": "Sun Feb 11 23:13:48 +0000 2018",
        "id": 962827034790694913,
        "text": "RT @Fuctupmind: Pretty much everyone knew about the Steele Dossier.\n\nThe entire Obama admin.\nSid Blumenthal.\nHillary Clinton.\nLoretta Lynch\u2026",
        "user.screen_name": "dwulke"
    },
    {
        "created_at": "Sun Feb 11 23:13:47 +0000 2018",
        "id": 962827032747917312,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "Clariiiiice"
    },
    {
        "created_at": "Sun Feb 11 23:13:47 +0000 2018",
        "id": 962827030202060800,
        "text": "@rcevat69 @JacobAWohl @realDonaldTrump I would like to hear the whole story on how Porter blames Obama for that! Pl\u2026 https://t.co/TRuGfyErbv",
        "user.screen_name": "WilliamEBraunJr"
    },
    {
        "created_at": "Sun Feb 11 23:13:47 +0000 2018",
        "id": 962827030155821056,
        "text": "RT @TeaPainUSA: Who does Fox News blame for Trump harborin' serial domestic abuser, Rob Porter?  \n\nYou guessed it!  The black guy!\n\nhttps:/\u2026",
        "user.screen_name": "biegenci"
    },
    {
        "created_at": "Sun Feb 11 23:13:46 +0000 2018",
        "id": 962827029493231617,
        "text": "RT @village_jordan: @sxdoc @realcorylynn @realDonaldTrump Iran and Obama and Valerie Jarrett \nhow close do you get..\nEvil Muslims in the WH\u2026",
        "user.screen_name": "Brendag38323989"
    },
    {
        "created_at": "Sun Feb 11 23:13:46 +0000 2018",
        "id": 962827029094785024,
        "text": "RT @mattmfm: Barack Obama was in the same room as Louis Farrakhan once and it caused a decades-long controversy. \n\nDonald Trump gave a shou\u2026",
        "user.screen_name": "bluejay6537"
    },
    {
        "created_at": "Sun Feb 11 23:13:46 +0000 2018",
        "id": 962827027526103042,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "prioleaustreet"
    },
    {
        "created_at": "Sun Feb 11 23:13:46 +0000 2018",
        "id": 962827026380996609,
        "text": "RT @Maryland4Trump2: @realDonaldTrump How liberals view the stock market:\ud83d\udc47\n\n\u2796Up:\u00a0\u00a0Credit Obama\u00a0\u00a0\n\u2796Down:\u00a0\u00a0Blame Trump\u00a0\u00a0\n\nIt\u2019s ok liberals...\u2026",
        "user.screen_name": "dsshep1959"
    },
    {
        "created_at": "Sun Feb 11 23:13:46 +0000 2018",
        "id": 962827026217381888,
        "text": "RT @ElderLansing: I will never respect the Ex Resident Coward Obama! He was a horrible leader and had numerous scandals overlooked because\u2026",
        "user.screen_name": "Gregory52230449"
    },
    {
        "created_at": "Sun Feb 11 23:13:45 +0000 2018",
        "id": 962827025416204288,
        "text": "#MAGA #Patriot #Qanon #TheStormIsHere #GreatAwakening #AmericaFirst #WeThePeople #CCCTrain #TrumpsTroops \ud83c\uddfa\ud83c\uddf8 FACT; W\u2026 https://t.co/h9wfMO7gOo",
        "user.screen_name": "ChrissyUSA1"
    },
    {
        "created_at": "Sun Feb 11 23:13:45 +0000 2018",
        "id": 962827024749420544,
        "text": "Hey Demorats your \"MEMO\" wasn't blocked,it was sent back to you to correct your screw up that you wanted in it or m\u2026 https://t.co/mkIJwiQMnw",
        "user.screen_name": "hwfranzjr"
    },
    {
        "created_at": "Sun Feb 11 23:13:45 +0000 2018",
        "id": 962827023067398144,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "Anasoptora3"
    },
    {
        "created_at": "Sun Feb 11 23:13:45 +0000 2018",
        "id": 962827022513958912,
        "text": "RT @ChristiChat: OBAMA KNEW EVERYTHING\nOn Friday Sept 2, 2016\n67 days before America's\nPresidential Election\nFBI Lawyer Lisa Page\nsent a te\u2026",
        "user.screen_name": "Chicago10th"
    },
    {
        "created_at": "Sun Feb 11 23:13:44 +0000 2018",
        "id": 962827020853014530,
        "text": "RT @Education4Libs: The media is going nuts over Trump\u2019s hair flapping in the wind which revealed part of his scalp.\n\nTell me again how thi\u2026",
        "user.screen_name": "Deplorable_Didi"
    },
    {
        "created_at": "Sun Feb 11 23:13:44 +0000 2018",
        "id": 962827019213066240,
        "text": "@Tiffany1985B @jennyleesac30 @Obama_FOS Oh, I practice it frequently and still get stuff wrong! It gets hard for me\u2026 https://t.co/qzIrc2ks4q",
        "user.screen_name": "___aniT___"
    },
    {
        "created_at": "Sun Feb 11 23:13:44 +0000 2018",
        "id": 962827017858179072,
        "text": "RT @Frederick987: foxnews should be stopped. Enough . No Democratic country has to put up,with an anti democratic, non factual broadcasting\u2026",
        "user.screen_name": "scubasylph49"
    },
    {
        "created_at": "Sun Feb 11 23:13:43 +0000 2018",
        "id": 962827015320633345,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "stevetwiss"
    },
    {
        "created_at": "Sun Feb 11 23:13:43 +0000 2018",
        "id": 962827014959960064,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "graycsam"
    },
    {
        "created_at": "Sun Feb 11 23:13:43 +0000 2018",
        "id": 962827014741766145,
        "text": "RT @AlexTJohansen: I saw a documentrary where Obama's Kenyan grandmother pointed out the hut he was born in.\n\nWeird.\n\nIt's almost like he w\u2026",
        "user.screen_name": "AlexTJohansen"
    },
    {
        "created_at": "Sun Feb 11 23:13:42 +0000 2018",
        "id": 962827011529027585,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "SheerHubris"
    },
    {
        "created_at": "Sun Feb 11 23:13:42 +0000 2018",
        "id": 962827011369480193,
        "text": "RT @watspn1013: \ud83d\udd25Obama-Backed, Holder-Led Group\ud83d\udd25 dedicated to \"enacting a comprehensive, multi-cycle Democratic Party redistricting strateg\u2026",
        "user.screen_name": "Snap_Politics"
    },
    {
        "created_at": "Sun Feb 11 23:13:42 +0000 2018",
        "id": 962827008911781890,
        "text": "RT @JohnFromCranber: America Dodged a Bullet. Hillary Would Have Been a '3rd Obama Term'.  Alt-Left/Soros's Fundamental Transformation Woul\u2026",
        "user.screen_name": "usedcars1995"
    },
    {
        "created_at": "Sun Feb 11 23:13:41 +0000 2018",
        "id": 962827008660172800,
        "text": "RT @RyanAFournier: Do you believe the Obama Administration improperly and illegally surveilled the Trump Campaign? #SHARE",
        "user.screen_name": "dough43"
    },
    {
        "created_at": "Sun Feb 11 23:13:41 +0000 2018",
        "id": 962827004755300352,
        "text": "@AnthonyDiGrazio Think what he means is they could have done something properly (i.e. legislatively) But did nothin\u2026 https://t.co/5pxTMi7V1f",
        "user.screen_name": "PhillyFanForum"
    },
    {
        "created_at": "Sun Feb 11 23:13:40 +0000 2018",
        "id": 962827004084215809,
        "text": "RT @thecharleschall: The rest of America is catching up to what we said 7 years ago: Obama is one of the worst presidents ever!\n\n\u201cAmericans\u2026",
        "user.screen_name": "JeffW20762675"
    },
    {
        "created_at": "Sun Feb 11 23:13:40 +0000 2018",
        "id": 962827002989498370,
        "text": "RT @FiveRights: For 5 years Obama couldn't stop ISIS, couldn't even contain them.\nTrump, w same military, wiped out ISIS in 9 mos.\nO wasn't\u2026",
        "user.screen_name": "Chriskl70208387"
    },
    {
        "created_at": "Sun Feb 11 23:13:40 +0000 2018",
        "id": 962827002934804480,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "drwpuma"
    },
    {
        "created_at": "Sun Feb 11 23:13:40 +0000 2018",
        "id": 962827001592778753,
        "text": "RT @Riff_Raff45: @EddieGriffinCom which budget did Obama balance? His checking account? I turned you off after 10 minutes. Sorry. I was a f\u2026",
        "user.screen_name": "DrSchmalz"
    },
    {
        "created_at": "Sun Feb 11 23:13:40 +0000 2018",
        "id": 962827001588584448,
        "text": "RT @mattmfm: Barack Obama was in the same room as Louis Farrakhan once and it caused a decades-long controversy. \n\nDonald Trump gave a shou\u2026",
        "user.screen_name": "francie57"
    },
    {
        "created_at": "Sun Feb 11 23:13:40 +0000 2018",
        "id": 962827000690884608,
        "text": "RT @FaceTheNation: .@RandPaul: We were very critical of President Obama\u2019s deficits approaching a trillion dollars a year. We talked endless\u2026",
        "user.screen_name": "bmain249"
    },
    {
        "created_at": "Sun Feb 11 23:13:39 +0000 2018",
        "id": 962826999667474432,
        "text": "Back in 2009, a NYTimes blogger is obsessed with Obama. She writes about having 'Sex Dreams' about Barack!! ... Yuc\u2026 https://t.co/mexl2E5E7c",
        "user.screen_name": "DragonForce_One"
    },
    {
        "created_at": "Sun Feb 11 23:13:39 +0000 2018",
        "id": 962826999298486272,
        "text": "RT @TheNYevening: #Trump Sends Feds To Arrest #Obama Appointed Judge https://t.co/dZPMNBglSH https://t.co/luPGCQtyv7",
        "user.screen_name": "SUCCESSFULGGIRL"
    },
    {
        "created_at": "Sun Feb 11 23:13:39 +0000 2018",
        "id": 962826998392545280,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "_teralynn_"
    },
    {
        "created_at": "Sun Feb 11 23:13:39 +0000 2018",
        "id": 962826997461405696,
        "text": "@CNN @VanJones68 He\u2019s still 100 percent better then obama",
        "user.screen_name": "standaman218"
    },
    {
        "created_at": "Sun Feb 11 23:13:39 +0000 2018",
        "id": 962826996689629186,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "heyitsssaj"
    },
    {
        "created_at": "Sun Feb 11 23:13:38 +0000 2018",
        "id": 962826996018540544,
        "text": "@OmnivoreBlog @MaxBoot No. I don't think you owe me anything. I do think it's misleading to tweet that you're a car\u2026 https://t.co/sf3sE9s9QN",
        "user.screen_name": "DawnDCS92"
    },
    {
        "created_at": "Sun Feb 11 23:13:38 +0000 2018",
        "id": 962826994911203329,
        "text": "RT @RyanAFournier: Do you believe the Obama Administration improperly and illegally surveilled the Trump Campaign? #SHARE",
        "user.screen_name": "harrowsand"
    },
    {
        "created_at": "Sun Feb 11 23:13:38 +0000 2018",
        "id": 962826994214842368,
        "text": "RT @MatthewACherry: This Michelle Obama gif was from BET's \"Love &amp; Happiness\" musical celebration at the White House honoring the Obamas.\u2026",
        "user.screen_name": "Smoke_nd_Pearls"
    },
    {
        "created_at": "Sun Feb 11 23:13:38 +0000 2018",
        "id": 962826993673887745,
        "text": "RT @Hoosiers1986: #FakeRelationshipFacts\n\nDEM voters are gullible fools!\n\nThey revere idiots like Obama, Schumer &amp; Pelosi who COULD have pr\u2026",
        "user.screen_name": "PhilMcCrackin44"
    },
    {
        "created_at": "Sun Feb 11 23:13:37 +0000 2018",
        "id": 962826991614529536,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "kpjc57"
    },
    {
        "created_at": "Sun Feb 11 23:13:37 +0000 2018",
        "id": 962826991371149312,
        "text": "@amandanaude @1234bulldog @abiantes @IamMarkStephens @bellaace52 @realDonaldTrump \ud83e\udd23 Prez Obama regulations. Can you\u2026 https://t.co/0miYUDEKwT",
        "user.screen_name": "Inked_Buddhist"
    },
    {
        "created_at": "Sun Feb 11 23:13:37 +0000 2018",
        "id": 962826989836128256,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "GinaWinter"
    },
    {
        "created_at": "Sun Feb 11 23:13:37 +0000 2018",
        "id": 962826988778962944,
        "text": "RT @jeffhauser: Donald Trump's hidden tax returns should have been a DEFINING ISSUE of 2017. \n\nInstead, Trump's tax returns discussed less\u2026",
        "user.screen_name": "comeau6_paul"
    },
    {
        "created_at": "Sun Feb 11 23:13:37 +0000 2018",
        "id": 962826988263280642,
        "text": "RT @jh45123: This is Obama's birth certificate born in Kenya look for yourself Obama is a fraud his whole life is a fraud! https://t.co/aKf\u2026",
        "user.screen_name": "G_Pond47"
    },
    {
        "created_at": "Sun Feb 11 23:13:36 +0000 2018",
        "id": 962826986870763521,
        "text": "RT @TheLastRefuge2: Andrew McCarthy admits he was wrong.  Obama/Clinton's FISA-Gate is very real. The Grassley-Graham Memo proves it... htt\u2026",
        "user.screen_name": "SharonK_s"
    },
    {
        "created_at": "Sun Feb 11 23:13:36 +0000 2018",
        "id": 962826984173834240,
        "text": "RT @Maeve_Crowley: I only love my bed and Obama, I\u2019m sorry",
        "user.screen_name": "mollygravy"
    },
    {
        "created_at": "Sun Feb 11 23:13:35 +0000 2018",
        "id": 962826982361915392,
        "text": "RT @MOVEFORWARDHUGE: THE OBAMA ADMINISTRATION HOUSE OF CARDS\n\nIS ABOUT TO MEET GITMO BARS!\n\nWHEN THE MILITARY TRIBUNALS ARE DONE,\n\nAMERICA\u2026",
        "user.screen_name": "shillelagh1"
    },
    {
        "created_at": "Sun Feb 11 23:13:35 +0000 2018",
        "id": 962826981803884544,
        "text": "RT @EdKrassen: If Jeanine Pirro can blame Barack Obama for Rob Porter beating his wives, then I blame Jeanine Pirro for Donald Trump assaul\u2026",
        "user.screen_name": "CrimeDefense"
    },
    {
        "created_at": "Sun Feb 11 23:13:35 +0000 2018",
        "id": 962826980616998912,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "william_mendel"
    },
    {
        "created_at": "Sun Feb 11 23:13:35 +0000 2018",
        "id": 962826980222734337,
        "text": "To Everyone who says that in the short amount of time in office, @realDonaldTrump has done more than @BarackObama d\u2026 https://t.co/2PLFfshWzK",
        "user.screen_name": "I_create_things"
    },
    {
        "created_at": "Sun Feb 11 23:13:35 +0000 2018",
        "id": 962826979635597312,
        "text": "RT @TuckerCarlson: Here's what is clear right now, the bottom line on what we've learned this week and the one thing worth remembering: The\u2026",
        "user.screen_name": "Okay_kaykay_"
    },
    {
        "created_at": "Sun Feb 11 23:13:34 +0000 2018",
        "id": 962826978209488898,
        "text": "RT @TheNYevening: Trump BLOWS THE LID Off Obama\u2019s Phony Birth Certificate https://t.co/N19XzDzTvc https://t.co/HL8qmo6xhT",
        "user.screen_name": "GHallSAFC"
    },
    {
        "created_at": "Sun Feb 11 23:13:34 +0000 2018",
        "id": 962826977689219074,
        "text": "#twitter -  Tweets About Obama's Facial Hair \u201cPhoto\u201d Have Twitter So Damn Thirsty - Elite Daily\u2026 https://t.co/h3kGJFemTa",
        "user.screen_name": "Tw1tterDemise"
    },
    {
        "created_at": "Sun Feb 11 23:13:34 +0000 2018",
        "id": 962826976036765696,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "Pam9291"
    },
    {
        "created_at": "Sun Feb 11 23:13:34 +0000 2018",
        "id": 962826975743266816,
        "text": "With these faces I hope they are behind the camera:  #HBO hires former Obama staffers to create specials ahead of m\u2026 https://t.co/4eDV17gFc4",
        "user.screen_name": "BruceMajors4DC"
    },
    {
        "created_at": "Sun Feb 11 23:13:34 +0000 2018",
        "id": 962826975260958721,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "annebernstein64"
    },
    {
        "created_at": "Sun Feb 11 23:13:33 +0000 2018",
        "id": 962826974795243520,
        "text": "RT @MichelleTrain79: Never forget  @BarackObama invited Black Lives Matter to the White House. Obama praised the leaders and encouraged the\u2026",
        "user.screen_name": "Raymoz50"
    },
    {
        "created_at": "Sun Feb 11 23:13:33 +0000 2018",
        "id": 962826973759393794,
        "text": "@ArthurSchwartz @michellemalkin So, how does CNN's view on fascism work again? \n\nI guess, they'd be happy if Obama\u2026 https://t.co/eVJ8X0FMVf",
        "user.screen_name": "JohnAdversary"
    },
    {
        "created_at": "Sun Feb 11 23:13:33 +0000 2018",
        "id": 962826971242745856,
        "text": "RT @Chicago1Ray: \" You, me... we own this Country. Politicians are employees of ours. And when somebody doesn't do the Job, We gotta let 'e\u2026",
        "user.screen_name": "RitaLeach9"
    },
    {
        "created_at": "Sun Feb 11 23:13:32 +0000 2018",
        "id": 962826970978570242,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "Electroman05"
    },
    {
        "created_at": "Sun Feb 11 23:13:32 +0000 2018",
        "id": 962826969388847104,
        "text": "RT @miamijj48: Our fast-growing national debt is a toxic legacy for my generation \n\n$1 Trillion in debt is unacceptable-We need to continue\u2026",
        "user.screen_name": "Carlstrasburge1"
    },
    {
        "created_at": "Sun Feb 11 23:13:31 +0000 2018",
        "id": 962826966289141760,
        "text": "RT @FiveRights: For 5 years Obama couldn't stop ISIS, couldn't even contain them.\nTrump, w same military, wiped out ISIS in 9 mos.\nO wasn't\u2026",
        "user.screen_name": "carr_55"
    },
    {
        "created_at": "Sun Feb 11 23:13:31 +0000 2018",
        "id": 962826965848739841,
        "text": "RT @gymbeaux143: Yup!  Along with MSNBC and NBC for certain. Look how they all played up Obama's visit with the COMMUNIST MURDERERS in Cuba\u2026",
        "user.screen_name": "williamlharbuck"
    },
    {
        "created_at": "Sun Feb 11 23:13:31 +0000 2018",
        "id": 962826964833841154,
        "text": "RT @dbongino: So now we know:\n-The Obama admin spied on the Trump team\n-Hillary\u2019s campaign assisted in the effort\n-Russians assisted the Hi\u2026",
        "user.screen_name": "jamievisser21"
    },
    {
        "created_at": "Sun Feb 11 23:13:31 +0000 2018",
        "id": 962826963873353729,
        "text": "RT @jefftiedrich: Kellyanne Conway, because when I need facts grounded in reality I turn to a woman who accused Barack Obama of spying on t\u2026",
        "user.screen_name": "learnpolsci"
    },
    {
        "created_at": "Sun Feb 11 23:13:30 +0000 2018",
        "id": 962826962518659073,
        "text": "RT @Debradelai: @GenFlynn (29) When it came out thet this jewel of a journalist was clearing stories with Obama\u2019s CIA before publication:\u2026",
        "user.screen_name": "Lrod49"
    },
    {
        "created_at": "Sun Feb 11 23:13:30 +0000 2018",
        "id": 962826959808950272,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "Tyger_Yang"
    },
    {
        "created_at": "Sun Feb 11 23:13:29 +0000 2018",
        "id": 962826957288128513,
        "text": "What? And implicate OBAMA in this scandal?! Can\u2019t do that.......yet. https://t.co/aNu8J4384J",
        "user.screen_name": "Randobot_Z"
    },
    {
        "created_at": "Sun Feb 11 23:13:29 +0000 2018",
        "id": 962826957170896902,
        "text": "RT @cathibrgnr58: @LoriJac47135906 @SandraTXAS @ClintonM614 @LVNancy @JVER1 @Hoosiers1986 @GrizzleMeister @GaetaSusan @baalter @On_The_Hook\u2026",
        "user.screen_name": "GramsStands"
    },
    {
        "created_at": "Sun Feb 11 23:13:29 +0000 2018",
        "id": 962826956508225536,
        "text": "@tedlieu The GOP would have had kittens if Obama did this. And they would have already drawn up impeachment papers\u2026 https://t.co/wnenCI4jxZ",
        "user.screen_name": "CliftRobbie"
    },
    {
        "created_at": "Sun Feb 11 23:13:29 +0000 2018",
        "id": 962826954310406147,
        "text": "@MSNBC #msnbc @NBC is really Hard UP. Backed into a corner they decide to fight back using Domestic Abuse &amp; Securit\u2026 https://t.co/S0OWZwFPT4",
        "user.screen_name": "Writer_Big"
    },
    {
        "created_at": "Sun Feb 11 23:13:28 +0000 2018",
        "id": 962826953966399488,
        "text": "@chrislhayes Remind #OMB Director #Mulvaney that despite #GreatRecession, #Obama saved US from #Depression, brought\u2026 https://t.co/YsC7E1MzNG",
        "user.screen_name": "TravelFeatures"
    },
    {
        "created_at": "Sun Feb 11 23:13:28 +0000 2018",
        "id": 962826953752563713,
        "text": "@Will4Pres2020 @AlbertM17889786 @davidpom2000 @FoxNews @Franklin_Graham @POTUS Obama been in hiding. So you ain't reading much.",
        "user.screen_name": "MMchiefsquid"
    },
    {
        "created_at": "Sun Feb 11 23:13:28 +0000 2018",
        "id": 962826953651838981,
        "text": "@Franklin_Graham @FoxNews @foxandfriends So far, Graham &amp; @SamaritansPurse have accepted $235K from Trump, some whi\u2026 https://t.co/FECmgFiXBJ",
        "user.screen_name": "Tribulation7"
    },
    {
        "created_at": "Sun Feb 11 23:13:28 +0000 2018",
        "id": 962826950766194688,
        "text": "RT @realDonaldTrump: \u201cMy view is that not only has Trump been vindicated in the last several weeks about the mishandling of the Dossier and\u2026",
        "user.screen_name": "JohnPaulSimpso2"
    },
    {
        "created_at": "Sun Feb 11 23:13:28 +0000 2018",
        "id": 962826950376124416,
        "text": "Former Obama campaign manager says 'all public pollsters should be shot' https://t.co/a7pHbTsSBq #FoxNews",
        "user.screen_name": "SilverFoxOO7"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826949910462465,
        "text": "RT @MplsMe: Wall can't stop MS-13 because it started in Los Angeles, and is well-established in US. Many US citizens are members. Wall won'\u2026",
        "user.screen_name": "jennah_justen"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826949877002241,
        "text": "RT @MOVEFORWARDHUGE: THE OBAMA ADMINISTRATION HOUSE OF CARDS\n\nIS ABOUT TO MEET GITMO BARS!\n\nWHEN THE MILITARY TRIBUNALS ARE DONE,\n\nAMERICA\u2026",
        "user.screen_name": "DavesSpataro"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826949415653377,
        "text": "@realDonaldTrump \n\nUm are you smoking weed cos you are definitely NOT more popular than Obama... it should skip fro\u2026 https://t.co/9cjMQBiRmJ",
        "user.screen_name": "111AdVictoriam"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826949033803776,
        "text": "RT @AynRandPaulRyan: Fox News host Jeanine Pirro, inexplicably and yet somehow predictably, blames Barack Obama for Rob Porter wife-beating\u2026",
        "user.screen_name": "CrimeDefense"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826948673228800,
        "text": "RT @JrcheneyJohn: Obama\u2019s Department Of Justice was Politically Biased And they Politicized That BIAS to Attack Conservatives \n\n#MAGA #Frid\u2026",
        "user.screen_name": "Hillbilly45638"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826948480262144,
        "text": "@dcexaminer Good. More Obama people leaving",
        "user.screen_name": "Kelly2Teresa"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826948236972038,
        "text": "@jlflorida14 @Richard2015200 @DMansini Obama said this in October 2016. Please watch the video\nhttps://t.co/nOmqtqxgHI",
        "user.screen_name": "brian_dutch"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826947226144768,
        "text": "RT @miamijj48: Our fast-growing national debt is a toxic legacy for my generation \n\n$1 Trillion in debt is unacceptable-We need to continue\u2026",
        "user.screen_name": "bswerdon"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826946349621248,
        "text": "Do you guys remember how much shit Obama talked openly &amp; derisively about the repubs when they locked arms to go wh\u2026 https://t.co/1LNc6mDYdK",
        "user.screen_name": "imtanjab"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826946303479808,
        "text": "It's time to drop the DOUBLE Standard of the Laws against Obama and Hillary Clinton. And it's time to give equal Ju\u2026 https://t.co/2DQz8WDwm1",
        "user.screen_name": "62seabee"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826946261409792,
        "text": "RT @JalenSkutt: Barack Obama https://t.co/Z91o7bG2EH",
        "user.screen_name": "Babypaige2012"
    },
    {
        "created_at": "Sun Feb 11 23:13:27 +0000 2018",
        "id": 962826946186043392,
        "text": "RT @stand4honor: @4USASoldiers @CAoutcast @RoryGilligan1 @CothranVicky @jeeptec420 @Baby___Del @bronson69 @Seeds81Planting @ezrateach @Tabb\u2026",
        "user.screen_name": "DonDonsmith007"
    },
    {
        "created_at": "Sun Feb 11 23:13:26 +0000 2018",
        "id": 962826945548443654,
        "text": "RT @FiveRights: For 5 years Obama couldn't stop ISIS, couldn't even contain them.\nTrump, w same military, wiped out ISIS in 9 mos.\nO wasn't\u2026",
        "user.screen_name": "momofhornnhalos"
    },
    {
        "created_at": "Sun Feb 11 23:13:26 +0000 2018",
        "id": 962826945280045056,
        "text": "RT @Bakari_Sellers: Fox News viewers believe its Obama\u2019s fault Rob Porter beat his wives. https://t.co/5y8wPzWLOu",
        "user.screen_name": "rasssalgc"
    },
    {
        "created_at": "Sun Feb 11 23:13:26 +0000 2018",
        "id": 962826944961064961,
        "text": "RT @joncoopertweets: Sure, @realDonaldTrump is a lying, corrupt, racist, traitorous imbecile who defends white supremacists, Nazis, wife be\u2026",
        "user.screen_name": "kats_horsemen"
    },
    {
        "created_at": "Sun Feb 11 23:13:26 +0000 2018",
        "id": 962826944474595328,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "mizwalliz"
    },
    {
        "created_at": "Sun Feb 11 23:13:26 +0000 2018",
        "id": 962826942125715456,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "sofiegeorge"
    },
    {
        "created_at": "Sun Feb 11 23:13:25 +0000 2018",
        "id": 962826940792082433,
        "text": "RT @Imperator_Rex3: Important thread focussing on how the criminals used a foreign intelligence service (GCHQ) to inject the dodgy dossier\u2026",
        "user.screen_name": "PurpleDragon333"
    },
    {
        "created_at": "Sun Feb 11 23:13:25 +0000 2018",
        "id": 962826940481703938,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "Hops_a_Chord"
    },
    {
        "created_at": "Sun Feb 11 23:13:25 +0000 2018",
        "id": 962826939357716481,
        "text": "RT @msue1000: Jeanine Pirro ~~&gt; This cross-eyed lunatic is placing blame on President Obama for Rob Porter abuse scandal. I guess Hillary C\u2026",
        "user.screen_name": "Fearless211314"
    },
    {
        "created_at": "Sun Feb 11 23:13:24 +0000 2018",
        "id": 962826937407361024,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "SeeNacks"
    },
    {
        "created_at": "Sun Feb 11 23:13:24 +0000 2018",
        "id": 962826937075949568,
        "text": "RT @MarkRocon: Obama, the Marxist and Chief, shoving his brand of Socialism down our throats. https://t.co/qshHa0XAcF",
        "user.screen_name": "carlislecockato"
    },
    {
        "created_at": "Sun Feb 11 23:13:24 +0000 2018",
        "id": 962826934018289664,
        "text": "This is so not true!! Obama is the one who brought racism to the surface again and President Trump is trying to fix\u2026 https://t.co/RkPLYnX2JM",
        "user.screen_name": "accmomcat"
    },
    {
        "created_at": "Sun Feb 11 23:13:24 +0000 2018",
        "id": 962826933544218625,
        "text": "RT @essenviews: Sarah Huckabee Sanders is one of the officials who is spreading the false smear that Obama didn\u2019t call Gen. John Kelly afte\u2026",
        "user.screen_name": "dupergramp"
    },
    {
        "created_at": "Sun Feb 11 23:13:24 +0000 2018",
        "id": 962826933380591616,
        "text": "RT @MichelleTrain79: Don't forget Obama sent his cronies to three funerals and never sent one to kate's funeral https://t.co/mnOfzmIFqF",
        "user.screen_name": "Raymoz50"
    },
    {
        "created_at": "Sun Feb 11 23:13:23 +0000 2018",
        "id": 962826930587389952,
        "text": "RT @FiveRights: Laura Ingraham on Fox: Why did George W. Bush refuse to criticize Obama even when O screwed up badly but he often criticize\u2026",
        "user.screen_name": "jjmac59"
    },
    {
        "created_at": "Sun Feb 11 23:13:23 +0000 2018",
        "id": 962826929291358214,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "auntiejul"
    },
    {
        "created_at": "Sun Feb 11 23:13:22 +0000 2018",
        "id": 962826928896983040,
        "text": "RT @EdKrassen: If Jeanine Pirro can blame Barack Obama for Rob Porter beating his wives, then I blame Jeanine Pirro for Donald Trump assaul\u2026",
        "user.screen_name": "BettyArtLemus1"
    },
    {
        "created_at": "Sun Feb 11 23:13:22 +0000 2018",
        "id": 962826928255307783,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "FchubayFred"
    },
    {
        "created_at": "Sun Feb 11 23:13:22 +0000 2018",
        "id": 962826927995326464,
        "text": "RT @sdc0911: \ud83d\udd25Clinton and Obama\ud83d\udd25Two people\u2019s \ud83d\ude21NAMES\ud83d\ude21 that are ENOUGH\u274c\u274cTO PISS YOU OFF\u203c\ufe0f\ud83d\ude21#LockThemUp\ud83d\udca5#ClintonCrimeFamily \ud83d\udca5#ObamaGateExposed\u2026",
        "user.screen_name": "jen4trump1"
    },
    {
        "created_at": "Sun Feb 11 23:13:22 +0000 2018",
        "id": 962826926074155009,
        "text": "RT @thestationchief: The Truth will out, eventually...\n\nNo suprise that Obama, who Lives in DC, has been keeping a low profile lately....\u2026",
        "user.screen_name": "mrmatt408"
    },
    {
        "created_at": "Sun Feb 11 23:13:21 +0000 2018",
        "id": 962826924358762497,
        "text": "RT @KaniJJackson: This is just your daily reminder that Barack Obama did not have 1 scandal or allegation against him during his time in th\u2026",
        "user.screen_name": "lyarmosky1"
    },
    {
        "created_at": "Sun Feb 11 23:13:21 +0000 2018",
        "id": 962826923444441088,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "J_DCB"
    },
    {
        "created_at": "Sun Feb 11 23:13:20 +0000 2018",
        "id": 962826920487456770,
        "text": "RT @TuckerCarlson: Here's what is clear right now, the bottom line on what we've learned this week and the one thing worth remembering: The\u2026",
        "user.screen_name": "EdHarvey55"
    },
    {
        "created_at": "Sun Feb 11 23:13:20 +0000 2018",
        "id": 962826919778639872,
        "text": "RT @Hoosiers1986: #FakeRelationshipFacts\n\nDEM voters are gullible fools!\n\nThey revere idiots like Obama, Schumer &amp; Pelosi who COULD have pr\u2026",
        "user.screen_name": "couerfidele"
    },
    {
        "created_at": "Sun Feb 11 23:13:20 +0000 2018",
        "id": 962826919090835457,
        "text": "RT @JudicialWatch: Reminder: JW found evidence showing Obama State Dept under John Kerry sent its own \"dossier\" of classified info on Russi\u2026",
        "user.screen_name": "jb19tele"
    },
    {
        "created_at": "Sun Feb 11 23:13:20 +0000 2018",
        "id": 962826918977507330,
        "text": "RT @Pink_About_it: The real question about fake dossier is not IF #Fisa warrant is now a widely known retroactive cover up, but rather, wha\u2026",
        "user.screen_name": "RitaLeach9"
    },
    {
        "created_at": "Sun Feb 11 23:13:20 +0000 2018",
        "id": 962826918633484288,
        "text": "RT @conserv_tribune: It's incredible how fast Obama's \"legacy\" is collapsing. https://t.co/q1fK0zCVsO",
        "user.screen_name": "Sonorandesertra"
    },
    {
        "created_at": "Sun Feb 11 23:13:20 +0000 2018",
        "id": 962826917689913344,
        "text": "RT @Fuctupmind: Pretty much everyone knew about the Steele Dossier.\n\nThe entire Obama admin.\nSid Blumenthal.\nHillary Clinton.\nLoretta Lynch\u2026",
        "user.screen_name": "GrantJanzen"
    },
    {
        "created_at": "Sun Feb 11 23:13:20 +0000 2018",
        "id": 962826916846866432,
        "text": "@FoxNews FROM A HAS BEEN ACTOR ,THAT'S FUNNY. LIBERALS HATE THAT TRUMP DID IN 1 YEAR WHAT OBAMA FAILED TO DO IN A\n8\u2026 https://t.co/M056RU9A1s",
        "user.screen_name": "PoppopktruckPop"
    },
    {
        "created_at": "Sun Feb 11 23:13:19 +0000 2018",
        "id": 962826915924135936,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "PattyxB"
    },
    {
        "created_at": "Sun Feb 11 23:13:19 +0000 2018",
        "id": 962826915827671040,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "circumspectus"
    },
    {
        "created_at": "Sun Feb 11 23:13:19 +0000 2018",
        "id": 962826914821017600,
        "text": "RT @jcpenni7maga: I am dropping my #HBO subscription after hearing about this BS\ud83e\udd2c\ud83e\udd2c\ud83e\udd2cand you should too!\n\nHBO - #HomeBoxOffice is hiring #Oba\u2026",
        "user.screen_name": "S25040459"
    },
    {
        "created_at": "Sun Feb 11 23:13:19 +0000 2018",
        "id": 962826914544209920,
        "text": "RT @mattmfm: Barack Obama was in the same room as Louis Farrakhan once and it caused a decades-long controversy. \n\nDonald Trump gave a shou\u2026",
        "user.screen_name": "annejowrites"
    },
    {
        "created_at": "Sun Feb 11 23:13:19 +0000 2018",
        "id": 962826912547536896,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "DrJudyOhmer"
    },
    {
        "created_at": "Sun Feb 11 23:13:18 +0000 2018",
        "id": 962826911897530368,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "AColorfulBrain"
    },
    {
        "created_at": "Sun Feb 11 23:13:18 +0000 2018",
        "id": 962826911796858881,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "JPrekoski"
    },
    {
        "created_at": "Sun Feb 11 23:13:18 +0000 2018",
        "id": 962826911301980161,
        "text": "RT @GrrrGraphics: \"In the Head of Hillary\" #BenGarrison #cartoon \nSomeone asked me why I draw so many #Obama &amp; #Hillary cartoons. \nread mor\u2026",
        "user.screen_name": "jared96540410"
    },
    {
        "created_at": "Sun Feb 11 23:13:18 +0000 2018",
        "id": 962826911201206274,
        "text": "RT @MichelleTrain79: #Obama best friends. Says a lot about obama. https://t.co/jnFAx8bGAJ",
        "user.screen_name": "Raymoz50"
    },
    {
        "created_at": "Sun Feb 11 23:13:18 +0000 2018",
        "id": 962826911159287808,
        "text": "RT @Chicago1Ray: \" You, me... we own this Country. Politicians are employees of ours. And when somebody doesn't do the Job, We gotta let 'e\u2026",
        "user.screen_name": "RLee50608689"
    },
    {
        "created_at": "Sun Feb 11 23:13:18 +0000 2018",
        "id": 962826910060355584,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "Reggievm"
    },
    {
        "created_at": "Sun Feb 11 23:13:18 +0000 2018",
        "id": 962826909603319808,
        "text": "@Clark408 @realDonaldTrump Better than it did under obama",
        "user.screen_name": "Davidalandavis3"
    },
    {
        "created_at": "Sun Feb 11 23:13:18 +0000 2018",
        "id": 962826909536067584,
        "text": "RT @HrrEerrer: Maybe Kelly didn\u2019t know because it didn\u2019t happen. How many times did obama say he found out when a scandal hit the press? Be\u2026",
        "user.screen_name": "Bob42746"
    },
    {
        "created_at": "Sun Feb 11 23:13:18 +0000 2018",
        "id": 962826909498437632,
        "text": "RT @DTrumpPoll: Do you think @realDonaldTrump was vicitmized by the Obama Administration, or were investigations in to ties with Russia jus\u2026",
        "user.screen_name": "Maniacus"
    },
    {
        "created_at": "Sun Feb 11 23:13:17 +0000 2018",
        "id": 962826906679894017,
        "text": "@realDonaldTrump Thanks Obama - thanks to Trump we can play now and pay later - back to roaring 20\u2019s",
        "user.screen_name": "jccalabrese"
    },
    {
        "created_at": "Sun Feb 11 23:13:17 +0000 2018",
        "id": 962826906650361857,
        "text": "RT @dailykos: Budget-busting deal shows that Barack Obama was much better at business than Trump https://t.co/N9OWwlHjwL",
        "user.screen_name": "9Gweedo"
    },
    {
        "created_at": "Sun Feb 11 23:13:17 +0000 2018",
        "id": 962826906524704769,
        "text": "RT @FiveRights: Laura Ingraham on Fox: Why did George W. Bush refuse to criticize Obama even when O screwed up badly but he often criticize\u2026",
        "user.screen_name": "kattywompas1"
    },
    {
        "created_at": "Sun Feb 11 23:13:17 +0000 2018",
        "id": 962826903882223616,
        "text": "RT @PatriotHole: Eerie: This Compilation Proves That A Lone Seagull Has Been Following Obama Everywhere For Years https://t.co/6kbWOv3BeI",
        "user.screen_name": "SquillyWonka"
    },
    {
        "created_at": "Sun Feb 11 23:13:16 +0000 2018",
        "id": 962826903412400128,
        "text": "@RepPeteKing @RandPaul You called out Obama as not being Presidential because he wore a tan suit yet I believe call\u2026 https://t.co/grVcyrJTfB",
        "user.screen_name": "vanithaj11"
    },
    {
        "created_at": "Sun Feb 11 23:13:16 +0000 2018",
        "id": 962826902770733058,
        "text": "@TeaPainUSA @realDonaldTrump @BarackObama PRESIDENT OBAMA WASNT ALWAYS RIGHT ABOUT EVERYTHING NO ONE EVER IS BUT TR\u2026 https://t.co/B3CsDJZp6T",
        "user.screen_name": "pootsie01"
    },
    {
        "created_at": "Sun Feb 11 23:13:16 +0000 2018",
        "id": 962826902217076736,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "Sean_Tillery23"
    },
    {
        "created_at": "Sun Feb 11 23:13:16 +0000 2018",
        "id": 962826902053453824,
        "text": "RT @GartrellLinda: American Public Opinion Finally Turns on Obama Admin Overwhelmingly\nJanuary Investors Daily Poll: 55% believe @POTUS ove\u2026",
        "user.screen_name": "mtaft48"
    },
    {
        "created_at": "Sun Feb 11 23:13:16 +0000 2018",
        "id": 962826901914923008,
        "text": "@Maycatyll1 @CaravellaBeth @SAAR1980 @fourtwentytoday @us_poll @hogwarts7777777 @TAKEURLANDBACK @EveTweets\u2026 https://t.co/nGVjhjPdWI",
        "user.screen_name": "cybervoyager"
    },
    {
        "created_at": "Sun Feb 11 23:13:16 +0000 2018",
        "id": 962826901889921024,
        "text": "RT @realDonaldTrump: \u201cMy view is that not only has Trump been vindicated in the last several weeks about the mishandling of the Dossier and\u2026",
        "user.screen_name": "JustinPell03"
    },
    {
        "created_at": "Sun Feb 11 23:13:16 +0000 2018",
        "id": 962826900836986880,
        "text": "RT @KNP2BP: @Thom_Thom9 #Feinstein is WRONG on every issue\n\nSides w/Palestine to make it appear Israel is the aggressor rather than victim\u2026",
        "user.screen_name": "RLPolk3"
    },
    {
        "created_at": "Sun Feb 11 23:13:16 +0000 2018",
        "id": 962826899918553089,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "RahamanMD"
    },
    {
        "created_at": "Sun Feb 11 23:13:15 +0000 2018",
        "id": 962826898492547077,
        "text": "RT @ElderLansing: I will never respect the Ex Resident Coward Obama! He was a horrible leader and had numerous scandals overlooked because\u2026",
        "user.screen_name": "wsaideh74"
    },
    {
        "created_at": "Sun Feb 11 23:13:14 +0000 2018",
        "id": 962826893312577539,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "micket123"
    },
    {
        "created_at": "Sun Feb 11 23:13:14 +0000 2018",
        "id": 962826892872159232,
        "text": "@Exile714 @2021_free @realDonaldTrump Obama &amp; dems tried to change it, Republicans stonewalled it, as they held congress!",
        "user.screen_name": "JLily10303"
    },
    {
        "created_at": "Sun Feb 11 23:13:14 +0000 2018",
        "id": 962826892238782465,
        "text": "Watching @Marcshort45 try to vaguely blame Obama for wife beater Rob Porter's clearance on Meet The Press is really something else",
        "user.screen_name": "Kip_PR"
    },
    {
        "created_at": "Sun Feb 11 23:13:13 +0000 2018",
        "id": 962826889579630592,
        "text": "RT @PamelaGeller: Obama provided Iran with stealth drone that penetrated Israel\u2019s border https://t.co/pQqaiwDeSN https://t.co/rJuFUggwZl",
        "user.screen_name": "williamgardanis"
    },
    {
        "created_at": "Sun Feb 11 23:13:13 +0000 2018",
        "id": 962826888749166595,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "pwykoff"
    },
    {
        "created_at": "Sun Feb 11 23:13:13 +0000 2018",
        "id": 962826888417865735,
        "text": "RT @mattmfm: Barack Obama was in the same room as Louis Farrakhan once and it caused a decades-long controversy. \n\nDonald Trump gave a shou\u2026",
        "user.screen_name": "CareBear_Kara"
    },
    {
        "created_at": "Sun Feb 11 23:13:13 +0000 2018",
        "id": 962826888094855168,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "moonbeam_0416"
    },
    {
        "created_at": "Sun Feb 11 23:13:12 +0000 2018",
        "id": 962826886345822208,
        "text": "RT @retireleo: Obama knew! Damning texts surface that name Barack Obama in corrupt exoneration of Hillary Clinton and her illegal email ser\u2026",
        "user.screen_name": "ARRESTBHO"
    },
    {
        "created_at": "Sun Feb 11 23:13:12 +0000 2018",
        "id": 962826885473370112,
        "text": "@foxandfriends @Nigel_Farage Soros is a socialist and communist. He and a couple his wealthy cronies tried to take\u2026 https://t.co/YlMGsysCJs",
        "user.screen_name": "john_jcedwards"
    },
    {
        "created_at": "Sun Feb 11 23:13:12 +0000 2018",
        "id": 962826884387082241,
        "text": "RT @PoliticalShort: When did Obama\u2019s CIA Director John Brennan begin his \u201cinvestigation\u201d of Trump? Brennan has some questions he needs to a\u2026",
        "user.screen_name": "josephbenning"
    },
    {
        "created_at": "Sun Feb 11 23:13:12 +0000 2018",
        "id": 962826883623673856,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "bigdaddycaddy2"
    },
    {
        "created_at": "Sun Feb 11 23:13:12 +0000 2018",
        "id": 962826883292266496,
        "text": "RT @TeaPainUSA: FUN FACTS:  DACA was established by the Obama Administration in June 2012 and RESCINDED by the Trump Administration in Sept\u2026",
        "user.screen_name": "Blackswan725"
    },
    {
        "created_at": "Sun Feb 11 23:13:12 +0000 2018",
        "id": 962826883141455877,
        "text": "RT @CraigRozniecki: \"Fox News host Jeanine Pirro blames Barack Obama for Rob Porter wife-beating scandal\" - https://t.co/lxGf4GPCmu",
        "user.screen_name": "ILoveBernie1"
    },
    {
        "created_at": "Sun Feb 11 23:13:11 +0000 2018",
        "id": 962826881228619777,
        "text": "RT @edgecrusher23: DEA Agent Notices $200,000,000 in Cars Being Shipped into South Africa by Obama Admin. as Drug Money flows to American B\u2026",
        "user.screen_name": "Justice41ca"
    },
    {
        "created_at": "Sun Feb 11 23:13:11 +0000 2018",
        "id": 962826881123962880,
        "text": "RT @ChristieC733: When is #Obama going to update his bio from President to to former or 44th president? \n\n#TrumpIsYourPresident \n#GetOverIt\u2026",
        "user.screen_name": "laearle"
    },
    {
        "created_at": "Sun Feb 11 23:13:11 +0000 2018",
        "id": 962826879874097153,
        "text": "RT @mattmfm: Barack Obama was in the same room as Louis Farrakhan once and it caused a decades-long controversy. \n\nDonald Trump gave a shou\u2026",
        "user.screen_name": "jlastivka"
    },
    {
        "created_at": "Sun Feb 11 23:13:11 +0000 2018",
        "id": 962826879836262406,
        "text": "@algonman77 @saderman @LarryCoppock1 @realDonaldTrump June 15, 2012 - President Obama Signs DACA to Allow Some Undo\u2026 https://t.co/g0sbxf9jD6",
        "user.screen_name": "SaintlyCitySue"
    },
    {
        "created_at": "Sun Feb 11 23:13:11 +0000 2018",
        "id": 962826879261691905,
        "text": "RT @sujkar: @DeeptiSathe @NancyPelosi @SenatorDurbin @NancyPelosi @chuckschumer @SenateDems Legal Tax Paying immigrants have supported Dems\u2026",
        "user.screen_name": "RashGC"
    },
    {
        "created_at": "Sun Feb 11 23:13:10 +0000 2018",
        "id": 962826878569668608,
        "text": "@SugarBearJohnW @thehill Mean spirited is what your brutal N. Korean friends did to an American student. Sorry no s\u2026 https://t.co/5Qns4fJ4ZX",
        "user.screen_name": "truthsquad123"
    },
    {
        "created_at": "Sun Feb 11 23:13:10 +0000 2018",
        "id": 962826878481416192,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "CDFREEIII"
    },
    {
        "created_at": "Sun Feb 11 23:13:10 +0000 2018",
        "id": 962826876518625280,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "earle_ella"
    },
    {
        "created_at": "Sun Feb 11 23:13:10 +0000 2018",
        "id": 962826876258365440,
        "text": "RT @jeffhauser: Donald Trump's hidden tax returns should have been a DEFINING ISSUE of 2017. \n\nInstead, Trump's tax returns discussed less\u2026",
        "user.screen_name": "kate_hawkins776"
    },
    {
        "created_at": "Sun Feb 11 23:13:10 +0000 2018",
        "id": 962826875591634946,
        "text": "@Keeu19 @qlc_1983 @mrscynthia88 @realDonaldTrump Will somebody tell me wtf has Trump done other than piggy back on\u2026 https://t.co/4XfNGGtVLi",
        "user.screen_name": "sine_nomine88"
    },
    {
        "created_at": "Sun Feb 11 23:13:10 +0000 2018",
        "id": 962826875532972032,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "jaquelinehogreb"
    },
    {
        "created_at": "Sun Feb 11 23:13:10 +0000 2018",
        "id": 962826875486818305,
        "text": "@ricardo_de_anda Melania Trump only follows 5 people Pres. Obama is one of them!",
        "user.screen_name": "kling_barbara"
    },
    {
        "created_at": "Sun Feb 11 23:13:10 +0000 2018",
        "id": 962826875109179392,
        "text": "Saddest eBay item of the day: Obama/Grateful Dead/Star Wars acid blotter paper. https://t.co/ZykCLdXZ1E https://t.co/qSUHeFn2js",
        "user.screen_name": "patrick_brice"
    },
    {
        "created_at": "Sun Feb 11 23:13:10 +0000 2018",
        "id": 962826874966675456,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "ImBlest247"
    },
    {
        "created_at": "Sun Feb 11 23:13:09 +0000 2018",
        "id": 962826873469308928,
        "text": "RT @C_3MAGA: We\u2019re witnessing a battle between GOOD &amp; EVIL for the survival of the USA.\n\nGOOD\nTrump\nRogers\nSessions\nWray\nNunes\nGrassley\nGoo\u2026",
        "user.screen_name": "gns1013"
    },
    {
        "created_at": "Sun Feb 11 23:13:09 +0000 2018",
        "id": 962826873431609344,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "Ludi2shoes"
    },
    {
        "created_at": "Sun Feb 11 23:13:09 +0000 2018",
        "id": 962826872039100417,
        "text": "@DavidTurley4 @tangncallie @RepAdamSchiff Grow up telling them how great Killary and Obama were and how awful Trump\u2026 https://t.co/H2gMbWoAT0",
        "user.screen_name": "Heraldthehedge"
    },
    {
        "created_at": "Sun Feb 11 23:13:09 +0000 2018",
        "id": 962826871426682880,
        "text": "RT @Bakari_Sellers: Fox News viewers believe its Obama\u2019s fault Rob Porter beat his wives. https://t.co/5y8wPzWLOu",
        "user.screen_name": "EhrenreichAlex"
    },
    {
        "created_at": "Sun Feb 11 23:13:08 +0000 2018",
        "id": 962826869707075585,
        "text": "RT cathibrgnr58: LoriJac47135906 SandraTXAS ClintonM614 LVNancy JVER1 Hoosiers1986 GrizzleMeister GaetaSusan baalte\u2026 https://t.co/E8wrrD3odp",
        "user.screen_name": "realityblow"
    },
    {
        "created_at": "Sun Feb 11 23:13:08 +0000 2018",
        "id": 962826868448813056,
        "text": "RT @RealJack: It\u2019s not looking good for the Democrats.\n\nPOLL: Majority of Americans Believe Obama SPIED on Trump Campaign https://t.co/dC30\u2026",
        "user.screen_name": "salinas_m123"
    },
    {
        "created_at": "Sun Feb 11 23:13:08 +0000 2018",
        "id": 962826867773407232,
        "text": "@kscdc @MAGAPILL @realDonaldTrump Thank you President Obama for keeping America safe, for getting us out of a reces\u2026 https://t.co/biV4JzKFVb",
        "user.screen_name": "Ailia88248158"
    },
    {
        "created_at": "Sun Feb 11 23:13:08 +0000 2018",
        "id": 962826866305437696,
        "text": "I hate who ever photoshopped an earring on obama lol https://t.co/7jZEIGbjDO",
        "user.screen_name": "axnxnxa_"
    },
    {
        "created_at": "Sun Feb 11 23:13:07 +0000 2018",
        "id": 962826865672060928,
        "text": "RT @jhershour: @realDonaldTrump And President Obama signed an executive order in 2012 to support DACA. You signed an executive order in 201\u2026",
        "user.screen_name": "WalkerWorlde"
    },
    {
        "created_at": "Sun Feb 11 23:13:07 +0000 2018",
        "id": 962826864011173888,
        "text": "I think that we are agreeing.\n\ud83e\udd14@jerp163 my personal belief is that Obama did more to hurt America and help foreign\u2026 https://t.co/SlX4a7m86u",
        "user.screen_name": "FortkampValerie"
    },
    {
        "created_at": "Sun Feb 11 23:13:07 +0000 2018",
        "id": 962826863520440322,
        "text": "RT @jefftiedrich: Kellyanne Conway, because when I need facts grounded in reality I turn to a woman who accused Barack Obama of spying on t\u2026",
        "user.screen_name": "c2015_rafael"
    },
    {
        "created_at": "Sun Feb 11 23:13:07 +0000 2018",
        "id": 962826863273037824,
        "text": "RT @joncoopertweets: Setting aside Donald Trump\u2019s minor scandals \u2014 such as Trump\u2019s conspiracy with Russia, obstruction of justice, politica\u2026",
        "user.screen_name": "NancyRo45542024"
    },
    {
        "created_at": "Sun Feb 11 23:13:07 +0000 2018",
        "id": 962826863222640641,
        "text": "RT @NewtTrump: Newt Gingrich: \"Let me just point out how sick the elite media is \u2014 they report all that as though it\u2019s something bad about\u2026",
        "user.screen_name": "NanaOxford"
    },
    {
        "created_at": "Sun Feb 11 23:13:06 +0000 2018",
        "id": 962826861800763392,
        "text": "RT @unscriptedmike: Ex-Obama State Official Jonathan Winer admits passing dossier to Kerry &amp; info from Sid Blumenthal to Steele.\n\nHe \u201cadmit\u2026",
        "user.screen_name": "FrankVespa1"
    },
    {
        "created_at": "Sun Feb 11 23:13:06 +0000 2018",
        "id": 962826860429266944,
        "text": "RT @GartrellLinda: Obama Official Johnathan Winer: I Passed Clinton Lies to Steele That Were Used Against Trump Now the #ObamaGate scandal\u2026",
        "user.screen_name": "LizzyBB10"
    },
    {
        "created_at": "Sun Feb 11 23:13:06 +0000 2018",
        "id": 962826859217010688,
        "text": "RT @mattmfm: Barack Obama was in the same room as Louis Farrakhan once and it caused a decades-long controversy. \n\nDonald Trump gave a shou\u2026",
        "user.screen_name": "ElianaT_CA"
    },
    {
        "created_at": "Sun Feb 11 23:13:06 +0000 2018",
        "id": 962826859191955456,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "NickiiBloom"
    },
    {
        "created_at": "Sun Feb 11 23:13:06 +0000 2018",
        "id": 962826857937887232,
        "text": "@cyanideann @BarackObama @POTUS Obama started the dam daca program illegally with his pen remember???",
        "user.screen_name": "RayWeinkauf"
    },
    {
        "created_at": "Sun Feb 11 23:13:05 +0000 2018",
        "id": 962826856046186496,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "NancyCatalano6"
    },
    {
        "created_at": "Sun Feb 11 23:13:05 +0000 2018",
        "id": 962826855932981248,
        "text": "RT @KrisParonto: We also didn\u2019t use the @FBI @CIA and @NSAGov to spy on @realDonaldTrump either.......isn\u2019t that what you said to Chris Wal\u2026",
        "user.screen_name": "Mayauk1219"
    },
    {
        "created_at": "Sun Feb 11 23:13:05 +0000 2018",
        "id": 962826855001726976,
        "text": "RT @ConservaMomUSA: It\u2019s undeniable that #Obama worked tirelessly 2weaken&amp; hobble America for 8 yrs with the expectation #CrookedHillary wo\u2026",
        "user.screen_name": "Chanel4646"
    },
    {
        "created_at": "Sun Feb 11 23:13:04 +0000 2018",
        "id": 962826853185654784,
        "text": "RT @FoxNews: .@TomFitton: \"[@realDonaldTrump] has been victimized by the Obama Administration.\" https://t.co/z3Vn9KY1M3",
        "user.screen_name": "auntiejul"
    },
    {
        "created_at": "Sun Feb 11 23:13:04 +0000 2018",
        "id": 962826849754730498,
        "text": "RT @Debradelai: @GenFlynn (25) She\u2019s got her head so far up Obama\u2019s arse they had to isert an oxygen tube.\n\nAnd\u2026",
        "user.screen_name": "Lrod49"
    },
    {
        "created_at": "Sun Feb 11 23:13:04 +0000 2018",
        "id": 962826849490493441,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "whetzel_sherri"
    },
    {
        "created_at": "Sun Feb 11 23:13:03 +0000 2018",
        "id": 962826848899141633,
        "text": "RT @tonyposnanski: Trump believes in due process except for...\n\n- Kenyan born Obama\n- Crooked Hillary\n- FBI\n- Anyone in the media who doesn\u2026",
        "user.screen_name": "DeanBrowncrayon"
    },
    {
        "created_at": "Sun Feb 11 23:13:03 +0000 2018",
        "id": 962826847607296002,
        "text": "RT @DonnaWR8: In addition to removing ALL pagan and demonic items from the Obama and Clinton years at the White House, Pastor Paul Begley s\u2026",
        "user.screen_name": "1gudGOD"
    },
    {
        "created_at": "Sun Feb 11 23:13:03 +0000 2018",
        "id": 962826846785155072,
        "text": "RT @Momof3gngrs: @HopeEstaAqui @Jthe4th Its even better when you show them that Obama actually volunteered in the humanitarian efforts post\u2026",
        "user.screen_name": "baldgotti"
    },
    {
        "created_at": "Sun Feb 11 23:13:03 +0000 2018",
        "id": 962826845162000384,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "jjmac59"
    },
    {
        "created_at": "Sun Feb 11 23:13:02 +0000 2018",
        "id": 962826844566269953,
        "text": "RT @KaniJJackson: This is just your daily reminder that Barack Obama did not have 1 scandal or allegation against him during his time in th\u2026",
        "user.screen_name": "chelseaboots"
    },
    {
        "created_at": "Sun Feb 11 23:13:02 +0000 2018",
        "id": 962826843861798912,
        "text": "@kwilli1046 Calling for DOJ AG Jeff Sessions to do his job. Convene a special counsel to investigate these\u2026 https://t.co/NR9XLcUwBO",
        "user.screen_name": "bienafe"
    },
    {
        "created_at": "Sun Feb 11 23:13:02 +0000 2018",
        "id": 962826842163089408,
        "text": "RT @MartyVizi: @sxdoc @KatTheHammer1 @realDonaldTrump Obama should be treated and charged as a terrorist!!! Because he is.",
        "user.screen_name": "Brendag38323989"
    },
    {
        "created_at": "Sun Feb 11 23:13:02 +0000 2018",
        "id": 962826842095759360,
        "text": "How AWESOME Would it be, if when all said &amp; done the proof is shown that Saint Obama, was in on the hole thing. J.C\u2026 https://t.co/F3S7kURVcz",
        "user.screen_name": "tjbpdb"
    },
    {
        "created_at": "Sun Feb 11 23:13:02 +0000 2018",
        "id": 962826841361977344,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "iluvamerica1208"
    },
    {
        "created_at": "Sun Feb 11 23:13:02 +0000 2018",
        "id": 962826840980127744,
        "text": "RT @johncusack: You wanna play ?  Answer-  look up Obama\u2019s war on constitution - interview I did - check out @FreedomofPress  I\u2019m on the bo\u2026",
        "user.screen_name": "lgwiesen1"
    },
    {
        "created_at": "Sun Feb 11 23:13:01 +0000 2018",
        "id": 962826839956905984,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "LianaMaria___"
    },
    {
        "created_at": "Sun Feb 11 23:13:01 +0000 2018",
        "id": 962826839378022400,
        "text": "RT @FiveRights: .@CNN\nTwo huge stories broke this wk:\n1. Strzok &amp; Page texts show Obama knew abt FBI's illegal spying on Trump &amp; did nothin\u2026",
        "user.screen_name": "jb19tele"
    },
    {
        "created_at": "Sun Feb 11 23:13:01 +0000 2018",
        "id": 962826838635560960,
        "text": "RT @RedWaveRising: #ObamaGate\n\n#SundayThoughts\n#BarackObama used classified intelligence leaks for political gain - https://t.co/tkba3Y498I\u2026",
        "user.screen_name": "Sputtter"
    },
    {
        "created_at": "Sun Feb 11 23:13:01 +0000 2018",
        "id": 962826838635499521,
        "text": "RT @hotfunkytown: Yet another example of failure by Obama.....\n\nDespite having weaponized every powerful agency to cripple the opposition,\u2026",
        "user.screen_name": "KenNg"
    },
    {
        "created_at": "Sun Feb 11 23:13:01 +0000 2018",
        "id": 962826837163421696,
        "text": "RT @CHIZMAGA: So if Donald Trump interacts with James Comey on an FBI Investigation it\u2019s \u201cObstructing Justice\u201d, but when Barack Obama inter\u2026",
        "user.screen_name": "Matarr1776"
    },
    {
        "created_at": "Sun Feb 11 23:13:00 +0000 2018",
        "id": 962826835678715904,
        "text": "RT @oxminaox: Snapchat didn\u2019t suck while Obama was in office... just saying",
        "user.screen_name": "Alexsofiag"
    },
    {
        "created_at": "Sun Feb 11 23:13:00 +0000 2018",
        "id": 962826835175276544,
        "text": "RT @johncusack: You wanna play ?  Answer-  look up Obama\u2019s war on constitution - interview I did - check out @FreedomofPress  I\u2019m on the bo\u2026",
        "user.screen_name": "Painless_Dave"
    },
    {
        "created_at": "Sun Feb 11 23:13:00 +0000 2018",
        "id": 962826834126651392,
        "text": "RT @BettyBowers: TRUMP LIE: Democrats didn't fix #DACA from 2008-2011. \n\nINCONVENIENT FACT: DACA didn't exist until 2012.\n\nTRUMP LIE: Repub\u2026",
        "user.screen_name": "karolynnnnnn12"
    },
    {
        "created_at": "Sun Feb 11 23:13:00 +0000 2018",
        "id": 962826833480900608,
        "text": "RT @EdKrassen: If Jeanine Pirro can blame Barack Obama for Rob Porter beating his wives, then I blame Jeanine Pirro for Donald Trump assaul\u2026",
        "user.screen_name": "divineem"
    },
    {
        "created_at": "Sun Feb 11 23:13:00 +0000 2018",
        "id": 962826833111715840,
        "text": "RT @anne_boydston: @romeo49435 @JacquieLeyns @Brasilmagic Well, this white person can\u2019t stand trump and I voted for President Obama both ti\u2026",
        "user.screen_name": "booatticus63"
    },
    {
        "created_at": "Sun Feb 11 23:13:00 +0000 2018",
        "id": 962826832889425920,
        "text": "RT @RyanAFournier: Do you believe the Obama Administration improperly and illegally surveilled the Trump Campaign? #SHARE",
        "user.screen_name": "JessicaLyn55"
    },
    {
        "created_at": "Sun Feb 11 23:13:00 +0000 2018",
        "id": 962826832709009409,
        "text": "RT @mattmfm: Barack Obama was in the same room as Louis Farrakhan once and it caused a decades-long controversy. \n\nDonald Trump gave a shou\u2026",
        "user.screen_name": "keeponkeepngon"
    },
    {
        "created_at": "Sun Feb 11 23:13:00 +0000 2018",
        "id": 962826832625176576,
        "text": "@braun_fay52 @CoreyLMJones @realDonaldTrump @WestervillePD We the people have call or write our Congressmen in our\u2026 https://t.co/t7QMxZGb70",
        "user.screen_name": "arfed88"
    },
    {
        "created_at": "Sun Feb 11 23:12:59 +0000 2018",
        "id": 962826831987691520,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "curiocat13"
    },
    {
        "created_at": "Sun Feb 11 23:12:59 +0000 2018",
        "id": 962826831547256832,
        "text": "@NancyKellyMart1 Hell was 8 years of Obama",
        "user.screen_name": "RRaymond_FL"
    },
    {
        "created_at": "Sun Feb 11 23:12:59 +0000 2018",
        "id": 962826831354216448,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "PamNeufeld"
    },
    {
        "created_at": "Sun Feb 11 23:12:59 +0000 2018",
        "id": 962826828414177280,
        "text": "RT @HrrEerrer: Does @realDonaldTrump hafta spend money where congress says?Obama didn\u2019t!Almost NO stimulus went2shovel ready jobs https://t\u2026",
        "user.screen_name": "SiddonsDan"
    },
    {
        "created_at": "Sun Feb 11 23:12:58 +0000 2018",
        "id": 962826827843751936,
        "text": "RT @algonzalezlu393: trump is promoting a conservative argument that he's been \"victimized\" by the Obama administration. https://t.co/iR07Z\u2026",
        "user.screen_name": "pamelakissinger"
    },
    {
        "created_at": "Sun Feb 11 23:12:58 +0000 2018",
        "id": 962826827826974720,
        "text": "RT @RedWaveRising: #ObamaGate\n\n#SundayThoughts\n#BarackObama used classified intelligence leaks for political gain - https://t.co/tkba3Y498I\u2026",
        "user.screen_name": "DonDonsmith007"
    },
    {
        "created_at": "Sun Feb 11 23:12:58 +0000 2018",
        "id": 962826826925174784,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "hammerman0206"
    },
    {
        "created_at": "Sun Feb 11 23:12:58 +0000 2018",
        "id": 962826826761539584,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "shotgunss52"
    },
    {
        "created_at": "Sun Feb 11 23:12:58 +0000 2018",
        "id": 962826826639904768,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "gftzer"
    },
    {
        "created_at": "Sun Feb 11 23:12:58 +0000 2018",
        "id": 962826826069495810,
        "text": "RT @joncoopertweets: Sure, @realDonaldTrump is a lying, corrupt, racist, traitorous imbecile who defends white supremacists, Nazis, wife be\u2026",
        "user.screen_name": "ILoveBernie1"
    },
    {
        "created_at": "Sun Feb 11 23:12:58 +0000 2018",
        "id": 962826824592928768,
        "text": "@ThomasMHern @RyanAFournier Obama, Democrats and the MSM were ALL instrumental in pushing the hate and Obama's invi\u2026 https://t.co/rbMeioEL1d",
        "user.screen_name": "ClaraWeim"
    },
    {
        "created_at": "Sun Feb 11 23:12:57 +0000 2018",
        "id": 962826823708024832,
        "text": "RT @jobahout: \u201cIn order to address a terrifying but hypothetical danger -an Iranian nuke- the Obama administration\u2019s foreign policy accepte\u2026",
        "user.screen_name": "AMR11082016"
    },
    {
        "created_at": "Sun Feb 11 23:12:57 +0000 2018",
        "id": 962826823259250690,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "Taffi801"
    },
    {
        "created_at": "Sun Feb 11 23:12:57 +0000 2018",
        "id": 962826821288022016,
        "text": "RT @JudicialWatch: Reminder: JW found evidence showing Obama State Dept under John Kerry sent its own \"dossier\" of classified info on Russi\u2026",
        "user.screen_name": "WildHogs6"
    },
    {
        "created_at": "Sun Feb 11 23:12:57 +0000 2018",
        "id": 962826821082365952,
        "text": "RT @1GodlessWoman: We see your identity politics @JustinTrudeau first with Muslims #HijabHoax that backfired &amp; now the natives. This too is\u2026",
        "user.screen_name": "snappy_peas"
    },
    {
        "created_at": "Sun Feb 11 23:12:56 +0000 2018",
        "id": 962826819476041729,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "rdehler16"
    },
    {
        "created_at": "Sun Feb 11 23:12:56 +0000 2018",
        "id": 962826817810976768,
        "text": "RT @RedWaveRising: #ObamaGate\n\n#SundayThoughts\n#BarackObama used classified intelligence leaks for political gain - https://t.co/tkba3Y498I\u2026",
        "user.screen_name": "raymondlipford"
    },
    {
        "created_at": "Sun Feb 11 23:12:56 +0000 2018",
        "id": 962826817307541504,
        "text": "RT @DearAuntCrabby: Trump promotes argument that he's been 'victimized' by Obama administration https://t.co/NY5a0e77YZ \n\nOh brother, what\u2026",
        "user.screen_name": "SheriBmuddy"
    },
    {
        "created_at": "Sun Feb 11 23:12:56 +0000 2018",
        "id": 962826816900628480,
        "text": "RT @RogueNASA: Trump believes Porter may be innocent even though he saw the picture of his ex-wife\u2019s black eye.\n\nTrump still believes Obama\u2026",
        "user.screen_name": "dapetrick"
    },
    {
        "created_at": "Sun Feb 11 23:12:56 +0000 2018",
        "id": 962826816728772608,
        "text": "RT @FiveRights: Laura Ingraham on Fox: Why did George W. Bush refuse to criticize Obama even when O screwed up badly but he often criticize\u2026",
        "user.screen_name": "BjLloyd3"
    },
    {
        "created_at": "Sun Feb 11 23:12:55 +0000 2018",
        "id": 962826815600390144,
        "text": "RT @soledadobrien: 'Sabato said he was \"absolutely\" sure President Obama was a Muslim and not a Christian. ' https://t.co/yAVnhP3JI6",
        "user.screen_name": "ronbeckner"
    },
    {
        "created_at": "Sun Feb 11 23:12:55 +0000 2018",
        "id": 962826815197687808,
        "text": "@JohnFromCranber Then Bush and Obama are both traitors!",
        "user.screen_name": "Lynny222"
    },
    {
        "created_at": "Sun Feb 11 23:12:55 +0000 2018",
        "id": 962826812895178754,
        "text": "RT @RedWaveRising: #ObamaGate\n\n#SundayThoughts\n#BarackObama used classified intelligence leaks for political gain - https://t.co/tkba3Y498I\u2026",
        "user.screen_name": "specialK1947"
    },
    {
        "created_at": "Sun Feb 11 23:12:55 +0000 2018",
        "id": 962826812299628545,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "BobbieH95713641"
    },
    {
        "created_at": "Sun Feb 11 23:12:55 +0000 2018",
        "id": 962826812261851136,
        "text": "@robreiner Fox News is not state run.  If you are referring to being favorable to Trump, that is not all of Fox New\u2026 https://t.co/Rby7F1g4dF",
        "user.screen_name": "LinkMEP"
    },
    {
        "created_at": "Sun Feb 11 23:12:54 +0000 2018",
        "id": 962826811460800512,
        "text": "RT @SebGorka: The UNMASKING Scandal will prove to be much bigger than FISAGate or Watergate combined. \n\nTime to just call it what it is:\u2026",
        "user.screen_name": "KateReilly111"
    },
    {
        "created_at": "Sun Feb 11 23:12:54 +0000 2018",
        "id": 962826811448217600,
        "text": "@vnuek BS story !! If Kelly's staff said that then they got paid and/or are Obama left overs! But I'm calling BS! D\u2026 https://t.co/h8Wa8kvBMN",
        "user.screen_name": "moreenie31"
    },
    {
        "created_at": "Sun Feb 11 23:12:54 +0000 2018",
        "id": 962826808675545089,
        "text": "RT @RealJack: The whole system is going to come crashing down...\n\nFamous Trump Prophet Just Said It:  \"Obama Is Going To Jail\" https://t.co\u2026",
        "user.screen_name": "DECMarkWalker"
    },
    {
        "created_at": "Sun Feb 11 23:12:53 +0000 2018",
        "id": 962826804133335040,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "Jasongoofygrape"
    },
    {
        "created_at": "Sun Feb 11 23:12:52 +0000 2018",
        "id": 962826802514182144,
        "text": "RT @evangesolc: @KimStrassel The biggest scandal is the MSM\u2019s effort  to  cover up the Obama administration\u2019s corruption - proving  without\u2026",
        "user.screen_name": "EricSteeleLive"
    },
    {
        "created_at": "Sun Feb 11 23:12:52 +0000 2018",
        "id": 962826802203975680,
        "text": "RT @TuckerCarlson: Here's what is clear right now, the bottom line on what we've learned this week and the one thing worth remembering: The\u2026",
        "user.screen_name": "sharonocasey"
    },
    {
        "created_at": "Sun Feb 11 23:12:52 +0000 2018",
        "id": 962826801667018752,
        "text": "RT @Fuctupmind: Pretty much everyone knew about the Steele Dossier.\n\nThe entire Obama admin.\nSid Blumenthal.\nHillary Clinton.\nLoretta Lynch\u2026",
        "user.screen_name": "Tarkan291"
    },
    {
        "created_at": "Sun Feb 11 23:12:52 +0000 2018",
        "id": 962826800601747456,
        "text": "RT @DineshDSouza: It seems the FBI during Obama\u2019s tenure acted like the Democratic Party\u2019s private protection agency &amp; police force",
        "user.screen_name": "dmassad12"
    },
    {
        "created_at": "Sun Feb 11 23:12:52 +0000 2018",
        "id": 962826799523577857,
        "text": "RT @MOVEFORWARDHUGE: YOU SNOWFLAKES THINK YOU HAD A BAD DAY YESTERDAY,\n\nWAIT TILL I TELL YOU WHAT OBAMA, HILLARY AND THE CABAL REALLY DID T\u2026",
        "user.screen_name": "rebrokerjoe"
    },
    {
        "created_at": "Sun Feb 11 23:12:52 +0000 2018",
        "id": 962826799427260416,
        "text": "@ZPoet That was Obama\u2019s Admin",
        "user.screen_name": "19Patriot59"
    },
    {
        "created_at": "Sun Feb 11 23:12:52 +0000 2018",
        "id": 962826799204978688,
        "text": "RT @jefftiedrich: Kellyanne Conway, because when I need facts grounded in reality I turn to a woman who accused Barack Obama of spying on t\u2026",
        "user.screen_name": "windmillcharger"
    },
    {
        "created_at": "Sun Feb 11 23:12:51 +0000 2018",
        "id": 962826798923993090,
        "text": "RT @Jthe4th: @NatashaBertrand This reminds me of all the pro-Trumpers criticizing Obama\u2019s Katrina response after Trump Admin\u2019s failures in\u2026",
        "user.screen_name": "baldgotti"
    },
    {
        "created_at": "Sun Feb 11 23:12:51 +0000 2018",
        "id": 962826798869266433,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "TweetTweetHAR"
    },
    {
        "created_at": "Sun Feb 11 23:12:51 +0000 2018",
        "id": 962826795979624448,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "ChadAnimeTweets"
    },
    {
        "created_at": "Sun Feb 11 23:12:51 +0000 2018",
        "id": 962826795690135554,
        "text": "RT @ziki0001: A bad #website can destroy your whole business. #Obama learned it the hard way.   https://t.co/XmSYLIewoW #18f #internet #bus\u2026",
        "user.screen_name": "LJT_is_me"
    },
    {
        "created_at": "Sun Feb 11 23:12:50 +0000 2018",
        "id": 962826793768992769,
        "text": "RT @WilDonnelly: 1. The White House, the Senate and the House are not the three branches of government.\n\n2. Obama wasn't president in 2008.\u2026",
        "user.screen_name": "WhiteLotus3_9"
    },
    {
        "created_at": "Sun Feb 11 23:12:50 +0000 2018",
        "id": 962826793521700865,
        "text": "RT @brianklaas: You falsely alleged that Ted Cruz\u2019s Dad plotted to kill JFK and that Obama was born in Kenya and later wiretapped you. Thos\u2026",
        "user.screen_name": "momma_carp"
    },
    {
        "created_at": "Sun Feb 11 23:12:50 +0000 2018",
        "id": 962826792070537216,
        "text": "RT @chuckwoolery: Who started the rumor that #Obama was from #Kenya? Was it #Trump? Nope it was #SidBlumenthal. Yes he worked for Hillary.\u2026",
        "user.screen_name": "luxtualuceat"
    },
    {
        "created_at": "Sun Feb 11 23:12:49 +0000 2018",
        "id": 962826789843120135,
        "text": "RT @TeaPainUSA: President Obama was everything @realDonaldTrump will never be.  Honorable. Dignified. Compassionate.  A level headed leader\u2026",
        "user.screen_name": "AngelVa13497878"
    },
    {
        "created_at": "Sun Feb 11 23:12:49 +0000 2018",
        "id": 962826789272899584,
        "text": "RT @johncusack: You wanna play ?  Answer-  look up Obama\u2019s war on constitution - interview I did - check out @FreedomofPress  I\u2019m on the bo\u2026",
        "user.screen_name": "V_4_Vendetta27"
    },
    {
        "created_at": "Sun Feb 11 23:12:49 +0000 2018",
        "id": 962826788534734848,
        "text": "The Truth will out, eventually...\n\nNo suprise that Obama, who Lives in DC, has been keeping a low profile lately...\u2026 https://t.co/RAkNJE8eUv",
        "user.screen_name": "thestationchief"
    },
    {
        "created_at": "Sun Feb 11 23:12:49 +0000 2018",
        "id": 962826788291440645,
        "text": "RT @qz: Hip-hop painter Kehinde Wiley\u2019s portrait of Barack Obama will be unveiled tomorrow https://t.co/8wCPxkTX78",
        "user.screen_name": "_bredda_"
    },
    {
        "created_at": "Sun Feb 11 23:12:49 +0000 2018",
        "id": 962826787792347141,
        "text": "RT @PoliticalShort: Obama-Backed, Holder-Led Group Raised More Than $11 Million in 2017; Will Target Republicans in 12 states https://t.co/\u2026",
        "user.screen_name": "cubbiebear07"
    },
    {
        "created_at": "Sun Feb 11 23:12:48 +0000 2018",
        "id": 962826784696946693,
        "text": "RT @TomFitton: .@JudicialWatch lawsuit uncovered ANOTHER Russia Dossier used to undermine @RealDonaldTrump--this one created by Obama State\u2026",
        "user.screen_name": "jared96540410"
    },
    {
        "created_at": "Sun Feb 11 23:12:48 +0000 2018",
        "id": 962826782264217600,
        "text": "RT @kylegriffin1: A comparison of the S&amp;P 500 under Obama and Trump during the same period in their presidencies shows better performance u\u2026",
        "user.screen_name": "DerekBritain"
    },
    {
        "created_at": "Sun Feb 11 23:12:47 +0000 2018",
        "id": 962826781555240960,
        "text": "RT @ElderLansing: I will never respect the Ex Resident Coward Obama! He was a horrible leader and had numerous scandals overlooked because\u2026",
        "user.screen_name": "andrea77214732"
    },
    {
        "created_at": "Sun Feb 11 23:12:47 +0000 2018",
        "id": 962826780418756608,
        "text": "Can't wait for the Obama bootlicker @BobbyScott to try and explain how getting more money is a bad thing to his con\u2026 https://t.co/PMiaEGUvkn",
        "user.screen_name": "leroyritter86"
    },
    {
        "created_at": "Sun Feb 11 23:12:47 +0000 2018",
        "id": 962826780410294274,
        "text": "RT @KrisParonto: We also didn\u2019t use the @FBI @CIA and @NSAGov to spy on @realDonaldTrump either.......isn\u2019t that what you said to Chris Wal\u2026",
        "user.screen_name": "lackerman009"
    }
]